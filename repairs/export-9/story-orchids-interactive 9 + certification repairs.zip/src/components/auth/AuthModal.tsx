import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Flourish } from '@/components/site/Ornaments';

const AuthModal: React.FC = () => {
  const { authOpen, closeAuth, signIn, signUp, user } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [asEditor, setAsEditor] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeAuth();
    };
    if (authOpen) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [authOpen, closeAuth]);

  useEffect(() => {
    if (!authOpen) {
      setError('');
      setNotice('');
      setBusy(false);
    }
  }, [authOpen]);

  if (!authOpen) return null;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setNotice('');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Passwords must be at least six characters.');
      return;
    }
    setBusy(true);
    const result =
      mode === 'signin'
        ? await signIn(email, password)
        : await signUp(email, password, displayName, asEditor);
    setBusy(false);

    if (result.error) {
      setError(result.error);
      return;
    }
    if ('message' in result && result.message) {
      setNotice(String(result.message));
      setMode('signin');
      return;
    }
    closeAuth();
    navigate('/admin');
  };

  return (
    <div
      className="no-print fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 sm:items-center"
      role="dialog"
      aria-modal="true"
      aria-label="Editor sign in"
    >
      <button
        type="button"
        aria-label="Close sign in"
        onClick={closeAuth}
        className="absolute inset-0 bg-[hsl(var(--charcoal))]/55 backdrop-blur-[2px]"
      />
      <div className="relative my-8 w-full max-w-md rounded-sm border border-border bg-[hsl(var(--cream))] shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-border/70 px-6 py-5">
          <div>
            <p className="font-label text-[0.58rem] uppercase text-[hsl(var(--moss))]">Five Cities Orchid Society</p>
            <h2 className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">
              {mode === 'signin' ? 'Editor sign in' : 'Create an editor account'}
            </h2>
          </div>
          <button
            type="button"
            onClick={closeAuth}
            aria-label="Close"
            className="rounded-sm border border-border p-1.5 text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <div className="px-6 py-6">
          {user ? (
            <p className="text-sm text-[hsl(var(--ink))]">You are already signed in.</p>
          ) : (
            <>
              <div className="mb-5 grid grid-cols-2 gap-2">
                {(['signin', 'signup'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`rounded-sm border px-3 py-2 font-label text-[0.58rem] uppercase transition-colors ${
                      mode === m
                        ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                        : 'border-border text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8'
                    }`}
                  >
                    {m === 'signin' ? 'Sign in' : 'Sign up'}
                  </button>
                ))}
              </div>

              <form onSubmit={submit} className="space-y-3">
                {mode === 'signup' && (
                  <label className="block">
                    <span className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Display name</span>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Edith Bramble"
                      className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2 text-sm outline-none focus:border-[hsl(var(--botanical))]"
                    />
                  </label>
                )}
                <label className="block">
                  <span className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Email</span>
                  <input
                    type="email"
                    required
                    autoComplete="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2 text-sm outline-none focus:border-[hsl(var(--botanical))]"
                  />
                </label>
                <label className="block">
                  <span className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Password</span>
                  <input
                    type="password"
                    required
                    autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2 text-sm outline-none focus:border-[hsl(var(--botanical))]"
                  />
                </label>

                {mode === 'signup' && (
                  <label className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
                    <input
                      type="checkbox"
                      checked={asEditor}
                      onChange={(e) => setAsEditor(e.target.checked)}
                      className="mt-0.5 h-4 w-4 rounded-sm border-border accent-[hsl(var(--botanical))]"
                    />
                    <span>
                      I am a Society editor and need access to the content workspace. Editor access can be changed later
                      from your account panel.
                    </span>
                  </label>
                )}

                {error && (
                  <p role="alert" className="text-sm text-[hsl(var(--burgundy))]">
                    {error}
                  </p>
                )}
                {notice && (
                  <p role="status" className="text-sm text-[hsl(var(--botanical))]">
                    {notice}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={busy}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-5 py-3 font-label text-[0.62rem] uppercase text-[hsl(var(--cream))] transition-colors hover:bg-[hsl(var(--moss))] disabled:opacity-60"
                >
                  {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />}
                  {mode === 'signin' ? 'Sign in' : 'Create account'}
                </button>
              </form>
            </>
          )}

          <Flourish className="mt-6 opacity-60" />
          <p className="mt-4 text-center text-xs leading-relaxed text-muted-foreground">
            Reading the Chronicles never requires an account. Sign-in exists only so Society editors can manage content
            without touching the repository.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
