/* ------------------------------------------------------------------
   Chronicle I soundscape — entirely synthesised in the browser with the
   Web Audio API. No recordings, no commercial music: every sound is
   generated here (original, royalty-free by construction).
   Only ever started from a user gesture. Default is OFF.
------------------------------------------------------------------- */

export type Mood =
  | 'night'
  | 'edith'
  | 'outside'
  | 'curse'
  | 'morning'
  | 'silence'
  | 'engulf'
  | 'aftermath'
  | 'fcos'
  | 'charm'
  | 'hazel'
  | 'ending';

export type Cue = 'drop' | 'croak' | 'tap' | 'edith' | 'whisper' | 'shears' | 'whoomph' | 'rumble' | 'hush' | 'creak';

export const MOOD_CAPTIONS: Record<Mood, string> = {
  night: 'Distant Pacific surf. Soft coastal wind against glass.',
  edith: 'Water drops from a watering can. A slow, warm piano figure. Somewhere, a tree frog.',
  outside: 'The fan hum slows. The frog stops. A thin glass harmonic.',
  curse: 'A low cello interval, not quite resolved. Water gathering on glass.',
  morning: 'Grey morning stillness. A single drip, now and then.',
  silence: 'Near silence.',
  engulf: 'A dry, faint whisper. The fan drags and muffles. A low pressure rumble. Metal strikes stone. Sound pulls inward to silence — then one deep, soft whump.',
  aftermath: 'Near silence. A faint creak of the greenhouse frame. Far off, surf; a fan slowly returns.',
  fcos: 'Daylight. The fan hums again. A brighter chord.',
  charm: 'Warmth returns. Fans steady. Water drops fall normally.',
  hazel: 'The wind drops away. A bowed-glass tone. A single tap on a pane.',
  ending: 'Soft surf. A gentle, open chord settling.',
};

type Layer = { gain: GainNode };

const NOTE = (n: string) => {
  const map: Record<string, number> = { C: -9, D: -7, E: -5, F: -4, G: -2, A: 0, B: 2 };
  const m = /^([A-G])(#|b)?(\d)$/.exec(n);
  if (!m) return 440;
  const semi = map[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + (Number(m[3]) - 4) * 12;
  return 440 * Math.pow(2, semi / 12);
};

export class Soundscape {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private layers: Record<string, Layer> = {};
  private fan!: OscillatorNode;
  private timers: number[] = [];
  private mood: Mood = 'night';
  private muted = true;

  get running() {
    return !!this.ctx && !this.muted;
  }

  private noiseBuffer(ctx: AudioContext, brown: boolean) {
    const len = ctx.sampleRate * 4;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (brown) {
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.5;
      } else d[i] = w;
    }
    return buf;
  }

  private makeLayer(name: string): GainNode {
    const g = this.ctx!.createGain();
    g.gain.value = 0;
    g.connect(this.master);
    this.layers[name] = { gain: g };
    return g;
  }

  private build() {
    const ctx = this.ctx!;
    this.master = ctx.createGain();
    this.master.gain.value = 0;
    this.master.connect(ctx.destination);

    // Surf: brown noise, low-passed, swelling slowly like waves.
    const surf = ctx.createBufferSource();
    surf.buffer = this.noiseBuffer(ctx, true);
    surf.loop = true;
    const surfLp = ctx.createBiquadFilter();
    surfLp.type = 'lowpass';
    surfLp.frequency.value = 420;
    const swell = ctx.createGain();
    swell.gain.value = 0.6;
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.07;
    const lfoAmt = ctx.createGain();
    lfoAmt.gain.value = 0.4;
    lfo.connect(lfoAmt).connect(swell.gain);
    surf.connect(surfLp).connect(swell).connect(this.makeLayer('surf'));
    surf.start();
    lfo.start();

    // Wind: band-passed white noise with a wandering centre frequency.
    const wind = ctx.createBufferSource();
    wind.buffer = this.noiseBuffer(ctx, false);
    wind.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 600;
    bp.Q.value = 0.8;
    const wLfo = ctx.createOscillator();
    wLfo.frequency.value = 0.05;
    const wAmt = ctx.createGain();
    wAmt.gain.value = 260;
    wLfo.connect(wAmt).connect(bp.frequency);
    wind.connect(bp).connect(this.makeLayer('wind'));
    wind.start();
    wLfo.start();

    // Fan hum.
    this.fan = ctx.createOscillator();
    this.fan.type = 'sine';
    this.fan.frequency.value = 58;
    const fanLp = ctx.createBiquadFilter();
    fanLp.type = 'lowpass';
    fanLp.frequency.value = 200;
    this.fan.connect(fanLp).connect(this.makeLayer('fan'));
    this.fan.start();

    // Drone pad (greenhouse): two soft sines a fifth apart.
    const pad = this.makeLayer('pad');
    ['D2', 'A2'].forEach((n) => {
      const o = ctx.createOscillator();
      o.frequency.value = NOTE(n);
      o.connect(pad);
      o.start();
    });

    // Hazel: a low minor-second "cello" interval + a high glass harmonic with tremolo.
    const hz = this.makeLayer('hazel');
    ['D2', 'Eb2'].forEach((n) => {
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = NOTE(n);
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 380;
      o.connect(lp).connect(hz);
      o.start();
    });
    const glass = ctx.createOscillator();
    glass.frequency.value = 1760;
    const trem = ctx.createGain();
    trem.gain.value = 0.05;
    const tLfo = ctx.createOscillator();
    tLfo.frequency.value = 5.5;
    const tAmt = ctx.createGain();
    tAmt.gain.value = 0.04;
    tLfo.connect(tAmt).connect(trem.gain);
    glass.connect(trem).connect(hz);
    glass.start();
    tLfo.start();

    // FCOS: a brighter open chord.
    const fc = this.makeLayer('fcos');
    ['G3', 'D4', 'B4'].forEach((n) => {
      const o = ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = NOTE(n);
      o.connect(fc);
      o.start();
    });

    this.schedule();
  }

  /* ---------- one-shot voices ---------- */

  private blip(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', drop = 0.5) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(40, freq * drop), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private pianoNote(n: string, when: number, vol = 0.05) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + when;
    [1, 2].forEach((h, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = i ? 'sine' : 'triangle';
      o.frequency.value = NOTE(n) * h;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(vol / (h * 1.5), t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 3.2);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 3.4);
    });
  }

  /** Short burst of filtered noise (air, dust, pressure). */
  private noiseBurst(dur: number, vol: number, type: BiquadFilterType, freq: number, freqEnd?: number) {
    if (!this.ctx) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer(ctx, false);
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.4, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + dur + 0.05);
  }

  cue(name: Cue) {
    if (!this.running) return;
    if (name === 'drop') this.blip(1300, 0.09, 0.08, 'sine', 0.45);
    if (name === 'tap') this.blip(2600, 0.05, 0.05, 'triangle', 0.9);
    if (name === 'croak') {
      [0, 0.22].forEach((d) => window.setTimeout(() => this.blip(190, 0.16, 0.06, 'square', 0.7), d * 1000));
    }
    if (name === 'edith') ['D4', 'F#4', 'A4', 'E5'].forEach((n, i) => this.pianoNote(n, i * 0.7));
    // Dry, almost imperceptible whisper of particles / leaves stirring.
    if (name === 'whisper') this.noiseBurst(2.2, 0.018, 'highpass', 3800);
    // Pruning shears striking a flagstone: a few inharmonic metallic partials.
    if (name === 'shears') {
      [2150, 3310, 4870, 6420].forEach((f, i) => this.blip(f, 0.55 - i * 0.08, 0.05 - i * 0.008, 'sine', 0.97));
      window.setTimeout(() => [2400, 3900].forEach((f) => this.blip(f, 0.25, 0.02, 'sine', 0.97)), 140);
    }
    // Low pressure-like rumble as the cloud closes over Edith.
    if (name === 'rumble') {
      this.blip(48, 3.2, 0.09, 'sine', 0.8);
      this.noiseBurst(3.4, 0.05, 'lowpass', 140, 70);
    }
    // The implosion: everything is sucked inward, then almost silent.
    if (name === 'hush' && this.ctx) {
      const t = this.ctx.currentTime;
      this.noiseBurst(0.55, 0.035, 'bandpass', 260, 2400);
      this.master.gain.cancelScheduledValues(t);
      this.master.gain.setTargetAtTime(0.05, t + 0.2, 0.12);
      // safety: never leave the soundscape ducked if the release doesn't follow (e.g. the reader scrolls back)
      this.master.gain.setTargetAtTime(0.55, t + 1.6, 0.4);
    }
    // One deep, soft WHUMP as the cloud releases (restores the master level first).
    if (name === 'whoomph' && this.ctx) {
      const t = this.ctx.currentTime;
      this.master.gain.cancelScheduledValues(t);
      this.master.gain.setValueAtTime(0.55, t);
      this.blip(95, 0.9, 0.22, 'sine', 0.32);
      this.noiseBurst(1.1, 0.12, 'lowpass', 520, 60);
    }
    // A faint timber creak of the greenhouse frame, in the silence afterwards.
    if (name === 'creak' && this.ctx) {
      const ctx = this.ctx;
      const t = ctx.currentTime;
      const o = ctx.createOscillator();
      const f = ctx.createBiquadFilter();
      const g = ctx.createGain();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(92, t);
      o.frequency.linearRampToValueAtTime(118, t + 0.5);
      o.frequency.linearRampToValueAtTime(84, t + 1.1);
      f.type = 'bandpass';
      f.frequency.value = 700;
      f.Q.value = 6;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.018, t + 0.15);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.2);
      o.connect(f).connect(g).connect(this.master);
      o.start(t);
      o.stop(t + 1.3);
    }
  }

  private schedule() {
    const loop = (fn: () => void, min: number, max: number) => {
      const tick = () => {
        fn();
        this.timers.push(window.setTimeout(tick, (min + Math.random() * (max - min)) * 1000));
      };
      this.timers.push(window.setTimeout(tick, min * 1000));
    };
    loop(() => ['night', 'edith', 'morning', 'charm', 'fcos'].includes(this.mood) && this.cue('drop'), 3, 9);
    loop(() => ['night', 'edith', 'charm', 'ending'].includes(this.mood) && this.cue('croak'), 18, 40);
    loop(() => this.mood === 'edith' && this.cue('edith'), 6, 26);
    loop(() => (this.mood === 'hazel' || this.mood === 'outside') && Math.random() < 0.35 && this.cue('tap'), 9, 22);
  }

  /* ---------- public ---------- */

  async start() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.build();
    }
    await this.ctx.resume();
    this.muted = false;
    this.master.gain.cancelScheduledValues(this.ctx.currentTime);
    this.master.gain.setTargetAtTime(0.55, this.ctx.currentTime, 0.8);
    this.setMood(this.mood, true);
  }

  mute() {
    this.muted = true;
    if (!this.ctx) return;
    // Immediate (≈50 ms) fade so muting feels instant, then suspend.
    this.master.gain.cancelScheduledValues(this.ctx.currentTime);
    this.master.gain.setTargetAtTime(0, this.ctx.currentTime, 0.02);
    window.setTimeout(() => this.muted && this.ctx?.suspend(), 250);
  }

  setMood(mood: Mood, force = false) {
    if (mood === this.mood && !force) return;
    this.mood = mood;
    if (!this.ctx) return;
    const levels: Record<Mood, Partial<Record<string, number>>> = {
      night: { surf: 0.22, wind: 0.05, fan: 0.05, pad: 0.012 },
      edith: { surf: 0.12, wind: 0.02, fan: 0.06, pad: 0.018 },
      outside: { surf: 0.1, wind: 0.08, fan: 0.02, pad: 0.008, hazel: 0.006 },
      curse: { surf: 0.06, wind: 0.02, fan: 0.0, pad: 0.004, hazel: 0.014 },
      morning: { surf: 0.08, wind: 0.02, fan: 0.03, pad: 0.008 },
      silence: { surf: 0.02 },
      engulf: { surf: 0.03, wind: 0.09, fan: 0.035, pad: 0.003, hazel: 0.009 },
      aftermath: { surf: 0.015, fan: 0.03 },
      fcos: { surf: 0.1, wind: 0.02, fan: 0.06, pad: 0.008, fcos: 0.006 },
      charm: { surf: 0.14, wind: 0.02, fan: 0.07, pad: 0.012, fcos: 0.008 },
      hazel: { surf: 0.04, wind: 0.0, fan: 0.01, pad: 0.004, hazel: 0.016 },
      ending: { surf: 0.2, wind: 0.03, fan: 0.04, pad: 0.01, fcos: 0.007 },
    };
    const t = this.ctx.currentTime;
    const target = levels[mood];
    // After Edith vanishes: near silence, then the distant fan returns very slowly.
    const tc = mood === 'aftermath' ? 5 : mood === 'engulf' ? 1.2 : 1.6;
    Object.entries(this.layers).forEach(([k, l]) => l.gain.gain.setTargetAtTime(target[k] ?? 0, t, tc));
    // When Hazel is near, the fan audibly slows; as the cloud comes it drags and distorts.
    const fanHz = mood === 'engulf' ? 33 : mood === 'hazel' || mood === 'outside' || mood === 'curse' ? 41 : mood === 'aftermath' ? 52 : 58;
    this.fan.frequency.setTargetAtTime(fanHz, t, mood === 'aftermath' ? 6 : 2.5);
  }

  dispose() {
    this.timers.forEach((id) => window.clearTimeout(id));
    this.timers = [];
    this.ctx?.close();
    this.ctx = null;
    this.layers = {};
  }
}
