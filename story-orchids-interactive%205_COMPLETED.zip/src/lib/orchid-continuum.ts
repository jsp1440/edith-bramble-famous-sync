import type { OrchidProfile, RegionKey } from './orchid-types';
import { profilesA } from '@/content/orchid-profiles-a';
import { profilesB } from '@/content/orchid-profiles-b';

/* ------------------------------------------------------------------
   Orchid Continuum integration seam.

   Intended source layers (none are called yet — no endpoints are
   assumed or invented):
     • AOS                      – practical culture reference (link only)
     • OC Knowledge Graph       – taxonomy, names, distribution, morphology, phenology
     • OC Image System          – rights-cleared, provenance-aware imagery
     • OC Vision Lab            – image observations (never proof of physiology)
     • Scientific literature    – habitat / physiology / adaptation evidence

   Components depend only on this interface. When OC provides a live
   adapter, implement OrchidDataSource and swap `dataSource` below.
------------------------------------------------------------------- */

export interface OrchidDataSource {
  readonly name: string;
  readonly live: boolean;
  listProfiles(): OrchidProfile[];
  getProfile(id: string): OrchidProfile | undefined;
}

const staticProfiles: OrchidProfile[] = [...profilesA, ...profilesB];

/* The static profiles are AI-assisted drafts curated by FCOS. They have
   NOT been independently verified, so the label must not say so. */
export const staticDataSource: OrchidDataSource = {
  name: 'FCOS curated draft',
  live: false,
  listProfiles: () => staticProfiles,
  getProfile: (id) => staticProfiles.find((p) => p.id === id),
};

export const dataSource: OrchidDataSource = staticDataSource;

export const listProfiles = () => dataSource.listProfiles();
export const getProfile = (id?: string | null) => (id ? dataSource.getProfile(id) : undefined);

/** Permanent home of the Orchid Culture Library (independent of any Chronicle). */
export const LIBRARY_PATH = '/culture-library';
export const profilePath = (id: string, tab?: string) => `${LIBRARY_PATH}/${id}${tab ? `?tab=${tab}` : ''}`;

/** Real American Orchid Society home page. */
export const AOS_HOME = 'https://www.aos.org/';

/* ------------------------------------------------------------------
   Orchid Continuum adapter contract.

   These are the shapes the Culture Library is ready to consume. NO
   endpoint is configured, so `ocConnection.status` is 'pending' and
   every OC panel says "Orchid Continuum connection pending". Do not
   return sample data from here — an empty result is the honest result.
------------------------------------------------------------------- */

export interface OCProvenance {
  sourceDatabase: string;
  recordUrl?: string;
  citation?: string;
  license?: string;
  retrievedAt: string;
}

export interface OCTaxonRecord {
  acceptedName: string;
  authority?: string;
  synonyms: string[];
  rank: string;
  provenance: OCProvenance;
}

export interface OCObservation {
  kind: 'habitat' | 'ecology' | 'pollinator' | 'mycorrhizal' | 'interaction' | 'morphology' | 'conservation' | 'phenology';
  statement: string;
  /** OC reasoning output must be flagged; it is inference, not evidence. */
  isInference: boolean;
  provenance: OCProvenance;
}

export interface OrchidContinuumAdapter {
  getTaxon(name: string): Promise<OCTaxonRecord | null>;
  getOccurrences(name: string): Promise<import('./evidence-types').MapRecord[]>;
  getObservations(name: string): Promise<OCObservation[]>;
  getImages(name: string): Promise<import('./evidence-types').ImageProvenance[]>;
  getLiterature(name: string): Promise<import('./evidence-types').ClaimSource[]>;
}

export const ocConnection: { status: 'pending' | 'live'; adapter: OrchidContinuumAdapter | null; note: string } = {
  status: 'pending',
  adapter: null,
  note: 'No Orchid Continuum endpoint is configured yet. Nothing on this site is currently retrieved from Orchid Continuum.',
};

/** Approximate schematic positions on a 200×100 equirectangular frame. */
export const REGIONS: Record<RegionKey, { label: string; x: number; y: number }> = {
  mexico: { label: 'Mexico', x: 49, y: 38 },
  'central-america': { label: 'Central America', x: 53, y: 43 },
  andes: { label: 'Andes', x: 57, y: 52 },
  'amazon-guianas': { label: 'Amazon & Guianas', x: 66, y: 49 },
  brazil: { label: 'Brazil', x: 73, y: 58 },
  himalaya: { label: 'Himalaya', x: 148, y: 34 },
  china: { label: 'Southern China', x: 160, y: 36 },
  indochina: { label: 'Indochina', x: 157, y: 42 },
  'new-guinea': { label: 'New Guinea', x: 179, y: 53 },
  'ne-australia': { label: 'NE Australia', x: 181, y: 60 },
  'e-australia': { label: 'Eastern Australia', x: 184, y: 67 },
};

export const CLIMATE_AXES: { key: 'temperature' | 'moisture' | 'light' | 'airflow' | 'seasonality'; label: string; low: string; high: string }[] = [
  { key: 'temperature', label: 'Temperature', low: 'Cool', high: 'Warm' },
  { key: 'moisture', label: 'Moisture pattern', low: 'Seasonally dry', high: 'Constantly moist' },
  { key: 'light', label: 'Light', low: 'Shade', high: 'Bright' },
  { key: 'airflow', label: 'Airflow', low: 'Tolerant', high: 'Essential' },
  { key: 'seasonality', label: 'Seasonal behaviour', low: 'Even', high: 'Strongly seasonal' },
];
