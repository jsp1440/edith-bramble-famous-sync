import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

/* ------------------------------------------------------------------
   FEATURE GENIUS — the orchid exploration layer.
   Story → character / culture card → Feature Genius → deeper data.

   Data arrives through the `orchid-explorer` edge function:
     • taxonomy, licensed images, occurrence summaries: GBIF open data
       (the same public biodiversity layer Orchid Continuum draws on)
     • plain-language summary: Wikipedia (CC BY-SA)
     • Orchid Continuum Atlas: only when ORCHID_CONTINUUM_API_BASE is
       configured on the function — otherwise reported honestly.
   Nothing here is invented; an empty result is shown as empty.
------------------------------------------------------------------- */

export interface FGImage {
  src: string;
  species: string;
  creator: string | null;
  license: string;
  source: string;
  recordUrl: string;
  country: string | null;
}

export interface FGSpecies {
  name: string;
  scientificName?: string;
  key?: number;
  image?: FGImage | null;
  imageCount?: number;
}

export interface FGResult {
  query: string;
  found: boolean;
  taxon?: {
    key: number;
    name: string;
    scientificName: string;
    authorship: string | null;
    rank: string;
    status: string;
    synonymOf: string | null;
    kingdom: string;
    family: string;
    genus: string | null;
    species: string | null;
    gbifUrl: string;
  };
  images: FGImage[];
  /** Optional complete species list supplied by the canonical backend. Older deployed
      explorer functions may omit it; the UI then falls back honestly to species
      represented in approved media rather than inventing missing taxa. */
  species?: FGSpecies[];
  summary: { text: string; url?: string; source: string; license: string } | null;
  occurrences: { total: number; countries: { code: string; count: number }[]; months: { month: number; count: number }[] };
  elevation: { low: number; median: number; high: number; n: number } | null;
  view: { lat: number; lng: number; zoom: number } | null;
  continuum: { status: 'not-configured' | 'connected' | 'error'; genus?: string; data?: unknown };
  retrievedAt: string;
}

/** Culture-profile id → the name Feature Genius looks up. */
export const PROFILE_TAXON: Record<string, string> = {
  catasetinae: 'Catasetum',
  phragmipedium: 'Phragmipedium',
  'dendrobium-nobile': 'Dendrobium nobile',
  'dendrobium-phalaenanthe': 'Dendrobium bigibbum',
  lycaste: 'Lycaste',
  cymbidium: 'Cymbidium',
  sarcochilus: 'Sarcochilus',
  stanhopea: 'Stanhopea',
  'laelia-anceps': 'Laelia anceps',
};

/** Orchids that appear in the Chronicles, for the Feature Genius index. */
export const FEATURED_TAXA: { name: string; note: string; profile?: string }[] = [
  { name: 'Phragmipedium', note: 'The wet slipper bench', profile: 'phragmipedium' },
  { name: 'Catasetum', note: 'Seasonal dormancy on the dry-rest shelf', profile: 'catasetinae' },
  { name: 'Dendrobium nobile', note: 'Cool autumn nights', profile: 'dendrobium-nobile' },
  { name: 'Dendrobium bigibbum', note: 'Warm and evergreen', profile: 'dendrobium-phalaenanthe' },
  { name: 'Stanhopea', note: 'Flowers that grow downward', profile: 'stanhopea' },
  { name: 'Cymbidium', note: 'The lath house and coastal nights', profile: 'cymbidium' },
  { name: 'Sarcochilus', note: 'Coastal growing', profile: 'sarcochilus' },
  { name: 'Lycaste', note: 'Deciduous and evergreen', profile: 'lycaste' },
  { name: 'Laelia anceps', note: 'The seasonal clock', profile: 'laelia-anceps' },
  { name: 'Cattleya', note: 'The bright, stable bench' },
  { name: 'Bulbophyllum', note: 'An enormous, varied genus' },
  { name: 'Pleurothallis', note: 'Small pleurothallids, often mounted' },
];

export const explorePath = (name: string) => `/explore/${encodeURIComponent(name)}`;
export const atlasPath = (name: string) => `${explorePath(name)}#atlas`;
export const profileExplorePath = (profileId: string) => {
  const t = PROFILE_TAXON[profileId];
  return t ? explorePath(t) : null;
};

/** iNaturalist originals are very large; request a sensible size. */
export const sized = (src: string, size: 'medium' | 'large' = 'medium') =>
  src.includes('inaturalist') ? src.replace(/\/original\.(jpe?g|png)/i, `/${size}.$1`) : src;

const memo = new Map<string, FGResult>();

export function useOrchidExplorer(name: string | null | undefined) {
  const [data, setData] = useState<FGResult | null>(name ? memo.get(name) ?? null : null);
  const [state, setState] = useState<'idle' | 'loading' | 'ok' | 'error'>(name ? (memo.has(name) ? 'ok' : 'loading') : 'idle');

  useEffect(() => {
    if (!name) return;
    if (memo.has(name)) {
      setData(memo.get(name)!);
      setState('ok');
      return;
    }
    let alive = true;
    setState('loading');
    supabase.functions.invoke('orchid-explorer', { body: { name } }).then(({ data: d, error }) => {
      if (!alive) return;
      if (error || !d || d.error) {
        setState('error');
        return;
      }
      memo.set(name, d as FGResult);
      setData(d as FGResult);
      setState('ok');
    });
    return () => {
      alive = false;
    };
  }, [name]);

  return { data, state };
}

export const countryName = (code: string) => {
  try {
    return new Intl.DisplayNames(['en'], { type: 'region' }).of(code) ?? code;
  } catch {
    return code;
  }
};

export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
