/**
 * Go Deeper — Orchid Continuum / Calyx integration boundary.
 *
 * This adapter is intentionally NOT connected to any service. It defines the
 * contract only. To activate the integration later, set CONTINUUM_BASE_URL and
 * implement `fetchDeepRecord`; every existing deep link across the site will
 * begin resolving without any other code change.
 */

export type DeepSubject = 'taxon' | 'concept' | 'pathogen' | 'card';

export interface DeepLinkRequest {
  subject: DeepSubject;
  /** taxon name, concept slug, pathogen slug, or card id */
  identifier: string;
  /** where in the site the request originated, for analytics/back-links */
  origin?: string;
}

export interface DeepRecord {
  title: string;
  summary: string;
  source: string;
  license?: string;
  url?: string;
}

export const CONTINUUM_BASE_URL: string | null = null;

export function isDeepIntegrationEnabled(): boolean {
  return Boolean(CONTINUUM_BASE_URL);
}

/** Returns null while the integration is unavailable. Never fabricates data. */
export async function fetchDeepRecord(_request: DeepLinkRequest): Promise<DeepRecord | null> {
  if (!isDeepIntegrationEnabled()) return null;
  return null;
}

/** Internal route a deep link resolves to while the integration is offline. */
export function deepLinkHref(request: DeepLinkRequest): string {
  const params = new URLSearchParams({ subject: request.subject, id: request.identifier });
  return `/go-deeper?${params.toString()}`;
}
