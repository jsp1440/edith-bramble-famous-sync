import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, RotateCcw, Scale } from 'lucide-react';
import { ZONES, zoneShort } from '@/content/edith-greenhouse';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { ActivityHeader, GreenhouseStepBar, StepFooter } from '@/components/greenhouse/GreenhouseShell';

type Fit = 'good' | 'possible' | 'poor' | 'info';
type Factor = 'temperature' | 'moisture' | 'light' | 'airflow' | 'seasonal state' | 'growth stage' | 'container';
type Verdict = { fit: Fit; why: string; factors: Factor[] };
type BenchPlant = { id: string; name: string; state: string; profile: string; fits: Record<string, Verdict>; otherwise: Verdict };

const FIT_UI: Record<Fit, { label: string; icon: React.ElementType; tone: string }> = {
  good: { label: 'Good fit', icon: CheckCircle2, tone: 'border-[hsl(150_40%_28%)] bg-[hsl(150_30%_92%)] text-[hsl(150_45%_16%)]' },
  possible: { label: 'Possible with conditions', icon: AlertTriangle, tone: 'border-[hsl(38_60%_38%)] bg-[hsl(44_70%_91%)] text-[hsl(30_60%_18%)]' },
  poor: { label: 'Poor fit', icon: XCircle, tone: 'border-[hsl(0_45%_38%)] bg-[hsl(0_50%_94%)] text-[hsl(0_55%_22%)]' },
  info: { label: 'Needs more information', icon: HelpCircle, tone: 'border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] text-[hsl(30_25%_14%)]' },
};

/* Edith's reasoning for HER fictional greenhouse. Orchid-biology claims
   behind these choices are in the linked Culture Library profiles, each
   with its own evidence status. Species, hybrids and local climates vary. */
const PLANTS: BenchPlant[] = [
  {
    id: 'phrag', name: 'Phragmipedium', state: 'In active growth', profile: 'phragmipedium',
    fits: {
      'wet-bench': { fit: 'good', why: 'Consistently moist media with moving air is how Edith grows the Phragmipediums in her collection. Species and hybrids differ, so she still watches each plant.', factors: ['moisture', 'airflow'] },
      'warm-zone': { fit: 'possible', why: 'Possible if watering stays consistent. How much warmth suits it depends on the species or hybrid.', factors: ['temperature', 'moisture'] },
      'cool-west': { fit: 'info', why: 'Some Phragmipedium grow cooler than others. Which species or hybrid is it?', factors: ['temperature'] },
      'dry-rest': { fit: 'poor', why: 'A dry rest is exactly what Edith does not give this plant — the wet bench exists for it.', factors: ['moisture', 'seasonal state'] },
      hanging: { fit: 'poor', why: 'Open baskets high in the house dry fast; consistent moisture would be very hard to keep.', factors: ['moisture', 'container'] },
    },
    otherwise: { fit: 'info', why: 'Edith would ask how moisture could be kept consistent there before choosing it.', factors: ['moisture'] },
  },
  {
    id: 'cata', name: 'Catasetum', state: 'Leafless, growth mature', profile: 'catasetinae',
    fits: {
      'dry-rest': { fit: 'good', why: 'The leaves have fallen after a completed growth, so it moves where it will not be watered with everything else — until new growth appears.', factors: ['seasonal state', 'moisture', 'growth stage'] },
      'wet-bench': { fit: 'poor', why: 'Constant moisture during rest is the one thing Edith is trying to avoid for this plant.', factors: ['moisture', 'seasonal state'] },
      hanging: { fit: 'possible', why: 'Possible if the basket is left out of the watering round while the plant rests.', factors: ['moisture', 'container'] },
      'warm-zone': { fit: 'possible', why: 'Warmth is not the problem — watering is. Possible if it is excluded from the routine.', factors: ['temperature', 'moisture'] },
    },
    otherwise: { fit: 'info', why: 'Is the leaf drop a normal seasonal rest, or a sign of a problem? Check the pseudobulb and roots first.', factors: ['seasonal state', 'growth stage'] },
  },
  {
    id: 'den-warm', name: 'Phalaenanthe-type Dendrobium', state: 'Evergreen, in leaf', profile: 'dendrobium-phalaenanthe',
    fits: {
      'warm-zone': { fit: 'good', why: 'A warm, protected, stable position suits this warm-growing, evergreen type.', factors: ['temperature'] },
      cattleya: { fit: 'possible', why: 'The light can suit; possible if it stays warm enough as the south bench cools at night.', factors: ['light', 'temperature'] },
      'cool-west': { fit: 'poor', why: 'The cool autumn contrast a nobile-type uses is the treatment this group is not given.', factors: ['temperature', 'seasonal state'] },
      'dry-rest': { fit: 'poor', why: 'It keeps its leaves and is not entering a hard dry rest.', factors: ['moisture', 'seasonal state'] },
      'outdoor-lath': { fit: 'poor', why: 'Coastal autumn nights outdoors are cooler than Edith gives this plant.', factors: ['temperature'] },
    },
    otherwise: { fit: 'info', why: 'Edith would check how warm that spot stays at night before choosing it.', factors: ['temperature'] },
  },
  {
    id: 'den-nobile', name: 'Nobile-type Dendrobium', state: 'Canes mature', profile: 'dendrobium-nobile',
    fits: {
      'cool-west': { fit: 'good', why: 'Mature canes get the cooler autumn nights Edith uses as a seasonal cue for this group.', factors: ['temperature', 'seasonal state', 'growth stage'] },
      cattleya: { fit: 'possible', why: 'Bright light suits; possible if nights there cool enough in autumn.', factors: ['light', 'temperature'] },
      'outdoor-lath': { fit: 'possible', why: 'Possible on the coast while autumn nights are cool but not extreme.', factors: ['temperature', 'light'] },
      'warm-zone': { fit: 'poor', why: 'Kept warm through autumn, it misses the seasonal contrast Edith relies on for this group.', factors: ['temperature', 'seasonal state'] },
      'wet-bench': { fit: 'poor', why: 'Constantly moist media is not how Edith treats mature canes in autumn.', factors: ['moisture', 'seasonal state'] },
    },
    otherwise: { fit: 'info', why: 'Are the canes mature yet? Edith changes treatment only once growth has finished.', factors: ['growth stage'] },
  },
  {
    id: 'stan', name: 'Stanhopea', state: 'Spikes forming', profile: 'stanhopea',
    fits: {
      hanging: { fit: 'good', why: 'Its inflorescences grow downward through and below an open basket; hanging high leaves room beneath.', factors: ['container', 'growth stage'] },
      ficus: { fit: 'possible', why: 'Possible if hung in an open basket under the canopy with clear space below.', factors: ['container', 'light'] },
    },
    otherwise: { fit: 'poor', why: 'On a bench in a solid pot, spikes that grow downward have nowhere to go. The container matters as much as the spot.', factors: ['container'] },
  },
  {
    id: 'cym', name: 'Cymbidium', state: 'Autumn, before spiking', profile: 'cymbidium',
    fits: {
      'outdoor-lath': { fit: 'good', why: 'Outdoor light and cool coastal nights, protected from extremes, are how Edith grows hers.', factors: ['temperature', 'light', 'seasonal state'] },
      'cool-west': { fit: 'possible', why: 'Possible if it gets enough light; indoors it may get less night contrast.', factors: ['light', 'temperature'] },
      cattleya: { fit: 'possible', why: 'Bright enough; possible if nights there still cool.', factors: ['light', 'temperature'] },
      'warm-zone': { fit: 'poor', why: 'Kept warm, it loses the cool autumn nights Edith uses for it.', factors: ['temperature', 'seasonal state'] },
      staging: { fit: 'info', why: 'Staging is temporary. Where is the plant going next?', factors: ['seasonal state'] },
    },
    otherwise: { fit: 'info', why: 'Edith would ask whether that spot gets enough light and cool nights.', factors: ['light', 'temperature'] },
  },
];

const OPTIONS = ZONES.filter((z) => z.kind === 'growing' || z.id === 'staging');

const BuildABench: React.FC = () => {
  const [placed, setPlaced] = useState<Record<string, string>>({});
  const done = Object.keys(placed).length;

  return (
    <div>
      <GreenhouseStepBar current="bench" />
      <ActivityHeader step="Step 3 · Build a bench" title="Build a bench" question="Where would you put them?">
        Place each orchid in the greenhouse. Then read why your choice works — or why Edith would choose somewhere else. There is often more
        than one reasonable answer.
      </ActivityHeader>

      <div className="mx-auto max-w-5xl space-y-5 px-4 sm:px-6">
        {PLANTS.map((p) => {
          const zoneId = placed[p.id];
          const v = zoneId ? p.fits[zoneId] ?? p.otherwise : null;
          const ui = v ? FIT_UI[v.fit] : null;
          const Icon = ui?.icon;
          const prof = getProfile(p.profile);
          return (
            <section key={p.id} className="rounded-md border-2 border-border bg-white/70 p-5 sm:p-6">
              <div className="grid gap-3 sm:grid-cols-[1fr_minmax(0,18rem)] sm:items-center">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</h2>
                  <p className="text-[1.125rem] text-[hsl(var(--ink))]">Right now: <strong>{p.state}</strong></p>
                </div>
                <label>
                  <span className="sr-only">Zone for {p.name}</span>
                  <select value={zoneId || ''} onChange={(e) => setPlaced((s) => ({ ...s, [p.id]: e.target.value }))}
                    className="min-h-[52px] w-full rounded-md border-2 border-border bg-background px-3 text-[1.125rem] text-[hsl(var(--ink))]">
                    <option value="">Choose a place…</option>
                    {OPTIONS.map((z) => <option key={z.id} value={z.id}>{zoneShort(z.id)}</option>)}
                  </select>
                </label>
              </div>

              {v && ui && Icon && (
                <div aria-live="polite" className={`mt-4 rounded-md border-2 p-4 ${ui.tone}`}>
                  <p className="flex items-center gap-2 font-ui text-[1.125rem] font-bold uppercase tracking-wide">
                    <Icon className="h-5 w-5" aria-hidden="true" /> {ui.label} · {zoneShort(zoneId)}
                  </p>
                  <p className="mt-2 text-[1.1875rem] leading-relaxed">{v.why}</p>
                  <p className="mt-2 text-[1rem]"><strong>Factors:</strong> {v.factors.join(' · ')}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {prof && (
                      <Link to={profilePath(p.profile, 'culture')} className="inline-flex min-h-[44px] items-center rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--cream))]">View culture profile</Link>
                    )}
                    <Link to={profilePath(p.profile, 'evidence')} className="inline-flex min-h-[44px] items-center rounded-md border-2 border-current px-4 font-ui text-[1rem] font-semibold">View sources</Link>
                  </div>
                </div>
              )}
            </section>
          );
        })}

        <div className="flex flex-wrap items-center gap-3 rounded-md bg-[hsl(var(--botanical))]/[0.06] p-5">
          <p className="text-[1.1875rem] text-[hsl(var(--ink))]">{done} of {PLANTS.length} placed. Real greenhouses allow for judgement.</p>
          <button type="button" onClick={() => setPlaced({})} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-border bg-white px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Start again
          </button>
          <Link to="/greenhouse/compare" className="ml-auto inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            <Scale className="h-5 w-5" aria-hidden="true" /> Compare two orchids
          </Link>
        </div>
        <p className="text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
          These verdicts describe Edith's reasoning in her fictional coastal greenhouse. The orchid biology behind them lives in each Culture
          Library profile, where every statement shows its evidence status. Orchid culture varies among species, hybrids, climates and growing systems.
        </p>
      </div>
      <StepFooter current="bench" />
    </div>
  );
};

export default BuildABench;
