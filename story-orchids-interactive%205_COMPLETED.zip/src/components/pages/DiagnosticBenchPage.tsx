import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, RotateCcw } from 'lucide-react';
import { detectiveClues, diagnostics, getMedia } from '@/lib/content';
import type { DetectiveClue } from '@/lib/content-types';
import { Kicker, Notice } from '@/components/site/Ornaments';

const choices: DetectiveClue['answer'][] = ['NORMAL', 'SEASONAL SIGNAL', 'CULTURAL WARNING', 'NEEDS MORE EVIDENCE', 'FICTIONAL'];

const tone: Record<string, string> = {
  NORMAL: 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]',
  'CULTURAL WARNING': 'bg-[hsl(var(--burgundy))] text-[hsl(var(--cream))]',
  'SEASONAL SIGNAL': 'bg-[hsl(var(--moss))] text-[hsl(var(--cream))]',
  'NEEDS MORE EVIDENCE': 'bg-[hsl(210_18%_32%)] text-[hsl(var(--cream))]',
  FICTIONAL: 'bg-[hsl(var(--amber))] text-[hsl(30_35%_15%)]',
};

const DetectiveCase: React.FC<{ clue: DetectiveClue }> = ({ clue }) => {
  const [pick, setPick] = useState<string | null>(null);
  const ok = pick && (pick === clue.answer || clue.alsoAccept?.includes(pick as DetectiveClue['answer']));
  return (
    <li className="rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-5">
      <p className="font-display text-xl leading-snug text-[hsl(var(--charcoal))]">{clue.clue}</p>
      <div className="mt-4 grid grid-cols-2 gap-2">
        {choices.map((c) => (
          <button
            key={c}
            type="button"
            onClick={() => setPick(c)}
            aria-pressed={pick === c}
            className={`rounded-sm px-2 py-2.5 font-label text-[0.5rem] uppercase transition-colors ${
              pick === c ? tone[c] : 'border border-border bg-background text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]/60'
            }`}
          >
            {c}
          </button>
        ))}
      </div>
      {pick && (
        <div aria-live="polite" className="mt-4 rounded-sm border-l-4 border-[hsl(var(--amber))]/60 bg-background px-3 py-2.5">
          <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">
            {ok ? 'Good eye.' : 'Look again.'} Edith's reading: <span className={`ml-1 rounded-sm px-1.5 py-0.5 ${tone[clue.answer]}`}>{clue.answer}</span>
          </p>
          <p className="mt-1.5 text-sm leading-relaxed text-[hsl(var(--ink))]">{clue.explanation}</p>
        </div>
      )}
    </li>
  );
};

const DiagnosticBenchPage: React.FC = () => {
  const [open, setOpen] = useState<string | null>(diagnostics[0]?.id || null);
  const [round, setRound] = useState(0);
  const hero = getMedia('c2-phrag-cata');

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div>
          <Kicker>Optional · never part of the reading path</Kicker>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
            Mara's Diagnostic Bench
          </h1>
          <p className="mt-4 max-w-xl text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
            Mara reads a greenhouse the way she reads a patient: history, signs, then a differential. Nothing here is a
            test. It is an invitation to look for pattern before treatment.
          </p>
        </div>
        {hero && <img src={hero.src} alt={hero.alt} className="w-full rounded-sm border border-border/70 object-cover" />}
      </div>

      <section className="mt-14">
        <Kicker>Symptom cards</Kicker>
        <h2 className="mt-2 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">What else could it be?</h2>
        <div className="mt-6 grid gap-3 md:grid-cols-[16rem_1fr]">
          <ul className="flex gap-2 overflow-x-auto md:flex-col md:overflow-visible">
            {diagnostics.map((d) => (
              <li key={d.id} className="shrink-0">
                <button
                  type="button"
                  onClick={() => setOpen(d.id)}
                  aria-pressed={open === d.id}
                  className={`w-full rounded-sm px-4 py-3 text-left font-display text-lg ${
                    open === d.id ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border border-border bg-background text-[hsl(var(--ink))]'
                  }`}
                >
                  {d.symptom}
                </button>
              </li>
            ))}
          </ul>
          {diagnostics
            .filter((d) => d.id === open)
            .map((d) => (
              <article key={d.id} aria-live="polite" className="rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6">
                <p className="font-display text-2xl italic text-[hsl(var(--botanical))]">{d.question}</p>
                <p className="mt-4 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">The differential</p>
                <ul className="mt-2 grid gap-2 sm:grid-cols-2">
                  {d.possibilities.map((p) => (
                    <li key={p} className="flex items-start gap-2 rounded-sm border border-border/70 bg-background px-3 py-2 text-sm">
                      <Search className="mt-0.5 h-3.5 w-3.5 shrink-0 text-[hsl(var(--moss))]" aria-hidden="true" />
                      {p}
                    </li>
                  ))}
                </ul>
                <p className="mt-5 rounded-sm border-l-4 border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))]/6 px-4 py-3 text-[0.98rem] leading-relaxed text-[hsl(var(--ink))]">
                  <strong className="font-display text-lg">Mara:</strong> {d.karen}
                </p>
              </article>
            ))}
        </div>
      </section>

      <section className="mt-16" id="detective">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Kicker>Orchid Detective mode</Kicker>
            <h2 className="mt-2 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Investigating Edith's greenhouse</h2>
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
              Classify each clue as NORMAL, SEASONAL SIGNAL, CULTURAL WARNING, NEEDS MORE EVIDENCE or FICTIONAL. Some
              clues are honestly more than one thing — Edith's reading explains why.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setRound((r) => r + 1)}
            className="inline-flex items-center gap-2 rounded-sm border border-border px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--ink))]"
          >
            <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> Start over
          </button>
        </div>
        <ul key={round} className="mt-6 grid gap-4 md:grid-cols-2">
          {detectiveClues.map((c) => (
            <DetectiveCase key={c.id} clue={c} />
          ))}
        </ul>
      </section>

      <div className="mt-12 max-w-3xl">
        <Notice
          tone="caution"
          title="Not a diagnosis service"
          body="Never diagnose a fungal disease from one photograph or one symptom alone. For a valuable or spreading problem, isolate the plant and consult experienced growers or a plant diagnostic lab."
        />
      </div>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link to="/grow" className="rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))]">
          Grower Cards
        </Link>
        <Link to="/color#certificate" className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
          Print an Orchid Detective certificate
        </Link>
      </div>
    </div>
  );
};

export default DiagnosticBenchPage;
