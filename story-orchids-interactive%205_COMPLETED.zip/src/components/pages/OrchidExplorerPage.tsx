import React, { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  ExternalLink,
  Globe2,
  ImageOff,
  Images,
  Mountain,
  Sprout,
  X,
} from 'lucide-react';
import AtlasMap from '@/components/explore/AtlasMap';
import {
  FEATURED_TAXA,
  MONTHS,
  countryName,
  explorePath,
  sized,
  useOrchidExplorer,
  type FGImage,
  type FGSpecies,
} from '@/lib/feature-genius';
import { getProfile, profilePath } from '@/lib/orchid-continuum';

const Section: React.FC<{ id?: string; icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ id, icon, title, children }) => (
  <section id={id} className="scroll-mt-32 rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white p-5 shadow-sm sm:p-7">
    <h2 className="flex items-center gap-3 font-display text-3xl font-semibold text-[hsl(var(--botanical))]">
      {icon}
      {title}
    </h2>
    <div className="mt-4">{children}</div>
  </section>
);

const ImageDialog: React.FC<{ image: FGImage | null; onClose: () => void }> = ({ image, onClose }) => {
  if (!image) return null;
  return (
    <div role="dialog" aria-modal="true" aria-label={image.species} className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <figure className="max-h-full w-full max-w-5xl overflow-auto rounded-xl bg-[hsl(var(--cream))] p-4" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between gap-3">
          <figcaption className="font-display text-2xl italic text-[hsl(var(--charcoal))]">{image.species}</figcaption>
          <button type="button" onClick={onClose} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--charcoal))] px-4 font-ui font-semibold">
            <X className="h-5 w-5" aria-hidden="true" /> Close
          </button>
        </div>
        <img src={sized(image.src, 'large')} alt={image.species} className="mt-3 max-h-[72vh] w-full rounded-md object-contain" />
        <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
          Photo: {image.creator ?? 'unknown photographer'} · {image.license} · {image.source}
          {image.country ? ` · ${image.country}` : ''} ·{' '}
          <a href={image.recordUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">
            View the source record
          </a>
        </p>
      </figure>
    </div>
  );
};

const SpeciesGallery: React.FC<{ images: FGImage[] }> = ({ images }) => {
  const [open, setOpen] = useState<FGImage | null>(null);
  const [page, setPage] = useState(0);
  const pageSize = 24;
  const pages = Math.max(1, Math.ceil(images.length / pageSize));
  const current = images.slice(page * pageSize, page * pageSize + pageSize);

  useEffect(() => setPage(0), [images]);

  if (!images.length) {
    return (
      <div className="flex min-h-[180px] items-center justify-center rounded-lg border-2 border-dashed border-[hsl(var(--charcoal))]/30 bg-[hsl(var(--cream))] p-6 text-center">
        <div>
          <ImageOff className="mx-auto h-8 w-8 text-[hsl(var(--moss))]" aria-hidden="true" />
          <p className="mt-3 text-[1.125rem] text-[hsl(var(--ink))]">No approved image is currently available for this species.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <p className="max-w-3xl text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
          {images.length.toLocaleString()} provenance-bearing image{images.length === 1 ? '' : 's'} available in the current media response. Select an image to enlarge it and see its credit.
        </p>
        {pages > 1 && <p className="font-ui text-[1rem] font-semibold">Page {page + 1} of {pages}</p>}
      </div>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {current.map((im, i) => (
          <li key={`${im.src}-${i}`}>
            <button type="button" onClick={() => setOpen(im)} className="group block w-full overflow-hidden rounded-lg border-2 border-[hsl(var(--charcoal))]/25 bg-[hsl(var(--cream))] text-left">
              <div className="aspect-square overflow-hidden bg-[hsl(96_20%_85%)]">
                <img src={sized(im.src)} alt={`${im.species}, photographed in ${im.country ?? 'the wild or cultivation'}`} loading="lazy" decoding="async" className="h-full w-full object-cover transition-transform group-hover:scale-105" />
              </div>
              <p className="px-3 py-2 font-display text-[1.125rem] italic leading-snug text-[hsl(var(--charcoal))]">{im.species}</p>
            </button>
          </li>
        ))}
      </ul>
      {pages > 1 && (
        <div className="mt-5 flex items-center justify-center gap-3">
          <button type="button" disabled={page === 0} onClick={() => setPage((v) => Math.max(0, v - 1))} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui font-semibold text-[hsl(var(--botanical))] disabled:opacity-40">
            <ArrowLeft className="h-5 w-5" aria-hidden="true" /> Previous
          </button>
          <button type="button" disabled={page >= pages - 1} onClick={() => setPage((v) => Math.min(pages - 1, v + 1))} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui font-semibold text-[hsl(var(--botanical))] disabled:opacity-40">
            Next <ArrowRight className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      )}
      <ImageDialog image={open} onClose={() => setOpen(null)} />
    </>
  );
};

type SpeciesTile = { name: string; image: FGImage | null; imageCount: number };

const deriveSpecies = (species: FGSpecies[] | undefined, images: FGImage[]): SpeciesTile[] => {
  const byName = new Map<string, FGImage[]>();
  images.forEach((im) => {
    const key = im.species?.trim();
    if (!key) return;
    byName.set(key, [...(byName.get(key) ?? []), im]);
  });

  if (species?.length) {
    const seen = new Set<string>();
    return species
      .filter((s) => s.name && !seen.has(s.name) && seen.add(s.name))
      .map((s) => {
        const ims = byName.get(s.name) ?? [];
        return { name: s.name, image: s.image ?? ims[0] ?? null, imageCount: s.imageCount ?? ims.length };
      });
  }

  return [...byName.entries()]
    .map(([name, ims]) => ({ name, image: ims[0] ?? null, imageCount: ims.length }))
    .sort((a, b) => a.name.localeCompare(b.name));
};

const GenusTeachingUnit: React.FC<{ genus: string; images: FGImage[]; species?: FGSpecies[]; summary?: string | null }> = ({ genus, images, species, summary }) => {
  const tiles = useMemo(() => deriveSpecies(species, images), [species, images]);
  const [offset, setOffset] = useState(0);
  const [selectedName, setSelectedName] = useState<string | null>(tiles[0]?.name ?? null);
  const [open, setOpen] = useState<FGImage | null>(null);

  useEffect(() => {
    setOffset(0);
    setSelectedName(tiles[0]?.name ?? null);
  }, [genus, tiles.length]);

  const selected = tiles.find((s) => s.name === selectedName) ?? tiles[0];
  const selectedImages = selected ? images.filter((im) => im.species === selected.name) : [];
  const hero = selected?.image ?? selectedImages[0] ?? images[0] ?? null;
  const visible = Array.from({ length: Math.min(9, tiles.length) }, (_, i) => tiles[(offset + i) % tiles.length]).filter(Boolean);
  const canAdvance = tiles.length > 9;

  if (!tiles.length) {
    return (
      <div className="rounded-xl border-2 border-dashed border-[hsl(var(--charcoal))]/30 bg-[hsl(var(--cream))] p-8 text-center">
        <ImageOff className="mx-auto h-9 w-9 text-[hsl(var(--moss))]" aria-hidden="true" />
        <p className="mt-3 text-[1.125rem] text-[hsl(var(--ink))]">No approved species media are currently available for {genus}. Taxonomy and Atlas data remain available below.</p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(20rem,.9fr)]">
      <div className="overflow-hidden rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-[hsl(var(--cream))]">
        {hero ? (
          <button type="button" onClick={() => setOpen(hero)} className="block w-full text-left">
            <img src={sized(hero.src, 'large')} alt={selected?.name ?? genus} className="aspect-[4/3] w-full object-cover" />
          </button>
        ) : (
          <div className="flex aspect-[4/3] items-center justify-center bg-[hsl(96_20%_85%)]"><ImageOff className="h-10 w-10" aria-hidden="true" /></div>
        )}
        <div className="p-5">
          <p className="font-label uppercase text-[hsl(var(--moss))]">Active species</p>
          <h3 className="mt-1 font-display text-3xl font-semibold italic text-[hsl(var(--charcoal))]">{selected?.name ?? genus}</h3>
          {hero ? (
            <p className="mt-2 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
              {hero.creator ? `Photo by ${hero.creator}` : 'Photographer not supplied'} · {hero.source} · {hero.license}{hero.country ? ` · ${hero.country}` : ''}.
            </p>
          ) : <p className="mt-2 text-[1.0625rem] text-[hsl(var(--ink))]">No approved image available.</p>}
          {summary && <p className="mt-3 line-clamp-3 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">{summary}</p>}
          <div className="mt-4 flex flex-wrap gap-3">
            <Link to={explorePath(selected?.name ?? genus)} className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-4 font-ui font-semibold text-[hsl(var(--cream))]">
              Open species dossier <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
            {hero && <button type="button" onClick={() => setOpen(hero)} className="inline-flex min-h-[48px] items-center rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui font-semibold text-[hsl(var(--botanical))]">Enlarge image</button>}
          </div>
        </div>
      </div>

      <div>
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="font-label uppercase text-[hsl(var(--moss))]">Species in this genus</p>
            <p className="mt-1 text-[1rem] text-[hsl(var(--ink))]">
              {species?.length ? `${tiles.length.toLocaleString()} canonical species returned by the data service.` : `${tiles.length.toLocaleString()} species currently represented in the approved media response.`}
            </p>
          </div>
          {canAdvance && <span className="font-ui text-[0.95rem] font-semibold">Showing 9 at a time</span>}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2" aria-label={`${genus} species selector`}>
          {visible.map((sp) => (
            <button key={sp.name} type="button" onClick={() => setSelectedName(sp.name)} aria-pressed={selected?.name === sp.name} className={`overflow-hidden rounded-lg border-2 text-left ${selected?.name === sp.name ? 'border-[hsl(var(--botanical))] ring-2 ring-[hsl(var(--botanical))]/25' : 'border-[hsl(var(--charcoal))]/20'}`}>
              <div className="aspect-square bg-[hsl(96_20%_85%)]">
                {sp.image ? <img src={sized(sp.image.src)} alt="" aria-hidden="true" loading="lazy" className="h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center"><ImageOff className="h-6 w-6" aria-hidden="true" /></div>}
              </div>
              <div className="min-h-[4.7rem] bg-white p-2">
                <p className="line-clamp-2 font-display text-[1rem] italic leading-tight text-[hsl(var(--charcoal))]">{sp.name}</p>
                <p className="mt-1 font-ui text-[0.8rem] text-[hsl(var(--ink))]">{sp.imageCount ? `${sp.imageCount} image${sp.imageCount === 1 ? '' : 's'}` : 'No image'}</p>
              </div>
            </button>
          ))}
        </div>
        {canAdvance && (
          <div className="mt-4 flex gap-2">
            <button type="button" onClick={() => setOffset((v) => (v - 9 + tiles.length) % tiles.length)} className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] px-3 font-ui font-semibold text-[hsl(var(--botanical))]"><ArrowLeft className="h-4 w-4" /> Previous species</button>
            <button type="button" onClick={() => setOffset((v) => (v + 9) % tiles.length)} className="inline-flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] px-3 font-ui font-semibold text-[hsl(var(--botanical))]">More species <ArrowRight className="h-4 w-4" /></button>
          </div>
        )}
      </div>
      <ImageDialog image={open} onClose={() => setOpen(null)} />
    </div>
  );
};

const ExplorerIndex: React.FC = () => (
  <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
    <p className="font-label uppercase text-[hsl(var(--moss))]">Featured Genus</p>
    <h1 className="mt-2 font-display text-5xl font-semibold text-[hsl(var(--charcoal))]">One genus. Every species we can document.</h1>
    <p className="mt-4 max-w-3xl text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">
      Open a genus to move through its species, promote any species into the hero view, and continue into its dossier, photographs and Atlas record.
    </p>
    <ul className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {FEATURED_TAXA.map((t) => (
        <li key={t.name}>
          <Link to={explorePath(t.name)} className="flex h-full min-h-[96px] items-center justify-between gap-3 rounded-xl border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5 hover:border-[hsl(var(--botanical))]">
            <span>
              <span className="block font-display text-2xl italic font-semibold text-[hsl(var(--botanical))]">{t.name}</span>
              <span className="mt-1 block text-[1.0625rem] text-[hsl(var(--ink))]">{t.note}</span>
            </span>
            <ArrowRight className="h-6 w-6 shrink-0 text-[hsl(var(--botanical))]" aria-hidden="true" />
          </Link>
        </li>
      ))}
    </ul>
  </div>
);

const OrchidExplorerPage: React.FC = () => {
  const { taxon } = useParams();
  const name = taxon ? decodeURIComponent(taxon) : null;
  const { data, state } = useOrchidExplorer(name);
  if (!name) return <ExplorerIndex />;

  const featured = FEATURED_TAXA.find((t) => t.name.toLowerCase() === name.toLowerCase());
  const profile = featured?.profile ? getProfile(featured.profile) : undefined;
  const t = data?.taxon;
  const genusLevel = t ? t.rank !== 'SPECIES' : true;
  const maxCountry = Math.max(1, ...(data?.occurrences.countries.map((c) => c.count) ?? [1]));
  const maxMonth = Math.max(1, ...(data?.occurrences.months.map((m) => m.count) ?? [1]));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link to="/explore" className="font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">← Featured Genus index</Link>

      <header className="mt-4">
        <p className="font-label uppercase text-[hsl(var(--moss))]">Featured Genus · {t ? t.rank.toLowerCase() : 'orchid'}</p>
        <h1 className="mt-2 font-display text-5xl font-semibold italic text-[hsl(var(--charcoal))] sm:text-6xl">{t?.name ?? name}</h1>
        {t && <p className="mt-3 text-[1.1875rem] text-[hsl(var(--ink))]"><strong>Accepted name:</strong> {t.scientificName}{t.synonymOf && ' (searched name is a synonym)'} · Family {t.family}{t.genus && t.rank === 'SPECIES' ? ` · Genus ${t.genus}` : ''}</p>}
        {featured && <p className="mt-2 text-[1.1875rem] text-[hsl(var(--ink))]"><strong>In the Chronicles:</strong> {featured.note}</p>}
        <div className="mt-5 flex flex-wrap gap-3">
          <a href="#atlas" className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]"><Globe2 className="h-5 w-5" /> Atlas</a>
          {profile && <Link to={profilePath(profile.id)} className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] bg-white px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))]"><Sprout className="h-5 w-5" /> Culture & evidence</Link>}
        </div>
      </header>

      {state === 'loading' && <p className="mt-10 rounded-xl border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-white p-8 text-center text-[1.25rem]">Gathering taxonomy, images and records for {name}…</p>}
      {state === 'error' && <p className="mt-10 rounded-xl border-2 border-[hsl(var(--burgundy))] bg-white p-6 text-[1.1875rem]">The orchid data service could not be reached just now. The site remains usable; try this dossier again in a moment.</p>}
      {state === 'ok' && data && !data.found && <p className="mt-10 rounded-xl border-2 border-[hsl(var(--charcoal))]/40 bg-white p-6 text-[1.1875rem]">No accepted orchid name matched “{name}”.</p>}

      {state === 'ok' && data?.found && t && (
        <div className="mt-8 space-y-6">
          {genusLevel ? (
            <Section icon={<Images className="h-7 w-7" />} title="Species gallery">
              <GenusTeachingUnit genus={t.name} images={data.images} species={data.species} summary={data.summary?.text ?? null} />
            </Section>
          ) : (
            <Section icon={<Images className="h-7 w-7" />} title="Species image gallery">
              <SpeciesGallery images={data.images} />
            </Section>
          )}

          {data.summary && !genusLevel && (
            <Section icon={<BookOpen className="h-7 w-7" />} title="Species dossier · in brief">
              <p className="max-w-3xl text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{data.summary.text}</p>
              <p className="mt-3 text-[1rem] text-[hsl(var(--ink))]">Source: {data.summary.source} ({data.summary.license}). {data.summary.url && <a href={data.summary.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">Open source</a>}</p>
            </Section>
          )}

          <div className="grid gap-6 lg:grid-cols-2">
            <Section icon={<Globe2 className="h-7 w-7" />} title="Geography">
              <p className="text-[1.0625rem] text-[hsl(var(--ink))]">{data.occurrences.total.toLocaleString()} occurrence records in the current source response. Countries with the most records:</p>
              <ul className="mt-3 space-y-2">
                {data.occurrences.countries.map((c) => <li key={c.code} className="grid grid-cols-[minmax(0,9rem)_1fr_auto] items-center gap-3 text-[1.0625rem]"><span className="truncate font-semibold">{countryName(c.code)}</span><span className="h-3 rounded-full bg-[hsl(var(--botanical))]" style={{ width: `${Math.max(4, (c.count / maxCountry) * 100)}%` }} /><span className="tabular-nums">{c.count}</span></li>)}
              </ul>
              <p className="mt-3 text-[1rem] text-[hsl(var(--ink))]">Occurrence density reflects collection and reporting effort as well as biology.</p>
            </Section>

            <Section icon={<Mountain className="h-7 w-7" />} title="Elevation & record season">
              {data.elevation ? <p className="text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">Most sampled records with elevation fall between <strong>{Math.round(data.elevation.low)} m</strong> and <strong>{Math.round(data.elevation.high)} m</strong> (median about {Math.round(data.elevation.median)} m; n={data.elevation.n}).</p> : <p className="text-[1.125rem]">Too few records report elevation to summarize it honestly.</p>}
              {data.occurrences.months.length > 0 && <><p className="mt-4 font-ui text-[1.0625rem] font-bold">Month each record was made</p><div className="mt-2 flex h-32 items-end gap-1" aria-hidden="true">{MONTHS.map((m, i) => { const v=data.occurrences.months.find((x)=>x.month===i+1)?.count??0; return <div key={m} className="flex flex-1 flex-col items-center gap-1"><div className="w-full rounded-t bg-[hsl(var(--moss))]" style={{height:`${(v/maxMonth)*100}px`}}/><span className="font-ui text-[0.95rem]">{m.charAt(0)}</span></div>; })}</div><p className="mt-2 text-[1rem]">Record month is not automatically flowering season.</p></>}
            </Section>
          </div>

          <Section id="atlas" icon={<Globe2 className="h-7 w-7" />} title="Atlas">
            <AtlasMap taxonKey={t.key} taxonName={t.name} initial={data.view} />
          </Section>

          <Section icon={<ExternalLink className="h-7 w-7" />} title="Evidence & deeper routes">
            <ul className="space-y-3 text-[1.125rem]">
              <li><a href={t.gbifUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">Taxonomy and occurrence source record (GBIF)</a></li>
              {profile && <li><Link to={profilePath(profile.id)} className="font-semibold text-[hsl(var(--botanical))] underline">Culture, AOS links and claim-level evidence review</Link></li>}
              <li><Link to={`/expert-review?profile=${encodeURIComponent(profile?.id ?? '')}`} className="font-semibold text-[hsl(var(--botanical))] underline">Review or qualify an evidence claim</Link></li>
              <li className="text-[hsl(var(--ink))]"><strong>Orchid Continuum:</strong> {data.continuum.status === 'connected' ? `Connected for ${data.continuum.genus ?? t.name}.` : 'Deeper Continuum composition is not configured in this public data service yet; unavailable layers remain explicitly unavailable.'}</li>
            </ul>
            <p className="mt-4 text-[1rem] text-[hsl(var(--ink))]">Data retrieved {new Date(data.retrievedAt).toLocaleDateString()}.</p>
          </Section>
        </div>
      )}
    </div>
  );
};

export default OrchidExplorerPage;
