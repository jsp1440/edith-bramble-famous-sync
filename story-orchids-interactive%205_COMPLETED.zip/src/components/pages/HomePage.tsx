import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen } from 'lucide-react';
import { site, chronicles, getMedia, chroniclePath } from '@/lib/content';
import { Flourish, Kicker, SectionHeading } from '@/components/site/Ornaments';
import ChronicleCard from '@/components/site/ChronicleCard';

const HomePage: React.FC = () => {
  const hero = getMedia('c2-cover') || getMedia(site.heroImage);
  const featured = chronicles.filter((c) => c.status === 'live');
  const nav = site.primaryNav || [];


  return (
    <>
      <section className="relative isolate overflow-hidden border-b border-border/70">
        {hero && (
          <>
            <img
              src={hero.src}
              alt=""
              aria-hidden="true"
              className="absolute inset-0 h-full w-full object-cover"
              decoding="async"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[hsl(150_14%_10%)]/85 via-[hsl(150_12%_12%)]/72 to-[hsl(30_12%_12%)]/90" />
            <div className="fog-drift pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_30%_75%,hsl(40_30%_88%/0.24),transparent_62%)]" />
          </>
        )}
        <div className="relative mx-auto max-w-4xl px-4 py-24 text-center sm:px-6 sm:py-32 lg:px-8">
          <Kicker className="!text-[hsl(36_60%_72%)]">{site.org}</Kicker>
          <h1 className="mt-4 font-display text-5xl font-semibold leading-[1.05] text-[hsl(42_40%_95%)] sm:text-6xl lg:text-7xl">
            {site.title}
          </h1>
          <p className="mt-3 font-display text-2xl italic text-[hsl(36_50%_78%)] sm:text-3xl">{site.subtitle}</p>
          {site.heroLine && (
            <p className="mx-auto mt-8 max-w-2xl font-display text-xl italic leading-relaxed text-[hsl(42_30%_90%)] sm:text-2xl">
              “{site.heroLine}”
            </p>
          )}
          <p className="mx-auto mt-6 max-w-2xl text-xl leading-relaxed text-[hsl(42_40%_95%)]">
            {site.heroIntro}
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href="#story-cards"
              className="inline-flex min-h-[56px] items-center gap-2 rounded-md bg-[hsl(var(--cream))] px-8 font-ui text-lg font-semibold text-[hsl(145_34%_15%)] transition-transform hover:-translate-y-0.5"
            >
              <BookOpen className="h-5 w-5" aria-hidden="true" />
              Read the Chronicles
            </a>
            <Link
              to="/greenhouse"
              className="inline-flex min-h-[56px] items-center gap-2 rounded-md border-2 border-[hsl(42_40%_92%)] px-8 font-ui text-lg font-semibold text-[hsl(42_45%_96%)] transition-colors hover:bg-[hsl(42_30%_92%)]/15"
            >
              Enter Edith's Greenhouse
            </Link>
          </div>
        </div>
      </section>

      {/* Two prominent story cards */}
      <section id="story-cards" className="scroll-mt-20 border-b border-border/70 bg-[hsl(var(--charcoal))]">
        <div className="mx-auto grid max-w-6xl gap-6 px-4 py-14 sm:px-6 md:grid-cols-2 lg:px-8">
          {featured.map((c) => {
            const cover = getMedia(c.cover);
            return (
              <Link
                key={c.id}
                to={chroniclePath(c.slug)}
                className="group relative isolate flex min-h-[22rem] flex-col justify-end overflow-hidden rounded-sm border border-[hsl(42_30%_85%)]/20"
              >
                {cover && (
                  <img src={cover.src} alt="" aria-hidden="true" className="absolute inset-0 -z-10 h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
                )}
                <div className="absolute inset-0 -z-10 bg-gradient-to-t from-[hsl(30_14%_8%)]/95 via-[hsl(30_14%_8%)]/55 to-transparent" />
                <div className="m-3 rounded-md bg-[hsl(150_20%_6%)]/90 p-6 sm:m-4 sm:p-7">
                  <p className="font-label text-[1.0625rem] uppercase text-[hsl(44_70%_80%)]">Chronicle {c.number} · {c.readingTime}</p>
                  <h2 className="mt-2 font-display text-3xl font-semibold leading-tight text-[hsl(42_50%_97%)] sm:text-4xl">{c.title}</h2>
                  <p className="mt-3 max-w-md text-xl leading-relaxed text-[hsl(42_40%_95%)]">
                    {c.id === 'chronicle-i'
                      ? 'A Halloween night. A wet greenhouse. A curse in the fog. The story that began it all.'
                      : c.summary}
                  </p>
                  <span className="mt-5 inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--cream))] px-6 font-ui text-lg font-semibold text-[hsl(145_34%_15%)]">
                    <BookOpen className="h-5 w-5" aria-hidden="true" /> Read Chronicle {c.number}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Explore after reading */}
      <section className="border-b-2 border-[hsl(var(--charcoal))]/15 bg-[hsl(var(--cream))]">
        <nav aria-label="Explore after reading" className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
          <Kicker className="mb-4">Explore after reading</Kicker>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {nav.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="group flex h-full items-start justify-between gap-3 rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white px-5 py-4 shadow-sm transition-colors hover:border-[hsl(var(--botanical))]"
                >
                  <span>
                    <span className="block font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{item.label}</span>
                    <span className="mt-1 block text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">{item.blurb}</span>
                  </span>
                  <ArrowRight className="mt-1 h-5 w-5 shrink-0 text-[hsl(var(--botanical))] transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </section>


      {/* Three levels */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <SectionHeading
          kicker="Read it at whatever depth you like"
          title="One greenhouse, three ways in"
          subtitle="Nothing educational is ever forced into the path of the story. The doors are there if you want them."
          align="center"
        />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[
            { level: 'Level one', title: 'Story', body: 'An atmospheric botanical mystery. Read it start to finish and never open a single door.', to: '/library', cta: 'Read the Chronicles' },
            { level: 'Level two', title: 'Grower', body: 'Watering, light, airflow, roots, pests and disease — the practical craft behind every scene.', to: '/notebook', cta: "The Grower's Notebook" },
            { level: 'Level three', title: 'Science', body: 'Anatomy, physiology, pathology, mycorrhizae, pollination and conservation, at three depths each.', to: '/science', cta: 'Science Behind the Stories' },
          ].map((card) => (
            <div key={card.title} className="flex flex-col rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white p-6 shadow-sm">
              <Kicker>{card.level}</Kicker>
              <h3 className="mt-2 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">{card.title}</h3>
              <p className="mt-2 flex-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{card.body}</p>
              <Link to={card.to} className="mt-5 inline-flex min-h-[48px] items-center gap-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                {card.cta} <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Chronicle cards — data-driven, any number of Chronicles */}
      <section className="border-y-2 border-[hsl(var(--charcoal))]/15 bg-[hsl(40_30%_88%)]">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
          <SectionHeading kicker="The series" title="The Chronicles" align="center" />
          <ul className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {chronicles.map((c) => (
              <li key={c.id}>
                <ChronicleCard c={c} />
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Featured Genus doorway */}
      <section className="mx-auto max-w-6xl px-4 pt-16 sm:px-6 lg:px-8">
        <Link to="/explore" className="group flex flex-col items-start gap-4 rounded-xl border-2 border-[hsl(var(--botanical))] bg-white p-7 shadow-sm sm:flex-row sm:items-center sm:justify-between">
          <span>
            <Kicker>Featured Genus</Kicker>
            <span className="mt-2 block font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Meet the real orchids behind the story</span>
            <span className="mt-2 block text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">Photographs, where each orchid has been documented in the wild, and an interactive Atlas map.</span>
          </span>
          <span className="inline-flex min-h-[52px] shrink-0 items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-6 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">
            Explore the orchids <ArrowRight className="h-5 w-5" aria-hidden="true" />
          </span>
        </Link>
      </section>

      {/* Modules */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:px-8">
        <Flourish className="mb-12" />
        <SectionHeading
          kicker="The whole greenhouse"
          title="Rooms to explore"
          subtitle="Journal, grimoire, bench, clinic, kitchen, studio, herbarium, plates, cabinet and more."
          align="center"
        />
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {site.modules.map((mod) => (
            <Link
              key={mod.id}
              to={mod.path}
              className="group flex flex-col rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white p-6 shadow-sm transition-all hover:-translate-y-0.5 hover:border-[hsl(var(--botanical))]"
            >
              <Kicker>{mod.group}</Kicker>
              <h3 className="mt-2 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{mod.title}</h3>
              <p className="mt-2 flex-1 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">{mod.blurb}</p>
              <span className="mt-4 inline-flex items-center gap-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                Open
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 pb-20 sm:px-6 lg:px-8">
        <div className="eb-panel-green rounded-lg p-8 text-center shadow-lg sm:p-12">
          <Kicker>{site.fcos.name}</Kicker>
          <p className="mx-auto mt-5 max-w-2xl text-xl leading-relaxed">
            {site.fcos.about[1]}
          </p>
          <p className="mt-6 font-display text-3xl italic text-[hsl(44_70%_84%)]">“{site.fcos.talisman}”</p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link
              to="/fcos"
              className="eb-btn-cream inline-flex min-h-[52px] items-center rounded-md px-6 font-ui text-lg font-semibold"
            >
              Join the Society
            </Link>
            <Link
              to="/about"
              className="inline-flex min-h-[52px] items-center rounded-md border-2 border-[hsl(42_45%_95%)] px-6 font-ui text-lg font-semibold text-[hsl(42_45%_95%)] hover:bg-white/10"
            >
              About the Society
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
