import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, BookOpen, Bookmark, BookmarkCheck, Check, RotateCcw } from 'lucide-react';
import { getChronicle, getMedia, getStory } from '@/lib/content';
import type { StoryBlock } from '@/lib/content-types';
import { useDiscovery } from '@/contexts/DiscoveryContext';
import DiscoveryDrawer from '@/components/story/DiscoveryDrawer';
import GrowerCardDialog from '@/components/story/GrowerCardDialog';
import ScienceDrawer from '@/components/science/ScienceDrawer';
import C2StoryFlow from '@/components/c2/C2StoryFlow';
import { Fog, SceneHeading } from '@/components/c1/Atmosphere';
import { useReducedMotion, useScrollProgress } from '@/components/c1/c1-hooks';
import { Flourish, Kicker, Notice } from '@/components/site/Ornaments';
import { ReadingViewToggle } from '@/components/site/ReadingControls';

interface Chapter {
  number: number;
  label: string;
  title: string;
  blocks: StoryBlock[];
}

interface Progress {
  read: number[];
  last?: { chapter: number; y: number };
}

const KEY = 'eb-chronicle-ii-progress';
/** Cinematic opener art for each chapter (ids in media JSON). */
const CHAPTER_ART = ['c2-cover', 'c2-zone-map', 'c2-lathhouse', 'c2-hazel-glass', 'c2-halloween'];

function loadProgress(): Progress {
  try {
    return JSON.parse(localStorage.getItem(KEY) || '{"read":[]}');
  } catch {
    return { read: [] };
  }
}

function saveProgress(p: Progress) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}

function splitChapters(blocks: StoryBlock[]): Chapter[] {
  const chapters: Chapter[] = [];
  blocks.forEach((b) => {
    if (b.type === 'heading' && b.text.startsWith('Chapter')) {
      const [label, ...rest] = b.text.split('—');
      chapters.push({ number: chapters.length + 1, label: label.trim(), title: rest.join('—').trim(), blocks: [] });
    } else if (chapters.length) {
      chapters[chapters.length - 1].blocks.push(b);
    }
  });
  return chapters;
}

/** Full-screen opener: the scene emerges from fog as the title settles. */
const Opener: React.FC<{ art: string; kicker: string; title: string; sub: string; children?: React.ReactNode }> = ({ art, kicker, title, sub, children }) => {
  const img = getMedia(art);
  const [ref, p] = useScrollProgress<HTMLElement>();
  const reduced = useReducedMotion();
  return (
    <header ref={ref} className="relative isolate h-[92svh] min-h-[520px] overflow-hidden bg-[hsl(210_14%_8%)]">
      {img && (
        <img
          src={img.src}
          alt={img.alt}
          className={`absolute inset-0 h-full w-full object-cover ${reduced ? '' : 'c1-breathe'}`}
          style={{ filter: `brightness(${0.62 - p * 0.2})`, transform: reduced ? undefined : `translateY(${p * 8}%)` }}
        />
      )}
      <Fog density={0.55} />
      <div className="absolute inset-0 bg-gradient-to-b from-[hsl(210_14%_8%)]/60 via-transparent to-[hsl(40_33%_94%)]" />
      <div className="relative flex h-full flex-col items-center justify-center px-4 pb-16 text-center">
        {/* Solid reading panel so the title never sits directly on the painting */}
        <div className="max-w-3xl rounded-xl bg-[hsl(210_22%_6%)]/78 px-6 py-8 shadow-2xl backdrop-blur-sm sm:px-10 sm:py-10">
          <Kicker className="!text-[hsl(44_70%_80%)]">{kicker}</Kicker>
          <div className="mt-4">
            <SceneHeading>{title}</SceneHeading>
          </div>
          <p className="mt-3 font-display text-2xl italic text-[hsl(42_45%_94%)] sm:text-3xl">{sub}</p>
          {children}
        </div>
      </div>
    </header>
  );
};

const ChapteredChroniclePage: React.FC = () => {
  const chronicle = getChronicle('chronicle-ii');
  const story = getStory(chronicle);
  const chapters = useMemo(() => splitChapters(story?.blocks || []), [story]);
  const [params, setParams] = useSearchParams();
  const current = Math.min(Math.max(Number(params.get('chapter')) || 0, 0), chapters.length);
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [grower, setGrower] = useState<string | null>(null);
  const [active, setActive] = useState<string | null>(null);
  const [science, setScience] = useState<string | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);
  const { discover } = useDiscovery();
  const endRef = useRef<HTMLDivElement>(null);
  const pendingScroll = useRef<number | null>(null);

  const onDiscover = useCallback(
    (id: string) => {
      discover(id);
      setActive(id);
    },
    [discover],
  );

  const goTo = (n: number, y?: number) => {
    pendingScroll.current = y ?? null;
    setParams(n ? { chapter: String(n) } : {});
  };

  const savePlace = () => {
    if (!current) return;
    setProgress((p) => {
      const next = { ...p, last: { chapter: current, y: window.scrollY } };
      saveProgress(next);
      return next;
    });
    setSavedFlash(true);
    window.setTimeout(() => setSavedFlash(false), 2000);
  };

  useEffect(() => {
    const y = pendingScroll.current;
    pendingScroll.current = null;
    window.setTimeout(() => window.scrollTo({ top: y ?? 0, behavior: 'auto' }), 30);
  }, [current]);

  // Remember reading position automatically
  useEffect(() => {
    if (!current) return;
    let t: number | undefined;
    const onScroll = () => {
      window.clearTimeout(t);
      t = window.setTimeout(() => {
        setProgress((p) => {
          const next = { ...p, last: { chapter: current, y: window.scrollY } };
          saveProgress(next);
          return next;
        });
      }, 500);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.clearTimeout(t);
    };
  }, [current]);

  useEffect(() => {
    const el = endRef.current;
    if (!el || !current) return;
    const io = new IntersectionObserver((entries) => {
      if (entries.some((e) => e.isIntersecting)) {
        setProgress((p) => {
          if (p.read.includes(current)) return p;
          const next = { ...p, read: [...p.read, current] };
          saveProgress(next);
          return next;
        });
      }
    });
    io.observe(el);
    return () => io.disconnect();
  }, [current]);

  if (!chronicle || !story) return null;
  const chapter = current ? chapters[current - 1] : null;
  const pct = Math.round((progress.read.length / chapters.length) * 100);
  const navBtn = (on: boolean) =>
    `inline-flex min-h-[44px] shrink-0 items-center gap-1.5 rounded-md px-3 font-ui text-[1.0625rem] font-semibold ${
      on ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10'
    }`;

  return (
    <article className="overflow-x-clip bg-[hsl(40_33%_94%)]">
      {chapter ? (
        <Opener art={CHAPTER_ART[current - 1] || 'c2-cover'} kicker={`Chronicle II · ${chapter.label} of Five`} title={chapter.title} sub={chronicle.title} />
      ) : (
        <Opener art="c2-cover" kicker={`Chronicle ${chronicle.number} · ${chronicle.season}`} title={chronicle.title} sub={chronicle.subtitle}>
          {story.frontmatter.epigraph && (
            <>
              <Flourish className="my-6" />
              <blockquote className="mx-auto max-w-xl font-display text-2xl italic leading-relaxed text-[hsl(42_45%_95%)]">
                “{story.frontmatter.epigraph}”
                <footer className="mt-3 font-ui text-lg font-semibold not-italic text-[hsl(44_70%_80%)]">— {story.frontmatter.epigraphSource}</footer>
              </blockquote>
            </>
          )}
        </Opener>
      )}

      <nav aria-label="Chapters" className="eb-below-header no-print sticky z-30 border-b-2 border-border bg-[hsl(var(--cream))]">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-2 px-4 py-2 sm:px-6">
          <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto">
            <button type="button" onClick={() => goTo(0)} className={navBtn(!current)}>
              Contents
            </button>
            {chapters.map((c) => (
              <button key={c.number} type="button" onClick={() => goTo(c.number)} aria-current={current === c.number ? 'page' : undefined} aria-label={`${c.label}${progress.read.includes(c.number) ? ' (read)' : ''}`} className={navBtn(current === c.number)}>
                {progress.read.includes(c.number) && <Check className="h-4 w-4" aria-hidden="true" />}
                {c.label.replace('Chapter ', 'Ch. ')}
              </button>
            ))}
          </div>
          <span className="flex shrink-0 flex-wrap items-center gap-2">
            <ReadingViewToggle className="!shadow-none" />
            {current > 0 && (
              <button type="button" onClick={savePlace} className="inline-flex min-h-[48px] items-center gap-1.5 rounded-md border-2 border-border px-3 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10">
                {savedFlash ? <BookmarkCheck className="h-5 w-5" aria-hidden="true" /> : <Bookmark className="h-5 w-5" aria-hidden="true" />}
                {savedFlash ? 'Saved' : 'Save my place'}
              </button>
            )}
            <span className="eb-rv-hide hidden items-center gap-2 lg:flex">
              <span className="h-2 w-20 overflow-hidden rounded-full bg-border" aria-hidden="true">
                <span className="block h-full bg-[hsl(var(--botanical))]" style={{ width: `${pct}%` }} />
              </span>
              <span className="font-ui text-[1.0625rem] font-semibold text-[hsl(var(--moss))]">{progress.read.length}/5 read</span>
            </span>
          </span>
        </div>
      </nav>

      {!chapter ? (
        <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 sm:py-16">
          <p className="mx-auto max-w-2xl text-center font-display text-2xl italic leading-relaxed text-[hsl(var(--botanical))]">{chronicle.summary}</p>
          <p className="mx-auto mt-4 max-w-xl text-center font-label text-[0.6rem] uppercase tracking-[0.2em] text-[hsl(var(--moss))]">There is no single autumn for every orchid.</p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            {progress.last && (
              <button
                type="button"
                onClick={() => goTo(progress.last!.chapter, progress.last!.y)}
                className="inline-flex min-h-[46px] items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-6 py-3 font-label text-[0.62rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
              >
                <RotateCcw className="h-4 w-4" aria-hidden="true" />
                Continue reading · {chapters[progress.last.chapter - 1]?.label}
              </button>
            )}
            <button
              type="button"
              onClick={() => goTo(1)}
              className={`inline-flex min-h-[46px] items-center gap-2 rounded-sm px-6 py-3 font-label text-[0.62rem] uppercase ${
                progress.last ? 'border border-border text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8' : 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]'
              }`}
            >
              <BookOpen className="h-4 w-4" aria-hidden="true" />
              {progress.last ? 'Start from Chapter One' : 'Begin Chapter One'}
            </button>
          </div>

          <div className="mx-auto mt-10 max-w-2xl">
            <Notice tone="fiction" title="A note on this text" body={story.frontmatter.notice} />
          </div>

          <ol className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {chapters.map((c) => {
              const img = getMedia(CHAPTER_ART[c.number - 1]);
              const read = progress.read.includes(c.number);
              return (
                <li key={c.number}>
                  <button type="button" onClick={() => goTo(c.number)} className="group flex h-full w-full flex-col overflow-hidden rounded-sm border border-border/80 bg-[hsl(var(--cream))] text-left transition-transform hover:-translate-y-0.5">
                    <span className="relative block aspect-[4/3] overflow-hidden bg-muted">
                      {img && <img src={img.src} alt="" aria-hidden="true" loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />}
                      {read && (
                        <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-sm bg-[hsl(var(--botanical))] px-2 py-0.5 font-label text-[0.48rem] uppercase text-[hsl(var(--cream))]">
                          <Check className="h-3 w-3" aria-hidden="true" /> Read
                        </span>
                      )}
                    </span>
                    <span className="flex flex-1 flex-col p-4">
                      <span className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">{c.label}</span>
                      <span className="mt-1 font-display text-lg font-semibold leading-tight text-[hsl(var(--charcoal))]">{c.title}</span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
        </div>
      ) : (
        <div className="mx-auto max-w-2xl px-5 py-10 sm:px-6 sm:py-14">
          <C2StoryFlow blocks={chapter.blocks} onDiscover={onDiscover} onGrower={setGrower} onScience={setScience} />
          <div ref={endRef} className="h-px" aria-hidden="true" />

          <div className="no-print clear-both mt-14 flex flex-wrap items-center justify-between gap-3 border-t border-border/70 pt-6">
            {current > 1 ? (
              <button type="button" onClick={() => goTo(current - 1)} className="inline-flex min-h-[44px] items-center gap-2 rounded-sm border border-border px-4 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8">
                <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" /> {chapters[current - 2].label}
              </button>
            ) : (
              <span />
            )}
            {current < chapters.length ? (
              <button type="button" onClick={() => goTo(current + 1)} className="inline-flex min-h-[44px] items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
                {chapters[current].label} <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </button>
            ) : (
              <button type="button" onClick={() => goTo(0)} className="min-h-[44px] rounded-sm border border-border px-4 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
                Back to contents
              </button>
            )}
          </div>
        </div>
      )}

      {current === chapters.length && chapter && (
        <section className="relative overflow-hidden bg-[hsl(215_18%_8%)] py-24 text-center" aria-label="End of Chronicle II">
          <Fog density={0.5} />
          <div className="eb-panel-green relative mx-auto max-w-3xl rounded-lg px-6 py-12 shadow-2xl sm:px-12">
            <Kicker>The End of Chronicle II</Kicker>
            <p className="mt-4 font-display text-4xl font-semibold italic text-[hsl(42_50%_97%)] sm:text-5xl">Hazel wanted the greenhouse perfect. Edith wanted it alive.</p>
            <p className="mt-6 text-xl font-semibold text-[hsl(44_70%_82%)]">There is no single autumn for every orchid.</p>
            <div className="no-print mt-10 flex flex-wrap justify-center gap-3">
              <Link to="/science/orchids" className="eb-btn-cream inline-flex min-h-[52px] items-center gap-2 rounded-md px-6 font-ui text-lg font-semibold">
                Why does this orchid do that? <ArrowRight className="h-5 w-5" aria-hidden="true" />
              </Link>
              <Link to="/greenhouse" className="inline-flex min-h-[52px] items-center rounded-md border-2 border-[hsl(42_45%_95%)] px-6 font-ui text-lg font-semibold text-[hsl(42_45%_95%)] hover:bg-white/10">
                Visit Edith's greenhouse
              </Link>
              <Link to="/chronicle-1" className="inline-flex min-h-[52px] items-center rounded-md border-2 border-[hsl(42_45%_95%)] px-6 font-ui text-lg font-semibold text-[hsl(42_45%_95%)] hover:bg-white/10">
                Back to Chronicle I
              </Link>
            </div>
          </div>
        </section>
      )}

      {(current === chapters.length || !chapter) && (
        <section className="no-print border-t border-border/70 bg-[hsl(var(--cream))]">
          <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
            <div className="eb-panel-green rounded-lg p-7 sm:p-10">
              <Kicker>Explore after reading</Kicker>
              <h2 className="mt-3 font-display text-4xl font-semibold">Science Behind Chronicle II</h2>
              <p className="mt-4 max-w-2xl text-xl leading-relaxed">
                Hazel's magic is fiction. The mistake she makes — giving every orchid the same autumn — is real, and the cure in the story is ordinary horticulture. Everything below is optional.
              </p>
            </div>
            <ul className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {[
                { to: '/science/orchids', t: 'The Science Greenhouse', b: 'Why does this orchid do that? Habitat, adaptation, Read the Plant.' },
                { to: '/greenhouse/walk', t: "Edith's Greenhouse Zones", b: 'Tap each microclimate in one greenhouse.' },
                { to: '/greenhouse/compare', t: 'Why Are These Orchids Neighbors?', b: 'Environmental fit, not name or continent.' },
                { to: '/grow', t: 'Culture Cards & Root Viewer', b: 'Catasetinae, Phragmipedium, two Dendrobiums, Lycaste and more.' },
                { to: '/diagnostic-bench', t: "Mara's Diagnostic Bench", b: 'Symptoms are evidence — plus Orchid Detective.' },
                { to: '/color', t: 'Coloring Greenhouse', b: 'Printable pages and the Autumn Orchid Check.' },
                { to: '/kitchen', t: 'Autumn Kitchen', b: "Including Theo's apple-blackberry tart." },
                { to: '/characters', t: 'Characters', b: 'Everyone at the potting bench.' },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="block h-full rounded-sm border border-border/80 bg-background p-4 hover:border-[hsl(var(--botanical))]/60">
                    <span className="font-display text-lg font-semibold text-[hsl(var(--charcoal))]">{l.t}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{l.b}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <GrowerCardDialog cardId={grower} onClose={() => setGrower(null)} />
      <DiscoveryDrawer discoveryId={active} onClose={() => setActive(null)} />
      <ScienceDrawer id={science} onClose={() => setScience(null)} />

    </article>
  );
};

export default ChapteredChroniclePage;
