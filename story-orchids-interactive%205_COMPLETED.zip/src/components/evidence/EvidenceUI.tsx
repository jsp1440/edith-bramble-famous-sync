import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, HelpCircle, ImageOff, Unplug, MessageSquarePlus } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { supabase } from '@/lib/supabase';
import type { Claim, ClaimReviewState, EvidenceClass, ImageProvenance } from '@/lib/evidence-types';
import type { OrchidProfile } from '@/lib/orchid-types';
import {
  AOS_INDEX,
  CONFIDENCE_LABEL,
  EVIDENCE_CLASS_LABEL,
  REVIEW_STATE_LABEL,
  aosSheetsFor,
  hasScientificProvenance,
  profileStatus,
} from '@/lib/evidence';
import { ocConnection } from '@/lib/orchid-continuum';

/* ---------------- badges ---------------- */

const stateTone: Record<ClaimReviewState, string> = {
  draft: 'bg-[hsl(40_60%_88%)] text-[hsl(30_60%_20%)] border-[hsl(30_50%_40%)]',
  'source-checked': 'bg-[hsl(150_30%_88%)] text-[hsl(150_45%_16%)] border-[hsl(150_40%_28%)]',
  'expert-reviewed': 'bg-[hsl(150_40%_20%)] text-[hsl(44_60%_94%)] border-[hsl(150_40%_20%)]',
  disputed: 'bg-[hsl(0_60%_92%)] text-[hsl(0_60%_25%)] border-[hsl(0_50%_35%)]',
  'evidence-pending': 'bg-[hsl(44_30%_92%)] text-[hsl(30_20%_14%)] border-[hsl(30_20%_30%)] border-dashed',
};

export const ReviewBadge: React.FC<{ state: ClaimReviewState; className?: string }> = ({ state, className = '' }) => (
  <span className={`inline-flex items-center rounded-md border-2 px-2.5 py-0.5 font-ui text-[1rem] font-bold uppercase tracking-wide ${stateTone[state]} ${className}`}>
    {REVIEW_STATE_LABEL[state]}
  </span>
);

const classTone: Record<EvidenceClass, string> = {
  'published-science': 'border-[hsl(210_50%_30%)] text-[hsl(210_55%_22%)]',
  'horticultural-guidance': 'border-[hsl(150_40%_28%)] text-[hsl(150_45%_18%)]',
  'botanical-database': 'border-[hsl(260_30%_35%)] text-[hsl(260_35%_25%)]',
  'field-observation': 'border-[hsl(180_35%_28%)] text-[hsl(180_40%_18%)]',
  'grower-experience': 'border-[hsl(30_55%_35%)] text-[hsl(30_60%_22%)]',
  'fcos-interpretation': 'border-[hsl(96_30%_30%)] text-[hsl(96_35%_18%)]',
  'oc-inference': 'border-[hsl(300_25%_35%)] text-[hsl(300_30%_24%)]',
  unverified: 'border-dashed border-[hsl(30_20%_30%)] text-[hsl(30_20%_14%)]',
};

export const ClassBadge: React.FC<{ cls: EvidenceClass }> = ({ cls }) => (
  <span className={`inline-flex items-center rounded-md border-2 bg-white/70 px-2.5 py-0.5 font-ui text-[1rem] font-semibold ${classTone[cls]}`}>
    {EVIDENCE_CLASS_LABEL[cls].label}
  </span>
);

export const EvidencePending: React.FC<{ label?: string; children?: React.ReactNode }> = ({ label = 'Evidence pending', children }) => (
  <div className="rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] px-5 py-4">
    <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(30_25%_14%)]">{label}</p>
    {children && <div className="mt-1.5 text-[1.125rem] leading-relaxed text-[hsl(30_20%_14%)]">{children}</div>}
  </div>
);

/* ---------------- claim-level provenance ---------------- */

export const ClaimIndicator: React.FC<{ claim: Claim; profileName?: string }> = ({ claim, profileName }) => (
  <Popover>
    <PopoverTrigger asChild>
      <button
        type="button"
        aria-label="What supports this statement?"
        title="What supports this?"
        className={`ml-1.5 inline-flex h-7 w-7 translate-y-[-1px] items-center justify-center rounded-full border-2 align-middle transition-colors hover:bg-[hsl(var(--botanical))] hover:text-[hsl(var(--cream))] ${
          claim.sources.length ? 'border-[hsl(var(--botanical))] text-[hsl(var(--botanical))]' : 'border-dashed border-[hsl(30_20%_35%)] text-[hsl(30_20%_20%)]'
        }`}
      >
        <HelpCircle className="h-4 w-4" aria-hidden="true" />
      </button>
    </PopoverTrigger>
    <PopoverContent className="w-[min(92vw,30rem)] border-2 border-[hsl(var(--botanical))]/40 bg-[hsl(var(--cream))] p-5 text-[hsl(var(--ink))]">
      <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">What supports this?</p>
      <p className="mt-2 text-[1.0625rem] italic leading-relaxed">“{claim.text}”</p>
      <dl className="mt-4 grid gap-3 text-[1.0625rem]">
        <div>
          <dt className="font-semibold">Source type</dt>
          <dd className="mt-1"><ClassBadge cls={claim.evidenceClass} /></dd>
        </div>
        <div>
          <dt className="font-semibold">Source</dt>
          <dd className="mt-1">
            {claim.sources.length ? (
              <ul className="space-y-2">
                {claim.sources.map((s, i) => (
                  <li key={i}>
                    <span className="block">{s.citation}</span>
                    {s.context && <span className="block text-[1rem]">Context: {s.context}</span>}
                    {s.url && <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline">Open source</a>}
                    {s.doi && <a href={`https://doi.org/${s.doi}`} target="_blank" rel="noopener noreferrer" className="ml-3 underline">DOI {s.doi}</a>}
                  </li>
                ))}
              </ul>
            ) : (
              <span className="font-bold uppercase">Source needed</span>
            )}
          </dd>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          <div><dt className="font-semibold">Confidence</dt><dd>{CONFIDENCE_LABEL[claim.confidence]}</dd></div>
          <div><dt className="font-semibold">Review state</dt><dd>{REVIEW_STATE_LABEL[claim.reviewState]}</dd></div>
          <div><dt className="font-semibold">Last reviewed</dt><dd>{claim.lastReviewed ?? 'Not yet reviewed'}</dd></div>
        </div>
        {claim.origin === 'ai-assisted' && !claim.sources.length && (
          <p className="rounded-md bg-[hsl(44_30%_92%)] px-3 py-2 text-[1rem]">This draft wording was prepared with AI assistance and has not yet been checked against a source.</p>
        )}
      </dl>
      <div className="mt-4 flex flex-wrap gap-2">
        <Link to={`/expert-review?claim=${encodeURIComponent(claim.id)}`} className="inline-flex min-h-[44px] items-center gap-1.5 rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
          <MessageSquarePlus className="h-4 w-4" aria-hidden="true" /> Review this claim
        </Link>
        <Link to={`/report-evidence?claim=${encodeURIComponent(claim.id)}${profileName ? `&profile=${claim.profileId}` : ''}`} className="inline-flex min-h-[44px] items-center rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--botanical))]">
          Report / add evidence
        </Link>
      </div>
    </PopoverContent>
  </Popover>
);

/** Statement text followed by a discreet evidence indicator. */
export const ClaimText: React.FC<{ claim?: Claim; children: React.ReactNode }> = ({ claim, children }) => (
  <>
    {children}
    {claim && <ClaimIndicator claim={claim} />}
  </>
);

/* ---------------- AOS guidance (kept separate from FCOS interpretation) ---------------- */

export const AosGuidance: React.FC<{ profile: OrchidProfile }> = ({ profile }) => {
  const sheets = aosSheetsFor(profile.id);
  return (
    <section className="rounded-md border-2 border-[hsl(var(--botanical))] bg-white/60 p-5 sm:p-6" aria-labelledby={`aos-${profile.id}`}>
      <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Culture guidance</p>
      <h3 id={`aos-${profile.id}`} className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">American Orchid Society</h3>
      {sheets.length ? (
        <ul className="mt-4 space-y-4">
          {sheets.map((s) => (
            <li key={s.url} className="border-l-4 border-[hsl(var(--botanical))] pl-4">
              <p className="text-[1.1875rem] font-semibold text-[hsl(var(--charcoal))]">{s.title}</p>
              <p className="mt-1 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
                <strong>Scope:</strong> {s.scopeNote}
              </p>
              <a href={s.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
                Read the American Orchid Society culture sheet <ExternalLink className="h-4 w-4" aria-hidden="true" />
              </a>
              <p className="mt-1 text-[1rem] text-[hsl(var(--ink))]">Link confirmed on aos.org {s.verifiedOn}. Content belongs to the AOS and is not reproduced here.</p>
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-4">
          <EvidencePending label="No AOS culture sheet linked">
            No culture sheet for this group appears on the{' '}
            <a href={AOS_INDEX} target="_blank" rel="noopener noreferrer" className="underline">AOS culture-sheet index</a>. We do not
            substitute a sheet written for a different genus.
          </EvidencePending>
        </div>
      )}
    </section>
  );
};

/* ---------------- profile status (never invented counts) ---------------- */

export interface AcceptedReview {
  id: string;
  claim_id: string | null;
  claim_text: string | null;
  response: string;
  comment: string | null;
  suggested_wording: string | null;
  source_url: string | null;
  doi: string | null;
  citation: string | null;
  taxon_group: string | null;
  growing_environment: string | null;
  geographic_context: string | null;
  reviewer_name: string | null;
  reviewer_expertise: string[] | null;
  created_at: string;
  reviewed_at: string | null;
}

export const RESPONSE_LABEL: Record<string, string> = {
  agree: 'Agrees',
  'agree-qualified': 'Agrees with qualification',
  disagree: 'Disagrees',
  'needs-evidence': 'Needs evidence',
  'add-source': 'Added a source',
  'add-grower-observation': 'Added a grower observation',
  'report-error': 'Reported an error',
};

export const useAcceptedReviews = (profileId: string) => {
  const [reviews, setReviews] = useState<AcceptedReview[] | null>(null);
  const [error, setError] = useState(false);
  useEffect(() => {
    let alive = true;
    supabase.rpc('public_accepted_reviews', { p_profile: profileId }).then(({ data, error: e }) => {
      if (!alive) return;
      if (e) setError(true);
      setReviews((data as AcceptedReview[]) ?? []);
    });
    return () => {
      alive = false;
    };
  }, [profileId]);
  return { reviews, error };
};

export const ProfileStatusPanel: React.FC<{ profile: OrchidProfile; reviews: AcceptedReview[] | null }> = ({ profile, reviews }) => {
  const st = profileStatus(profile);
  const counts = (reviews ?? []).reduce<Record<string, number>>((acc, r) => ({ ...acc, [r.response]: (acc[r.response] || 0) + 1 }), {});
  const reviewers = new Set((reviews ?? []).map((r) => r.reviewer_name || r.id)).size;
  return (
    <aside className="rounded-md bg-[hsl(var(--botanical))] p-5 text-[hsl(44_50%_95%)] sm:p-6" aria-label="Review status">
      <div className="flex flex-wrap items-center gap-3">
        <p className="font-ui text-[1rem] font-bold uppercase tracking-wide">Profile status</p>
        <ReviewBadge state={st.state} />
        <span className="rounded-md border-2 border-[hsl(44_50%_90%)] px-2.5 py-0.5 font-ui text-[1rem] font-semibold">FCOS curated draft</span>
      </div>
      <dl className="mt-4 grid gap-x-6 gap-y-3 text-[1.0625rem] sm:grid-cols-2 lg:grid-cols-3">
        <div><dt className="font-semibold">Sources attached</dt><dd>{st.sourcesAttached || 'None yet — source needed'}</dd></div>
        <div><dt className="font-semibold">Statements source-checked</dt><dd>{st.sourceChecked} of {st.claims}</dd></div>
        <div><dt className="font-semibold">Statements awaiting evidence</dt><dd>{st.pending}</dd></div>
        <div>
          <dt className="font-semibold">Expert reviewers</dt>
          <dd>{reviews === null ? 'Loading…' : reviewers ? reviewers : 'Expert review pending'}</dd>
        </div>
        {reviewers > 0 && (
          <div className="sm:col-span-2">
            <dt className="font-semibold">Accepted reviewer responses</dt>
            <dd>{Object.entries(counts).map(([k, n]) => `${n} ${RESPONSE_LABEL[k]?.toLowerCase() ?? k}`).join(' · ')}</dd>
          </div>
        )}
        <div><dt className="font-semibold">Last reviewed</dt><dd>{st.lastReviewed ?? 'Not yet reviewed'}</dd></div>
      </dl>
      <p className="mt-4 text-[1.0625rem] leading-relaxed">
        This profile was drafted with AI assistance and is being prepared for source-checking and specialist review. Treat each statement as
        a draft until its evidence indicator shows a checked source.
      </p>
    </aside>
  );
};

/* ---------------- Orchid Continuum ---------------- */

export const OcPendingPanel: React.FC<{ what?: string }> = ({ what }) => (
  <div className="flex gap-3 rounded-md border-2 border-dashed border-[hsl(300_20%_35%)] bg-[hsl(300_20%_96%)] px-5 py-4 text-[hsl(300_25%_15%)]">
    <Unplug className="mt-1 h-5 w-5 shrink-0" aria-hidden="true" />
    <div>
      <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide">Orchid Continuum connection {ocConnection.status === 'live' ? 'live' : 'pending'}</p>
      <p className="mt-1 text-[1.0625rem] leading-relaxed">
        {what ? `${what} will come from Orchid Continuum when a connection exists. ` : ''}
        {ocConnection.note}
      </p>
    </div>
  </div>
);

/* ---------------- image provenance enforcement ---------------- */

export const ScientificImage: React.FC<{ image?: Partial<ImageProvenance> | null; caption: string; alt?: string }> = ({ image, caption, alt }) => {
  if (image?.role === 'story-illustration-ai' && image.src) {
    return (
      <figure>
        <img src={image.src} alt={alt ?? caption} loading="lazy" className="aspect-[4/3] w-full rounded-md object-cover" />
        <figcaption className="mt-2 text-[1rem] font-semibold text-[hsl(var(--ink))]">Story illustration — AI generated. Not scientific documentation.</figcaption>
      </figure>
    );
  }
  if (!hasScientificProvenance(image)) {
    return (
      <div className="flex aspect-[4/3] flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] p-4 text-center">
        <ImageOff className="h-6 w-6 text-[hsl(30_20%_20%)]" aria-hidden="true" />
        <p className="text-[1.0625rem] text-[hsl(var(--ink))]">{caption}</p>
        <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(30_25%_14%)]">Image pending verified source</p>
      </div>
    );
  }
  return (
    <figure>
      <img src={image!.src} alt={alt ?? caption} loading="lazy" className="aspect-[4/3] w-full rounded-md object-cover" />
      <figcaption className="mt-2 text-[1rem] leading-relaxed text-[hsl(var(--ink))]">
        {caption} · <em>{image!.taxon}</em> · {image!.creator} · {image!.license} · {image!.source}
        {image!.recordUrl && (
          <> · <a href={image!.recordUrl} target="_blank" rel="noopener noreferrer" className="underline">original record</a></>
        )}
      </figcaption>
    </figure>
  );
};
