/* ------------------------------------------------------------------
   Chronicle I — "The Science Inside the Spell".
   Single source for the copy that follows Hazel's antidote rhyme.
   Inline *text* renders as italics (story-parser syntax) — used for
   scientific names: *Phytophthora*, *Pythium*, *Croton lechleri*.
------------------------------------------------------------------- */

export const GRIMOIRE_LABEL = ['From Hazel\u2019s Grimoire', 'A story spell with real horticultural roots'] as const;

/** Mara connects the magic to the science. Rendered as story paragraphs. */
export const KAREN_TRANSITION: { text: string; quote?: boolean }[] = [
  {
    text: 'Mara read the page twice, slowly, the way she read a plant label. Her frown changed \u2014 not to fear, but to recognition.',
  },
  { text: '\u201cTake away the rhyme,\u201d Mara said, \u201cand she\u2019s written a sanitation protocol.\u201d', quote: true },
  {
    text: 'Julian leaned over her shoulder and tapped two words in the third verse. \u201cAnd Dragon\u2019s Blood? That sounds like the witch part.\u201d',
  },
  {
    text: '\u201cThat\u2019s where the evidence gets thinner,\u201d Mara said. \u201cIt\u2019s the red latex of *Croton lechleri*. People have used it traditionally for a long time, and some growers have tried it on cut orchid tissue. But trying something isn\u2019t the same as showing that it cures black rot.\u201d',
  },
  {
    text: 'She ran her finger back up the page, verse by verse. \u201cIsolate. Sterilize. Cut. Protect. Dry. Watch.\u201d',
    quote: true,
  },
];

export const SPELL_INTRO = {
  eyebrow: 'Science Behind the Story',
  title: 'The Science Inside the Spell',
  opening: 'There is no magic potion for black rot. There is, however, a ritual worth remembering.',
  closing: 'The best orchid magic is knowing what you\u2019re looking at.',
};

export type SpellStep = {
  word: string;
  /** The line of Hazel's rhyme this step hides inside. */
  verse: string;
  body: string[];
  safety?: string;
  aside?: { title: string; tag: string; body: string[] };
  diagram?: boolean;
};

export const SPELL_STEPS: SpellStep[] = [
  {
    word: 'Isolate',
    verse: 'Set the stricken one apart',
    body: [
      'Move a plant with suspected black rot away from the rest of the collection. Water splashing from an affected plant can carry the disease to its neighbors.',
    ],
  },
  {
    word: 'Sterilize',
    verse: 'Pass the blade through cleansing flame, cool it well',
    body: [
      'Use a clean cutting tool. A suitable metal orchid cutting tool can be flame-sterilized \u2014 then let it COOL before it touches plant tissue.',
      'Sterilize the tool again between cuts.',
    ],
    safety: 'Never use an open flame near alcohol, aerosol products, solvents or other flammable materials.',
  },
  {
    word: 'Cut',
    verse: 'Cut beyond the blackened line \u2026 cast away what carried rot',
    body: [
      'Remove the infected tissue and continue the cut into apparently healthy tissue beyond the visibly diseased area.',
      'Dispose of infected material rather than leaving it anywhere near the collection.',
    ],
    diagram: true,
  },
  {
    word: 'Protect',
    verse: 'Cinnamon upon the scar \u2026 or Dragon\u2019s Blood',
    body: [
      'On a suitable exposed cut surface, cinnamon is commonly used by orchid growers as a drying wound treatment, and it has antifungal properties.',
      'Dust the cut itself. Do not pour cinnamon onto healthy roots or throughout the potting medium.',
    ],
    aside: {
      title: 'Dragon\u2019s Blood',
      tag: 'Traditional & experimental \u2014 not a proven cure',
      body: [
        'Dragon\u2019s Blood \u2014 here, the red latex of *Croton lechleri* \u2014 has a long history of traditional use, and some orchid growers have experimented with it as a wound dressing. Its dramatic name makes it perfect for Hazel\u2019s grimoire.',
        'It has not been shown to cure orchid black rot. Treat cinnamon and Dragon\u2019s Blood as alternative wound-dressing ideas \u2014 not a combination that has been proven to work better together.',
      ],
    },
  },
  {
    word: 'Dry',
    verse: 'Give it air and keep it dry',
    body: [
      'After surgery, keep the cut surface from getting wet unnecessarily. Give the plant good air movement, and correct the overly wet conditions that favor the disease.',
      '\u201cDry\u201d means a dry wound and drier surroundings \u2014 not dehydrating the whole orchid.',
    ],
  },
  {
    word: 'Watch',
    verse: 'Watch the margin \u2026 stronger medicine must pursue',
    body: [
      'Keep the plant isolated and watch the cut margin closely. If discoloration or rot keeps advancing, the plant needs further intervention.',
      'For a valuable plant or an advancing infection, consult current orchid disease guidance and use an appropriately labeled product that is effective against the identified pathogen \u2014 following the label exactly.',
    ],
  },
];

export const EVIDENCE_KEY: { label: string; tone: 'science' | 'grower' | 'story'; items: string }[] = [
  {
    label: 'Supported orchid sanitation',
    tone: 'science',
    items: 'Isolation, sterile cutting tools, removing infected tissue, drying and protecting suitable cut surfaces, better growing conditions, monitoring, and a labeled treatment when needed.',
  },
  { label: 'Grower & traditional practice', tone: 'grower', items: 'Dragon\u2019s Blood as a wound dressing.' },
  { label: 'Story', tone: 'story', items: 'Hazel turns the procedure into a spell.' },
];

export const OOMYCETE_NOTE = {
  title: 'Why an ordinary fungicide may not be enough',
  body: [
    'Orchid black rot is commonly associated with species of *Phytophthora* and *Pythium*.',
    'These organisms are oomycetes, often called water molds. They are not true fungi \u2014 so not every ordinary fungicide will control them.',
    'Correct identification, good sanitation and an appropriately labeled treatment are what matter.',
  ],
};

export const SPELL_SOURCES = [
  { label: 'American Orchid Society \u2014 Black Rot', href: 'https://www.aos.org/orchid-care/orchid-pests-and-diseases/black-rot' },
  { label: 'American Orchid Society \u2014 Water Molds', href: 'https://www.aos.org/orchid-care/orchid-pests-and-diseases/water-molds' },
];

export const SPELL_IMAGE = {
  src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790402873067_649c1195.jpg',
  alt: 'An apothecary still life on a mossy potting bench: a curved pruning blade catching a candle flame, a corked jar of cinnamon, a small brown vial of crimson resin labelled Croton lechleri with a single red drop beside it, an orchid leaf and an old parchment page.',
  caption: 'Hazel\u2019s kit, as the grimoire imagines it: a flamed blade, cinnamon, and a vial of Dragon\u2019s Blood resin.',
};
