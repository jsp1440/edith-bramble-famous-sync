---
id: chronicle-ii
title: The Greenhouse That Forgot Autumn
subtitle: Chronicle II · in five chapters
number: II
accent: autumn
epigraph: "Look at the plant."
epigraphSource: Edith Bramble
notice: Chronicle II is fiction. Hazel Nightshade is fictional; the orchid-growing observations are presented as optional educational material and should be checked against the linked evidence before being treated as guidance.
---

## Chapter One — The Wrong Kind of Perfect

::: image id="c2-perfect" layout="full" caption="The greenhouse looked immaculate. That was the first warning." :::

By the first week of September, Edith Bramble had been missing for eleven months.

Her greenhouse had never looked better.

That was the first sign something was terribly wrong.

Nora Bramble stopped just inside the doorway and waited for Mara Ellison to say something. Mara did not. She stood with one hand on the doorframe and looked down the long central aisle.

Every label faced forward. Every clay pot had been turned so its cleanest side showed. The floor was swept. The hanging baskets had been lowered until they made a neat, even line above the benches. The two old ficus trees had been cut back hard enough that September light reached corners Nora could not remember ever seeing in full sun.

There was nothing dead on the floor. No papery sheath. No fallen leaf. No moss knocked from a basket. No root had been permitted to wander into the aisle.

Nora gave a tired little laugh. “I know what you’re thinking.”

“I haven’t said anything.”

“You don’t have to.”

Mara finally stepped inside. “Who did the trees?”

“Hazel.”

“The gardener?”

Nora nodded. “I couldn’t keep up with this place. Not after Edith disappeared. Hazel said the whole greenhouse was overcomplicated. She said she could simplify it so anybody could manage it.”

Mara looked up at the bare spaces in the ficus canopy.

“Did Edith ever use the word simplify?”

Nora smiled despite herself. “Not without sounding threatening.”

Mara had taken only three more steps when she stopped beside the wet bench.

“Wait.”

Nora nearly walked into her.

“What?”

Mara pointed. “That Phrag. Was it always there?”

“I think so.”

“Think so?”

“I’m doing my best, Mara.”

“I know. I’m not criticizing you.” Mara reached between two pots and lifted a large [[phragmipedium|Phragmipedium]]. “I’m asking because this is very light.”

Nora touched the rim. “Hazel watered Friday.”

“It’s Wednesday.”

“That’s bad?”

“For this plant, yes.”

The leaves were still green, but two had begun to fold lengthwise, the way a strip of paper curls when tension pulls unevenly from either side.

Mara set the pot back down and looked along the bench.

Three feet away a [[catasetinae|Catasetum]] sat in a black plastic pot. Its newest pseudobulb was fat and hard. The lowest leaves had yellowed nearly to the midrib.

Mara lifted that pot too.

This one was heavy.

Very heavy.

Nora saw her face. “What?”

“Did Hazel water this on Friday too?”

“Yes.”

“Anything since?”

“She watered the yellow plants yesterday. She thought they were drying out.”

Mara put a finger into the medium, withdrew it wet, and looked again at the yellow leaves.

One came away when she barely touched it.

Nora’s expression changed. “Oh no.”

“What?”

“It fell off.”

“I know.”

“Is it dying?”

Mara turned the leaf over in her hand. “Maybe not. Look at the bulb.”

Nora leaned closer.

“What about it?”

“Is it shriveled?”

“No.”

“Soft?”

“No.”

“New growth still trying to make another leaf?”

Nora bent until her hair nearly touched the plant. “No. It looks finished.”

“Right.” Mara handed her the leaf. “So before we decide yellow means sick, we need to know whether this one is finishing its season.”

Nora looked from the wet Catasetum to the dry Phragmipedium.

“So the one that looks like it needs water may need less, and the one that still looks green may need more.”

“That’s what I’m worried about.”

The greenhouse door opened behind them.

Theo Mercer came in sideways with a cardboard carrier of coffee and a paper sack pressed under his arm.

“I brought enough for four people,” he announced. “Which means either I planned badly or somebody needs to arrive.”

Mara held up the fallen leaf.

Theo stopped. “I see we’re starting with death.”

“It’s not dead.”

“The leaf appears unconvinced.”

Nora pointed at the two pots. “Tell me what you see.”

Theo set the coffee down, lifted the Phragmipedium, then the Catasetum.

“One’s dry. One’s wet.”

“Anything else?” Mara asked.

He studied the plants. “The dry one still has active leaves. The wet one’s packing it in for the year.”

Nora stared at him. “How did you know that so fast?”

“I didn’t. I’ve just killed enough things to recognize some of the early paperwork.”

Mara laughed.

Nora did not. She was still looking at the two plants.

“Hazel put everything on a schedule.”

“What schedule?” Theo asked.

“Wednesday and Friday. More in summer. Less in winter.”

“For everything?”

Nora nodded.

Theo slowly put his coffee back down.

“All five hundred?”

“She grouped them by pot size.”

He looked at Mara.

Mara looked down the aisle.

“That,” she said, “is probably our first real problem.”

By eleven, word had spread through the society that something was wrong in Edith Bramble’s greenhouse.

Julian Cross arrived first and went immediately to the [[dendrobium-strategies|Dendrobiums]]. He did not say hello until he had pulled two plants from the same row.

“Who put these together?”

Nora raised a hand halfway. “Hazel.”

Julian set the pots on the bench. “Nobile-type. Warm-growing Phalaenanthe-type.”

Theo looked at them. “Both [[dendrobium-strategies|Dendrobium]].”

Julian gave him a patient look.

Theo raised both hands. “I’m only saying what Hazel saw.”

“Then Hazel stopped too early.”

Mina Serrano called from the other end of the greenhouse.

“Can somebody come here?”

They found her holding a wooden [[stanhopea|Stanhopea]] basket halfway out of a white ceramic cachepot.

Nora frowned. “That actually looks nice.”

“It does,” Mina said. “That’s the problem.”

She lifted the basket completely free and pointed underneath.

“What do you notice?”

Nora crouched.

“There’s nowhere for anything to come out.”

“Exactly.”

Theo peered over her shoulder. “I’m going to guess something needs to come out.”

“The flower spike.”

“Down?”

“Down.”

He stared at the basket, then at the solid pot Hazel had put around it.

“That seems like an unfortunate design disagreement.”

“Between the orchid and the decorator?” Mina asked.

“Strongly held positions on both sides.”

More people arrived.

Gabriel Soto went straight to the Phragmipedium bench and began lifting pots without speaking. Iris Calder stood under the bright south glazing and looked at the Cattleyas one by one. Owen Hart walked outside, found the [[cymbidium|Cymbidiums]] that Hazel had moved indoors during August, and asked why anybody had decided they were frightened of a cool night. Tessa Wynn stood in the doorway to the lath house for nearly a minute, feeling the breeze before she said anything about the [[sarcochilus|Sarcochilus]].

Leah Moreno brought a tablet full of photographs from society visits to Edith’s greenhouse over the previous five years.

By lunch, the room had become noisy.

Not chaotic. No one was shouting. But conversations crossed each other from bench to bench.

“Was this always here?”

“No, I remember it higher.”

“Higher where?”

“Under the ficus. Look at Leah’s photo.”

“Feel this pot.”

“I already did.”

“Feel it again.”

“That root tip is active.”

“Which one?”

“Turn it around.”

“Don’t move that yet.”

“Why not?”

“Because I don’t know why it’s here.”

That last sentence stopped Mara.

She looked around the greenhouse.

That was the difference between what they were doing and what Hazel had done.

Hazel had seen disorder and corrected it.

They were seeing disorder and asking what it meant.

Near the center bench Nora picked up a deciduous [[lycaste|Lycaste]] with yellowing leaves.

“Here’s another one.”

Mara came over.

Nora touched the old pseudobulb. “It’s firm.”

“Yes.”

“The yellowing is pretty even.”

“Yes.”

“So I’m not watering it because it’s yellow.”

“Not yet.”

“Not yet?”

Mara smiled. “You’re learning to make me nervous with confidence.”

“Good.”

Beside it sat an evergreen Lycaste hybrid, still fully leafed.

Nora pointed from one to the other. “Same shelf?”

“For now.”

“You don’t know?”

“I want someone who grows more Lycastes than I do.”

Nora looked surprised.

Mara noticed. “What?”

“I thought you knew.”

“I know enough to know when I want another opinion.”

That seemed to reassure Nora more than certainty would have.

Late in the afternoon, she found Hazel’s final invoice in a drawer near the potting sink.

Most of it was ordinary: pruning, cleaning, replacement hose fittings, fertilizer, labor.

At the bottom Hazel had written one extra line by hand.

SEASONAL INCONSISTENCIES CORRECTED.

Nora read it twice.

Then she carried it to Mara.

Mara read it once.

“Oh,” she said.

Theo came up behind them. “Good oh or bad oh?”

Mara handed him the invoice.

He read the line and stopped smiling.

“She knew,” Nora said.

Mara looked through the greenhouse: the lowered baskets, the pruned ficus, the Cymbidiums indoors, the wet Catasetum, the dry Phrag, the warm Phalaenopsis against the cold west glass.

“Yes,” she said. “I think she did.”

They left after sunset.

Nora was the last to lock the greenhouse. She had already turned toward the house when Theo called her back.

The western panes had fogged.

That would not have been strange on another night, but the air was dry and the other glass remained clear.

A narrow line appeared in the condensation.

It moved slowly downward, stopped, then turned.

Nora stood very still.

“Did you see that?” she whispered.

Theo did not answer until the line had disappeared beneath a fresh bloom of fog.

“Yes.”

Mara came back from the gate.

“What happened?”

Neither of them spoke for a moment.

Then Nora looked through the glass into her sister’s greenhouse.

“I think,” she said, “we’d better come back tomorrow.”

## Chapter Two — The Map of Many Climates

::: image id="c2-lycastes" layout="full" caption="Different orchids can occupy the same greenhouse and still need very different conditions." :::

The next morning they did not begin by moving orchids.

They began by trying to understand where the orchids had been.

Leah spread old photographs across the potting bench. Some were formal pictures from society tours. Others were casual phone photographs: somebody holding a flower, somebody else standing behind a table of plants, a badly framed picture of cake that happened to show half the greenhouse in the background.

Those accidental photographs became the most useful.

“Here,” Leah said. “Look behind Nora’s shoulder.”

Nora leaned over the screen. “That was three Christmases ago.”

“I don’t care about Christmas. Look up.”

A row of baskets hung high beneath the ficus canopy.

Mina looked toward the same rafters now. The hooks were still there.

“Those didn’t get lowered because the plants grew,” she said. “Somebody lowered all of them.”

Julian was already at the west wall with a thermometer in one hand.

“This end still drops first at night.”

“Even after all Hazel’s changes?” Theo asked.

“She changed plants. She didn’t move the Pacific Ocean.”

Owen, coming through the outside door, heard him.

“Give her time.”

Theo pointed. “See? That is why I like having him here.”

Mara ignored both of them. She was looking at the floor.

A faint green line of moss ran beneath one bench and stopped almost exactly at its end.

“Gabriel.”

He came over.

“This your Phrag bench?”

He crouched and pressed the old moss with two fingers.

“It used to stay wetter than the others.”

“You remember that?” Nora asked.

“I remember getting my knees wet every time I crawled under it looking for dropped labels.”

“That counts as data?” Theo asked.

“It counts as wet knees.”

“It’s all we’ve got.”

They kept going.

Mineral rings on the bench showed where pots had sat for years. A line of sun bleaching across the wood showed where shade once fell before Hazel cut the ficus. Fan blades pointed toward areas where fine debris had been pushed into the same corners again and again. Old hooks, brackets and hanging wires showed where mounted plants had once occupied air instead of bench space.

Leah began making a new drawing, not as a secret map left by Edith but as a reconstruction made by the people standing in the greenhouse now.

Warm side.

Cool west end.

Bright wall.

Wet bench.

Drying shelf.

Hanging zone.

Outdoor lath.

The shapes overlapped.

Theo looked over Leah’s shoulder.

“That’s a terrible map.”

“It’s not finished.”

“It looks like weather.”

Leah considered it. “Good.”

At the Lycaste bench, Nora called Mara over.

“I want to try this again.”

Mara folded her arms. “Go ahead.”

Nora pointed to the first plant. “Lycaste aromatica. The new pseudobulb is mature. It’s plump. Leaves are yellowing together instead of one random leaf collapsing. Old bulbs have the sharp remains of the leaf bases.”

“And?”

“I think it’s going into its normal seasonal decline.”

“You think?”

“I’m not saying I know how dry to keep it.”

“Good.”

“Why is that good?”

“Because now you’re separating what you observed from what you still need to decide.”

Nora pointed at the evergreen hybrid beside it. “And I don’t assume this one should do the same thing just because the label says Lycaste.”

“Exactly.”

Iris had come up behind them.

“Now ask what each one did last year.”

Nora turned. “We don’t have last year.”

Leah raised a finger from across the aisle. “Actually—”

“You have a photograph, don’t you?” Theo said.

“September twenty-eighth. Same bench.”

They crowded around the tablet.

The deciduous plant had already lost half its leaves. The evergreen hybrid was still green.

Nora exhaled. “That helps.”

“It doesn’t tell you everything,” Mara said.

“No. But it tells me they didn’t behave the same way before Hazel either.”

Across the aisle, Julian was less patient with the Dendrobiums.

He had two pots on the bench and Theo beside him.

“Tell me what you see,” Julian said.

Theo looked suspicious. “Why is everybody doing this to me now?”

“Because you keep talking.”

Theo studied the first plant. “Cane is mature. Leaves still on most of it. Newest growth looks finished.”

“Second one?”

“Also a cane.”

Julian waited.

Theo sighed. “Broader leaves. More tropical-looking, if I’m allowed to say that without being attacked.”

“You’re allowed to notice it.”

“Both say Dendrobium.”

“There’s your trap.”

Julian turned the first pot until the label faced them.

“Nobile-type. It can take a cooler, drier shift as the growth matures. Not bone dry, not some ritual punishment, but a real seasonal change.”

He touched the second plant.

“This one stays warm. If you give it the same treatment because the genus name matches, you can damage it.”

Theo looked down the row Hazel had made.

“She alphabetized them.”

“Yes.”

“That is almost impressive.”

“It would be, if they were books.”

Outside, Owen had the Cymbidiums spread across the lath house benches.

Nora joined him.

“Hazel brought these in because nights were getting colder.”

“I know.”

“Is that wrong for all of them?”

“No.” Owen parted the leaves around the base of a mature growth. “And that’s the part I want you to keep. We don’t replace her rule with the opposite rule.”

He pointed.

Nora bent closer. “Is that a spike?”

“Maybe.”

“You can’t tell?”

“Not yet.”

Theo appeared behind them. “I enjoy hearing experts say that.”

Owen did not look up. “Then enjoy it quietly.”

Nora laughed.

Owen touched the emerging structure with the back of one finger, barely enough to move the leaves around it.

“Cooler autumn nights can be part of the flowering signal for many of these. So bringing every [[cymbidium|Cymbidium]] into a warm house at the first cool night may be exactly the wrong thing. But we watch this. We don’t announce a flower because we want one.”

“What do we watch?” Nora asked.

“Shape. Direction. How it develops over the next couple of weeks.”

“And if it’s just another growth?”

“Then it’s another growth.”

That answer pleased her.

By midday Leah’s reconstruction covered most of a folding table. It did not look like a greenhouse divided into neat rectangles. It looked like currents: warm air rising; cooler marine air arriving at the west end; brighter exposure along the south; dampness lingering under benches; moving air near the door; shade where the ficus canopy had once softened midday light.

Tessa stood at the lath house doorway and held one hand out into the breeze.

“The Sarcochilus were here,” she said.

“How sure are you?” Mara asked.

Tessa pointed at one of Leah’s photographs. “There’s one behind Edith’s elbow. Same hook.”

“Why here?” Nora asked.

“Because ‘outside’ isn’t the condition. This is the condition.” Tessa nodded toward the moving air. “Cool but not brutal. Bright but filtered. Regular moisture without sitting wet and stagnant. I wouldn’t put every Sarc in exactly the same place. But this is where I’d start.”

Gabriel, passing behind her, said, “That’s the whole greenhouse, isn’t it?”

“What is?”

“Where I’d start.”

Mara looked back through the open door.

That was it.

Not certainty.

A starting place, followed by observation.

They spent the rest of the day marking plants, but the tags did not say GOOD or BAD. They said what had to happen next.

MOVE.

WATER NOW.

LET DRY FURTHER.

CHECK ROOTS.

WAIT.

RECHECK MONDAY.

The last tag bothered Theo.

“Waiting is not a treatment.”

Mara looked up from a pot.

“Sometimes it’s the only way to find out whether the last treatment worked.”

He read the tag again.

“Fine. But I want it noted that I objected to patience on procedural grounds.”

That evening, Nora stood alone for a moment in the center aisle.

The greenhouse was less tidy than it had been the day before. Pots had moved. Baskets were back in the air. A fan now blew across an area Hazel had left still. One bench remained conspicuously wet while another had been allowed to dry.

It looked worse.

For the first time since Edith disappeared, Nora found that reassuring.

## Chapter Three — Putting Autumn Back

::: image id="c2-lathhouse" layout="full" caption="Restoring the greenhouse meant restoring its different growing places." :::

They restored the greenhouse a little at a time.

Mara insisted on that.

“You don’t fix months of bad decisions by making fifty new decisions in one afternoon.”

Theo looked at the carts lined up in the aisle. “This feels like a personal attack on everyone who volunteered.”

“It’s a request that we notice what happens after we touch something.”

“That’s less exciting.”

“It’s gardening.”

The Cymbidiums went back under the lath first. Not all of them, and not blindly. Owen looked at each plant, its growth stage, its condition and where it had been grown before. The plants that could use the natural autumn cooling went outside. The questionable ones stayed where they could be watched.

Tessa rehung the Sarcochilus nearby, but not on the same watering schedule.

Nora watched her soak one basket thoroughly, then rotate it and wet it again from the other side.

“Why twice?”

“Because a basket can look wet from here and still be dry inside.”

She turned it so Nora could see the back.

“See?”

The moss on one side had darkened. A pocket on the far side remained pale.

Nora touched it.

“Still dry.”

“Exactly. Watering isn’t just how much. It’s whether the root zone actually gets wet, how evenly, and how long it stays that way before air gets back in.”

Jonah Pike, who had arrived carrying two Bulbophyllum baskets of his own for comparison, heard her and held one up.

“And ‘let it dry’ doesn’t mean the same thing for everything either.”

Theo eyed the plant. “That thing looks like it has opinions.”

“It does. Mostly about my watering.”

Jonah set the basket down.

“If you want a useful question, don’t ask me how many times a week I water it. Ask how long this stays moist in this basket, in this air, with this medium.”

Nora looked at the slatted container.

“So the schedule isn’t the answer.”

“It can be a starting reminder. It isn’t the plant.”

That phrase followed her all afternoon.

At the Phragmipedium bench, Gabriel was checking roots.

He handed Nora a pot.

“Feel the weight.”

“Heavier than the first one was.”

“Good. Now look.”

He tipped the pot enough for her to see roots against the clear inner wall.

“Active tips,” she said.

“Some. And the leaves?”

“Not folding as much.”

“Then what do you want to do?”

“Keep it evenly moist.”

Gabriel shook his head slightly.

“What?”

“You skipped a step.”

Nora looked again.

“Make sure it isn’t staying stagnant.”

“Right. Moist is not the same thing as suffocated. Feel the air moving here.”

She did.

The fan was pushing a steady current along the bench.

“Hazel heard ‘likes water’ and made one mistake. Somebody else hears ‘don’t let it dry’ and can make a different one.”

Nora nodded. “So what do we watch?”

“Roots. Leaf posture. How quickly the pot loses water. New growth. And if it changes, we change.”

Mara, listening from the next bench, smiled.

“That’s the sentence I want everyone to remember.”

Gabriel looked at her. “Which one?”

“If it changes, we change.”

“I said four sentences.”

“Then I’m editing.”

At the Cattleya wall, Iris had a different problem.

Theo reached toward a pot and she caught his wrist before he touched it.

“No.”

“I was going to turn it.”

“I know.”

“Why can’t I turn it?”

“Because it’s stable, it’s growing well, and it has a developing sheath. We have no evidence that moving it helps.”

“The label is facing backward.”

“The orchid has survived the humiliation.”

Theo withdrew his hand.

Iris leaned closer to the plant.

“Look at the newest pseudobulb. Look at the roots. If it were failing, we’d have something to discuss. Right now our urge to improve it is the biggest risk on this bench.”

“Can I at least clean the pot?”

“No.”

He sighed. “I’m learning a great deal about restraint against my will.”

Mina had the Stanhopea back in the air by then.

She hung the slatted basket where the bottom remained completely open.

Nora came over as Mina crouched underneath it.

“What are you looking for?”

“A spike that may or may not be there.”

“That reassuring phrase again.”

Mina smiled. “Come down here.”

Nora crouched beside her.

From underneath, the basket made more sense. Roots and medium filled the slats, but there was space for an inflorescence to emerge and travel downward.

“So Hazel’s outer pot didn’t hurt the leaves,” Nora said.

“No.”

“It could have looked perfectly healthy.”

“Exactly.”

“And never flowered.”

“Exactly.”

Nora sat back on her heels.

“That might be the most irritating thing I’ve learned.”

“Wait until you grow orchids longer.”

The Laelia turned up almost by accident.

Tessa found it on a lower indoor shelf where Hazel had moved plants she considered exposed to autumn cold.

“Iris?” she called.

Iris came over.

From the top of a mature pseudobulb rose a long green spike.

Theo leaned in. “That one I know. Flower spike.”

Iris glanced at him. “You sound very sure.”

“I’m taking a risk.”

She smiled. “You’re right.”

Nora looked from the plant to the open lath house door.

“Where was it before?”

Leah was already searching photographs.

“Outside. Bright side. Same place for at least three autumns.”

Iris touched the edge of the pot but did not lift it yet.

“Roots?”

Tessa checked.

“Good.”

“Growth mature?”

“Yes.”

“Spike intact?”

“Yes.”

Nora waited.

Iris looked at her. “What?”

“You’re going to ask me.”

“Fine. What would you do?”

“Put it back where it was.”

“Why?”

“Because it was doing well there before Hazel moved it, the roots look good, the growth is mature, and the spike is already developing. I wouldn’t invent a new problem.”

Iris nodded. “Good enough for me.”

They carried the Laelia back outside.

After that, the spike became a quiet marker of time.

No one called it a clock. No one wrote a slogan on a tag. They simply noticed it.

A week later it was longer.

Then longer again.

The Cymbidium growth Owen had been watching became more clearly a spike. The Phragmipedium leaves regained better posture. The deciduous Lycaste continued to yellow while its pseudobulbs stayed firm. The evergreen hybrid did not follow it. Julian’s cooler Dendrobium began responding differently from the warm-growing plant beside the Phalaenopsis. Jonah adjusted one Bulbophyllum basket because it was drying too fast after they rehung it higher; another, in denser moss, stayed wet too long and moved closer to the fan.

Nobody won an argument by being right once.

They made a change, then came back to see what the orchid had done with it.

By early October the greenhouse had lost Hazel’s symmetry.

Some baskets hung high, others low. One bench stayed moist. Another was entering a deliberate dry phase. Shade cloth replaced part of the ficus canopy that could not be regrown in a month. Cool growers occupied the end where nights dropped first; warm plants moved away from the glass. Outside plants went outside when that suited them and came in when conditions required it, not because the calendar announced that autumn was dangerous.

Nora stood in the aisle with Leah one evening.

“It looks messy.”

Leah took a photograph.

“It looks better.”

“That’s not the same thing.”

“No.”

Leah lowered the camera.

“That may be the point.”

Later that evening, while looking for spare plant labels, Leah found a business card pushed behind the drawer in the potting bench.

HAZEL NIGHTSHADE
GARDEN RESTORATION & PRESERVATION

Underneath, in smaller type:

Nothing properly preserved should ever be allowed to die back.

Leah handed it to Nora without comment.

Nora read it and went quiet.

Mara found them a few minutes later.

“What?”

Nora passed her the card.

Mara read it.

Then she looked toward the dry-rest shelf.

A Catasetum stood nearly leafless, pseudobulb still firm.

“She wasn’t trying to kill them,” Nora said.

“No.”

“She thought she was saving them.”

Mara nodded.

From outside came Theo’s voice.

“Anybody want to see how much longer the Laelia spike is?”

Nora looked toward the door.

For the first time, Hazel frightened her more because the greenhouse made sense.

## Chapter Four — Hazel’s Perfect Greenhouse

::: image id="c2-hazel-glass" layout="full" caption="Hazel returned to find the greenhouse becoming uneven again." :::

Hazel returned on October twenty-fourth.

Nora saw her from the kitchen window.

She was standing beside the greenhouse in gardening gloves and a dark olive overshirt, studying the roofline as though she had arrived to inspect work done by an unreliable contractor.

Nora called Mara.

By the time Mara reached the greenhouse, half the society was already there for the evening check.

Theo was inside with Julian. Gabriel had just finished watering the Phragmipedium bench. Iris was examining a Cattleya root tip. Mina and Jonah were arguing mildly about whether one hanging basket should be six inches higher. Owen was outside with the Cymbidiums. Tessa and Leah were in the lath house.

Hazel entered without knocking.

She stopped three steps inside.

The expression on her face was not anger at first.

It was disbelief.

“What happened?”

Nora stood beside the potting bench. “We put things back.”

Hazel looked up at the baskets.

“Those were lowered.”

“Yes.”

“For access.”

Mina stepped down from a small ladder. “Some of them needed the air up there.”

Hazel’s eyes moved to the dry-rest shelf.

Three nearly leafless Catasetinae stood there.

She walked toward them.

“You stopped watering these.”

“Reduced,” Mara said. “As the plants changed.”

Hazel reached for a watering wand leaning against the wall.

Gabriel put his hand on it first.

“No.”

Hazel looked at him.

“They are dehydrating.”

Gabriel picked up one pot and handed it to her.

“Feel the pseudobulb.”

She did not take it.

“Feel it,” he said again, not unkindly.

After a moment, Hazel put two gloved fingers against the bulb.

“Firm,” she said.

“Yes.”

“And the leaves are gone.”

“Yes.”

“That is decline.”

“It’s a seasonal state.”

Hazel moved away from him before he finished.

At the wet bench she stopped.

“These are still being watered.”

Gabriel set the Catasetum down.

“Those Phrags are actively growing.”

“So one bench is dry and one is wet.”

“Yes.”

She looked at Mara. “You call that management?”

Mara leaned against the bench. “I call it two different plants.”

Hazel turned toward the west end.

Julian followed her gaze.

“You moved those back into the cold.”

“Cooler,” he said.

“And these?” She pointed toward the warm side.

“They stay warmer.”

“Same genus.”

Julian nodded. “That was the mistake.”

Hazel’s jaw tightened.

She went from bench to bench faster after that.

The outdoor Cymbidiums offended her. The uneven shade offended her. The Stanhopea basket hanging over open air offended her. The sight of old leaves allowed to yellow naturally seemed almost personal.

Then she reached for the ficus.

Nora stepped between them.

“You already cut enough of that.”

Hazel looked at her.

“It was blocking light.”

“It was making shade.”

“Shade is blocked light.”

“Not to the orchids that needed it.”

For the first time, Hazel seemed to really see Nora.

“You are not your sister.”

Nora swallowed.

“No.”

The word hurt, but not in the way Hazel intended.

“No,” she said again. “I’m not.”

Theo had gone quiet.

Mara came to stand beside Nora.

Hazel looked around the greenhouse one more time.

“You’ve made it inconsistent again.”

No one answered immediately.

The fans slowed.

Julian looked up.

“Did somebody touch the control?”

“No,” Leah said.

The fan blades turned more slowly.

Condensation spread across the glass.

Not everywhere at once. It began at the west wall, moved across one pane, then another.

Mina opened the nearest vent.

“Airflow first,” she said.

Julian was already at the controls. “Power’s on.”

Leah checked the outlet strip.

“Still live.”

Theo looked through the glass at Hazel.

“Are we going to discuss the supernatural part?”

“Later,” Mara said. “Open the door.”

He did.

That irritated Hazel.

Nora saw it.

Not the door itself. The response.

They were not standing frozen while the greenhouse transformed around them. They were checking what could be checked.

Mina moved freshly watered mounted plants into better air. Gabriel made sure the Phrag bench was not being chilled by the open door. Iris kept Theo from moving the Cattleya that still did not need moving. Owen came in from outside and left the Cymbidiums where they were.

Hazel pressed one hand against the glass.

The condensation thickened around it.

Then a yellow Catasetum leaf detached from the dry-rest shelf.

It floated slowly to the floor.

Hazel stared at it.

Theo looked at Mara.

“Do I pick that up?”

“No.”

“You’re sure?”

“Yes.”

The leaf landed between two benches.

Hazel’s face hardened.

“You’re letting them die.”

Gabriel shook his head. “That leaf was finished.”

“The plant discarded it.”

“It withdrew from it.”

“It lost it.”

Mara stepped closer to the shelf but did not touch the plant.

“Look at the pseudobulb.”

Hazel did not.

“Look at it,” Mara said.

The bulb was green and full.

“The leaf fell,” Mara said. “The plant didn’t.”

Hazel turned away.

That was when she saw the Laelia outside.

Its spike had lengthened far beyond what it had been when they first found it. Buds were now distinct near the tip.

Hazel walked to the open door.

“That was inside.”

Tessa, standing just beyond it, said, “We put it back.”

“You exposed it.”

“To the conditions it was growing in before.”

“It should have stopped.”

Iris came beside her.

“Why?”

Hazel looked at the spike.

For once she had no immediate answer.

The fog thickened outside.

It moved around her ankles and across the threshold.

Nora had the sudden, unreasonable impression that the greenhouse itself was resisting two shapes at once: Hazel’s perfect greenhouse, where nothing yellowed or rested or hung crookedly, and Edith’s greenhouse, where every bench was allowed to be different.

Hazel stepped backward into the fog.

“Then keep it this way,” she said.

No one moved.

“Keep all of it. Every dry bulb. Every fallen leaf. Every uneven bench. Let us see what it gives you.”

The fog closed.

When it thinned, Hazel was gone.

Theo waited a full ten seconds.

“Was that a threat?”

Mara looked toward the Laelia buds.

“I think it was a deadline.”

Owen checked the calendar hanging beside the sink.

“Halloween is next Friday.”

Theo exhaled. “Of course it is.”

Nora bent down and picked up the fallen Catasetum leaf.

She almost threw it away.

Instead she looked at the clean abscission point, then at the firm green pseudobulb above it.

She set the leaf on the potting bench.

Not as a charm.

Not as evidence of magic.

Just because a week earlier she would have thought it meant the plant was dying.

Now she knew better.

## Chapter Five — The Greenhouse Remembers

::: image id="c2-edith-returns" layout="full" caption="The greenhouse remembered its seasons — and then Edith came home." :::

On Halloween afternoon, the greenhouse was full of people who were trying very hard not to wait for a ghost.

They told themselves they were preparing for visitors.

Leah taped a small sign beside the door explaining that the greenhouse contained plants in different seasonal states and that leafless did not necessarily mean dead. Mina rehung one basket that had drifted into the aisle. Owen brought in a Cymbidium only long enough to show a visitor the developing spike, then carried it back outside. Gabriel checked the wet bench. Jonah checked his baskets. Iris checked the Cattleya and, after looking at it for several seconds, announced that she intended to continue doing absolutely nothing to it.

Theo applauded.

“Finally, a cultural program I can follow.”

“You would overdo it,” Iris said.

Nora heard herself laugh.

A year earlier she would have thought the greenhouse looked neglected.

Now she could read some of what she was seeing.

A leafless Catasetum resting on a dry shelf.

A Phragmipedium carrying active roots in a moist, airy pot.

A nobile-type Dendrobium receiving cool nights while a warm-growing Dendrobium remained protected.

A Stanhopea with open space beneath its basket.

A deciduous Lycaste losing leaves beside an evergreen hybrid that was not.

A Sarcochilus moving gently in the lath-house air.

Nothing matched.

Nothing needed to.

Near sunset Leah called from outside.

“Everybody. You might want to see this.”

They went out one by one.

Two flowers had opened on the [[laelia-anceps|Laelia anceps]].

They stood high on the arching spike, magenta-lavender against a sky that had gone the flat silver of an approaching marine layer.

No thunder sounded.

No glass broke.

No mysterious light shone from the flowers.

Theo waited anyway.

“Well?” he said.

Iris looked at him. “Well what?”

“Nothing dramatic?”

“It flowered.”

“Yes, I can see that.”

“What more did you want?”

“Given this greenhouse? At minimum, a small electrical disturbance.”

Nora stepped closer to the plant.

“Did we make it flower?”

Iris shook her head.

“We stopped getting in its way.”

“That sounds less impressive.”

“It’s often harder.”

Mara had stayed near the door.

She looked at the flowers, then back through the greenhouse.

The bloom did not prove that every decision they had made was correct. It did not prove that the greenhouse was fixed. It did not prove anything supernatural at all.

It meant one plant had completed enough of its own sequence to flower.

That was enough.

The fog arrived just after dark.

It rolled across the yard faster than the evening cooling could explain and pressed against the greenhouse glass until the outside world disappeared.

Visitors stopped talking.

Nora felt Theo move closer to her.

“Now?” he whispered.

“Now what?”

“The electrical disturbance.”

The lights flickered.

Theo closed his eyes. “I hate being right.”

Condensation raced across the west panes.

A shadow appeared outside.

Nora’s breath caught.

Hazel stepped out of the fog.

She looked exactly as she had a week before: gloves, dark overshirt, expression composed almost to the point of kindness.

Her eyes moved first to the Laelia flowers.

Then to the greenhouse behind them.

She raised one hand toward the glass.

Before she touched it, someone knocked from the other side of the door.

Three ordinary knocks.

Everyone turned.

A small woman stood on the threshold.

Her hair was tangled. Mud marked one sleeve. She wore one shoe.

For a second Nora did not move because her mind refused to give the figure a name.

Then the woman looked through the glass and frowned.

“Why,” Edith Bramble said, “is everybody standing around outside my greenhouse?”

Nora made a sound that was not quite Edith’s name.

Edith barely had time to open the door before Nora hit her hard enough to push them both backward.

“Careful,” Edith said into her sister’s shoulder. “I appear to have misplaced a shoe.”

Nora was crying.

“You’ve been gone for a year.”

Edith stopped.

“What?”

Nora pulled back and looked at her.

“Eleven months.”

Edith stared at her, then at the greenhouse, then at the people inside it.

“No.”

“Yes.”

“I was watering.”

Nora waited.

Edith’s expression changed as she tried to reach something in memory.

“It was evening,” she said. “There was fog.”

“What happened after that?” Mara asked gently.

Edith looked at her.

“I don’t know.”

“That’s all you remember?”

“Watering. Fog. Then standing outside just now wondering why the ficus looks butchered.”

Nora laughed through tears.

Edith looked over her shoulder.

Hazel was still beyond the glass.

The reunion left Edith’s face all at once.

“Oh,” she said.

Hazel entered.

No one stopped her.

Not because they trusted her. Because Edith was looking at her as though she recognized a weed she had pulled before.

Hazel looked Edith up and down.

“You came back.”

“So it seems.”

“You left them with decay.”

Edith looked genuinely confused.

“What decay?”

Hazel pointed toward the dry-rest shelf.

“That.”

Edith walked over.

She picked up the nearest Catasetum pot, felt its weight, pressed the pseudobulb with one finger, then looked at Gabriel.

“When did the last leaf go?”

“Tuesday.”

“Roots?”

“Old roots declining. New growth hasn’t started.”

“Fine.”

She put the pot back.

Hazel’s mouth tightened.

She pointed to the wet bench. “And those?”

Edith walked to the Phragmipediums.

She looked under a leaf, checked a root against the side of the pot, then glanced at the moving fan.

“Who changed the air here?”

“Gabriel and Julian,” Nora said.

“Better.”

She moved on.

At the Stanhopea she stopped.

“Who put this in a solid pot?”

Every head in the greenhouse turned toward Hazel.

Hazel did not answer.

Mina said, “We took it back out.”

Edith crouched, looked underneath the basket, and stood again.

“Good.”

Hazel’s composure cracked.

“You call this good?”

Edith turned.

Hazel swept one hand toward the greenhouse.

“One plant wet. One dry. One cold. One warm. Leaves on the floor. Baskets at different heights. Nothing aligned. Nothing preserved.”

Edith looked where Hazel pointed.

Then she looked at Nora.

“Did the Catasetum finish its growth?”

“Yes.”

“Did the Phrag recover?”

“Yes.”

“The cool Dendrobium?”

Julian answered. “Holding well. Bud development looks promising, but I’m not calling it yet.”

Edith nodded.

“Warm one?”

“Warm.”

“Cymbidiums?”

Owen said, “Outside. One definite spike. Two possibles.”

“Possible means possible.”

“I know.”

“Good.”

She looked at the Laelia through the open door.

“Whose idea was that?”

Tessa and Iris both pointed at each other.

Edith went outside.

Hazel followed.

Everyone else followed because no one had any intention of missing whatever came next.

Edith stood beneath the Laelia spike and looked at the two open flowers.

She did not smile immediately.

She looked at the pseudobulb first.

Then the leaves.

Then the roots she could see at the edge of the pot.

Then the flowers.

Only then did her face soften.

Hazel said, “You let the greenhouse fall apart.”

Edith did not look at her.

“No.”

“You always did. You let things yellow. You let them stop. You let them become ugly.”

Edith finally turned.

“Which plant?”

Hazel blinked.

“What?”

“Which plant are you talking about?”

“All of them.”

“That’s not an answer.”

Hazel’s face changed.

Edith pointed back through the greenhouse door.

“The leafless one? The one making roots? The one in spike? The one finishing a growth? The one that wants cooler nights? Which one?”

Hazel said nothing.

Edith waited.

Not triumphantly. Impatiently.

When Hazel still did not answer, Edith looked at Nora.

“What did she do to the ficus?”

Nora wiped her face. “Pruned it.”

“How much?”

Nora pointed upward.

Edith stared.

“Oh, for heaven’s sake.”

Theo made a noise that might have been a laugh.

Hazel stepped backward.

Fog curled around her legs.

“This will not last,” she said.

Edith shrugged. “Of course it won’t.”

That stopped everyone.

Hazel stared at her.

Edith gestured toward the greenhouse.

“Nothing in there lasts exactly as it is. That’s why we keep looking.”

Hazel’s outline thinned.

The fog seemed to pass through her rather than around her.

Nora took one step toward Edith.

Hazel looked at the Laelia one last time.

Then she was gone.

No scream.

No flash.

Only fog crossing the yard where she had been.

For several seconds nobody spoke.

Then Edith turned to Nora.

“Eleven months?”

“Yes.”

“You’re certain?”

“Very.”

Edith looked down at her one remaining shoe.

“That is inconvenient.”

Nora laughed again, and this time everyone else did too.

Later, coffee crowded the potting bench. Someone had brought an apple-blackberry tart, though nobody could remember who. Edith sat on a stool with a blanket around her shoulders and Nora close enough that their elbows touched.

The others tried not to interrogate her.

They failed within six minutes.

Theo went first.

“Did you see anything?”

“Fog.”

“Anything else?”

“No.”

“Were you conscious?”

“I was apparently capable of losing a shoe.”

“That does not answer the question.”

“It is the best answer I have.”

Mara handed Edith a cup of coffee.

“Do you remember Hazel?”

“Yes.”

“From before?”

Edith looked into the cup.

“I remember not liking her.”

“That narrows it down,” Nora said.

Edith gave her a sideways look.

Nora smiled into her own coffee.

After a while, Edith stood.

She was still unsteady, but she refused three offers of help and accepted the fourth without comment when Nora simply took her arm.

They walked the greenhouse together.

At the Lycaste bench Edith stopped.

Nora pointed to the deciduous plant.

“That one was yellowing when we started. We thought it might be a problem. Then we looked at the pseudobulb, the pattern of leaf loss, old photographs, what kind of Lycaste it was—”

Edith held up a hand.

Nora stopped.

“What?”

Edith pointed to the base of the newest pseudobulb.

“What do you see there?”

Nora bent closer.

A small new structure pressed from the base.

She looked up.

“I’m not sure yet.”

Edith nodded.

“Good.”

Nora laughed. “That’s all?”

“For tonight.”

They moved on.

At the Phragmipedium bench Edith asked Gabriel how quickly the pots were drying now. At the Dendrobiums she asked Julian which canes were mature. At Jonah’s Bulbophyllum basket she put one finger into the edge of the medium, then asked how long it had been since watering. At the Stanhopea she looked underneath before she looked at the leaves.

She did not give a speech.

She asked questions.

The answers belonged to the people who had spent the last two months learning the greenhouse without her.

Near midnight Nora found her sister standing alone in the center aisle.

“Are you all right?”

Edith looked around.

“No.”

Nora waited.

“But the orchids mostly are.”

“That’s a very Edith answer.”

“I’ve had practice.”

Outside, the fog pressed softly against the glass.

Inside, the greenhouse was warm in one place and cool in another. One bench was wet. One shelf was dry. Roots were growing, leaves were falling, spikes were lengthening, pseudobulbs were resting, and flowers were opening according to schedules no gardener had written.

Nora looked down the aisle that had seemed so beautifully perfect seven weeks before.

Now it was crowded, uneven and alive.

Edith touched her arm.

“Tomorrow,” she said, “we look again.”

And they did.
