---
id: chronicle-i
title: The Night of the Black Rot
subtitle: A tale of orchids and Halloween
number: I
accent: halloween
epigraph: "Beneath the moon's eerie glow, an orchid blooms only once a year, but beware, for it may not be the only thing stirring in the night."
epigraphSource: The Night of the Black Rot
source: Canonical text — "The Night of the Black Rot: a tale of orchids and Halloween", Five Cities Orchid Society
notice: This Chronicle reproduces the Five Cities Orchid Society story exactly as written. The curse, the antidote rhyme and the charm are fiction and are part of the tale. Factual disease guidance is kept separate, under "Science Behind the Story" and in the Plant Doctor.
---

::: image id="scene-fog-cliffs" layout="full" caption="The night before Halloween, above the coastal cliffs of Pismo Beach." :::

It was the night before Halloween, and a heavy fog settled over the coastal cliffs of Pismo Beach.

Beneath the moon's eerie glow, an orchid blooms only once a year, but beware, for it may not be the only thing stirring in the night.

[divider]

::: image id="scene-edith-lantern" layout="full" caption="Inside Edith Bramble's greenhouse, the jack-o'-lantern casting eerie shadows on the plants." :::

Inside Edith Bramble's greenhouse, her orchids sparkled with the dampness from a late evening watering. In the center of the room sat a large {{jack-o-lantern|jack-o-lantern}}, its flickering light casting eerie shadows on the plants.

[divider]

::: image id="scene-hazel-arrives" layout="wrap-right" caption="Hazel Nightshade, a wicked witch who thrived in the cold, wet night." :::

In the deep of the night, the air grew heavy with the scent of the {{black-orchid|black orchid's}} bloom. But with its beauty came a sinister presence. Eyes-unseen but felt-pierced through the veil of darkness, and the faint rustle of leaves whispered a warning that no one would ever hear.

Unbeknownst to Edith, her greenhouse had caught the attention of Hazel Nightshade, a wicked witch who thrived in the cold, wet night. From the edge of the mist, Hazel approached, her long fingers tracing the glass as she whispered a dark curse in the old tongue:

::: effect name="hazel-hand" :::

::: image id="scene-curse" layout="full" caption="A dark curse, whispered in the old tongue." :::

::: verse title="The Curse of the Black Rot" :::
"In damp and cold, let the rot take hold,
From roots to bloom, decay and gloom.
By night's cold breath, the blooms shall die,
And in their place, black rot will lie."
:::

As the curse was cast, tendrils of black rot began to snake up the roots of Edith's orchids, creeping through the dark, drawn to the rotting pumpkin in the corner.

[divider]

## The Morning Horror

::: image id="scene-black-rot" layout="wrap-left" caption="Roots and leaves blackened, the air thick with the stench of decay." :::

The next morning, Edith returned to her greenhouse, expecting to find her orchids thriving. Instead, she found them consumed by black rot, their roots and leaves blackened, the air thick with the stench of decay. The jack-o-lantern, now sagging and moldy, seemed to grin wider as the rot spread toward it.

Panicked, Edith tried to save her plants, cutting away the infected parts, but the rot spread faster than she could move. Before she could react, the rot pulsed, sending a dark cloud of {{spray-bottle|spores}} into the air.

::: effect name="spore-sequence" :::

The cloud swirled around her, and before she could scream, she vanished, engulfed by the blackness.

::: science id="black-rot" label="Science behind black rot" :::

[divider]

## The Orchid Society Arrives

::: image id="scene-society-arrives" layout="wrap-right" caption="Mara, Julian, Mina and a few new members arrive for their greenhouse tour." :::

Later that day, the members of the Five Cities Orchid Society—you, Mara, Julian, and Mina and few new members arrived for their greenhouse tour. They were met with a scene of devastation. The greenhouse, once filled with vibrant orchids, was now overrun with black rot, the plants withering and collapsing. "Where's Edith?" Mara asked, her voice concerned.

::: effect name="fog-help" id="scene-edith-lantern" :::

"This isn't just black rot," Julian muttered, inspecting one of the infected plants. "There's something darker at work here."

::: image id="scene-grimoire-found" layout="wrap-left" caption="A small set of newsletters, bound in a worn, cracked cover." :::

As they searched the greenhouse, Mara found something unusual—a small set of newsletters, bound in a worn, cracked cover. She flipped through the pages and gasped.

"This isn't just a collection of orchid tips," she whispered. "This is Hazel Nightshade's {{grimoire|grimoire}}, disguised to look like society newsletters!" Inside the grimoire, hidden among orchid care tips, was the antidote to the black rot, written in an ancient rhyme:

[divider]

## The Antidote to the Black Rot

::: image id="scene-antidote" layout="wrap-right" caption="The society members quickly made the potion and used the fungicide to treat the plants." :::

::: verse title="The Antidote to the Black Rot" :::
"Set the stricken one apart,
Far from leaf and root and heart.
Pass the blade through cleansing flame,
Cool it well, then cut the stain.
Cut beyond the blackened line,
Till the flesh is clean and fine.
Flame the blade 'twixt every cut,
Cast away what carried rot.
Cinnamon upon the scar,
Keeps the creeping damp afar.
Or Dragon's Blood, a crimson seal,
Where the wounded tissues heal.
Give it air and keep it dry,
Watch the margin with your eye.
Should the darkness spread anew,
Stronger medicine must pursue."
:::

The society members quickly made the potion and used the fungicide to treat the plants.

[divider]

## The Power of the Charm

::: image id="scene-charm" layout="wrap-left" caption="The logo of the Five Cities Orchid Society, engraved on a medallion." :::

But there was more. In the back of the grimoire, hidden within the folds of its dark pages, Mara found a small charm—the logo of the Five Cities Orchid Society, engraved on a medallion. The orchid, in full bloom, was encircled by ancient protective symbols.

"This {{talisman|charm}}," Mara explained, holding it up, "was made by the wisest to encourage and inspire. It's said to ward off evil and ignorance and protect orchids. We need to hang it here, at the door, to let the witch know this greenhouse is cared for by a member of the society."

They hung the charm on the door of the greenhouse, and as it swung gently in the foggy air, the atmosphere inside began to shift. The heavy, cursed air seemed to lift, and the rot stopped its spread.

[divider]

## The Witch Returns

::: image id="scene-witch-returns" layout="wrap-right" caption="Her shadowy form appeared once more, her eyes glowing faintly in the mist." :::

But Hazel was not finished. From the back of the greenhouse, her shadowy form appeared once more, her eyes glowing faintly in the mist. She hissed as she saw the charm hanging on the door.

"Poor Edith Bramble" she mocked. "Did she not pay her dues?"

And with an evil flourish of her dark cloak, she reached out with her craggy hand and grasped the still blooming black orchid, and incanted,

::: verse title="Hazel's Parting Incantation" :::
"A charm of gold, to ward me back,
But I'll return, when nights are black.
Though now you stand and think you've won,
Beware, for rot has just begun."
:::

Mara stood firm, holding up the grimoire and the fungicide they had mixed from its pages. "You can't curse what's cared for by the Five Cities Orchid Society," she said, her voice steady. "We have the knowledge, the protection, and the together we will stop you."

As the charm glowed brightly in the fog, Hazel screeched, her form dissolving into the mist. "I'll be back!" she howled as she vanished into the fog. "Every cold night, I'll return!"

[divider]

::: image id="scene-charm-on-door" layout="full" caption="The charm hangs at the door, and the fog lifts." :::

::: effect name="frog" id="frog-c1" :::

In the end, the black rot was not beaten by any single trick. It was beaten by the right care—isolating the sick plants, clean tools, good airflow, careful {{journal|watering}} and proper treatment—and by the collective strength of the orchid society.

The charm, carrying the logo of the Five Cities Orchid Society, served as a reminder that no grower is ever alone in their journey.

To this day, the charm is passed among society members, a symbol of protection and community. And each year, as Halloween approaches and the cold fog rolls in, the society gathers to share this tale—a reminder that knowledge and community are the true defenses against whatever darkness may creep into their greenhouses.

::: closing :::
No grower is ever alone.
:::
