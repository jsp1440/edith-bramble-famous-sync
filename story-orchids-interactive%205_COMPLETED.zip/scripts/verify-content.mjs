import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve('src');
const forbidden = [
  /\bKaren\b/, /\bMichael\b/, /\bKrystie\b/, /\bEd\b/, /\bChris\b/, /\bLance\b/, /\bEric\b/, /\bAlan\b/, /\bJeff\b/, /\bRhianna\b/, /\bJohn\b/,
  /AUTUMN DOES NOT HAPPEN TO THE GREENHOUSE/i,
  /c2-pencil-map/,
];
const allowedInternal = new Set([
  path.join(root, 'components/c1/SceneGrimoire.tsx'),
  path.join(root, 'components/c1/SanitationSpell.tsx'),
]);

const files = [];
function walk(dir) {
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p);
    else if (/\.(tsx?|json|md)$/.test(name)) files.push(p);
  }
}
walk(root);

const failures = [];
for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  for (const re of forbidden) {
    if (re.test(text)) {
      if (allowedInternal.has(file) && /Karen/.test(re.source)) continue;
      failures.push(`${path.relative(process.cwd(), file)} matched ${re}`);
    }
  }
}

const chronicle = fs.readFileSync(path.join(root, 'content/chronicles/chronicle-ii.md'), 'utf8');
for (const h of ['Chapter One', 'Chapter Two', 'Chapter Three', 'Chapter Four', 'Chapter Five']) {
  if (!chronicle.includes(`## ${h}`)) failures.push(`Chronicle II missing ${h}`);
}

if (failures.length) {
  console.error('Publish-readiness content check failed:\n' + failures.join('\n'));
  process.exit(1);
}
console.log('Publish-readiness content check passed.');
