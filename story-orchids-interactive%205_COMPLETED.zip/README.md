# The Edith Bramble Chronicles — Stories from the Greenhouse

An interactive, illustrated storytelling website for the **Five Cities Orchid Society**, combining
fiction, orchid-growing education, botany, plant pathology, printable activities, recipes and an
optional route into deeper science.

The repository is the **canonical source of truth**. Story text, articles, character information,
activities, image references and cards all live in Markdown and JSON under `src/content/`. No story
content is hard-coded into presentation components.

---

## Stack

- React 18 + TypeScript + Vite
- Tailwind CSS (design tokens in `src/index.css`)
- React Router for module routing
- No CMS, no vendor lock-in — plain files, fully exportable

---

## Content directory

```
src/content/
├── site.json               site identity, module navigation, FCOS info
├── chronicles.json         six-volume manifest (live / coming-soon)
├── media.json              image registry: id → { src, alt, credit }
├── discoveries.json        story markers → drawers, modules, cards
├── cards.json              Collector's Cabinet (character / artifact / orchid)
├── chronicles/
│   └── chronicle-i.md      manuscript (frontmatter + story blocks)
└── modules/
    ├── journal.json        Edith's Greenhouse Journal
    ├── grimoire.json       Hazel Nightshade's Grimoire
    ├── potting-bench.json  Edith's Potting Bench
    ├── plant-doctor.json   Plant Doctor
    ├── kitchen.json        Edith's Kitchen
    ├── coloring.json       Coloring Studio (three audience levels)
    ├── herbarium.json      Edith's Herbarium
    ├── plates.json         Botanical Plates
    ├── watch-listen.json   Multimedia slots
    └── go-deeper.json      Orchid Continuum / Calyx boundary
```

Module JSON files and chronicle Markdown files are auto-registered with `import.meta.glob`
(`src/lib/content.ts`) — dropping in a new file is enough.

## Presentation directory

```
src/components/
├── AppLayout.tsx           routes + shell
├── site/                   header, footer, ornaments, print button
├── story/                  StoryRenderer, DiscoveryDrawer
├── modules/ModulePage.tsx  generic content-driven module renderer
├── cards/TradingCard.tsx   printable collector card
└── pages/                  Home, Library, Chronicle, Cabinet, Coloring, GoDeeper, About
src/lib/
├── content.ts              content loaders
├── content-types.ts        content schema (TypeScript)
├── story-parser.ts         Markdown + directive → block model
└── goDeeper.ts             Orchid Continuum / Calyx adapter boundary
```

---

## Adding Chronicle II (or III … VI)

1. **Register images** in `src/content/media.json`:
   ```json
   "scene-ii-opening": { "src": "…", "alt": "Descriptive alt text", "credit": "Illustration — Chronicle II" }
   ```
2. **Write the manuscript** at `src/content/chronicles/chronicle-ii.md` (syntax below).
3. **Activate the volume** in `src/content/chronicles.json`: set `status` to `"live"`,
   `contentFile` to `"chronicle-ii.md"`, `cover` to a media id, and fill in title/subtitle/summary.
4. **Add discoveries** to `src/content/discoveries.json` for any inline `{{marker}}` used.
5. **Add cards** to `src/content/cards.json` (`discoverable: true` locks a card until it is found).
6. Deploy. **No component, route or stylesheet changes are required.**

### Story syntax

```markdown
---
id: chronicle-ii
title: Pending Title
number: II
accent: default
epigraph: "A line of verse."
epigraphSource: Attribution
notice: Optional editorial note displayed above the story.
---

## Scene One — Heading

Ordinary prose. *Italic* and **bold** work.
Inline discoveries look like {{talisman|the talisman}} and open a side drawer.

> A pull quote.

[divider]

::: image id="media-id" layout="full" caption="Caption" :::
::: image id="media-id" layout="wrap-right" caption="Wrapped image" :::
::: audio id="narration-id" :::

::: pending title="Scenes Four to Nine" :::
Text explaining what is still to come.
:::

::: closing :::
No grower is ever alone.
:::
```

Image layouts: `full`, `wrap-right`, `wrap-left`, `inline`.

---

## Module entry schema

```jsonc
{
  "id": "unique-id",
  "title": "Entry title",
  "kind": "Method | Disease | Recipe | Activity | …",
  "status": "live | pending",
  "summary": "One-line italic summary",
  "body": ["Paragraph one.", "Paragraph two."],
  "meta": [{ "label": "Level", "value": "Everyone" }],
  "list": [{ "title": "Steps", "items": ["…"] }],
  "practice": { "title": "Grower practice — not validated treatment", "body": "…" },
  "notes": { "label": "Edith's Note", "body": "…" },
  "goDeeper": { "title": "Go Deeper — …", "body": ["…"] },
  "links": [{ "label": "Plant Doctor", "to": "/plant-doctor" }],
  "printable": { "kind": "recipe", "label": "Print recipe card" },
  "image": "media-id",
  "media": { "type": "audio", "src": null }
}
```

---

## Editor sign-in (database-backed)

Reading is always public — there is no landing gate. Society editors sign in from the **Editor sign
in** button in the site header, which opens a modal (`src/components/auth/AuthModal.tsx`).

- Auth state lives in `src/contexts/AuthContext.tsx` (Supabase session + `profiles` row + modal state).
- The `profiles` table stores `id`, `email`, `display_name` and `role` (`member` | `editor` | `admin`),
  with RLS so a signed-in user can only read and update their own row. A trigger on `auth.users`
  provisions the profile automatically at sign-up.
- `/admin` (`src/components/pages/AdminPage.tsx`) is protected: signed-out visitors see a prompt to
  open the sign-in modal, `member` accounts see a role notice, and `editor`/`admin` accounts get the
  workspace listing every Chronicle, module entry and card with its live/pending status.

---

## Editorial standards

- Never invent scientific claims, remedies, recipes or Society history to fill a section. Mark it
  `"status": "pending"` — the UI renders a clearly-labelled pending state.
- Grower tradition is labelled **grower practice**, distinct from validated treatment, and carries
  phytotoxicity / label-compliance cautions.
- Fiction (the Grimoire) is visibly separated from horticultural guidance.
- **Observe, photograph, and sketch wild orchids. Do not collect them.** Plant-press activities
  recommend only common weeds, cultivated plants, fallen leaves, or material collected with
  permission.
- Every image needs meaningful alt text where it is registered in `media.json`.

---

## Printing

Print styles live at the bottom of `src/index.css`. Elements marked `.no-print` are hidden,
`.print-sheet` avoids page breaks, and coloring sheets, cards, recipes, herbarium sheets and
botanical plates all print on A4 / US Letter.

## Orchid Continuum integration

The public site is publishable without private Orchid Continuum credentials. Feature Genius uses the deployed `orchid-explorer` data service and clearly reports when the deeper Orchid Continuum endpoint is unavailable. The Culture Library keeps unsupported claims in an evidence-pending state rather than fabricating a result.

For a full Orchid Continuum connection, configure the public read-only integration endpoint in the backend service. Secrets remain server-side; the browser must never contain a privileged OC credential.

## Development

```bash
npm install
npm run dev      # local development
npm run build    # production build
```
