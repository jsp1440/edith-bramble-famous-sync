import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://yjmgqccvilhxuuxmvzud.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIyNWI2YjI4LWM2NTYtNGUzYy05N2JjLTRhNzMzNWNhZGNmZiJ9.eyJwcm9qZWN0SWQiOiJ5am1ncWNjdmlsaHh1dXhtdnp1ZCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzg3MjEyMjY5LCJleHAiOjIxMDI1NzIyNjksImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.3qIZopQhmM5fmM_xb3ZFsgRPnRBvtJA9dH3mG-SRUQE';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };