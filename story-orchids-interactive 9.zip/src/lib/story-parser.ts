import type { StoryBlock, StoryDocument } from './content-types';

const attrRe = /(\w+)="([^"]*)"/g;

function parseAttrs(source: string): Record<string, string> {
  const attrs: Record<string, string> = {};
  let match: RegExpExecArray | null;
  attrRe.lastIndex = 0;
  while ((match = attrRe.exec(source)) !== null) attrs[match[1]] = match[2];
  return attrs;
}

function parseFrontmatter(raw: string): { frontmatter: Record<string, string>; body: string } {
  if (!raw.startsWith('---')) return { frontmatter: {}, body: raw };
  const end = raw.indexOf('\n---', 3);
  if (end === -1) return { frontmatter: {}, body: raw };
  const head = raw.slice(3, end);
  const body = raw.slice(end + 4);
  const frontmatter: Record<string, string> = {};
  head.split('\n').forEach((line) => {
    const idx = line.indexOf(':');
    if (idx === -1) return;
    const key = line.slice(0, idx).trim();
    let value = line.slice(idx + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (key) frontmatter[key] = value;
  });
  return { frontmatter, body };
}

/**
 * Parses the Chronicle story syntax:
 *   ## Heading
 *   > pull quote
 *   [divider]
 *   ::: image id="x" layout="full" caption="y" :::
 *   ::: pending title="t" :::  ...text...  :::
 *   ::: closing ::: ...text... :::
 *   inline: {{discovery-id|visible label}}, *italic*, **bold**
 */
export function parseStory(raw: string): StoryDocument {
  const { frontmatter, body } = parseFrontmatter(raw);
  const lines = body.split('\n');
  const blocks: StoryBlock[] = [];
  let paragraph: string[] = [];

  const flush = () => {
    if (paragraph.length) {
      blocks.push({ type: 'paragraph', text: paragraph.join(' ').trim() });
      paragraph = [];
    }
  };

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      flush();
      continue;
    }

    if (trimmed.startsWith(':::')) {
      flush();
      const inner = trimmed.replace(/^:::\s*/, '').replace(/\s*:::$/, '');
      const [directive] = inner.split(/\s+/);
      const attrs = parseAttrs(inner);

      if (directive === 'image' && trimmed.endsWith(':::')) {
        blocks.push({
          type: 'image',
          id: attrs.id || '',
          layout: (attrs.layout as 'full' | 'wrap-right' | 'wrap-left' | 'inline') || 'full',
          caption: attrs.caption,
          effect: attrs.effect,
        });
        continue;
      }

      if (directive === 'effect' && trimmed.endsWith(':::')) {
        blocks.push({
          type: 'effect',
          name: attrs.name || '',
          id: attrs.id,
          stage: attrs.stage ? Number(attrs.stage) : undefined,
        });
        continue;
      }

      if (directive === 'audio' && trimmed.endsWith(':::')) {
        blocks.push({ type: 'audio', id: attrs.id || '', caption: attrs.caption });
        continue;
      }

      if (directive === 'science' && trimmed.endsWith(':::')) {
        blocks.push({ type: 'science', id: attrs.id || '', label: attrs.label });
        continue;
      }

      if (directive === 'verse' || directive === 'note') {
        const collected: string[] = [];
        i += 1;
        while (i < lines.length && lines[i].trim() !== ':::') {
          collected.push(lines[i].trim());
          i += 1;
        }
        blocks.push({ type: directive, title: attrs.title, lines: collected.filter(Boolean) });
        continue;
      }


      if (directive === 'pending' || directive === 'closing') {
        const collected: string[] = [];
        i += 1;
        while (i < lines.length && lines[i].trim() !== ':::') {
          collected.push(lines[i].trim());
          i += 1;
        }
        const text = collected.join(' ').trim();
        blocks.push(
          directive === 'pending'
            ? { type: 'pending', title: attrs.title || 'Pending content', text }
            : { type: 'closing', text },
        );
        continue;
      }

      continue;
    }

    if (trimmed === '[divider]' || trimmed === '* * *') {
      flush();
      blocks.push({ type: 'divider' });
      continue;
    }

    if (trimmed.startsWith('## ')) {
      flush();
      blocks.push({ type: 'heading', text: trimmed.slice(3).trim() });
      continue;
    }

    if (trimmed.startsWith('> ')) {
      flush();
      blocks.push({ type: 'quote', text: trimmed.slice(2).trim() });
      continue;
    }

    paragraph.push(trimmed);
  }
  flush();

  return { frontmatter, blocks };
}

export type InlineToken =
  | { type: 'text'; value: string }
  | { type: 'em'; value: string }
  | { type: 'strong'; value: string }
  | { type: 'discovery'; id: string; value: string }
  | { type: 'grower'; id: string; value: string; italic: boolean };

/** Splits a line of story prose into inline tokens (bold, italic, discovery markers, grower cards). */
export function parseInline(text: string): InlineToken[] {
  const tokens: InlineToken[] = [];
  const re = /(\[\[[^\]]+\]\])|(\{\{[^}]+\}\})|(\*\*[^*]+\*\*)|(\*[^*]+\*)/g;
  let last = 0;
  let match: RegExpExecArray | null;

  while ((match = re.exec(text)) !== null) {
    if (match.index > last) tokens.push({ type: 'text', value: text.slice(last, match.index) });
    const chunk = match[0];
    if (chunk.startsWith('[[')) {
      const inner = chunk.slice(2, -2);
      const [id, rawLabel] = inner.split('|');
      let label = (rawLabel || id).trim();
      const italic = label.startsWith('*') && label.endsWith('*');
      if (italic) label = label.slice(1, -1);
      tokens.push({ type: 'grower', id: id.trim(), value: label, italic });
    } else if (chunk.startsWith('{{')) {
      const inner = chunk.slice(2, -2);
      const [id, label] = inner.split('|');
      tokens.push({ type: 'discovery', id: id.trim(), value: (label || id).trim() });
    } else if (chunk.startsWith('**')) {
      tokens.push({ type: 'strong', value: chunk.slice(2, -2) });
    } else {
      tokens.push({ type: 'em', value: chunk.slice(1, -1) });
    }
    last = match.index + chunk.length;
  }
  if (last < text.length) tokens.push({ type: 'text', value: text.slice(last) });
  return tokens;
}
