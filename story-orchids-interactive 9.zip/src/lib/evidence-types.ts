/* ------------------------------------------------------------------
   Evidence & provenance schema for the FCOS Orchid Culture Library.

   Constitution (enforced by the types and components, not by hope):
   • Nothing here is ever auto-filled. Missing = EVIDENCE PENDING.
   • Evidence classes are never merged. A grower observation is not a
     published finding; an Orchid Continuum inference is not evidence.
   • AI-generated or AI-assisted text is tracked as such internally and
     can never be labelled expert-reviewed by the software.
------------------------------------------------------------------- */

export type EvidenceClass =
  | 'published-science'
  | 'horticultural-guidance'
  | 'botanical-database'
  | 'field-observation'
  | 'grower-experience'
  | 'fcos-interpretation'
  | 'oc-inference'
  | 'unverified';

export type ClaimConfidence = 'high' | 'moderate' | 'low' | 'evidence-pending';

export type ClaimReviewState = 'draft' | 'source-checked' | 'expert-reviewed' | 'disputed' | 'evidence-pending';

/** Internal authorship record (Part 24). Never shown as authority. */
export type ContentOrigin = 'source-derived' | 'human-written' | 'ai-assisted' | 'ai-inferred' | 'expert-reviewed';

export interface ClaimSource {
  evidenceClass: EvidenceClass;
  /** Full citation exactly as published. Never generated. */
  citation: string;
  url?: string;
  doi?: string;
  /** For grower experience: who, where, growing context. */
  context?: string;
  /** ISO date the source was checked by a person. */
  checkedOn?: string;
}

export interface Claim {
  id: string;
  profileId: string;
  section: ProfileSection;
  text: string;
  evidenceClass: EvidenceClass;
  sources: ClaimSource[];
  confidence: ClaimConfidence;
  reviewState: ClaimReviewState;
  origin: ContentOrigin;
  lastReviewed: string | null;
  /** Taxonomic scope the statement is meant for, e.g. "genus", "moisture-loving species". */
  scope?: string;
}

export type ProfileSection =
  | 'overview'
  | 'habitat'
  | 'map'
  | 'adaptations'
  | 'seasonal'
  | 'culture'
  | 'signals'
  | 'evidence'
  | 'review';

export type AosScope = 'genus' | 'alliance' | 'related-alliance' | 'seasonal';

export interface AosSheet {
  title: string;
  url: string;
  scope: AosScope;
  /** Plain statement of what the sheet covers relative to this profile. */
  scopeNote: string;
  /** ISO date a person confirmed the link resolves on aos.org. */
  verifiedOn: string;
}

/* ---------------- Map evidence (provider-independent) ---------------- */

export type MapRecordKind =
  | 'documented-occurrence'
  | 'generalized-occurrence'
  | 'published-range'
  | 'inferred-distribution'
  | 'historical-record'
  | 'uncertain-record'
  | 'sensitive-obscured';

export interface MapRecord {
  id: string;
  kind: MapRecordKind;
  taxon: string;
  lat: number;
  lng: number;
  /** Radius (km) of positional uncertainty or generalisation. */
  uncertaintyKm?: number;
  sensitive?: boolean;
  year?: number;
  elevationM?: number;
  source: { database: string; recordUrl?: string; citation?: string; license?: string };
}

/* ---------------- Image provenance ---------------- */

export type ImageRole = 'scientific-photograph' | 'habitat-photograph' | 'story-illustration-ai' | 'decorative';

export interface ImageProvenance {
  role: ImageRole;
  src: string;
  creator?: string;
  source?: string;
  license?: string;
  recordUrl?: string;
  taxon?: string;
  sourceDatabase?: string;
  reviewState?: ClaimReviewState;
}
