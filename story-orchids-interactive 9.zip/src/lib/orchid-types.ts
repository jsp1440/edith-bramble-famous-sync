/* ------------------------------------------------------------------
   Science Greenhouse data model.

   Every orchid profile follows the causal chain the whole site teaches:
   ORIGIN → HABITAT → CONDITIONS → ADAPTATION → ANATOMY → FUNCTION
   → WHAT THE GROWER SEES → CULTURAL RESPONSE.

   Every assertion-bearing section can carry Evidence so that static,
   hand-verified content can later be replaced by Orchid Continuum data
   without changing any component.
------------------------------------------------------------------- */

export type EvidenceType =
  | 'horticultural-consensus'
  | 'botanical-literature'
  | 'field-observation'
  | 'image-observation'
  | 'story';

export type Confidence = 'high' | 'moderate' | 'low';
export type ReviewState = 'draft' | 'pending-review' | 'reviewed';

export interface Evidence {
  /** Citation text or source record id. null = not yet supplied (never invented). */
  source: string | null;
  evidenceType: EvidenceType;
  confidence: Confidence;
  reviewState: ReviewState;
}

export interface SourceRef {
  id: string;
  citation: string;
  url?: string;
  evidenceType: EvidenceType;
}

export type RegionKey =
  | 'mexico'
  | 'central-america'
  | 'andes'
  | 'amazon-guianas'
  | 'brazil'
  | 'himalaya'
  | 'china'
  | 'indochina'
  | 'new-guinea'
  | 'ne-australia'
  | 'e-australia';

export interface ReadThePlantFeature {
  id: string;
  label: string;
  /** WHAT YOU CAN SEE */
  see: string;
  /** WHAT SCIENCE SAYS THIS STRUCTURE DOES */
  does: string;
  /** WHAT HABITAT EVIDENCE SUGGESTS */
  habitat: string;
  /** WHAT IT MAY MEAN FOR CULTURE */
  culture: string;
  /** WHAT THIS IMAGE CANNOT TELL YOU */
  cannotTell: string;
}

export interface Adaptation {
  structure: string;
  fn: string;
}

export interface SeasonPhase {
  phase: string;
  when: string;
  note: string;
}

export type GrowPlace = 'Greenhouse' | 'Windowsill' | 'Patio' | 'Shade / lath house' | 'Under lights';

export interface WhereToGrow {
  place: GrowPlace;
  fit: 'good' | 'possible' | 'difficult' | 'unknown';
  note: string;
}

/** 1–5 scales used by "Why are these orchids neighbors?" */
export interface ClimateProfile {
  temperature: number; // 1 cool … 5 warm
  moisture: number; // 1 seasonally dry … 5 constantly moist
  light: number; // 1 shade … 5 bright
  airflow: number; // 1 tolerant of still air … 5 needs strong movement
  seasonality: number; // 1 even year-round … 5 strongly seasonal
  summary: {
    temperature: string;
    moisture: string;
    light: string;
    airflow: string;
    seasonality: string;
  };
}

export interface NatureImageSlot {
  caption: string;
  /** Filled only with rights-cleared, provenance-tracked photographs. */
  photo?: {
    src: string;
    creator?: string;
    license: string;
    source: string;
    taxon: string;
    location?: string;
  };
}

export interface OrchidProfile {
  id: string;
  name: string;
  acceptedName: string;
  rank: 'genus' | 'species' | 'group' | 'subtribe';
  taxonomy: string;
  synonyms?: string[];
  image?: string;
  imageKind: 'illustration' | 'photograph';
  hook: string;
  origin: { summary: string; regions: RegionKey[] };
  habitat: { label: string; value: string }[];
  natureImages: NatureImageSlot[];
  readThePlant: ReadThePlantFeature[];
  adaptations: Adaptation[];
  seasonal: SeasonPhase[];
  growerSees: string[];
  culture: { label: string; value: string }[];
  whereToGrow: WhereToGrow[];
  neighbors: { id?: string; name: string; why: string }[];
  sameNameDifferentLife?: { id?: string; name: string; contrast: string }[];
  climate: ClimateProfile;
  aos: { sheetTitle: string; url: string | null };
  sources: SourceRef[];
  evidence: Evidence;
  variationNote?: string;
  chronicles: { id: string; note: string }[];
}
