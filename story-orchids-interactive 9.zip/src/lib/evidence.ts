import type { OrchidProfile } from './orchid-types';
import type {
  AosSheet,
  Claim,
  ClaimConfidence,
  ClaimReviewState,
  ClaimSource,
  EvidenceClass,
  ImageProvenance,
  MapRecord,
  MapRecordKind,
  ProfileSection,
} from './evidence-types';

/* ================= Labels (single source of truth) ================= */

export const EVIDENCE_CLASS_LABEL: Record<EvidenceClass, { label: string; short: string; note: string }> = {
  'published-science': { label: 'Published scientific evidence', short: 'Published', note: 'Peer-reviewed or formally published research.' },
  'horticultural-guidance': { label: 'Authoritative horticultural guidance', short: 'Horticultural guidance', note: 'e.g. American Orchid Society culture sheets. Usually genus- or alliance-level.' },
  'botanical-database': { label: 'Botanical database record', short: 'Database record', note: 'e.g. taxonomic or specimen databases.' },
  'field-observation': { label: 'Field observation', short: 'Field observation', note: 'Recorded observation of plants in habitat.' },
  'grower-experience': { label: 'Expert grower experience', short: 'Grower experience', note: 'Valuable observation in a specific place and setup — not a universal rule.' },
  'fcos-interpretation': { label: 'FCOS interpretation', short: 'FCOS interpretation', note: 'Our explanation, linking sources together. Only as strong as the sources beneath it.' },
  'oc-inference': { label: 'Orchid Continuum inference', short: 'OC inference', note: 'A hypothesis produced by Orchid Continuum reasoning. Not evidence until supported.' },
  unverified: { label: 'Unverified — evidence pending', short: 'Evidence pending', note: 'No supporting source has been attached and checked yet.' },
};

export const REVIEW_STATE_LABEL: Record<ClaimReviewState, string> = {
  draft: 'Draft',
  'source-checked': 'Source-checked',
  'expert-reviewed': 'Expert-reviewed',
  disputed: 'Disputed',
  'evidence-pending': 'Evidence pending',
};

export const CONFIDENCE_LABEL: Record<ClaimConfidence, string> = {
  high: 'High',
  moderate: 'Moderate',
  low: 'Low',
  'evidence-pending': 'Evidence pending',
};

export const SECTION_LABEL: Record<ProfileSection, string> = {
  overview: 'Overview',
  habitat: 'Habitat',
  map: 'Map',
  adaptations: 'Adaptations',
  seasonal: 'Seasonal cycle',
  culture: 'Culture',
  signals: 'What the plant is telling you',
  evidence: 'Evidence & sources',
  review: 'Expert review',
};

export const MAP_RECORD_LABEL: Record<MapRecordKind, { label: string; note: string }> = {
  'documented-occurrence': { label: 'Documented occurrence', note: 'A specimen or verified observation at a recorded point.' },
  'generalized-occurrence': { label: 'Generalized occurrence', note: 'Location deliberately coarsened (e.g. to a grid cell or region).' },
  'published-range': { label: 'Published range', note: 'A range drawn by the cited authors — shown only with that citation.' },
  'inferred-distribution': { label: 'Inferred distribution', note: 'Modelled or inferred; not observed.' },
  'historical-record': { label: 'Historical record', note: 'Old collection; the population may no longer exist.' },
  'uncertain-record': { label: 'Uncertain record', note: 'Identification or location is in doubt.' },
  'sensitive-obscured': { label: 'Sensitive — locality obscured', note: 'Precise locality withheld for conservation.' },
};

export const SPECIALTIES = [
  'Phragmipedium',
  'Paphiopedilum',
  'Pleurothallids',
  'Dendrobium',
  'Catasetinae',
  'Cymbidium',
  'Sarcochilus',
  'Cattleya alliance',
  'Lycaste',
  'Stanhopea',
  'Orchid pathology',
  'Greenhouse systems',
  'Orchid ecology',
  'Taxonomy',
] as const;

/** Which specialties a profile belongs to — used by "Review claims in my specialty". */
export const PROFILE_SPECIALTIES: Record<string, string[]> = {
  catasetinae: ['Catasetinae'],
  phragmipedium: ['Phragmipedium'],
  'dendrobium-nobile': ['Dendrobium'],
  'dendrobium-phalaenanthe': ['Dendrobium'],
  lycaste: ['Lycaste'],
  cymbidium: ['Cymbidium'],
  sarcochilus: ['Sarcochilus'],
  stanhopea: ['Stanhopea'],
  'laelia-anceps': ['Cattleya alliance'],
};

/** Sections every specialist in these fields may also want to see. */
export const CROSS_CUTTING: Record<string, ProfileSection[]> = {
  'Orchid ecology': ['habitat', 'adaptations', 'seasonal'],
  'Greenhouse systems': ['culture'],
  'Orchid pathology': ['signals'],
  Taxonomy: ['overview'],
};

/* ================= American Orchid Society culture sheets =================
   Every URL below was confirmed as listed on
   https://www.aos.org/orchid-care/orchid-care-and-culture-sheets on 2026-09-27.
   Do not add a URL here without the same check. No sheet = no link.        */

const AOS_CHECKED = '2026-09-27';
export const AOS_INDEX = 'https://www.aos.org/orchid-care/orchid-care-and-culture-sheets';

export const AOS_SHEETS: Record<string, AosSheet[]> = {
  catasetinae: [
    { title: 'Catasetum Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/catasetum-culture-sheet', scope: 'genus', scopeNote: 'Genus-level guidance for Catasetum. Related genera in the subtribe have their own sheets.', verifiedOn: AOS_CHECKED },
    { title: 'Catasetum Seasonal Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/catasetum-seasonal-culture-sheet', scope: 'seasonal', scopeNote: 'Season-by-season guidance for Catasetum.', verifiedOn: AOS_CHECKED },
    { title: 'Cycnoches Seasonal Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/cycnoches-seasonal-culture-sheet', scope: 'seasonal', scopeNote: 'Genus-level seasonal guidance for Cycnoches.', verifiedOn: AOS_CHECKED },
    { title: 'Clowesia Seasonal Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/clowesia-seasonal-culture-sheet', scope: 'seasonal', scopeNote: 'Genus-level seasonal guidance for Clowesia.', verifiedOn: AOS_CHECKED },
  ],
  'dendrobium-nobile': [
    { title: 'Dendrobium Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/dendrobium-general-culture-sheet', scope: 'genus', scopeNote: 'General guidance for the whole, very diverse genus Dendrobium — not specific to nobile-type plants.', verifiedOn: AOS_CHECKED },
  ],
  'dendrobium-phalaenanthe': [
    { title: 'Dendrobium Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/dendrobium-general-culture-sheet', scope: 'genus', scopeNote: 'General guidance for the whole, very diverse genus Dendrobium — not specific to Phalaenanthe-type plants.', verifiedOn: AOS_CHECKED },
  ],
  lycaste: [
    { title: 'Lycaste Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/lycaste-culture-sheet', scope: 'genus', scopeNote: 'Genus-level guidance; the sheet itself distinguishes deciduous and evergreen species.', verifiedOn: AOS_CHECKED },
  ],
  cymbidium: [
    { title: 'Cymbidium Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/cymbidium-culture-sheet', scope: 'genus', scopeNote: 'Genus-level guidance, oriented to the commonly grown hybrids.', verifiedOn: AOS_CHECKED },
  ],
  sarcochilus: [
    { title: 'Sarcochilus Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/sarcochilus-culture-sheet', scope: 'genus', scopeNote: 'Genus-level guidance.', verifiedOn: AOS_CHECKED },
  ],
  stanhopea: [
    { title: 'Stanhopea Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/stanhopea-culture-sheet', scope: 'genus', scopeNote: 'Genus-level guidance.', verifiedOn: AOS_CHECKED },
  ],
  'laelia-anceps': [
    { title: 'Cattleya Culture Sheet', url: 'https://www.aos.org/orchid-care/care-sheets/cattleya-culture-sheet', scope: 'related-alliance', scopeNote: 'Guidance written for Cattleya. Laelia anceps belongs to the same broad alliance but is NOT a Cattleya; this is related, not species-specific, guidance.', verifiedOn: AOS_CHECKED },
  ],
  // phragmipedium: no Phragmipedium sheet appears on the AOS culture-sheet index (checked 2026-09-27).
  // The Paphiopedilum sheet is a different genus and is deliberately NOT substituted.
};

export const aosSheetsFor = (profileId: string): AosSheet[] => AOS_SHEETS[profileId] ?? [];

/* ================= Claim registry =================
   Existing profile prose is registered claim-by-claim so that each
   statement can carry its own evidence. These drafts were written with
   AI assistance and have NOT been source-checked, so every derived claim
   starts as UNVERIFIED / EVIDENCE PENDING.

   To attach real evidence, add an entry to CLAIM_EVIDENCE keyed by claim id
   (shown in the "What supports this?" panel). Source first, then claim.   */

export const CLAIM_EVIDENCE: Record<string, Partial<Pick<Claim, 'evidenceClass' | 'sources' | 'confidence' | 'reviewState' | 'origin' | 'lastReviewed' | 'scope'>>> = {
  // 'lycaste:seasonal:0': { evidenceClass: 'horticultural-guidance', sources: [{ ... real citation ... }], reviewState: 'source-checked', lastReviewed: 'YYYY-MM-DD' },
};

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 40);

const makeClaim = (profileId: string, section: ProfileSection, key: string, text: string): Claim => {
  const id = `${profileId}:${section}:${key}`;
  const base: Claim = {
    id,
    profileId,
    section,
    text,
    evidenceClass: 'unverified',
    sources: [],
    confidence: 'evidence-pending',
    reviewState: 'evidence-pending',
    origin: 'ai-assisted',
    lastReviewed: null,
  };
  const override = CLAIM_EVIDENCE[id];
  if (!override) return base;
  const merged = { ...base, ...override };
  // Software never self-promotes AI text to expert-reviewed.
  if (merged.reviewState === 'expert-reviewed' && merged.origin === 'ai-inferred') merged.reviewState = 'draft';
  // A claim with no sources cannot be source-checked.
  if (!merged.sources.length && merged.reviewState === 'source-checked') merged.reviewState = 'evidence-pending';
  return merged;
};

export const claimsFor = (p: OrchidProfile): Claim[] => [
  makeClaim(p.id, 'overview', 'hook', p.hook),
  makeClaim(p.id, 'overview', 'origin', p.origin.summary),
  ...p.habitat.map((h) => makeClaim(p.id, 'habitat', slug(h.label), `${h.label}: ${h.value}`)),
  ...p.adaptations.map((a) => makeClaim(p.id, 'adaptations', slug(a.structure), `${a.structure} — ${a.fn}`)),
  ...p.seasonal.map((s, i) => makeClaim(p.id, 'seasonal', String(i), `${s.phase} (${s.when}): ${s.note}`)),
  ...p.culture.map((c) => makeClaim(p.id, 'culture', slug(c.label), `${c.label}: ${c.value}`)),
  ...p.growerSees.map((g, i) => makeClaim(p.id, 'signals', String(i), g)),
];

export const claimMap = (p: OrchidProfile) => new Map(claimsFor(p).map((c) => [c.id, c]));

export const claimId = (profileId: string, section: ProfileSection, key: string | number) =>
  `${profileId}:${section}:${typeof key === 'number' ? key : slug(key)}`;

export interface ProfileStatus {
  state: ClaimReviewState;
  claims: number;
  sourcesAttached: number;
  sourceChecked: number;
  pending: number;
  lastReviewed: string | null;
}

export const profileStatus = (p: OrchidProfile): ProfileStatus => {
  const cs = claimsFor(p);
  const sources = new Set<string>();
  cs.forEach((c) => c.sources.forEach((s: ClaimSource) => sources.add(s.doi || s.url || s.citation)));
  p.sources.forEach((s) => sources.add(s.url || s.citation));
  const checked = cs.filter((c) => c.reviewState === 'source-checked' || c.reviewState === 'expert-reviewed').length;
  const disputed = cs.some((c) => c.reviewState === 'disputed');
  const pending = cs.filter((c) => c.reviewState === 'evidence-pending').length;
  const dates = cs.map((c) => c.lastReviewed).filter(Boolean) as string[];
  const state: ClaimReviewState = disputed ? 'disputed' : checked === cs.length && cs.length ? 'source-checked' : checked ? 'draft' : 'evidence-pending';
  return { state, claims: cs.length, sourcesAttached: sources.size, sourceChecked: checked, pending, lastReviewed: dates.sort().pop() ?? null };
};

/* ================= Image provenance enforcement =================
   NO PROVENANCE = NO SCIENTIFIC PHOTOGRAPH.                                */

export const hasScientificProvenance = (img?: Partial<ImageProvenance> | null) =>
  !!img && !!img.src && !!img.creator && !!img.license && !!img.source && !!img.taxon;

/* ================= Conservation privacy ================= */

/** Round to a coarse grid so a sensitive point cannot be recovered. */
export const obscureRecord = (r: MapRecord, gridDeg = 1): MapRecord => {
  if (!r.sensitive && r.kind !== 'sensitive-obscured') return r;
  const snap = (v: number) => Math.floor(v / gridDeg) * gridDeg + gridDeg / 2;
  return { ...r, kind: 'sensitive-obscured', lat: snap(r.lat), lng: snap(r.lng), uncertaintyKm: Math.max(r.uncertaintyKm ?? 0, gridDeg * 111), elevationM: undefined, source: { ...r.source, recordUrl: undefined } };
};

export const publicRecords = (records: MapRecord[]) => records.map((r) => obscureRecord(r));
