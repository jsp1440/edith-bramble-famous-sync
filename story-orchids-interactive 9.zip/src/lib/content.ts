import type {
  CharacterProfile,
  ChronicleMeta,
  CollectorCard,
  DetectiveClue,
  DiagnosticCard,
  Discovery,
  GreenhouseContent,
  GreenhouseZone,
  GrowerCard,
  MediaAsset,
  Microclimate,
  ModuleContent,
  NotebookContent,
  PrintableSheet,
  Recipe,
  ScienceConcept,
  StoryDocument,
} from './content-types';
import { parseStory } from './story-parser';

import mediaJson from '@/content/media.json';
import mediaTwoJson from '@/content/media-ii.json';
import mediaThreeJson from '@/content/media-iii.json';
import siteJson from '@/content/site.json';
import chroniclesJson from '@/content/chronicles.json';
import discoveriesJson from '@/content/discoveries.json';
import cardsJson from '@/content/cards.json';
import scienceJson from '@/content/science.json';
import greenhouseJson from '@/content/greenhouse.json';
import charactersJson from '@/content/characters.json';
import notebookJson from '@/content/notebook.json';
import growJson from '@/content/grow.json';
import benchJson from '@/content/bench.json';
import microclimatesJson from '@/content/microclimates.json';
import recipesJson from '@/content/recipes.json';
import printablesJson from '@/content/printables.json';

/* Module content files are auto-registered: drop a new JSON file in
   /src/content/modules and it becomes available by its `id`. */
const moduleFiles = import.meta.glob('/src/content/modules/*.json', { eager: true }) as Record<
  string,
  { default: ModuleContent }
>;

/* Chronicle manuscripts are auto-registered as raw Markdown. */
const chronicleFiles = import.meta.glob('/src/content/chronicles/*.md', {
  eager: true,
  query: '?raw',
  import: 'default',
}) as Record<string, string>;

export interface SiteModuleLink {
  id: string;
  path: string;
  title: string;
  icon: string;
  blurb: string;
  group: string;
}

export interface SiteContent {
  title: string;
  subtitle: string;
  org: string;
  tagline: string;
  heroImage: string;
  heroIntro: string;
  heroLine?: string;
  primaryNav?: { label: string; to: string; blurb: string }[];
  path: string;
  modules: SiteModuleLink[];
  fcos: { name: string; talisman: string; about: string[]; membershipNote: string };
}

export const site = siteJson as SiteContent;
export const media = {
  ...(mediaJson as Record<string, MediaAsset>),
  ...(mediaTwoJson as Record<string, MediaAsset>),
  ...(mediaThreeJson as Record<string, MediaAsset>),
};
export const chronicles = chroniclesJson as ChronicleMeta[];
export const discoveries = discoveriesJson as Record<string, Discovery>;
export const cards = cardsJson as CollectorCard[];
export const scienceConcepts = scienceJson as ScienceConcept[];
export const greenhouse = greenhouseJson as GreenhouseContent;
export const characters = charactersJson as CharacterProfile[];
export const notebook = notebookJson as NotebookContent;
export const growerCards = growJson.cards as GrowerCard[];
export const glossary = growJson.glossary as { term: string; body: string }[];
export const diagnostics = benchJson.diagnostics as DiagnosticCard[];
export const detectiveClues = benchJson.detective as DetectiveClue[];
export const chronicleOneClues = benchJson.chronicleOneClues as { id: string; label: string; body: string }[];
export const microclimates = microclimatesJson as Microclimate[];
export const recipes = recipesJson as Recipe[];
export const printables = printablesJson as PrintableSheet[];

export function getGrowerCard(id?: string | null): GrowerCard | undefined {
  if (!id) return undefined;
  return growerCards.find((c) => c.id === id);
}

/** Chronicle routes: the first two have short public paths. */
export function chroniclePath(slug: string): string {
  if (slug === 'chronicle-i') return '/chronicle-1';
  if (slug === 'chronicle-ii') return '/chronicle-2';
  return `/chronicle/${slug}`;
}


export function getScienceConcept(id?: string | null): ScienceConcept | undefined {
  if (!id) return undefined;
  return scienceConcepts.find((c) => c.id === id);
}

export function getScienceForChronicle(chronicleId: string): ScienceConcept[] {
  return scienceConcepts.filter((c) => c.chronicle === chronicleId);
}

export function getZone(id?: string | null): GreenhouseZone | undefined {
  if (!id) return undefined;
  return greenhouse.zones.find((z) => z.id === id);
}

export function getCharacter(id?: string | null): CharacterProfile | undefined {
  if (!id) return undefined;
  return characters.find((c) => c.id === id);
}


const modulesById: Record<string, ModuleContent> = {};
Object.values(moduleFiles).forEach((mod) => {
  const content = mod.default;
  if (content?.id) modulesById[content.id] = content;
});

export function getModule(id: string): ModuleContent | undefined {
  return modulesById[id];
}

export function getMedia(id?: string | null): MediaAsset | undefined {
  if (!id) return undefined;
  return media[id];
}

export function getChronicle(slug?: string): ChronicleMeta | undefined {
  return chronicles.find((c) => c.slug === slug || c.id === slug);
}

const storyCache: Record<string, StoryDocument> = {};

export function getStory(chronicle?: ChronicleMeta): StoryDocument | null {
  if (!chronicle?.contentFile) return null;
  if (storyCache[chronicle.contentFile]) return storyCache[chronicle.contentFile];
  const key = Object.keys(chronicleFiles).find((k) => k.endsWith(`/${chronicle.contentFile}`));
  if (!key) return null;
  const parsed = parseStory(chronicleFiles[key]);
  storyCache[chronicle.contentFile] = parsed;
  return parsed;
}

export function getDiscovery(id: string): Discovery | undefined {
  return discoveries[id];
}

export function getCard(id: string): CollectorCard | undefined {
  return cards.find((c) => c.id === id);
}

export function getModuleLink(id: string): SiteModuleLink | undefined {
  return site.modules.find((m) => m.id === id);
}
