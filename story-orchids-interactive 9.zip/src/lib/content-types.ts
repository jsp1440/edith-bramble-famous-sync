export interface MediaAsset {
  src: string;
  alt: string;
  credit?: string;
}

export interface LinkRef {
  label: string;
  to: string;
}

export interface ModuleEntry {
  id: string;
  title: string;
  kind?: string;
  status?: 'live' | 'pending';
  summary?: string;
  body?: string[];
  meta?: { label: string; value: string }[];
  list?: { title: string; items: string[] }[];
  goDeeper?: { title: string; body: string[] };
  notes?: { label: string; body: string };
  practice?: { title: string; body: string };
  links?: LinkRef[];
  image?: string | null;
  variants?: string[];
  printable?: { kind: string; label: string };
  media?: { type: 'audio' | 'video'; src: string | null };
}

export interface ModuleContent {
  id: string;
  title: string;
  kicker?: string;
  subtitle?: string;
  layout?: 'default' | 'journal' | 'grimoire' | 'gallery';
  heroImage?: string;
  intro?: string[];
  notice?: { tone: 'caution' | 'ethics' | 'fiction' | 'info'; title: string; body: string };
  entries?: ModuleEntry[];
  levels?: ColoringLevel[];
}

export interface ColoringSheet {
  id: string;
  title: string;
  image: string | null;
  fact?: string;
  note?: string;
  status?: 'pending';
}

export interface ColoringLevel {
  id: string;
  title: string;
  description: string;
  sheets: ColoringSheet[];
}

export interface ChroniclePart {
  label: string;
  title: string;
  month?: string;
  status?: 'live' | 'coming-soon' | 'locked';
}

export interface ChronicleMeta {
  id: string;
  number: string;
  slug: string;
  title: string;
  subtitle: string;
  status: 'live' | 'coming-soon' | 'announced' | 'locked';
  season?: string;
  accent?: string;
  cover?: string | null;
  readingTime?: string;
  characters?: string[];
  parts?: ChroniclePart[];
  summary: string;
  contentFile?: string | null;
}

/* ---- Series architecture: reusable content objects ---- */

export interface ScienceLayers {
  basic: string[];
  deeper: string[];
  scientific: string[];
  caution?: string;
}

export interface ScienceConcept {
  id: string;
  title: string;
  kind: string;
  label: 'observed' | 'fiction';
  chronicle?: string;
  chronicleNote?: string;
  summary: string;
  layers: ScienceLayers;
  related?: string[];
}

export interface GreenhouseScene {
  chronicle: string;
  label: string;
  note: string;
}

export interface GreenhouseZone {
  id: string;
  name: string;
  tagline: string;
  light: string;
  temperature: string;
  airflow: string;
  grows: string[];
  why: string;
  detail: string;
  scenes: GreenhouseScene[];
  science: string[];
}

export interface GreenhouseContent {
  title: string;
  kicker: string;
  heroImage: string;
  planImage: string;
  intro: string[];
  climate: { title: string; body: string; link: LinkRef };
  zones: GreenhouseZone[];
}

/**
 * A member of the STORY CAST. Story-only information: what the character
 * does, notices and teaches inside the fictional Chronicles. Never biography.
 * `image` (a character portrait) is used only for wholly fictional characters;
 * everyone else is represented by an `emblem` — an object or orchid from
 * their moment in the story.
 */
export interface CharacterProfile {
  id: string;
  name: string;
  /** 'principal' = central cast, 'society' = supporting Society members, 'future' = not yet in a published Chronicle. */
  group: 'principal' | 'society' | 'future';
  /** Role inside the fiction, e.g. "Antagonist" or "Edith's sister". */
  role: string;
  image?: string;
  emblem?: string;
  /** A line from, or a phrase that sums up, their part in the story. */
  tagline: string;
  /** Story / horticultural role as established by the project. Never invented. */
  orchid?: string;
  /** Orchid names to open in Feature Genius ("Explore their orchids"). */
  explore?: string[];
  notices?: string;
  moment?: string;
  teaches?: string;
  clue?: { label: string; to: string };
  profiles?: string[];
  chronicles: string[];
}

export interface VideoResource {
  id: string;
  category: string;
  status: 'pending' | 'live';
  title: string;
  speaker: string | null;
  topic: string;
  description: string;
  genera: string[];
  season: string | null;
  videoUrl: string | null;
  science: string | null;
  chronicle: string | null;
}

export interface NotebookContent {
  title: string;
  kicker: string;
  intro: string[];
  categories: { id: string; title: string; blurb: string }[];
  entries: VideoResource[];
}



export interface Discovery {
  kind: string;
  label: string;
  eyebrow: string;
  title: string;
  image?: string;
  body: string[];
  pending?: string;
  links?: LinkRef[];
}

export interface CollectorCard {
  id: string;
  class: 'character' | 'artifact' | 'orchid';
  name: string;
  epithet?: string;
  image?: string;
  rarity?: string;
  chronicle?: string;
  discoverable?: boolean;
  unlockedBy?: string;

  pending?: boolean;
  fields: { label: string; value: string }[];
  flavor?: string;
  note?: string;
}

/* ---- Chronicle II + education layer objects ---- */

export interface GrowerCard {
  id: string;
  title: string;
  taxon: string;
  group: string;
  image?: string;
  label: 'observed' | 'fiction';
  summary: string;
  points: string[];
  story?: string;
  caution?: string;
  zone?: string;
}

export interface DetectiveClue {
  id: string;
  clue: string;
  answer: 'NORMAL' | 'CULTURAL WARNING' | 'SEASONAL SIGNAL' | 'NEEDS MORE EVIDENCE' | 'FICTIONAL';
  alsoAccept?: string[];
  explanation: string;
}

export interface DiagnosticCard {
  id: string;
  symptom: string;
  question: string;
  possibilities: string[];
  karen: string;
}

export interface Microclimate {
  id: string;
  name: string;
  summary: string;
  detail: string;
  orchids: string[];
  cards: string[];
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Recipe {
  id: string;
  title: string;
  image: string;
  blurb: string;
  yield: string;
  prep: string;
  cook: string;
  ingredients: string[];
  steps: string[];
  allergens: string;
  variation?: string;
}

export interface PrintableSheet {
  id: string;
  title: string;
  level: 'kids' | 'botanical';
  image: string;
  caption: string;
}

/* ---- Story block model (parsed from Markdown) ---- */

export type StoryBlock =
  | { type: 'heading'; text: string }
  | { type: 'paragraph'; text: string }
  | { type: 'quote'; text: string }
  | { type: 'verse'; title?: string; lines: string[] }
  | { type: 'note'; title?: string; lines: string[] }
  | { type: 'effect'; name: string; id?: string; stage?: number }
  | { type: 'divider' }
  | {
      type: 'image';
      id: string;
      layout: 'full' | 'wrap-right' | 'wrap-left' | 'inline';
      caption?: string;
      effect?: string;
    }
  | { type: 'audio'; id: string; caption?: string }
  | { type: 'science'; id: string; label?: string }
  | { type: 'pending'; title: string; text: string }
  | { type: 'closing'; text: string };


export interface StoryDocument {
  frontmatter: Record<string, string>;
  blocks: StoryBlock[];
}

