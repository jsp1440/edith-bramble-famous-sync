import type { OrchidProfile, RegionKey } from './orchid-types';
import { profilesA } from '@/content/orchid-profiles-a';
import { profilesB } from '@/content/orchid-profiles-b';

/* ------------------------------------------------------------------
   Orchid Continuum integration seam.

   Source layers:
     • AOS                      – practical culture reference (link only)
     • OC Public API / Calyx    – taxonomy, media, species dossier (LIVE, read-only — see below)
     • OC Vision Lab            – image observations (never proof of physiology)
     • Scientific literature    – habitat / physiology / adaptation evidence

   The Culture Library profiles below remain FCOS curated drafts; live
   Continuum records are read through `ocConnection.adapter`.
------------------------------------------------------------------- */

export interface OrchidDataSource {
  readonly name: string;
  readonly live: boolean;
  listProfiles(): OrchidProfile[];
  getProfile(id: string): OrchidProfile | undefined;
}

const staticProfiles: OrchidProfile[] = [...profilesA, ...profilesB];

/* The static profiles are AI-assisted drafts curated by FCOS. They have
   NOT been independently verified, so the label must not say so. */
export const staticDataSource: OrchidDataSource = {
  name: 'FCOS curated draft',
  live: false,
  listProfiles: () => staticProfiles,
  getProfile: (id) => staticProfiles.find((p) => p.id === id),
};

export const dataSource: OrchidDataSource = staticDataSource;

export const listProfiles = () => dataSource.listProfiles();
export const getProfile = (id?: string | null) => (id ? dataSource.getProfile(id) : undefined);

/** Permanent home of the Orchid Culture Library (independent of any Chronicle). */
export const LIBRARY_PATH = '/culture-library';
export const profilePath = (id: string, tab?: string) => `${LIBRARY_PATH}/${id}${tab ? `?tab=${tab}` : ''}`;

/** Real American Orchid Society home page. */
export const AOS_HOME = 'https://www.aos.org/';

/* ------------------------------------------------------------------
   Orchid Continuum connection — LIVE, READ-ONLY.

   Client: src/lib/oc-direct.ts
     • OC Public API  (VITE_ORCHID_CONTINUUM_API_BASE_URL | VITE_OC_API_BASE_URL,
       default https://orchid-continuum-public-api.onrender.com)
     • OC Calyx       (VITE_CALYX_API_URL,
       default https://orchid-calyx-backend.onrender.com)
   Browser calls go direct when the service allows this origin (CORS);
   otherwise through the read-only allowlisted relay in `orchid-explorer`.
   GBIF remains only the fallback media/occurrence provider.
   Sections the Continuum has not assembled are reported as unavailable,
   with the Continuum's own reason — never filled in.
------------------------------------------------------------------- */

import { CALYX_API_BASE, OC_API_BASE, ocResolveExactSpecies, ocSpeciesDossier, ocSpeciesMedia, sectionAvailable, type OcSection } from '@/lib/oc-direct';

export interface OCProvenance {
  sourceDatabase: string;
  recordUrl?: string;
  citation?: string;
  license?: string;
  retrievedAt: string;
}

export interface OCTaxonRecord {
  acceptedName: string;
  authority?: string;
  synonyms: string[];
  rank: string;
  taxonId?: string;
  provenance: OCProvenance;
}

export interface OCObservation {
  kind: 'habitat' | 'ecology' | 'pollinator' | 'mycorrhizal' | 'interaction' | 'morphology' | 'conservation' | 'phenology';
  statement: string;
  /** OC reasoning output must be flagged; it is inference, not evidence. */
  isInference: boolean;
  /** The Continuum's own section state (available / provisional / conflicting / modeled / inferred). */
  state: string;
  provenance: OCProvenance;
}

export interface OrchidContinuumAdapter {
  getTaxon(name: string): Promise<OCTaxonRecord | null>;
  getOccurrences(name: string): Promise<import('./evidence-types').MapRecord[]>;
  getObservations(name: string): Promise<OCObservation[]>;
  getImages(name: string): Promise<import('./evidence-types').ImageProvenance[]>;
  getLiterature(name: string): Promise<import('./evidence-types').ClaimSource[]>;
}

export const OC_SITE_URL = 'https://orchidcontinuum.org';
export const OC_PUBLIC_API = OC_API_BASE;
export const OC_CALYX_API = CALYX_API_BASE;

const OBS_MAP: [string, OCObservation['kind']][] = [
  ['habitat', 'habitat'], ['ecology', 'ecology'], ['pollinators', 'pollinator'], ['mycorrhizae', 'mycorrhizal'],
  ['morphology', 'morphology'], ['conservation', 'conservation'], ['phenology', 'phenology'], ['knowledge_graph', 'interaction'],
];

/** Plain-text statement from a section — only the Continuum's own words/fields. */
export const sectionStatement = (s: OcSection): string => {
  if (s.summary && s.summary.trim()) return s.summary.trim();
  return s.items.slice(0, 6).map((it) => {
    if (typeof it === 'string') return it;
    const o = it as Record<string, unknown>;
    return String(o.statement ?? o.text ?? o.label ?? o.name ?? o.value ?? o.title ?? '').trim();
  }).filter(Boolean).join('; ');
};

const provFrom = (s: OcSection, fallback: string): OCProvenance => {
  const r = s.receipts[0];
  return { sourceDatabase: r?.source_name || fallback, recordUrl: r?.source_url || undefined, license: r?.license || undefined, citation: r?.attribution || undefined, retrievedAt: new Date().toISOString() };
};

const liveAdapter: OrchidContinuumAdapter = {
  async getTaxon(name) {
    const t = await ocResolveExactSpecies(name);
    if (!t) return null;
    let authority: string | undefined; let synonyms: string[] = [];
    try { const d = await ocSpeciesDossier(name); authority = d?.authorship || undefined; synonyms = d?.synonyms ?? []; } catch { /* identity still stands */ }
    return { acceptedName: t.canonicalName, authority, synonyms, rank: 'species', taxonId: t.taxonomyId, provenance: { sourceDatabase: 'Orchid Continuum Public API', recordUrl: `${OC_API_BASE}/api/species/search?q=${encodeURIComponent(name)}`, retrievedAt: new Date().toISOString() } };
  },
  /* Precise points are deliberately not requested (sensitive-locality protection);
     the Atlas uses generalised GBIF density tiles plus the Continuum's atlas_summary. */
  async getOccurrences() { return []; },
  async getObservations(name) {
    const d = await ocSpeciesDossier(name);
    if (!d) return [];
    return OBS_MAP.filter(([k]) => sectionAvailable(d, k)).map(([k, kind]) => {
      const s = d.sections[k];
      return { kind, statement: sectionStatement(s), state: s.state, isInference: /model|infer/i.test(s.state), provenance: provFrom(s, 'Orchid Continuum species dossier') };
    }).filter((o) => o.statement);
  },
  async getImages(name) {
    const [living, specimen] = await Promise.all([ocSpeciesMedia(name, 'HUMAN_OBSERVATION'), ocSpeciesMedia(name, 'PRESERVED_SPECIMEN')]);
    return [...living.items, ...specimen.items].map((m) => ({
      role: 'scientific-photograph' as const, src: m.src, creator: m.creator ?? undefined, source: m.source, license: m.license,
      recordUrl: m.recordUrl, taxon: m.scientificName, sourceDatabase: 'Orchid Continuum',
    }));
  },
  async getLiterature(name) {
    const d = await ocSpeciesDossier(name);
    if (!d || !sectionAvailable(d, 'literature')) return [];
    return d.sections.literature.items.map((it) => it as Record<string, unknown>)
      .filter((o) => typeof (o.citation ?? o.title) === 'string')
      .map((o) => ({ evidenceClass: 'botanical-database' as const, citation: String(o.citation ?? o.title), url: (o.url as string) || undefined, doi: (o.doi as string) || undefined }));
  },
};

export const ocConnection: { status: 'pending' | 'live'; adapter: OrchidContinuumAdapter | null; note: string } = {
  status: 'live',
  adapter: liveAdapter,
  note: 'Species identity, media and dossier sections are read from Orchid Continuum (read-only). Where the Continuum has not yet assembled a section it is shown as not available, with the Continuum’s own reason.',
};

/** Approximate schematic positions on a 200×100 equirectangular frame. */
export const REGIONS: Record<RegionKey, { label: string; x: number; y: number }> = {
  mexico: { label: 'Mexico', x: 49, y: 38 },
  'central-america': { label: 'Central America', x: 53, y: 43 },
  andes: { label: 'Andes', x: 57, y: 52 },
  'amazon-guianas': { label: 'Amazon & Guianas', x: 66, y: 49 },
  brazil: { label: 'Brazil', x: 73, y: 58 },
  himalaya: { label: 'Himalaya', x: 148, y: 34 },
  china: { label: 'Southern China', x: 160, y: 36 },
  indochina: { label: 'Indochina', x: 157, y: 42 },
  'new-guinea': { label: 'New Guinea', x: 179, y: 53 },
  'ne-australia': { label: 'NE Australia', x: 181, y: 60 },
  'e-australia': { label: 'Eastern Australia', x: 184, y: 67 },
};

export const CLIMATE_AXES: { key: 'temperature' | 'moisture' | 'light' | 'airflow' | 'seasonality'; label: string; low: string; high: string }[] = [
  { key: 'temperature', label: 'Temperature', low: 'Cool', high: 'Warm' },
  { key: 'moisture', label: 'Moisture pattern', low: 'Seasonally dry', high: 'Constantly moist' },
  { key: 'light', label: 'Light', low: 'Shade', high: 'Bright' },
  { key: 'airflow', label: 'Airflow', low: 'Tolerant', high: 'Essential' },
  { key: 'seasonality', label: 'Seasonal behaviour', low: 'Even', high: 'Strongly seasonal' },
];
