import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { isRejectedMediaUrl, ocBestFor, useOcGenusImages, type OcMedia } from '@/lib/oc-direct';

/* ------------------------------------------------------------------
   SHARED ORCHID CONTINUUM CONTRACTS — build knowledge once, render many.
   Species paging identity = GBIF Backbone usage key (from the existing
   orchid-explorer service). Media is resolved Orchid Continuum first
   (src/lib/oc-direct.ts), GBIF only as fallback. Every media record keeps
   taxon identity, source, attribution, licence and evidence class.
   Featured Genus, Species Dossier, Greenhouse, Characters and Atlas all
   read through this module — there is no Edith-only species database.
------------------------------------------------------------------- */

export type EvidenceClass = 'living-plant-observation' | 'herbarium-specimen' | 'other-record';

export interface MediaRecord {
  src: string;
  taxonKey: number;
  identifiedAs: string | null;
  species: string | null;
  creator: string | null;
  license: string;
  source: string;
  recordUrl: string;
  country: string | null;
  basisOfRecord: string | null;
  evidenceClass: EvidenceClass;
  /** 'Orchid Continuum' | 'GBIF' */
  provider?: string;
  /** Orchid Continuum taxonomy id the image is attached to, when from OC. */
  ocTaxonId?: string | null;
}

export interface SpeciesEntry {
  key: number;
  name: string;
  scientificName: string;
  authorship: string | null;
  status: string;
  hero: MediaRecord | null;
}

export interface GenusPage {
  genus: string;
  genusKey?: number;
  found: boolean;
  total: number;
  offset: number;
  limit: number;
  species: SpeciesEntry[];
  source?: string;
}

export interface MediaPage {
  taxonKey: number;
  basis: string;
  total: number;
  offset: number;
  limit: number;
  items: MediaRecord[];
}

export interface DossierExtras {
  taxonKey: number;
  synonyms: { name: string; status: string }[] | null;
  conservation: { category: string; code: string | null; source: string } | null;
  literature: { total: number; items: { title: string; year: number | null; source: string | null; doi: string | null; url: string | null; authors: string[] }[] } | null;
  vernacular: string[];
  retrievedAt: string;
}

export const EVIDENCE_LABEL: Record<EvidenceClass, string> = {
  'living-plant-observation': 'Living plant · field or garden photograph',
  'herbarium-specimen': 'Herbarium specimen',
  'other-record': 'Other record',
};

/** Genera the Chronicles touch. The Featured Genus rotates through these. */
export const FEATURED_GENERA: { genus: string; note: string }[] = [
  { genus: 'Stanhopea', note: 'Flowers that grow downward through the basket' },
  { genus: 'Phragmipedium', note: 'The wet slipper bench' },
  { genus: 'Catasetum', note: 'Seasonal dormancy on the dry-rest shelf' },
  { genus: 'Dendrobium', note: 'Same genus, different planets' },
  { genus: 'Cymbidium', note: 'Cool coastal nights in the lath house' },
  { genus: 'Sarcochilus', note: 'An Australian in the sea air' },
  { genus: 'Lycaste', note: 'Deciduous and evergreen' },
  { genus: 'Laelia', note: 'The seasonal clock' },
  { genus: 'Cattleya', note: 'The bright, stable bench' },
  { genus: 'Bulbophyllum', note: 'An enormous, varied genus' },
];

export const genusOfTheDay = (d = new Date()) => {
  const day = Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) - Date.UTC(d.getFullYear(), 0, 0)) / 86400000);
  return FEATURED_GENERA[day % FEATURED_GENERA.length];
};

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
export const dossierPath = (key: number, name: string) => `/species/${key}/${slug(name)}`;

/** iNaturalist originals are very large; request a sensible size. */
export const sizedSrc = (src: string, size: 'small' | 'medium' | 'large' = 'medium') =>
  src.includes('inaturalist') ? src.replace(/\/original\.(jpe?g|png)/i, `/${size}.$1`) : src;

const memo = new Map<string, unknown>();

function useExplorer<T>(ck: string | null, body: Record<string, unknown>) {
  const [data, setData] = useState<T | null>(ck ? ((memo.get(ck) as T) ?? null) : null);
  const [state, setState] = useState<'idle' | 'loading' | 'ok' | 'error'>(ck ? (memo.has(ck) ? 'ok' : 'loading') : 'idle');
  useEffect(() => {
    if (!ck) return;
    if (memo.has(ck)) {
      setData(memo.get(ck) as T);
      setState('ok');
      return;
    }
    let alive = true;
    setState('loading');
    supabase.functions.invoke('orchid-explorer', { body }).then(({ data: d, error }) => {
      if (!alive) return;
      if (error || !d || d.error) return setState('error');
      memo.set(ck, d);
      setData(d as T);
      setState('ok');
    });
    return () => {
      alive = false;
    };
    // body is derived from ck
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ck]);
  return { data, state };
}

/** OC media record → shared MediaRecord contract (identity, source, licence, evidence class preserved). */
export const ocToMedia = (m: OcMedia, taxonKey: number): MediaRecord => ({
  src: m.src, taxonKey, identifiedAs: m.scientificName, species: m.scientificName, creator: m.creator, license: m.license,
  source: m.source, recordUrl: m.recordUrl, country: m.country, basisOfRecord: null,
  evidenceClass: m.evidenceClass === 'other' ? 'other-record' : m.evidenceClass, provider: 'Orchid Continuum', ocTaxonId: m.taxonomyId,
});

const isLiving = (m: MediaRecord | null) => m?.evidenceClass === 'living-plant-observation';

/**
 * Species paging (complete accepted list, moving 9-window) is unchanged — it
 * comes from the existing orchid-explorer genus-species service. Media is then
 * re-resolved per tile against the Orchid Continuum genus media library:
 *   1 OC exact-taxon living photo → 2 existing exact-taxon living photo
 *   3 OC exact-taxon specimen     → 4 existing exact-taxon specimen → 5 none.
 * (Living always beats specimen; within each class OC wins.) `mediaPending`
 * stays true until the OC query has settled, so “No image available” is never
 * claimed early.
 */
export function useGenusSpecies(genus: string | null, offset: number, limit = 9) {
  const base = useExplorer<GenusPage>(genus ? `gs:${genus}:${offset}:${limit}` : null, { action: 'genus-species', genus, offset, limit });
  const oc = useOcGenusImages(genus);
  const data = useMemo<GenusPage | null>(() => {
    if (!base.data) return null;
    const g = oc.data;
    let used = 0;
    const species = base.data.species.map((s) => {
      /* Existing hero is dropped if it is a placeholder / culture icon / non-image,
         or an OC image the library attaches to several different taxa. */
      const cur = s.hero && !isRejectedMediaUrl(s.hero.src, g) ? s.hero : null;
      const best = ocBestFor(g, s.name);
      const ocRec = best ? ocToMedia(best, s.key) : null;
      const hero = isLiving(ocRec) ? ocRec : isLiving(cur) ? cur : ocRec ?? cur;
      if (hero && hero === ocRec) used++;
      return hero === s.hero ? s : { ...s, hero };
    });
    return { ...base.data, species, source: g ? `${base.data.source ?? 'GBIF Backbone'} + Orchid Continuum media (${used} of ${species.length} tiles on this page)` : base.data.source };
  }, [base.data, oc.data]);
  return { data, state: base.state, mediaPending: oc.state === 'loading', ocMediaState: oc.state, ocMediaError: oc.error, ocMedia: oc.data };
}

export const useMediaPage = (taxonKey: number | null, basis: 'HUMAN_OBSERVATION' | 'PRESERVED_SPECIMEN', offset: number, limit = 12) =>
  useExplorer<MediaPage>(taxonKey ? `m:${taxonKey}:${basis}:${offset}:${limit}` : null, { action: 'media', taxonKey, basis, offset, limit });

export const useDossierExtras = (taxonKey: number | null) =>
  useExplorer<DossierExtras>(taxonKey ? `d:${taxonKey}` : null, { action: 'dossier', taxonKey });

/* ---------------- Community verification ---------------- */

export type ReviewChoice = 'agree' | 'qualify' | 'disagree' | 'unsure';
export const REVIEW_CHOICES: { id: ReviewChoice; label: string }[] = [
  { id: 'agree', label: 'Agree as written' },
  { id: 'qualify', label: 'Needs qualification' },
  { id: 'disagree', label: 'Disagree' },
  { id: 'unsure', label: 'Not sure' },
];

export interface Claim {
  id: string;
  text: string;
  source: string;
  evidenceClass: string;
  reviewState: string;
}

export function contributorId(): string {
  const K = 'eb-contributor-id';
  try {
    let id = localStorage.getItem(K);
    if (!id) {
      id = typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `c-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      localStorage.setItem(K, id);
    }
    return id;
  } catch {
    return 'anonymous';
  }
}

export async function submitClaimReview(r: {
  taxonKey: number | null;
  taxonName: string;
  claim: Claim;
  choice: ReviewChoice;
  reasoning?: string;
  confidence?: 'low' | 'medium' | 'high';
  experience?: 'beginner' | 'hobbyist' | 'experienced' | 'professional';
}) {
  /* Server-side RPC: a signed-in reviewer is always recorded under their own
     user id (the server ignores any client-supplied id for them); anonymous
     reviewers keep a random per-browser id. Rows are never readable publicly. */
  const { error } = await supabase.rpc('submit_claim_review', {
    p_taxon_key: r.taxonKey,
    p_taxon_name: r.taxonName,
    p_claim_id: r.claim.id,
    p_claim_text: r.claim.text,
    p_claim_source: r.claim.source,
    p_evidence_class: r.claim.evidenceClass,
    p_choice: r.choice,
    p_reasoning: r.reasoning?.trim() || null,
    p_confidence: r.confidence ?? null,
    p_experience: r.experience ?? null,
    p_contributor: contributorId(),
  });
  if (error) throw error;
}

export async function fetchTallies(claimIds: string[]): Promise<Record<string, Partial<Record<ReviewChoice, number>>>> {
  if (!claimIds.length) return {};
  const { data, error } = await supabase.from('claim_review_tallies').select('claim_id, choice, n').in('claim_id', claimIds);
  if (error || !data) return {};
  const out: Record<string, Partial<Record<ReviewChoice, number>>> = {};
  for (const row of data as { claim_id: string; choice: ReviewChoice; n: number }[]) {
    (out[row.claim_id] ||= {})[row.choice] = row.n;
  }
  return out;
}
