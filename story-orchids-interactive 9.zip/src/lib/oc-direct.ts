import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

/* ==================================================================
   ORCHID CONTINUUM — READ-ONLY CLIENT
   Canonical services (no write authority, no credentials):
     • OC Public API  — species search, genus media library
     • OC Calyx       — federation resolver + oc-species-dossier-v1
   Transport: the browser calls the services directly first. Both
   services currently send CORS headers only for https://orchidcontinuum.org,
   so on any other origin the browser blocks the response; the client
   then records the exact CORS failure and uses the read-only,
   path-allowlisted relay in the existing `orchid-explorer` function.
   Endpoint failures are surfaced as errors — never treated as "no data".
   ================================================================== */

const env = import.meta.env as Record<string, string | undefined>;
export const OC_API_BASE = (env.VITE_ORCHID_CONTINUUM_API_BASE_URL || env.VITE_OC_API_BASE_URL || 'https://orchid-continuum-public-api.onrender.com').replace(/\/$/, '');
export const CALYX_API_BASE = (env.VITE_CALYX_API_URL || 'https://orchid-calyx-backend.onrender.com').replace(/\/$/, '');
export const OC_SITE = 'https://orchidcontinuum.org';

type Svc = 'public' | 'calyx';
export type OcErrorKind = 'cors' | 'network' | 'http' | 'auth' | 'shape' | 'relay';
export interface OcCallError { url: string; status: number; kind: OcErrorKind; message: string; at: string }

export class OcError extends Error {
  constructor(public info: OcCallError) { super(`${info.kind.toUpperCase()} ${info.status || ''} ${info.url} — ${info.message}`); }
}

/** Live diagnostics: which transport each service is using and every failure seen. */
export const ocDiagnostics: { transport: Record<Svc, 'unknown' | 'direct' | 'relay'>; errors: OcCallError[] } = {
  transport: { public: 'unknown', calyx: 'unknown' },
  errors: [],
};
const record = (e: Omit<OcCallError, 'at'>) => {
  const full = { ...e, at: new Date().toISOString() };
  ocDiagnostics.errors = [full, ...ocDiagnostics.errors].slice(0, 25);
  return full;
};

const BLOCK_KEY = (s: Svc) => `oc-direct-blocked:${s}`;
const isBlocked = (s: Svc) => { try { return sessionStorage.getItem(BLOCK_KEY(s)) === '1'; } catch { return false; } };
const setBlocked = (s: Svc) => { try { sessionStorage.setItem(BLOCK_KEY(s), '1'); } catch { /* private mode */ } };

const inflight = new Map<string, Promise<unknown>>();

async function rawGet<T>(svc: Svc, path: string): Promise<T> {
  const url = `${svc === 'calyx' ? CALYX_API_BASE : OC_API_BASE}${path}`;
  if (!isBlocked(svc)) {
    let res: Response | null = null;
    try {
      res = await fetch(url, { headers: { Accept: 'application/json' } });
    } catch {
      const origin = typeof location !== 'undefined' ? location.origin : 'this origin';
      record({ url, status: 0, kind: 'cors', message: `Browser blocked the response: no Access-Control-Allow-Origin header for ${origin} (service allows https://orchidcontinuum.org only). Switched to the read-only relay.` });
      setBlocked(svc);
    }
    if (res) {
      if (!res.ok) throw new OcError(record({ url, status: res.status, kind: res.status === 401 || res.status === 403 ? 'auth' : 'http', message: `HTTP ${res.status}` }));
      try { ocDiagnostics.transport[svc] = 'direct'; return (await res.json()) as T; }
      catch { throw new OcError(record({ url, status: res.status, kind: 'shape', message: 'Response was not valid JSON' })); }
    }
  }
  const { data, error } = await supabase.functions.invoke('orchid-explorer', { body: { action: 'oc-get', service: svc, path } });
  if (error || !data) throw new OcError(record({ url, status: 0, kind: 'relay', message: error?.message || 'Relay returned no body' }));
  const d = data as { upstreamStatus: number; error: string | null; data: unknown; auth: string | null };
  if (d.upstreamStatus !== 200 || d.error) {
    throw new OcError(record({ url, status: d.upstreamStatus, kind: d.auth ? 'auth' : d.upstreamStatus ? (d.upstreamStatus === 200 ? 'shape' : 'http') : 'network', message: d.error || `HTTP ${d.upstreamStatus}` }));
  }
  ocDiagnostics.transport[svc] = 'relay';
  return d.data as T;
}

function ocGet<T>(svc: Svc, path: string): Promise<T> {
  const k = `${svc}:${path}`;
  const hit = inflight.get(k);
  if (hit) return hit as Promise<T>;
  const p = rawGet<T>(svc, path);
  inflight.set(k, p);
  p.catch(() => inflight.delete(k));
  return p;
}

const enc = encodeURIComponent;
const norm = (s?: string | null) => (s || '').trim().toLowerCase().replace(/\s+/g, ' ');

/* ------------------------------ Taxon ------------------------------ */

interface OcSearchRow {
  taxonomy_id?: string | number; canonical_name?: string; scientific_name?: string; genus?: string; specific_epithet?: string;
  representative_image_url?: string | null; image_url?: string | null; medium_url?: string | null; original_url?: string | null;
  is_herbarium?: boolean; confidence_label?: string | null; knowledge_label?: string | null; [k: string]: unknown;
}

export interface OcTaxon { taxonomyId: string; canonicalName: string; scientificName: string; genus: string; raw: OcSearchRow }

/** Exact canonical match only — never a near or partial name. */
export async function ocResolveExactSpecies(name: string): Promise<OcTaxon | null> {
  const path = `/api/species/search?q=${enc(name.trim())}&limit=20`;
  const rows = await ocGet<unknown>('public', path);
  if (!Array.isArray(rows)) throw new OcError(record({ url: OC_API_BASE + path, status: 200, kind: 'shape', message: 'Expected an array of species records' }));
  const n = norm(name);
  const list = rows as OcSearchRow[];
  const hit = list.find((r) => norm(r.canonical_name) === n) ?? list.find((r) => norm(`${r.genus ?? ''} ${r.specific_epithet ?? ''}`) === n);
  if (!hit || hit.taxonomy_id == null) return null;
  return {
    taxonomyId: String(hit.taxonomy_id),
    canonicalName: hit.canonical_name || name,
    scientificName: (hit.scientific_name as string) || hit.canonical_name || name,
    genus: hit.genus || name.split(' ')[0],
    raw: hit,
  };
}

/* ------------------------------ Media ------------------------------ */

export type OcEvidenceClass = 'living-plant-observation' | 'herbarium-specimen' | 'other';

export interface OcMedia {
  id: string; src: string; thumb: string | null; scientificName: string; taxonomyId: string | null;
  source: string; imageSource: string | null; creator: string | null; license: string; recordUrl: string;
  country: string | null; evidenceClass: OcEvidenceClass; provider: 'Orchid Continuum'; identificationState: string | null;
}

export interface OcGenusMedia { genus: string; reported: number; items: OcMedia[]; rejected: Record<string, number>; source: string; sharedUrls: Set<string> }

interface OcImageRow {
  id?: string; image_url?: string | null; thumbnail_url?: string | null; medium_url?: string | null; original_url?: string | null;
  representative_image_url?: string | null; image_source?: string | null; license?: string | null; creator?: string | null;
  taxonomy_id?: string | number | null; genus?: string | null; species?: string | null; canonical_name?: string | null;
  is_herbarium?: boolean; country?: string | null; record_url?: string | null; source_url?: string | null;
}

const PLACEHOLDER = /placehold\.co|placeholder\.com|via\.placeholder|dummyimage|placekitten/i;
/** orchidspecies.com culture-condition icons (temperature / light / scent) — not plant photographs. */
const CULTURE_ICON = /orphotdir\/(temp(hot|int|cool|warm)?|partial(sun|shade)|deepshade|fullsun|brightlight|shade|scent|fragrant)\.(jpe?g|gif|png)$/i;
const NOT_IMAGE = /\.(pdf|djvu|tiff?|svg)(\?|$)/i;
const RIGHTS_RESERVED = /all rights reserved|^copyright|wipo copyright/i;
const HERBARIUM_HOST = /sweetgum\.nybg\.org|jbrj-public-img|imagens\d*\.jbrj\.gov\.br|oxalis\.br\.fgov\.be|fm-digital-assets\.fieldmuseum\.org|orphans\.gbif\.org|api\.idigbio\.org|herbari|\/hb\//i;
const ILLUSTRATION = /orchid_album|lindenia|reichenbachia|botanical_magazine|curtis|gardeners|journal|orchid_review|garden_and_forest|price_list|plate|iconograph|tab\._/i;
const LIVING_SOURCES = /iospe|plantnet|inaturalist|orchid_roots|orchidspecies|globalorchids|orchids_org|ecuagenera|eol|flickr|wikimedia|roberta_fox/i;
const HTTPS_OK_HOSTS = /^http:\/\/(sweetgum\.nybg\.org|[\w-]+\.s3[\w.-]*\.amazonaws\.com)\//i;

export const licenseLabel = (u?: string | null) => {
  const s = (u || '').toLowerCase().trim();
  if (!s || s === 'unspecified' || s === 'null') return 'Licence not stated by source';
  if (s === 'community_contributed') return 'Community contributed — licence not stated';
  if (s.includes('publicdomain/zero') || s.includes('cc0')) return 'CC0';
  if (s.includes('public domain') || s.includes('publicdomain')) return 'Public domain';
  if (s.includes('by-nc-sa')) return 'CC BY-NC-SA';
  if (s.includes('by-nc') || s.includes('cc by-nc')) return 'CC BY-NC';
  if (s.includes('by-sa') || s.includes('cc by-sa')) return u!.match(/\d\.\d/) ? `CC BY-SA ${u!.match(/\d\.\d/)![0]}` : 'CC BY-SA';
  if (s.includes('/by/') || s.startsWith('cc-by') || s.startsWith('cc by')) return u!.match(/\d\.\d/) ? `CC BY ${u!.match(/\d\.\d/)![0]}` : 'CC BY';
  return u!;
};

const secure = (u?: string | null): string | null => {
  if (!u) return null;
  let v = u.trim();
  if (HTTPS_OK_HOSTS.test(v)) v = v.replace(/^http:/i, 'https:');
  if (!/^https:\/\//i.test(v)) return null;
  try { return new URL(v.replace(/ /g, '%20')).href; } catch { return null; }
};

const fileName = (u: string) => { try { return decodeURIComponent(new URL(u).pathname.split('/').pop() || '').toLowerCase(); } catch { return ''; } };

/** True when the file name itself names a different species of the same genus. */
const namesOtherTaxon = (url: string, genus: string, epithet: string) => {
  const f = fileName(url).replace(/[_+%-]+/g, ' ');
  const m = f.match(new RegExp(`${genus.toLowerCase()}\\s+([a-z]{4,})`));
  return !!m && m[1] !== epithet.toLowerCase() && !['por', 'species', 'hybrid'].includes(m[1]);
};

function classify(row: OcImageRow, url: string): OcEvidenceClass {
  if (row.is_herbarium || HERBARIUM_HOST.test(url)) return 'herbarium-specimen';
  if (ILLUSTRATION.test(fileName(url))) return 'other';
  if (LIVING_SOURCES.test(row.image_source || '') || /inaturalist|plantnet/i.test(url)) return 'living-plant-observation';
  return 'other';
}

/** Screen a batch of OC image rows. Images attached to more than one taxon are NOT exact-taxon evidence and are rejected. */
function screen(rows: OcImageRow[], genus: string, extraShared?: Set<string>) {
  const namesPerUrl = new Map<string, Set<string>>();
  for (const r of rows) {
    const u = secure(r.image_url || r.original_url || r.representative_image_url);
    if (!u) continue;
    (namesPerUrl.get(u) ?? namesPerUrl.set(u, new Set()).get(u)!).add(norm(r.canonical_name));
  }
  const shared = new Set<string>([...namesPerUrl].filter(([, s]) => s.size > 1).map(([u]) => u));
  extraShared?.forEach((u) => shared.add(u));
  const rejected: Record<string, number> = {};
  const bump = (k: string) => (rejected[k] = (rejected[k] || 0) + 1);
  const seen = new Set<string>();
  const items: OcMedia[] = [];
  for (const r of rows) {
    const rawUrl = r.image_url || r.original_url || r.representative_image_url || '';
    const epithet = (r.species || '').trim();
    if (!r.canonical_name || !epithet || ['x', 'sp', 'sp.', 'spp'].includes(epithet.toLowerCase())) { bump('not species-level'); continue; }
    if (PLACEHOLDER.test(rawUrl)) { bump('placeholder image'); continue; }
    if (NOT_IMAGE.test(rawUrl)) { bump('not an image file'); continue; }
    if (CULTURE_ICON.test(rawUrl)) { bump('culture icon, not a plant photo'); continue; }
    const url = secure(rawUrl);
    if (!url) { bump('insecure http URL'); continue; }
    if (shared.has(url)) { bump('same image attached to several taxa'); continue; }
    if (namesOtherTaxon(url, r.genus || genus, epithet)) { bump('file name names another taxon'); continue; }
    if (/phalaenopsis|cattleya|dendrobium|oncidium|paphiopedilum|cymbidium|vanda|masdevallia/i.test(fileName(url)) && !fileName(url).includes((r.genus || genus).toLowerCase())) { bump('file name names another genus'); continue; }
    if (RIGHTS_RESERVED.test(r.license || '')) { bump('rights reserved'); continue; }
    if (seen.has(url)) { bump('duplicate'); continue; }
    seen.add(url);
    items.push({
      id: String(r.id ?? url), src: url, thumb: secure(r.thumbnail_url) || secure(r.medium_url), scientificName: r.canonical_name,
      taxonomyId: r.taxonomy_id != null ? String(r.taxonomy_id) : null,
      source: `Orchid Continuum media library${r.image_source ? ` · ${r.image_source.replace(/_/g, ' ')}` : ''}`,
      imageSource: r.image_source || null, creator: r.creator || null, license: licenseLabel(r.license),
      recordUrl: secure(r.record_url || r.source_url || r.original_url) || url, country: r.country || null,
      evidenceClass: classify(r, url), provider: 'Orchid Continuum', identificationState: null,
    });
  }
  return { items, rejected, shared };
}

/** Orchid Continuum genus media library, screened for exact-taxon integrity. Max 200 per request (API limit). */
export async function ocGenusImages(genus: string, limit = 200): Promise<OcGenusMedia> {
  const path = `/images/genus/${enc(genus.trim())}?limit=${Math.min(200, Math.max(1, limit))}`;
  const d = await ocGet<{ genus?: string; count?: number; images?: OcImageRow[]; source?: string }>('public', path);
  if (!d || !Array.isArray(d.images)) throw new OcError(record({ url: OC_API_BASE + path, status: 200, kind: 'shape', message: 'Expected { images: [...] }' }));
  const { items, rejected, shared } = screen(d.images, genus);
  return { genus: d.genus || genus, reported: d.count ?? d.images.length, items, rejected, source: d.source || 'Orchid Continuum', sharedUrls: shared };
}

/** URL-level integrity check usable on media from ANY provider. */
export const isRejectedMediaUrl = (u: string, g?: OcGenusMedia | null) => {
  if (PLACEHOLDER.test(u) || NOT_IMAGE.test(u) || CULTURE_ICON.test(u)) return true;
  const s = secure(u);
  return !s || !!g?.sharedUrls.has(s);
};

/** Best OC image for one exact species name from a screened genus set: living first, then specimen. */
export function ocBestFor(g: OcGenusMedia | null | undefined, name: string): OcMedia | null {
  if (!g) return null;
  const n = norm(name);
  const mine = g.items.filter((m) => norm(m.scientificName) === n);
  return mine.find((m) => m.evidenceClass === 'living-plant-observation') ?? mine.find((m) => m.evidenceClass === 'herbarium-specimen') ?? null;
}

export interface OcSpeciesMediaResult { name: string; taxonomyId: string | null; basis: 'HUMAN_OBSERVATION' | 'PRESERVED_SPECIMEN'; items: OcMedia[]; rejected: Record<string, number> }

/** Exact-taxon OC media for one species. Never returns another species' image. */
export async function ocSpeciesMedia(name: string, basis: 'HUMAN_OBSERVATION' | 'PRESERVED_SPECIMEN'): Promise<OcSpeciesMediaResult> {
  const sp = await ocResolveExactSpecies(name);
  const genus = sp?.genus || name.trim().split(/\s+/)[0];
  const g = await ocGenusImages(genus, 200);
  const want: OcEvidenceClass = basis === 'HUMAN_OBSERVATION' ? 'living-plant-observation' : 'herbarium-specimen';
  const n = norm(name);
  const extraRows: OcImageRow[] = [];
  if (sp) {
    const r = sp.raw;
    extraRows.push({ id: `search:${sp.taxonomyId}`, image_url: r.medium_url || r.representative_image_url || r.image_url || r.original_url, original_url: r.original_url, image_source: r.confidence_label || null, license: null, taxonomy_id: sp.taxonomyId, genus, species: name.split(' ')[1] || null, canonical_name: sp.canonicalName, is_herbarium: !!r.is_herbarium });
  }
  const extra = screen(extraRows, genus, g.sharedUrls).items;
  let fromDossier: OcMedia[] = [];
  {
    try {
      const d = await ocSpeciesDossier(name);
      const lm = d?.sections.living_media;
      if (d && lm && sectionAvailable(d, 'living_media')) {
        fromDossier = (lm.items as { id?: number | string; url?: string; source?: string; license?: string; rights_holder?: string | null; observer_name?: string | null; identification_state?: string | null; gbif_occurrence_key?: number | string | null }[])
          .map((m) => ({ m, url: secure(m.url) }))
          .filter(({ url }) => url && !g.sharedUrls.has(url) && !PLACEHOLDER.test(url) && !NOT_IMAGE.test(url) && !CULTURE_ICON.test(url))
          .map(({ m, url }) => ({
            id: `calyx:${m.id ?? url}`, src: url!, thumb: null, scientificName: d.acceptedName, taxonomyId: d.taxonId,
            source: `Orchid Continuum species dossier · ${m.source || 'stored image record'}`, imageSource: m.source || null,
            creator: m.rights_holder || m.observer_name || null, license: licenseLabel(m.license),
            recordUrl: m.gbif_occurrence_key ? `https://www.gbif.org/occurrence/${m.gbif_occurrence_key}` : url!, country: null,
            /* Calyx files herbarium sheets under living_media too; classify by known herbarium hosts. */
            evidenceClass: (HERBARIUM_HOST.test(url!) ? 'herbarium-specimen' : 'living-plant-observation') as OcEvidenceClass,
            provider: 'Orchid Continuum' as const, identificationState: m.identification_state || null,
          }));
      }
    } catch { /* dossier failure is reported by its own hook; media from the library still stands */ }
  }
  const seen = new Set<string>();
  const items = [...g.items.filter((m) => norm(m.scientificName) === n), ...extra, ...fromDossier]
    .filter((m) => m.evidenceClass === want && !seen.has(m.src) && seen.add(m.src));
  return { name, taxonomyId: sp?.taxonomyId ?? null, basis, items, rejected: g.rejected };
}

/* ----------------------------- Dossier ----------------------------- */

export interface OcReceipt { source_id?: string; source_name?: string; source_url?: string | null; record_id?: string; license?: string | null; attribution?: string | null; evidence_state?: string; confidence?: number | null; notes?: string | null }
export interface OcSection { state: string; summary: string | null; items: unknown[]; receipts: OcReceipt[]; unavailable_reason: string | null }
export interface OcDossier {
  taxonId: string; acceptedName: string; fullScientificName: string; authorship: string | null; synonyms: string[];
  sections: Record<string, OcSection>; resolution: 'resolved' | 'ambiguous-exact' | 'oc-public-fallback'; candidates: string[];
  dossierUrl: string; matrixUrl: string | null; generatedAt: string | null; contract: string | null; raw: Record<string, unknown>;
}

interface FedResult { status?: string; taxon_id?: string | null; candidates?: { taxon_id: string; accepted_name: string }[]; explanation?: string }

const AVAILABLE_STATES = new Set(['available', 'provisional', 'conflicting', 'modeled', 'modelled', 'inferred']);

/** True only when the section exists, is in a usable state AND carries real content. */
export function sectionAvailable(d: OcDossier | null | undefined, key: string): boolean {
  const s = d?.sections?.[key];
  if (!s || !AVAILABLE_STATES.has(String(s.state).toLowerCase())) return false;
  return Boolean((s.summary && String(s.summary).trim()) || (Array.isArray(s.items) && s.items.length));
}

function toDossier(raw: Record<string, unknown>, resolution: OcDossier['resolution'], candidates: string[]): OcDossier {
  const identity = (raw.identity || {}) as Record<string, unknown>;
  const sections: Record<string, OcSection> = {};
  for (const [k, v] of Object.entries(raw)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && typeof (v as { state?: unknown }).state === 'string') {
      const s = v as Partial<OcSection>;
      sections[k] = { state: String(s.state), summary: (s.summary as string) ?? null, items: Array.isArray(s.items) ? s.items : [], receipts: Array.isArray(s.receipts) ? s.receipts : [], unavailable_reason: (s.unavailable_reason as string) ?? null };
    }
  }
  const taxonId = String(raw.taxon_id ?? identity.taxon_id ?? '');
  const matrix = (raw.matrix_url as string) || null;
  return {
    taxonId, acceptedName: String(raw.accepted_name ?? identity.accepted_name ?? ''), fullScientificName: String(raw.full_scientific_name ?? identity.full_scientific_name ?? raw.accepted_name ?? ''),
    authorship: (identity.authorship as string) ?? null,
    synonyms: Array.isArray(identity.synonyms) ? (identity.synonyms as unknown[]).map((s) => (typeof s === 'string' ? s : String((s as { name?: string }).name ?? ''))).filter(Boolean) : [],
    sections, resolution, candidates, dossierUrl: `${OC_SITE}/species/${enc(taxonId)}`,
    matrixUrl: matrix ? (matrix.startsWith('http') ? matrix : `${OC_SITE}${matrix}`) : null,
    generatedAt: (raw.generated_at as string) ?? null, contract: (raw.contract_version as string) ?? null, raw,
  };
}

const countAvail = (d: OcDossier) => Object.keys(d.sections).filter((k) => sectionAvailable(d, k)).length;

/** Canonical Calyx species dossier. Returns null when no exact canonical taxon exists; throws when an endpoint fails. */
export async function ocSpeciesDossier(name: string): Promise<OcDossier | null> {
  const n = norm(name);
  let ids: string[] = [];
  let resolution: OcDossier['resolution'] = 'resolved';
  let fedError: unknown = null;
  try {
    const res = await ocGet<FedResult>('calyx', `/api/platform/federation/resolve-species?name=${enc(name.trim())}`);
    if (res.status === 'resolved' && res.taxon_id) ids = [String(res.taxon_id)];
    else if (res.status === 'ambiguous') {
      ids = (res.candidates || []).filter((c) => norm(c.accepted_name) === n).map((c) => String(c.taxon_id)).slice(0, 3);
      resolution = 'ambiguous-exact';
    }
  } catch (e) { fedError = e; }
  if (!ids.length) {
    const sp = await ocResolveExactSpecies(name).catch(() => null);
    if (sp) { ids = [sp.taxonomyId]; resolution = 'oc-public-fallback'; }
  }
  if (!ids.length) { if (fedError) throw fedError; return null; }
  const got = await Promise.allSettled(ids.map((id) => ocGet<Record<string, unknown>>('calyx', `/api/platform/species/${enc(id)}/dossier`)));
  /* Identity guard: a dossier is only accepted if its accepted name IS the requested name. */
  const ok = got.filter((g): g is PromiseFulfilledResult<Record<string, unknown>> => g.status === 'fulfilled')
    .map((g) => toDossier(g.value, resolution, ids))
    .filter((d) => norm(d.acceptedName) === n || norm(d.fullScientificName).startsWith(n));
  if (!ok.length) {
    const firstErr = got.find((g) => g.status === 'rejected') as PromiseRejectedResult | undefined;
    if (firstErr) throw firstErr.reason;
    return null;
  }
  return ok.sort((a, b) => countAvail(b) - countAvail(a))[0];
}

/* ------------------------------ Hooks ------------------------------ */

export type OcState = 'idle' | 'loading' | 'ok' | 'error';
const results = new Map<string, unknown>();

function useOc<T>(key: string | null, run: () => Promise<T>) {
  const [st, setSt] = useState<{ key: string | null; data: T | null; state: OcState; error: OcCallError | null }>(() => ({
    key, data: key && results.has(key) ? (results.get(key) as T) : null, state: key ? (results.has(key) ? 'ok' : 'loading') : 'idle', error: null,
  }));
  useEffect(() => {
    if (!key) { setSt({ key, data: null, state: 'idle', error: null }); return; }
    if (results.has(key)) { setSt({ key, data: results.get(key) as T, state: 'ok', error: null }); return; }
    let alive = true;
    setSt({ key, data: null, state: 'loading', error: null });
    run().then(
      (d) => { results.set(key, d); if (alive) setSt({ key, data: d, state: 'ok', error: null }); },
      (e) => { if (alive) setSt({ key, data: null, state: 'error', error: e instanceof OcError ? e.info : { url: '', status: 0, kind: 'network', message: String(e), at: new Date().toISOString() } }); },
    );
    return () => { alive = false; };
    // run is derived from key
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return st.key === key ? st : { key, data: null, state: (key ? 'loading' : 'idle') as OcState, error: null };
}

export const useOcSpeciesDossier = (name: string | null) => useOc(name ? `dossier:${norm(name)}` : null, () => ocSpeciesDossier(name!));
export const useOcSpeciesMedia = (name: string | null, basis: 'HUMAN_OBSERVATION' | 'PRESERVED_SPECIMEN') =>
  useOc(name ? `media:${basis}:${norm(name)}` : null, () => ocSpeciesMedia(name!, basis));
export const useOcGenusImages = (genus: string | null) => useOc(genus ? `genus:${norm(genus)}` : null, () => ocGenusImages(genus!, 200));
