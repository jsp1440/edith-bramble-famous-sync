import { supabase } from '@/lib/supabase';

/**
 * Go Deeper — Orchid Continuum / Calyx integration boundary.
 * Connected: taxon requests resolve through the `orchid-explorer` edge
 * function to the Calyx species dossier (oc-species-dossier-v1). Never
 * fabricates — an unresolved name returns null.
 */

export type DeepSubject = 'taxon' | 'concept' | 'pathogen' | 'card';

export interface DeepLinkRequest {
  subject: DeepSubject;
  /** taxon name, concept slug, pathogen slug, or card id */
  identifier: string;
  /** where in the site the request originated, for analytics/back-links */
  origin?: string;
}

export interface DeepRecord {
  title: string;
  summary: string;
  source: string;
  license?: string;
  url?: string;
}

export const CONTINUUM_BASE_URL: string | null = 'https://orchidcontinuum.org';

export function isDeepIntegrationEnabled(): boolean {
  return Boolean(CONTINUUM_BASE_URL);
}

/** Only taxon subjects are served by the Continuum today; others return null. */
export async function fetchDeepRecord(request: DeepLinkRequest): Promise<DeepRecord | null> {
  if (!isDeepIntegrationEnabled() || request.subject !== 'taxon') return null;
  const { data, error } = await supabase.functions.invoke('orchid-explorer', { body: { action: 'oc-dossier', name: request.identifier } });
  if (error || !data || data.status !== 'connected') return null;
  const avail = Object.entries(data.sections || {}).filter(([, s]) => (s as { state: string }).state !== 'unavailable').map(([k]) => k.replace(/_/g, ' '));
  return {
    title: data.identity?.accepted_name || request.identifier,
    summary: avail.length ? `Orchid Continuum has assembled: ${avail.join(', ')}.` : 'Orchid Continuum holds a canonical record for this taxon; its evidence sections are not yet assembled.',
    source: 'Orchid Continuum species dossier',
    url: data.dossierUrl || undefined,
  };
}

/** Internal route a deep link resolves to. */
export function deepLinkHref(request: DeepLinkRequest): string {
  const params = new URLSearchParams({ subject: request.subject, id: request.identifier });
  return `/go-deeper?${params.toString()}`;
}
