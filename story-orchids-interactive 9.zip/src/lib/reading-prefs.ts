/**
 * Site-wide reading preferences for the Edith Bramble Chronicles.
 * One source of truth for text size, contrast, motion, sound and the
 * story Reading View. Stored in localStorage (no account needed) and
 * mirrored onto <html> as data attributes so CSS can respond instantly.
 */

export type TextSize = 'smaller' | 'standard' | 'large' | 'xlarge';
export type Contrast = 'standard' | 'high';
export type Motion = 'auto' | 'full' | 'reduced';
export type SoundPref = 'off' | 'on';

export interface ReadingPrefs {
  size: TextSize;
  contrast: Contrast;
  motion: Motion;
  sound: SoundPref;
  readingView: boolean;
}

export const TEXT_SIZES: { id: TextSize; label: string; short: string; root: string; story: number }[] = [
  { id: 'smaller', label: 'Smaller', short: 'A−', root: '93.75%', story: 0.94 },
  { id: 'standard', label: 'Standard', short: 'A', root: '100%', story: 1 },
  { id: 'large', label: 'Large', short: 'A+', root: '115%', story: 1.15 },
  { id: 'xlarge', label: 'Extra large', short: 'A++', root: '130%', story: 1.3 },
];

export const DEFAULT_PREFS: ReadingPrefs = {
  size: 'standard',
  contrast: 'standard',
  motion: 'auto',
  sound: 'off',
  readingView: false,
};

const KEY = 'eb-reading-prefs';
export const PREFS_EVENT = 'eb-reading-change';

export function loadPrefs(): ReadingPrefs {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}');
    const p = { ...DEFAULT_PREFS, ...raw } as ReadingPrefs;
    if (!TEXT_SIZES.some((s) => s.id === p.size)) p.size = 'standard';
    // Legacy story-only scale from the earlier "Aa" control.
    if (!raw.size) {
      const legacy = parseFloat(localStorage.getItem('eb-reader-scale') || '1');
      if (legacy >= 1.3) p.size = 'xlarge';
      else if (legacy >= 1.15) p.size = 'large';
      else if (legacy < 1) p.size = 'smaller';
    }
    return p;
  } catch {
    return { ...DEFAULT_PREFS };
  }
}

export function osPrefersReducedMotion(): boolean {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
}

/** True when motion should be calmed: the reader chose Reduced, or chose
 *  nothing and the operating system asks for reduced motion. */
export function isMotionReduced(p: ReadingPrefs): boolean {
  if (p.motion === 'reduced') return true;
  if (p.motion === 'full') return false;
  return osPrefersReducedMotion();
}

export function applyPrefs(p: ReadingPrefs) {
  const html = document.documentElement;
  const size = TEXT_SIZES.find((s) => s.id === p.size) || TEXT_SIZES[1];
  html.dataset.ebSize = size.id;
  html.dataset.ebContrast = p.contrast;
  html.dataset.ebMotion = isMotionReduced(p) ? 'reduced' : 'full';
  if (p.readingView) html.dataset.ebReadingView = 'on';
  else delete html.dataset.ebReadingView;
  html.style.setProperty('--eb-read-scale', String(size.story));
}

export function savePrefs(p: ReadingPrefs) {
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* storage may be unavailable — the choice still applies for this visit */
  }
  applyPrefs(p);
  window.dispatchEvent(new CustomEvent<ReadingPrefs>(PREFS_EVENT, { detail: p }));
}

/** Update one or more preferences from anywhere (components, sound engine…). */
export function updatePrefs(patch: Partial<ReadingPrefs>): ReadingPrefs {
  const next = { ...loadPrefs(), ...patch };
  savePrefs(next);
  return next;
}

// Apply as early as possible so the first paint is already the reader's size.
if (typeof window !== 'undefined') {
  try {
    applyPrefs(loadPrefs());
  } catch {
    /* ignore */
  }
}
