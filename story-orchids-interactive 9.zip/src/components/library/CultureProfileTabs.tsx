import React, { useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, BookOpenText } from 'lucide-react';
import type { OrchidProfile } from '@/lib/orchid-types';
import type { Claim, ProfileSection } from '@/lib/evidence-types';
import { EVIDENCE_CLASS_LABEL, REVIEW_STATE_LABEL, SECTION_LABEL, claimId, claimsFor } from '@/lib/evidence';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { chroniclePath } from '@/lib/content';
import ReadThePlant from '@/components/science/ReadThePlant';
import HabitatMap from '@/components/map/HabitatMap';
import {
  AosGuidance,
  ClaimIndicator,
  ClassBadge,
  EvidencePending,
  OcPendingPanel,
  ProfileStatusPanel,
  RESPONSE_LABEL,
  ReviewBadge,
  ScientificImage,
  useAcceptedReviews,
} from '@/components/evidence/EvidenceUI';

const TABS: ProfileSection[] = ['overview', 'habitat', 'map', 'adaptations', 'seasonal', 'culture', 'signals', 'evidence', 'review'];

const H: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))] sm:text-[1.75rem]">{children}</h3>
);
const P: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <p className={`text-[1.25rem] leading-[1.7] text-[hsl(var(--ink))] ${className}`}>{children}</p>
);
const Card: React.FC<{ label?: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="rounded-md border-2 border-border bg-white/60 px-5 py-4">
    {label && <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--botanical))]">{label}</p>}
    <div className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{children}</div>
  </div>
);

export const ReportCta: React.FC<{ profileId?: string }> = ({ profileId }) => (
  <aside className="rounded-md bg-[hsl(var(--botanical))] p-6 text-[hsl(44_50%_95%)]">
    <p className="font-display text-2xl font-semibold">See something we should check?</p>
    <p className="mt-2 text-[1.1875rem] leading-relaxed">
      Orchid knowledge continues to develop. If you find something that appears inaccurate, overly broad, outdated, or unsupported, please
      help us improve this resource.
    </p>
    <div className="mt-4 flex flex-wrap gap-3">
      <Link to={`/report-evidence${profileId ? `?profile=${profileId}` : ''}`} className="eb-btn-cream inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(44_60%_94%)] px-6 font-ui text-[1.125rem] font-semibold text-[hsl(var(--botanical))]">
        Report an error or add evidence <ArrowRight className="h-5 w-5" aria-hidden="true" />
      </Link>
      <Link to="/how-we-handle-evidence" className="inline-flex min-h-[52px] items-center rounded-md border-2 border-[hsl(44_50%_90%)] px-6 font-ui text-[1.125rem] font-semibold">
        How we handle evidence
      </Link>
    </div>
  </aside>
);

const CultureProfileTabs: React.FC<{ profile: OrchidProfile }> = ({ profile }) => {
  const [params, setParams] = useSearchParams();
  const tab = (TABS.includes(params.get('tab') as ProfileSection) ? params.get('tab') : 'overview') as ProfileSection;
  const claims = useMemo(() => new Map(claimsFor(profile).map((c) => [c.id, c])), [profile]);
  const c = (section: ProfileSection, key: string | number): Claim | undefined => claims.get(claimId(profile.id, section, key));
  const { reviews } = useAcceptedReviews(profile.id);

  const setTab = (t: ProfileSection) => {
    const next = new URLSearchParams(params);
    next.set('tab', t);
    setParams(next, { replace: true });
  };

  return (
    <div className="space-y-8">
      <ProfileStatusPanel profile={profile} reviews={reviews} />

      <div role="tablist" aria-label="Profile sections" className="flex flex-wrap gap-2 border-b-2 border-border pb-3">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            type="button"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`min-h-[48px] rounded-md px-4 font-ui text-[1.0625rem] font-semibold transition-colors ${
              tab === t ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-2 border-border text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10'
            }`}
          >
            {SECTION_LABEL[t]}
          </button>
        ))}
      </div>

      <div role="tabpanel" className="space-y-6">
        {tab === 'overview' && (
          <>
            <P className="font-display text-[1.5rem] italic text-[hsl(var(--botanical))]">
              {profile.hook}
              {c('overview', 'hook') && <ClaimIndicator claim={c('overview', 'hook')!} />}
            </P>
            <Card label="Name used here">
              <em>{profile.acceptedName}</em> <span className="ml-1">({profile.rank})</span>
              <p className="mt-1">{profile.taxonomy}</p>
              <p className="mt-2 text-[1.0625rem]">Accepted name and synonyms will be confirmed against Orchid Continuum taxonomy — not yet checked.</p>
            </Card>
            {profile.variationNote && <Card label="Scope of this profile">{profile.variationNote}</Card>}
            <H>Where it comes from</H>
            <P>
              {profile.origin.summary}
              {c('overview', 'origin') && <ClaimIndicator claim={c('overview', 'origin')!} />}
            </P>
            {profile.chronicles.length > 0 && (
              <div className="flex flex-wrap gap-3">
                {profile.chronicles.map((ch) => (
                  <Link key={ch.id} to={chroniclePath(ch.id)} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-border px-4 text-[1.0625rem] text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]">
                    <BookOpenText className="h-5 w-5 text-[hsl(var(--botanical))]" aria-hidden="true" /> In the story: {ch.note}
                  </Link>
                ))}
              </div>
            )}
          </>
        )}

        {tab === 'habitat' && (
          <>
            <H>Habitat</H>
            <div className="grid gap-3 sm:grid-cols-2">
              {profile.habitat.map((h) => (
                <Card key={h.label} label={h.label}>
                  {h.value}
                  {c('habitat', h.label) && <ClaimIndicator claim={c('habitat', h.label)!} />}
                </Card>
              ))}
            </div>
            <H>Habitat imagery</H>
            <div className="grid gap-4 sm:grid-cols-2">
              {profile.natureImages.map((slot) => (
                <ScientificImage key={slot.caption} caption={slot.caption} image={slot.photo ? { ...slot.photo, role: 'habitat-photograph' } : null} />
              ))}
            </div>
            <OcPendingPanel what="Elevation, temperature and precipitation context" />
            <P className="text-[1.125rem]">Habitat → adaptation → seasonal behaviour → culture: follow the tabs in order to see why this plant is grown the way it is.</P>
          </>
        )}

        {tab === 'map' && (
          <>
            <H>Map</H>
            <HabitatMap profile={profile} />
          </>
        )}

        {tab === 'adaptations' && (
          <>
            <H>Adaptations</H>
            <ul className="space-y-3">
              {profile.adaptations.map((a) => (
                <li key={a.structure}>
                  <Card label={a.structure}>
                    {a.fn}
                    {c('adaptations', a.structure) && <ClaimIndicator claim={c('adaptations', a.structure)!} />}
                  </Card>
                </li>
              ))}
            </ul>
            <OcPendingPanel what="Morphological, pollinator and mycorrhizal evidence" />
          </>
        )}

        {tab === 'seasonal' && (
          <>
            <H>Seasonal cycle</H>
            <ol className="grid gap-3 sm:grid-cols-2">
              {profile.seasonal.map((s, i) => (
                <li key={s.phase}>
                  <Card label={`${i + 1} · ${s.when}`}>
                    <span className="block font-display text-[1.375rem] text-[hsl(var(--charcoal))]">{s.phase}</span>
                    {s.note}
                    {c('seasonal', i) && <ClaimIndicator claim={c('seasonal', i)!} />}
                  </Card>
                </li>
              ))}
            </ol>
            <P className="text-[1.125rem]">Timing shown is typical for cultivated plants in the Northern Hemisphere and varies with clone, climate and growing setup.</P>
          </>
        )}

        {tab === 'culture' && (
          <>
            <AosGuidance profile={profile} />
            <div className="rounded-md border-2 border-[hsl(96_30%_30%)] p-5 sm:p-6">
              <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(96_35%_22%)]">Separate from the AOS guidance above</p>
              <H>FCOS / Orchid Continuum interpretation</H>
              <P className="mt-2 text-[1.125rem]">Our own explanation, written as a draft. Each statement carries its own evidence indicator.</P>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {profile.culture.map((cu) => (
                  <Card key={cu.label} label={cu.label}>
                    {cu.value}
                    {c('culture', cu.label) && <ClaimIndicator claim={c('culture', cu.label)!} />}
                  </Card>
                ))}
              </div>
              <P className="mt-4 text-[1.125rem]">No watering schedule is given on purpose: the plant's stage, your media and your climate decide the interval.</P>
            </div>
            <div>
              <H>Where could I grow it?</H>
              <ul className="mt-3 grid gap-3 sm:grid-cols-2">
                {profile.whereToGrow.map((w) => (
                  <li key={w.place}>
                    <Card label={`${w.place} — ${w.fit}`}>{w.note}</Card>
                  </li>
                ))}
              </ul>
            </div>
          </>
        )}

        {tab === 'signals' && (
          <>
            <H>What the plant is telling you</H>
            <ul className="grid gap-3 sm:grid-cols-2">
              {profile.growerSees.map((g, i) => (
                <li key={g}>
                  <Card>
                    {g}
                    {c('signals', i) && <ClaimIndicator claim={c('signals', i)!} />}
                  </Card>
                </li>
              ))}
            </ul>
            <H>Read the plant</H>
            <ReadThePlant profile={profile} />
            {profile.sameNameDifferentLife && (
              <>
                <H>Same name, different life</H>
                <ul className="space-y-3">
                  {profile.sameNameDifferentLife.map((s) => (
                    <li key={s.name}>
                      <Card label={s.name}>
                        {s.contrast}
                        {s.id && getProfile(s.id) && (
                          <Link to={profilePath(s.id)} className="ml-2 font-semibold text-[hsl(var(--botanical))] underline">Open profile</Link>
                        )}
                      </Card>
                    </li>
                  ))}
                </ul>
                <Link to={`/culture-library/compare?a=${profile.id}${profile.sameNameDifferentLife[0]?.id ? `&b=${profile.sameNameDifferentLife[0].id}` : ''}`} className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">
                  Compare side by side <ArrowRight className="h-5 w-5" aria-hidden="true" />
                </Link>
              </>
            )}
          </>
        )}

        {tab === 'evidence' && (
          <>
            <H>Sources</H>
            {profile.sources.length ? (
              <ol className="list-decimal space-y-2 pl-6 text-[1.1875rem]">
                {profile.sources.map((s) => (
                  <li key={s.id}>{s.url ? <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline">{s.citation}</a> : s.citation}</li>
                ))}
              </ol>
            ) : (
              <EvidencePending label="Source needed">
                No sources have yet been attached and checked for this profile. This site never generates citations; sources will be added one
                statement at a time, source first.
              </EvidencePending>
            )}
            <H>Every statement on this profile</H>
            <div className="overflow-x-auto rounded-md border-2 border-border">
              <table className="w-full min-w-[42rem] border-collapse bg-white/60 text-left text-[1.0625rem]">
                <thead>
                  <tr className="border-b-2 border-border">
                    <th className="px-4 py-3 font-ui font-bold">Section</th>
                    <th className="px-4 py-3 font-ui font-bold">Statement</th>
                    <th className="px-4 py-3 font-ui font-bold">Evidence class</th>
                    <th className="px-4 py-3 font-ui font-bold">State</th>
                  </tr>
                </thead>
                <tbody>
                  {[...claims.values()].map((cl) => (
                    <tr key={cl.id} className="border-b border-border/60 align-top last:border-0">
                      <td className="px-4 py-3">{SECTION_LABEL[cl.section]}</td>
                      <td className="px-4 py-3 text-[hsl(var(--ink))]">{cl.text} <ClaimIndicator claim={cl} /></td>
                      <td className="px-4 py-3">{EVIDENCE_CLASS_LABEL[cl.evidenceClass].short}</td>
                      <td className="px-4 py-3">{REVIEW_STATE_LABEL[cl.reviewState]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <H>Evidence classes we keep separate</H>
            <ul className="grid gap-3 sm:grid-cols-2">
              {(Object.keys(EVIDENCE_CLASS_LABEL) as (keyof typeof EVIDENCE_CLASS_LABEL)[]).map((k) => (
                <li key={k} className="rounded-md border-2 border-border bg-white/60 p-4">
                  <ClassBadge cls={k} />
                  <p className="mt-2 text-[1.0625rem] text-[hsl(var(--ink))]">{EVIDENCE_CLASS_LABEL[k].note}</p>
                </li>
              ))}
            </ul>
            <OcPendingPanel what="Literature and database records" />
          </>
        )}

        {tab === 'review' && (
          <>
            <H>Expert review</H>
            {reviews && reviews.length ? (
              <ul className="space-y-3">
                {reviews.map((r) => (
                  <li key={r.id} className="rounded-md border-2 border-border bg-white/60 p-5">
                    <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">
                      {RESPONSE_LABEL[r.response] ?? r.response} — {r.reviewer_name || 'Reviewer'}
                      {r.reviewer_expertise?.length ? ` (stated expertise: ${r.reviewer_expertise.join(', ')})` : ''}
                    </p>
                    {r.claim_text && <p className="mt-1 text-[1.0625rem] italic">On: “{r.claim_text}”</p>}
                    {r.comment && <p className="mt-2 text-[1.125rem] text-[hsl(var(--ink))]">{r.comment}</p>}
                    {r.growing_environment && <p className="mt-1 text-[1.0625rem]">Growing context: {r.growing_environment}</p>}
                    {r.citation && <p className="mt-1 text-[1.0625rem]">Source: {r.citation}</p>}
                    <p className="mt-1 text-[1rem]">Submitted {new Date(r.created_at).toLocaleDateString()} · a reviewer's view, preserved as given — not automatically fact.</p>
                  </li>
                ))}
              </ul>
            ) : (
              <EvidencePending label="Expert review pending">No reviews of this profile have been accepted through moderation yet.</EvidencePending>
            )}
            <div className="flex flex-wrap gap-3">
              <Link to={`/expert-review?profile=${profile.id}`} className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-6 font-ui text-[1.125rem] font-semibold text-[hsl(var(--cream))]">
                Review claims on this profile <ArrowRight className="h-5 w-5" aria-hidden="true" />
              </Link>
            </div>
            <p className="text-[1.0625rem] text-[hsl(var(--ink))]">States: {(['draft', 'source-checked', 'expert-reviewed', 'disputed', 'evidence-pending'] as const).map((s) => <ReviewBadge key={s} state={s} className="mr-2 mt-2" />)}</p>
          </>
        )}
      </div>

      <ReportCta profileId={profile.id} />
    </div>
  );
};

export default CultureProfileTabs;
