import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, BookOpen, ImageOff, Loader2 } from 'lucide-react';
import {
  EVIDENCE_LABEL,
  FEATURED_GENERA,
  dossierPath,
  genusOfTheDay,
  sizedSrc,
  useGenusSpecies,
  type SpeciesEntry,
} from '@/lib/continuum';

const PAGE = 9;

const altFor = (s: SpeciesEntry) =>
  s.hero
    ? `${s.name}: ${s.hero.evidenceClass === 'herbarium-specimen' ? 'herbarium specimen' : 'living plant photographed'}${s.hero.country ? ` in ${s.hero.country}` : ''}`
    : `${s.name}: no image available`;

const NoImage: React.FC<{ big?: boolean; pending?: boolean }> = ({ big, pending }) => (
  <div className={`flex h-full w-full flex-col items-center justify-center gap-2 bg-[hsl(40_25%_88%)] p-3 text-center text-[hsl(var(--charcoal))] ${big ? 'text-xl' : 'text-[1rem]'}`}>
    {pending ? <Loader2 className={`${big ? 'h-10 w-10' : 'h-6 w-6'} animate-spin`} aria-hidden="true" /> : <ImageOff className={big ? 'h-10 w-10' : 'h-6 w-6'} aria-hidden="true" />}
    <span className="font-ui font-semibold">{pending ? 'Checking Orchid Continuum…' : 'No image available'}</span>
  </div>
);

/** An image that never shows a broken-image icon: on load failure it becomes an honest "No image available". */
const SafeImg: React.FC<{ src: string; alt: string; big?: boolean; lazy?: boolean }> = ({ src, alt, big, lazy }) => {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  return failed ? <NoImage big={big} /> : <img src={src} alt={alt} loading={lazy ? 'lazy' : undefined} decoding="async" onError={() => setFailed(true)} className="h-full w-full object-cover" />;
};

const FeaturedGenus: React.FC<{ initialGenus?: string; compact?: boolean }> = ({ initialGenus, compact }) => {
  const [genus, setGenus] = useState(initialGenus || genusOfTheDay().genus);
  const [offset, setOffset] = useState(0);
  const [selKey, setSelKey] = useState<number | null>(null);
  const [selected, setSelected] = useState<SpeciesEntry | null>(null);
  const { data, state, mediaPending, ocMediaState } = useGenusSpecies(genus, offset, PAGE);
  const note = FEATURED_GENERA.find((g) => g.genus === genus)?.note;

  useEffect(() => {
    setOffset(0);
    setSelKey(null);
    setSelected(null);
  }, [genus]);

  // Default hero: first species in the window that has an image.
  useEffect(() => {
    if (!data?.species?.length || selKey) return;
    setSelected(data.species.find((s) => s.hero) ?? data.species[0]);
  }, [data, selKey]);

  const total = data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));
  const page = Math.floor(offset / PAGE);
  /* Always render the LIVE record for the selected key, so a late-arriving
     Orchid Continuum image updates the hero and caption in place. */
  const hero = (selected && data?.species.find((s) => s.key === selected.key)) || selected;

  const choose = (s: SpeciesEntry) => {
    setSelKey(s.key);
    setSelected(s);
  };

  return (
    <section aria-labelledby="featured-genus-title" className="rounded-xl border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5 shadow-sm sm:p-7">
      <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">Featured Genus · Genus of the Day</p>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 id="featured-genus-title" className="font-display text-4xl font-semibold italic text-[hsl(var(--charcoal))] sm:text-5xl">{genus}</h2>
          {note && <p className="mt-1 text-[1.125rem] text-[hsl(var(--ink))]">In the Chronicles: {note}</p>}
        </div>
        <label className="flex flex-col gap-1 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]">
          Choose a genus
          <select value={genus} onChange={(e) => setGenus(e.target.value)} className="min-h-[52px] rounded-md border-2 border-[hsl(var(--charcoal))]/40 bg-white px-3 text-[1.125rem]">
            {(FEATURED_GENERA.some((g) => g.genus === genus) ? FEATURED_GENERA : [{ genus, note: '' }, ...FEATURED_GENERA]).map((g) => (
              <option key={g.genus} value={g.genus}>{g.genus}</option>
            ))}
          </select>
        </label>
      </div>

      {state === 'error' && (
        <p className="mt-6 rounded-lg border-2 border-[hsl(var(--burgundy))] p-5 text-[1.125rem]">The species list could not be loaded just now. Please try again in a moment.</p>
      )}
      {state === 'ok' && data && !data.found && <p className="mt-6 text-[1.125rem]">No accepted orchid genus matched “{genus}”.</p>}

      <div className={`mt-6 grid gap-6 ${compact ? '' : 'lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]'}`}>
        {/* HERO */}
        <figure className="overflow-hidden rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-[hsl(var(--cream))]">
          <div className="aspect-[4/3] w-full overflow-hidden bg-[hsl(40_25%_88%)]">
            {state === 'loading' && !hero ? (
              <div className="flex h-full items-center justify-center gap-3 text-[1.125rem]"><Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" /> Loading species…</div>
            ) : hero?.hero ? (
              <SafeImg key={hero.hero.src} src={sizedSrc(hero.hero.src, 'large')} alt={altFor(hero)} big />
            ) : hero ? (
              <NoImage big pending={mediaPending} />
            ) : null}
          </div>
          {hero && (
            <figcaption className="space-y-2 p-4 sm:p-5">
              <p className="font-display text-3xl font-semibold italic leading-tight text-[hsl(var(--charcoal))]">
                {hero.name} <span className="font-ui text-[1.0625rem] not-italic font-normal text-[hsl(var(--ink))]">{hero.authorship}</span>
              </p>
              {hero.hero ? (
                <p className="text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
                  <strong>{EVIDENCE_LABEL[hero.hero.evidenceClass]}</strong>
                  {hero.hero.country ? ` · ${hero.hero.country}` : ''} · Photo: {hero.hero.creator ?? 'not credited by source'} · {hero.hero.license} · {hero.hero.source} ·{' '}
                  <a href={hero.hero.recordUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">record</a>
                </p>
              ) : mediaPending ? (
                <p className="text-[1.0625rem] text-[hsl(var(--ink))]">Checking the Orchid Continuum media library for this exact species…</p>
              ) : (
                <p className="text-[1.0625rem] text-[hsl(var(--ink))]">No photograph or specimen image of this exact species was found in Orchid Continuum or the openly licensed fallback records. No other orchid is substituted.</p>
              )}
              <Link to={dossierPath(hero.key, hero.name)} className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
                <BookOpen className="h-5 w-5" aria-hidden="true" /> Open Species Dossier
              </Link>
            </figcaption>
          )}
        </figure>

        {/* 3×3 MOVING WINDOW */}
        <div>
          <p className="text-[1.125rem] text-[hsl(var(--ink))]">
            Tap a species to show it above.{' '}
            {total > 0 && (
              <strong>
                Species {offset + 1}–{Math.min(offset + PAGE, total)} of {total.toLocaleString()} accepted
              </strong>
            )}
          </p>
          <ul className="mt-3 grid grid-cols-3 gap-2 sm:gap-3" aria-busy={state === 'loading'}>
            {(data?.species ?? []).map((s) => {
              const on = hero?.key === s.key;
              return (
                <li key={s.key}>
                  <button
                    type="button"
                    onClick={() => choose(s)}
                    aria-pressed={on}
                    className={`block w-full overflow-hidden rounded-lg border-2 text-left ${on ? 'border-[hsl(var(--botanical))] ring-4 ring-[hsl(var(--botanical))]/30' : 'border-[hsl(var(--charcoal))]/25 hover:border-[hsl(var(--botanical))]'}`}
                  >
                    <span className="block aspect-square overflow-hidden bg-[hsl(40_25%_88%)]">
                      {s.hero ? <SafeImg key={s.hero.src} src={sizedSrc(s.hero.src, 'small')} alt={altFor(s)} lazy /> : <NoImage pending={mediaPending} />}
                    </span>
                    <span className="block min-h-[3.2em] px-2 py-1.5 font-display text-[1rem] italic leading-snug text-[hsl(var(--charcoal))] sm:text-[1.0625rem]">
                      {s.name.replace(`${genus} `, `${genus.charAt(0)}. `)}
                      {on && <span className="sr-only"> (selected)</span>}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button type="button" disabled={page === 0 || state === 'loading'} onClick={() => { setSelKey(null); setOffset(Math.max(0, offset - PAGE)); }}
              className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(var(--charcoal))]/50 bg-white px-4 font-ui text-[1.0625rem] font-semibold disabled:opacity-40">
              <ArrowLeft className="h-5 w-5" aria-hidden="true" /> Previous 9
            </button>
            <button type="button" disabled={page >= pages - 1 || state === 'loading'} onClick={() => { setSelKey(null); setOffset(offset + PAGE); }}
              className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] disabled:opacity-40">
              Next 9 <ArrowRight className="h-5 w-5" aria-hidden="true" />
            </button>
            {pages > 1 && (
              <label className="flex items-center gap-2 font-ui text-[1.0625rem] font-semibold">
                Jump to
                <select value={page} onChange={(e) => { setSelKey(null); setOffset(Number(e.target.value) * PAGE); }} className="min-h-[52px] rounded-md border-2 border-[hsl(var(--charcoal))]/40 bg-white px-2 text-[1.0625rem]">
                  {Array.from({ length: pages }, (_, i) => (
                    <option key={i} value={i}>{i * PAGE + 1}–{Math.min((i + 1) * PAGE, total)}</option>
                  ))}
                </select>
              </label>
            )}
          </div>
          <p className="mt-3 text-[1rem] text-[hsl(var(--ink))]">
            Species list: GBIF Backbone Taxonomy (accepted names). Pictures: Orchid Continuum media library first, openly licensed GBIF records as fallback — always that exact species, a living plant before a herbarium specimen, otherwise “No image available”.
            {ocMediaState === 'error' && <strong> Orchid Continuum media could not be reached just now; fallback records are shown.</strong>}
          </p>
        </div>
      </div>
    </section>
  );
};

export default FeaturedGenus;
