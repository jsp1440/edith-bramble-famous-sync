import React, { useEffect, useState } from 'react';
import { CheckCircle2, MessageSquareText, Users } from 'lucide-react';
import { REVIEW_CHOICES, fetchTallies, submitClaimReview, type Claim, type ReviewChoice } from '@/lib/continuum';

const ClaimRow: React.FC<{ claim: Claim; taxonKey: number | null; taxonName: string; tally?: Partial<Record<ReviewChoice, number>>; onDone: () => void }> = ({
  claim, taxonKey, taxonName, tally, onDone,
}) => {
  const [choice, setChoice] = useState<ReviewChoice | null>(null);
  const [reasoning, setReasoning] = useState('');
  const [confidence, setConfidence] = useState<'low' | 'medium' | 'high'>('medium');
  const [experience, setExperience] = useState<'beginner' | 'hobbyist' | 'experienced' | 'professional'>('hobbyist');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const n = tally ? Object.values(tally).reduce((a, b) => a + (b || 0), 0) : 0;

  const send = async () => {
    if (!choice) return;
    setStatus('sending');
    try {
      await submitClaimReview({ taxonKey, taxonName, claim, choice, reasoning, confidence, experience });
      setStatus('sent');
      onDone();
    } catch {
      setStatus('error');
    }
  };

  return (
    <li className="rounded-lg border-2 border-[hsl(var(--charcoal))]/25 bg-white p-4 sm:p-5">
      <p className="text-[1.1875rem] leading-relaxed text-[hsl(var(--charcoal))]">“{claim.text}”</p>
      <p className="mt-1 text-[1rem] text-[hsl(var(--ink))]">
        <strong>Source:</strong> {claim.source} · <strong>Evidence class:</strong> {claim.evidenceClass} · <strong>Review state:</strong> {claim.reviewState}
      </p>
      <p className="mt-1 flex items-center gap-2 text-[1rem] text-[hsl(var(--ink))]">
        <Users className="h-4 w-4" aria-hidden="true" />
        {n ? `Community responses so far: ${REVIEW_CHOICES.map((c) => `${c.label} ${tally?.[c.id] ?? 0}`).join(' · ')}` : 'No community responses yet.'}
      </p>

      {status === 'sent' ? (
        <p className="mt-3 flex items-center gap-2 rounded-md border-2 border-[hsl(150_40%_28%)] bg-[hsl(150_30%_94%)] p-3 text-[1.0625rem] font-semibold text-[hsl(150_45%_16%)]" aria-live="polite">
          <CheckCircle2 className="h-5 w-5" aria-hidden="true" /> Thank you — your review was recorded for this exact statement. It is shown as community opinion, not as scientific verification.
        </p>
      ) : (
        <fieldset className="mt-3">
          <legend className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">What do you think of this statement?</legend>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {REVIEW_CHOICES.map((c) => (
              <button key={c.id} type="button" aria-pressed={choice === c.id} onClick={() => setChoice(c.id)}
                className={`min-h-[52px] rounded-md border-2 px-3 font-ui text-[1.0625rem] font-semibold ${choice === c.id ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-[hsl(var(--charcoal))]/40 bg-white text-[hsl(var(--charcoal))]'}`}>
                {choice === c.id ? '● ' : ''}{c.label}
              </button>
            ))}
          </div>
          {choice && (
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="sm:col-span-2 flex flex-col gap-1 font-ui text-[1.0625rem] font-semibold">
                Your reasoning or source (optional)
                <textarea value={reasoning} onChange={(e) => setReasoning(e.target.value)} rows={3} maxLength={3500}
                  className="rounded-md border-2 border-[hsl(var(--charcoal))]/40 p-3 font-body text-[1.0625rem] font-normal" />
              </label>
              <label className="flex flex-col gap-1 font-ui text-[1.0625rem] font-semibold">
                How confident are you?
                <select value={confidence} onChange={(e) => setConfidence(e.target.value as typeof confidence)} className="min-h-[52px] rounded-md border-2 border-[hsl(var(--charcoal))]/40 bg-white px-3 text-[1.0625rem]">
                  <option value="low">Not very</option><option value="medium">Fairly</option><option value="high">Very</option>
                </select>
              </label>
              <label className="flex flex-col gap-1 font-ui text-[1.0625rem] font-semibold">
                Your growing experience
                <select value={experience} onChange={(e) => setExperience(e.target.value as typeof experience)} className="min-h-[52px] rounded-md border-2 border-[hsl(var(--charcoal))]/40 bg-white px-3 text-[1.0625rem]">
                  <option value="beginner">Beginner</option><option value="hobbyist">Hobbyist</option><option value="experienced">Experienced grower</option><option value="professional">Professional / researcher</option>
                </select>
              </label>
              <div className="sm:col-span-2 flex flex-wrap items-center gap-3">
                <button type="button" onClick={send} disabled={status === 'sending'} className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(var(--cream))] disabled:opacity-60">
                  <MessageSquareText className="h-5 w-5" aria-hidden="true" /> {status === 'sending' ? 'Sending…' : 'Send my review'}
                </button>
                {status === 'error' && <span className="text-[1.0625rem] font-semibold text-[hsl(var(--burgundy))]">Could not send. Please try again.</span>}
              </div>
            </div>
          )}
        </fieldset>
      )}
    </li>
  );
};

const ClaimReview: React.FC<{ claims: Claim[]; taxonKey: number | null; taxonName: string }> = ({ claims, taxonKey, taxonName }) => {
  const [tallies, setTallies] = useState<Record<string, Partial<Record<ReviewChoice, number>>>>({});
  const ids = claims.map((c) => c.id).join('|');
  const load = () => fetchTallies(claims.map((c) => c.id)).then(setTallies);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [ids]);
  if (!claims.length) return <p className="text-[1.125rem]">No reviewable statements are attached to this taxon yet.</p>;
  return (
    <div>
      <p className="max-w-3xl text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
        Review one statement at a time. Community agreement is recorded separately and is <strong>never</strong> treated as published scientific evidence; disagreement is kept, not erased.
      </p>
      <ul className="mt-4 space-y-4">
        {claims.map((c) => (
          <ClaimRow key={c.id} claim={c} taxonKey={taxonKey} taxonName={taxonName} tally={tallies[c.id]} onDone={load} />
        ))}
      </ul>
    </div>
  );
};

export default ClaimReview;
