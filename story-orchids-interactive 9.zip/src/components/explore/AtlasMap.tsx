import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Layers, Minus, Plus, RotateCcw } from 'lucide-react';

/* ------------------------------------------------------------------
   Interactive Atlas map (Web Mercator slippy map, no extra libraries).
   Basemap: GBIF-hosted OpenStreetMap / OpenMapTiles raster tiles.
   Orchid layer: GBIF occurrence DENSITY tiles, hex-binned. Records are
   aggregated into hexagons and zoom is capped, so no precise locality
   (including for sensitive species) can be read from this map.
------------------------------------------------------------------- */

const TILE = 256;
const MIN_Z = 1;
const MAX_Z = 7; // coarse on purpose — conservation privacy

const BASES = {
  natural: { label: 'Natural', url: (z: number, x: number, y: number) => `https://tile.gbif.org/3857/omt/${z}/${x}/${y}@1x.png?style=gbif-natural` },
  streets: { label: 'Streets', url: (z: number, x: number, y: number) => `https://tile.gbif.org/3857/omt/${z}/${x}/${y}@1x.png?style=osm-bright` },
} as const;
type BaseKey = keyof typeof BASES;

const lngToX = (lng: number, ws: number) => ((lng + 180) / 360) * ws;
const latToY = (lat: number, ws: number) => {
  const s = Math.sin((Math.max(-85, Math.min(85, lat)) * Math.PI) / 180);
  return (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * ws;
};
const xToLng = (x: number, ws: number) => (x / ws) * 360 - 180;
const yToLat = (y: number, ws: number) => (Math.atan(Math.sinh(Math.PI * (1 - (2 * y) / ws))) * 180) / Math.PI;

interface Props {
  taxonKey: number;
  taxonName: string;
  initial?: { lat: number; lng: number; zoom: number } | null;
}

const AtlasMap: React.FC<Props> = ({ taxonKey, taxonName, initial }) => {
  const start = { lat: initial?.lat ?? 10, lng: initial?.lng ?? -30, zoom: Math.min(MAX_Z, Math.max(MIN_Z, initial?.zoom ?? 2)) };
  const [view, setView] = useState(start);
  const [base, setBase] = useState<BaseKey>('natural');
  const [showRecords, setShowRecords] = useState(true);
  const boxRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 800, h: 460 });
  const drag = useRef<{ x: number; y: number; cx: number; cy: number } | null>(null);

  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  const ws = TILE * 2 ** view.zoom;
  const cx = lngToX(view.lng, ws);
  const cy = latToY(view.lat, ws);

  const setCenterPx = useCallback(
    (nx: number, ny: number, z = view.zoom) => {
      const w = TILE * 2 ** z;
      const clampedY = Math.max(Math.min(size.h / 2, w / 2), Math.min(w - Math.min(size.h / 2, w / 2), ny));
      const wrappedX = ((nx % w) + w) % w;
      setView({ lat: yToLat(clampedY, w), lng: xToLng(wrappedX, w), zoom: z });
    },
    [size.h, view.zoom],
  );

  const zoomBy = (d: number, anchor?: { x: number; y: number }) => {
    const z = Math.max(MIN_Z, Math.min(MAX_Z, view.zoom + d));
    if (z === view.zoom) return;
    const f = 2 ** (z - view.zoom);
    const ax = anchor ? anchor.x - size.w / 2 : 0;
    const ay = anchor ? anchor.y - size.h / 2 : 0;
    setCenterPx((cx + ax) * f - ax, (cy + ay) * f - ay, z);
  };
  const pan = (dx: number, dy: number) => setCenterPx(cx + dx, cy + dy);

  const onPointerDown = (e: React.PointerEvent) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { x: e.clientX, y: e.clientY, cx, cy };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current) return;
    setCenterPx(drag.current.cx - (e.clientX - drag.current.x), drag.current.cy - (e.clientY - drag.current.y));
  };
  const onPointerUp = () => (drag.current = null);

  const onKey = (e: React.KeyboardEvent) => {
    const step = 120;
    const map: Record<string, () => void> = {
      ArrowLeft: () => pan(-step, 0),
      ArrowRight: () => pan(step, 0),
      ArrowUp: () => pan(0, -step),
      ArrowDown: () => pan(0, step),
      '+': () => zoomBy(1),
      '=': () => zoomBy(1),
      '-': () => zoomBy(-1),
    };
    if (map[e.key]) {
      e.preventDefault();
      map[e.key]();
    }
  };

  // Visible tiles.
  const n = 2 ** view.zoom;
  const left = cx - size.w / 2;
  const top = cy - size.h / 2;
  const tiles: { key: string; x: number; y: number; wx: number; left: number; top: number }[] = [];
  for (let ty = Math.floor(top / TILE); ty <= Math.floor((top + size.h) / TILE); ty++) {
    if (ty < 0 || ty >= n) continue;
    for (let tx = Math.floor(left / TILE); tx <= Math.floor((left + size.w) / TILE); tx++) {
      const wx = ((tx % n) + n) % n;
      tiles.push({ key: `${view.zoom}-${tx}-${ty}`, x: tx, y: ty, wx, left: tx * TILE - left, top: ty * TILE - top });
    }
  }

  const btn =
    'inline-flex min-h-[48px] min-w-[48px] items-center justify-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] bg-[hsl(var(--cream))] px-3 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))]/10 disabled:opacity-40';

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-wrap gap-2" role="group" aria-label="Base map">
          {(Object.keys(BASES) as BaseKey[]).map((k) => (
            <button
              key={k}
              type="button"
              aria-pressed={base === k}
              onClick={() => setBase(k)}
              className={`${btn} ${base === k ? '!bg-[hsl(var(--botanical))] !text-[hsl(var(--cream))]' : ''}`}
            >
              {BASES[k].label}
            </button>
          ))}
        </div>
        <button type="button" aria-pressed={showRecords} onClick={() => setShowRecords((v) => !v)} className={btn}>
          <Layers className="h-5 w-5" aria-hidden="true" />
          {showRecords ? 'Hide documented records' : 'Show documented records'}
        </button>
      </div>

      <div
        ref={boxRef}
        role="application"
        tabIndex={0}
        aria-label={`Interactive map of documented ${taxonName} records. Drag to move, use the arrow keys to pan and plus or minus to zoom.`}
        onKeyDown={onKey}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onDoubleClick={(e) => {
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          zoomBy(1, { x: e.clientX - r.left, y: e.clientY - r.top });
        }}
        className="relative w-full cursor-grab touch-none select-none overflow-hidden rounded-lg border-2 border-[hsl(var(--charcoal))]/60 bg-[hsl(205_30%_86%)] active:cursor-grabbing"
        style={{ height: 'clamp(300px, 55vh, 520px)' }}
      >
        {tiles.map((t) => (
          <img
            key={`b-${base}-${t.key}`}
            src={BASES[base].url(view.zoom, t.wx, t.y)}
            alt=""
            draggable={false}
            className="pointer-events-none absolute"
            style={{ left: t.left, top: t.top, width: TILE, height: TILE }}
          />
        ))}
        {showRecords &&
          tiles.map((t) => (
            <img
              key={`o-${taxonKey}-${t.key}`}
              src={`https://api.gbif.org/v2/map/occurrence/density/${view.zoom}/${t.wx}/${t.y}@1x.png?taxonKey=${taxonKey}&bin=hex&hexPerTile=26&style=classic.poly`}
              alt=""
              draggable={false}
              onError={(e) => ((e.currentTarget as HTMLImageElement).style.visibility = 'hidden')}
              className="pointer-events-none absolute opacity-90"
              style={{ left: t.left, top: t.top, width: TILE, height: TILE }}
            />
          ))}

        <div className="absolute right-3 top-3 flex flex-col gap-2" onPointerDown={(e) => e.stopPropagation()}>
          <button type="button" className={btn} onClick={() => zoomBy(1)} disabled={view.zoom >= MAX_Z} aria-label="Zoom in">
            <Plus className="h-6 w-6" aria-hidden="true" />
          </button>
          <button type="button" className={btn} onClick={() => zoomBy(-1)} disabled={view.zoom <= MIN_Z} aria-label="Zoom out">
            <Minus className="h-6 w-6" aria-hidden="true" />
          </button>
          <button type="button" className={btn} onClick={() => setView(start)} aria-label="Reset view">
            <RotateCcw className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
        <div className="absolute bottom-3 left-3 grid grid-cols-3 gap-1" onPointerDown={(e) => e.stopPropagation()}>
          <span />
          <button type="button" className={btn} onClick={() => pan(0, -150)} aria-label="Move map up"><ArrowUp className="h-5 w-5" aria-hidden="true" /></button>
          <span />
          <button type="button" className={btn} onClick={() => pan(-150, 0)} aria-label="Move map left"><ArrowLeft className="h-5 w-5" aria-hidden="true" /></button>
          <button type="button" className={btn} onClick={() => pan(0, 150)} aria-label="Move map down"><ArrowDown className="h-5 w-5" aria-hidden="true" /></button>
          <button type="button" className={btn} onClick={() => pan(150, 0)} aria-label="Move map right"><ArrowRight className="h-5 w-5" aria-hidden="true" /></button>
        </div>
        <p className="absolute bottom-1 right-2 rounded bg-white/90 px-2 py-0.5 font-ui text-[0.95rem] text-black">
          Map © OpenStreetMap contributors, OpenMapTiles · Records: GBIF.org
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded-lg border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5">
          <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">How to read this map</p>
          <p className="mt-1 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
            Each coloured hexagon marks an area with at least one documented record; warmer colours mean more records. Records show where people
            have documented the plant — <strong>not</strong> its full range, and an empty area does <strong>not</strong> prove it is absent.
          </p>
        </div>
        <div className="rounded-lg border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5">
          <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">Conservation privacy</p>
          <p className="mt-1 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
            Records are grouped into hexagons and the map stops at regional zoom, so no individual locality is shown. Sensitive records are also
            generalised at source by the data publishers.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AtlasMap;
