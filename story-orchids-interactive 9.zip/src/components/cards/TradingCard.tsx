import React from 'react';
import { Lock } from 'lucide-react';
import type { CollectorCard } from '@/lib/content-types';
import { getMedia } from '@/lib/content';
import { PendingTag } from '@/components/site/Ornaments';

const classStyle: Record<string, { ring: string; label: string }> = {
  character: { ring: 'border-[hsl(var(--botanical))]/50', label: 'Character' },
  artifact: { ring: 'border-[hsl(var(--amber))]/60', label: 'Artifact' },
  orchid: { ring: 'border-[hsl(var(--burgundy))]/45', label: 'Orchid' },
};

const TradingCard: React.FC<{ card: CollectorCard; locked?: boolean; onReveal?: () => void }> = ({
  card,
  locked = false,
  onReveal,
}) => {
  const asset = getMedia(card.image);
  const style = classStyle[card.class] || classStyle.character;

  if (locked) {
    return (
      <button
        type="button"
        onClick={onReveal}
        className="print-sheet flex aspect-[3/4] w-full flex-col items-center justify-center gap-3 rounded-sm border border-dashed border-border bg-muted/40 p-6 text-center transition-colors hover:border-[hsl(var(--amber))] hover:bg-[hsl(var(--amber))]/5"
      >
        <Lock className="h-5 w-5 text-[hsl(var(--moss))]" aria-hidden="true" />
        <p className="font-label text-[0.6rem] uppercase text-[hsl(var(--moss))]">Undiscovered</p>
        <p className="text-xs leading-relaxed text-muted-foreground">
          Found while reading the Chronicles. Tap to reveal it anyway.
        </p>
      </button>
    );
  }

  return (
    <article
      className={`print-sheet paper flex h-full flex-col overflow-hidden rounded-sm border-2 ${style.ring} shadow-sm`}
    >
      <div className="flex items-center justify-between border-b border-border/60 px-3 py-2">
        <span className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">{style.label}</span>
        <span className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">
          {card.rarity} · Chronicle {card.chronicle}
        </span>
      </div>

      {asset ? (
        <img src={asset.src} alt={asset.alt} loading="lazy" className="aspect-[4/3] w-full object-cover" />
      ) : (
        <div className="flex aspect-[4/3] w-full items-center justify-center bg-muted/50">
          <PendingTag label="Art pending" />
        </div>
      )}

      <div className="flex flex-1 flex-col px-4 py-3">
        <h3 className="font-display text-xl font-semibold leading-tight text-[hsl(var(--charcoal))]">{card.name}</h3>
        {card.epithet && (
          <p className="mt-0.5 font-label text-[0.55rem] uppercase text-[hsl(var(--amber))]">{card.epithet}</p>
        )}

        <dl className="mt-3 space-y-1.5">
          {card.fields.map((field) => (
            <div key={field.label} className="grid grid-cols-[7.5rem_1fr] gap-2 border-b border-dotted border-border/70 pb-1">
              <dt className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">{field.label}</dt>
              <dd className="text-xs leading-snug text-[hsl(var(--ink))]">{field.value}</dd>
            </div>
          ))}
        </dl>

        {card.flavor && (
          <p className="mt-3 text-xs italic leading-relaxed text-muted-foreground">“{card.flavor}”</p>
        )}
        {card.pending && (
          <div className="mt-3">
            <PendingTag label="Data pending verification" />
          </div>
        )}
        <p className="mt-auto pt-3 font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">
          Five Cities Orchid Society · The Edith Bramble Chronicles
        </p>
      </div>
    </article>
  );
};

export default TradingCard;
