import React, { useEffect, useRef, useState } from 'react';
import { getMedia } from '@/lib/content';
import { HazelHand, LeafSenescence, RootTip, SporeSequence, SubtleTurnImage } from '@/components/story/StoryEffectsExtra';
import { PREFS_EVENT, isMotionReduced, loadPrefs } from '@/lib/reading-prefs';

/* ------------------------------------------------------------------
   Restrained, once-only story effects. Each one fires the first time it
   scrolls into view, then rests. Reduced-motion users get a still image.
------------------------------------------------------------------- */

/** True when the reader's Reading Settings (or, on "automatic", the
 *  operating system) ask for reduced motion. Updates live. */
export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState(() => {
    try {
      return isMotionReduced(loadPrefs());
    } catch {
      return false;
    }
  });
  useEffect(() => {
    const check = () => setReduced(isMotionReduced(loadPrefs()));
    check();
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    mq.addEventListener?.('change', check);
    window.addEventListener(PREFS_EVENT, check);
    return () => {
      mq.removeEventListener?.('change', check);
      window.removeEventListener(PREFS_EVENT, check);
    };
  }, []);
  return reduced;
}

export function useReveal<T extends HTMLElement>(threshold = 0.45): [React.RefObject<T>, boolean] {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [seen, threshold]);
  return [ref, seen];
}

/* ---------------- Frog easter egg ---------------- */

const FROG_KEY = 'eb-frogs-spotted';
const FROG_TOTAL = 5;

function readFrogs(): string[] {
  try {
    return JSON.parse(localStorage.getItem(FROG_KEY) || '[]');
  } catch {
    return [];
  }
}

export const FrogSvg: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 64 48" className={className} aria-hidden="true">
    <ellipse cx="32" cy="34" rx="20" ry="11" fill="hsl(96 30% 34%)" />
    <ellipse cx="32" cy="37" rx="13" ry="6" fill="hsl(80 30% 62%)" />
    <circle cx="21" cy="22" r="7" fill="hsl(96 30% 34%)" />
    <circle cx="43" cy="22" r="7" fill="hsl(96 30% 34%)" />
    <circle cx="21" cy="21" r="3.6" fill="hsl(42 60% 70%)" />
    <circle cx="43" cy="21" r="3.6" fill="hsl(42 60% 70%)" />
    <ellipse cx="21" cy="21" rx="1.1" ry="2.6" fill="hsl(30 20% 10%)" />
    <ellipse cx="43" cy="21" rx="1.1" ry="2.6" fill="hsl(30 20% 10%)" />
    <path d="M12 42c-4 1-7 3-8 5M52 42c4 1 7 3 8 5" stroke="hsl(96 30% 28%)" strokeWidth="3" strokeLinecap="round" />
    <path d="M26 30c4 2 8 2 12 0" stroke="hsl(96 30% 22%)" strokeWidth="1.2" fill="none" strokeLinecap="round" />
  </svg>
);

const FrogSpot: React.FC<{ id: string; hop?: boolean }> = ({ id, hop }) => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.8);
  const [found, setFound] = useState<string[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => setFound(readFrogs()), []);

  const onFind = () => {
    const next = found.includes(id) ? found : [...found, id];
    setFound(next);
    try {
      localStorage.setItem(FROG_KEY, JSON.stringify(next));
    } catch {
      /* storage may be unavailable */
    }
    setMsg(
      next.length >= FROG_TOTAL
        ? `All ${FROG_TOTAL} greenhouse frogs spotted. Edith would approve.`
        : `Greenhouse frog ${next.length} of ${FROG_TOTAL} spotted.`,
    );
    window.setTimeout(() => setMsg(null), 3200);
  };

  const hopping = hop && seen && !reduced;

  return (
    <div ref={ref} className="no-print relative clear-both my-2 flex h-10 justify-end" aria-live="polite">
      <button
        type="button"
        onClick={onFind}
        aria-label="A small greenhouse frog. Tap to count it."
        className={`relative z-20 h-9 w-12 opacity-80 transition-opacity hover:opacity-100 focus-visible:opacity-100 ${
          hopping ? 'frog-hop' : seen && !reduced ? 'frog-blink' : ''
        }`}
      >
        <FrogSvg className="h-full w-full drop-shadow-sm" />
      </button>
      {msg && (
        <span className="absolute right-14 top-1.5 rounded-sm bg-[hsl(var(--charcoal))] px-3 py-1 font-label text-[0.55rem] uppercase text-[hsl(var(--cream))]">
          {msg}
        </span>
      )}
    </div>
  );
};

/* ---------------- Glass that fogs and says HELP ---------------- */

const FogHelp: React.FC<{ bgId?: string }> = ({ bgId }) => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.6);
  const bg = getMedia(bgId) || getMedia('c2-perfect');
  const bgStyle = bg ? { backgroundImage: `url(${bg.src})` } : undefined;
  return (
    <div
      ref={ref}
      role="img"
      aria-label="Greenhouse glass fogging with condensation. For a moment the word HELP appears in the fog, then clouds over."
      className="relative clear-both my-10 aspect-[16/7] overflow-hidden rounded-sm border border-border/70 bg-cover bg-center"
      style={bgStyle}
    >
      <div className={`absolute inset-0 bg-[hsl(200_10%_88%)]/80 backdrop-blur-md ${seen && !reduced ? 'glass-fog-in' : ''}`} />
      <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent_0_24.6%,hsl(30_20%_20%/0.45)_24.6%_25%)]" />
      <span
        className={`absolute inset-0 flex items-center justify-center bg-cover bg-center bg-clip-text font-display text-[5rem] font-semibold tracking-[0.3em] text-transparent sm:text-[8rem] ${
          reduced ? 'opacity-25' : seen ? 'glass-help' : 'opacity-0'
        }`}
        style={{ ...bgStyle, WebkitBackgroundClip: 'text' }}
        aria-hidden="true"
      >
        HELP
      </span>
      <div className="absolute inset-x-0 bottom-0 h-1/3 bg-[linear-gradient(transparent,hsl(200_15%_92%/0.35))]" />
    </div>
  );
};

/* ---------------- Hazel's silhouette in moving fog ---------------- */

const HazelFog: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.6);
  return (
    <div
      ref={ref}
      role="img"
      aria-label="Fog rolling past the greenhouse glass at dusk. For a moment a tall figure stands in it, then is gone."
      className="relative clear-both my-10 aspect-[16/7] overflow-hidden rounded-sm border border-border/70 bg-[linear-gradient(180deg,hsl(210_12%_30%),hsl(210_10%_18%))]"
    >
      <svg
        viewBox="0 0 100 200"
        className={`absolute bottom-0 left-[58%] h-[88%] ${reduced ? 'opacity-30' : seen ? 'hazel-appear' : 'opacity-0'}`}
        aria-hidden="true"
      >
        <path
          d="M50 18c7 0 11 6 11 13s-4 12-11 12-11-5-11-12 4-13 11-13Zm-15 30c6-3 24-3 30 0 8 5 12 22 14 50 2 30 6 70 8 102H13c2-32 6-72 8-102 2-28 6-45 14-50Z"
          fill="hsl(210 15% 8%)"
        />
      </svg>
      <div className={`absolute inset-0 ${reduced ? '' : 'fog-layer-a'} bg-[radial-gradient(ellipse_at_30%_60%,hsl(210_15%_85%/0.55),transparent_60%)]`} />
      <div className={`absolute inset-0 ${reduced ? '' : 'fog-layer-b'} bg-[radial-gradient(ellipse_at_70%_40%,hsl(210_15%_80%/0.45),transparent_55%)]`} />
      <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent_0_19.7%,hsl(30_25%_12%/0.7)_19.7%_20%)]" />
      <div className="absolute inset-x-0 top-[38%] h-px bg-[hsl(30_25%_12%/0.7)]" />
    </div>
  );
};

/* ---------------- A Catasetum leaf falling across the text ---------------- */

const FallingLeaf: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(1);
  if (reduced) return null;
  return (
    <div ref={ref} className="no-print pointer-events-none relative z-30 h-0" aria-hidden="true">
      <svg viewBox="0 0 40 90" className={`absolute left-[62%] top-0 h-24 w-10 opacity-0 ${seen ? 'leaf-fall' : ''}`}>
        <path d="M20 2C8 20 4 50 20 88 36 50 32 20 20 2Z" fill="hsl(46 72% 56%)" />
        <path d="M20 6v80" stroke="hsl(40 55% 40%)" strokeWidth="1.2" />
        <path d="M20 30l-8-6M20 44l-9-6M20 58l-8-6M20 30l8-6M20 44l9-6M20 58l8-6" stroke="hsl(40 55% 44%)" strokeWidth="0.7" />
      </svg>
    </div>
  );
};

/* ---------------- Laelia anceps seasonal clock ---------------- */

const stages = ['Small spike', 'Longer spike', 'Buds', 'First flowers (this plant; timing varies by clone)'];
const months = ['Early October', 'Mid October', 'October 24', 'October 31'];

const LaeliaClock: React.FC<{ stage: number }> = ({ stage }) => {
  const [ref, seen] = useReveal<HTMLDivElement>(0.6);
  const s = Math.min(Math.max(stage, 1), 4);
  const lengths = [40, 90, 130, 150];
  const len = lengths[s - 1];
  return (
    <div
      ref={ref}
      className="clear-both my-10 flex items-center gap-5 rounded-sm border border-[hsl(var(--botanical))]/25 bg-[hsl(var(--botanical))]/[0.05] p-4 sm:p-5"
    >
      <svg viewBox="0 0 170 120" className="h-24 w-32 shrink-0 sm:h-28 sm:w-40" role="img" aria-label={`Laelia anceps spike: ${stages[s - 1]}`}>
        <ellipse cx="30" cy="100" rx="11" ry="16" fill="hsl(96 22% 42%)" />
        <path d="M30 86c-6-20-14-34-24-42" stroke="hsl(96 22% 36%)" strokeWidth="4" fill="none" strokeLinecap="round" />
        <path
          d="M30 86 C 50 30, 110 10, 160 40"
          stroke="hsl(96 30% 38%)"
          strokeWidth="2.2"
          fill="none"
          strokeLinecap="round"
          pathLength={150}
          strokeDasharray="150"
          strokeDashoffset={seen ? 150 - len : 150}
          style={{ transition: 'stroke-dashoffset 2.6s ease-out' }}
        />
        {s >= 3 && (
          <g className={seen ? 'bud-in' : 'opacity-0'}>
            <ellipse cx="140" cy="29" rx="4" ry="6" fill="hsl(330 30% 60%)" />
            <ellipse cx="152" cy="34" rx="3.5" ry="5.5" fill="hsl(330 30% 64%)" />
          </g>
        )}
        {s === 4 && (
          <g className={seen ? 'bud-in' : 'opacity-0'}>
            {[0, 72, 144, 216, 288].map((r) => (
              <ellipse key={r} cx="148" cy="22" rx="4.5" ry="12" fill="hsl(318 45% 62%)" transform={`rotate(${r} 148 34)`} />
            ))}
            <circle cx="148" cy="34" r="5" fill="hsl(300 45% 32%)" />
          </g>
        )}
      </svg>
      <div>
        <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">The Laelia clock · {months[s - 1]}</p>
        <p className="mt-1 font-display text-xl text-[hsl(var(--charcoal))]">{stages[s - 1]}</p>
        <ol className="mt-2 flex gap-1.5" aria-hidden="true">
          {stages.map((_, i) => (
            <li key={i} className={`h-1.5 w-8 rounded-full ${i < s ? 'bg-[hsl(var(--botanical))]' : 'bg-border'}`} />
          ))}
        </ol>
      </div>
    </div>
  );
};

/* ---------------- Dispatcher ---------------- */

const StoryEffect: React.FC<{ name: string; id?: string; stage?: number }> = ({ name, id, stage }) => {
  switch (name) {
    case 'frog':
      return <FrogSpot id={id || 'frog'} />;
    case 'frog-hop':
      return <FrogSpot id={id || 'frog-hop'} hop />;
    case 'fog-help':
      return <FogHelp bgId={id} />;
    case 'hazel-fog':
      return <HazelFog />;
    case 'hazel-hand':
      return <HazelHand />;
    case 'spore-sequence':
      return <SporeSequence />;
    case 'leaf-senescence':
      return <LeafSenescence />;
    case 'root-tip':
      return <RootTip />;
    case 'falling-leaf':
      return <FallingLeaf />;
    case 'laelia-clock':
      return <LaeliaClock stage={stage || 1} />;
    default:
      return null;
  }
};

export default StoryEffect;

/* ---------------- Image effects (turn / breakout / stanhopea) ---------------- */

export const EffectImage: React.FC<{
  src: string;
  alt: string;
  effect?: string;
  className: string;
}> = ({ src, alt, effect, className }) => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.5);
  const active = seen && !reduced;

  if (effect === 'turn-subtle') {
    return <SubtleTurnImage src={src} alt={alt} className={className} />;
  }

  if (effect === 'turn') {
    return (
      <div ref={ref} className="[perspective:1200px]">
        <img
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          className={`${className} ${active ? 'orchid-turn' : ''}`}
          style={{ transformOrigin: '55% 50%' }}
        />
      </div>
    );
  }

  if (effect === 'breakout') {
    return (
      <div ref={ref} className="relative">
        <img src={src} alt={alt} loading="lazy" decoding="async" className={className} />
        <div
          aria-hidden="true"
          className={`pointer-events-none absolute -bottom-10 -right-4 h-32 w-3/5 rounded-full bg-[radial-gradient(ellipse,hsl(210_15%_88%/0.85),transparent_70%)] blur-md sm:-right-10 ${
            active ? 'fog-spill' : 'opacity-60'
          }`}
        />
      </div>
    );
  }

  if (effect === 'stanhopea') {
    return (
      <div ref={ref} className="relative">
        <img src={src} alt={alt} loading="lazy" decoding="async" className={className} />
        <svg
          viewBox="0 0 40 120"
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-24 left-1/2 h-28 w-10 -translate-x-1/2"
        >
          <path
            d="M20 0 C 22 30, 16 60, 20 110"
            stroke="hsl(80 30% 45%)"
            strokeWidth="2.4"
            fill="none"
            strokeLinecap="round"
            pathLength={100}
            strokeDasharray="100"
            strokeDashoffset={active || reduced ? 0 : 100}
            style={{ transition: 'stroke-dashoffset 4s ease-out' }}
          />
          {[60, 80, 100].map((y, i) => (
            <ellipse
              key={y}
              cx={i % 2 ? 24 : 16}
              cy={y}
              rx="4"
              ry="6"
              fill="hsl(48 55% 62%)"
              className={active || reduced ? 'bud-in' : 'opacity-0'}
              style={{ animationDelay: `${2.4 + i * 0.5}s` }}
            />
          ))}
        </svg>
      </div>
    );
  }

  return <img src={src} alt={alt} loading="lazy" decoding="async" className={className} />;
};
