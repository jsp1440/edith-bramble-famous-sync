import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { X, ArrowRight } from 'lucide-react';
import { getDiscovery, getMedia } from '@/lib/content';
import { PendingTag } from '@/components/site/Ornaments';

interface Props {
  discoveryId: string | null;
  onClose: () => void;
}

const DiscoveryDrawer: React.FC<Props> = ({ discoveryId, onClose }) => {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (discoveryId) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [discoveryId, onClose]);

  if (!discoveryId) return null;
  const discovery = getDiscovery(discoveryId);
  if (!discovery) return null;
  const asset = getMedia(discovery.image);

  return (
    <div className="no-print fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label={discovery.title}>
      <button
        type="button"
        aria-label="Close discovery"
        onClick={onClose}
        className="absolute inset-0 bg-[hsl(var(--charcoal))]/45 backdrop-blur-[2px]"
      />
      <aside className="relative flex h-full w-full max-w-md flex-col overflow-y-auto border-l border-border bg-[hsl(var(--cream))] shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-border/70 px-6 py-5">
          <div>
            <p className="font-label text-[0.6rem] uppercase text-[hsl(var(--amber))]">{discovery.eyebrow}</p>
            <h2 className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{discovery.title}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-sm border border-border p-1.5 text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10"
            aria-label="Close"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {asset && (
          <img
            src={asset.src}
            alt={asset.alt}
            loading="lazy"
            className="h-52 w-full border-b border-border/70 object-cover"
          />
        )}

        <div className="space-y-4 px-6 py-6">
          {discovery.body.map((paragraph, i) => (
            <p key={i} className="text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">
              {paragraph}
            </p>
          ))}

          {discovery.pending && <PendingTag label={discovery.pending} />}

          {discovery.links && discovery.links.length > 0 && (
            <ul className="space-y-2 pt-2">
              {discovery.links.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    onClick={onClose}
                    className="group flex items-center justify-between gap-3 rounded-sm border border-border bg-background px-4 py-3 text-sm text-[hsl(var(--ink))] transition-colors hover:border-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))]/6"
                  >
                    <span>{link.label}</span>
                    <ArrowRight className="h-4 w-4 shrink-0 text-[hsl(var(--moss))] transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>

        <p className="mt-auto border-t border-border/70 px-6 py-4 text-xs italic text-muted-foreground">
          Discoveries are optional. Close this and the story continues where you left it.
        </p>
      </aside>
    </div>
  );
};

export default DiscoveryDrawer;
