import React from 'react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog';
import { getGrowerCard, getMedia } from '@/lib/content';
import type { GrowerCard } from '@/lib/content-types';

export const TruthLabel: React.FC<{ label: 'observed' | 'fiction' }> = ({ label }) => (
  <span
    className={`inline-flex items-center gap-1.5 rounded-sm px-2 py-0.5 font-label text-[0.52rem] uppercase ${
      label === 'observed'
        ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
        : 'bg-[hsl(var(--amber))]/90 text-[hsl(30_35%_18%)]'
    }`}
  >
    {label === 'observed' ? 'Observed biology' : 'Fictional extension'}
  </span>
);

export const GrowerCardBody: React.FC<{ card: GrowerCard; compact?: boolean }> = ({ card, compact }) => {
  const img = getMedia(card.image);
  return (
    <div>
      {img && (
        <img
          src={img.src}
          alt={img.alt}
          loading="lazy"
          className={`w-full rounded-sm border border-border/70 object-cover ${compact ? 'aspect-[16/9]' : 'aspect-square'}`}
        />
      )}
      {img?.credit && (
        <p className="mt-1 font-label text-[0.5rem] uppercase text-muted-foreground">{img.credit}</p>
      )}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <TruthLabel label={card.label} />
        <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">{card.group}</span>
      </div>
      <p className="mt-3 text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">{card.summary}</p>
      <ul className="mt-3 space-y-1.5">
        {card.points.map((p) => (
          <li key={p} className="flex gap-2 text-sm leading-relaxed text-[hsl(var(--ink))]">
            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--botanical))]" aria-hidden="true" />
            {p}
          </li>
        ))}
      </ul>
      {card.caution && (
        <p className="mt-3 rounded-sm border-l-4 border-[hsl(var(--burgundy))]/50 bg-[hsl(var(--burgundy))]/5 px-3 py-2 text-sm text-[hsl(var(--ink))]">
          {card.caution}
        </p>
      )}
      {card.story && (
        <p className="mt-3 rounded-sm border-l-4 border-[hsl(var(--amber))]/60 bg-[hsl(var(--amber))]/8 px-3 py-2 text-sm italic text-[hsl(var(--ink))]">
          In the story — {card.story}
        </p>
      )}
    </div>
  );
};

const GrowerCardDialog: React.FC<{ cardId: string | null; onClose: () => void }> = ({ cardId, onClose }) => {
  const card = getGrowerCard(cardId);
  return (
    <Dialog open={!!card} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-h-[88vh] max-w-lg overflow-y-auto bg-[hsl(var(--cream))]">
        {card && (
          <>
            <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Grower Card · {card.taxon}</p>
            <DialogTitle className="font-display text-2xl font-semibold leading-tight text-[hsl(var(--charcoal))]">
              {card.title}
            </DialogTitle>
            <DialogDescription className="sr-only">{card.summary}</DialogDescription>
            <GrowerCardBody card={card} compact />
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-border/70 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
              >
                Back to the story
              </button>
              <Link
                to={`/grow#${card.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-label text-[0.55rem] uppercase text-[hsl(var(--botanical))] underline underline-offset-4"
              >
                Open in the culture library (new tab)
              </Link>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default GrowerCardDialog;
