import React, { useState } from 'react';
import { Check } from 'lucide-react';
import { chronicleOneClues } from '@/lib/content';
import { TruthLabel } from '@/components/story/GrowerCardDialog';

/** Tap the three real prevention clues; then Hazel's curse is revealed as fiction. */
const ChronicleOneClues: React.FC = () => {
  const [found, setFound] = useState<string[]>([]);
  const all = found.length === chronicleOneClues.length;

  return (
    <div className="rounded-sm border border-border/80 bg-background p-5 sm:p-7">
      <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Science Behind Chronicle I · tap the three real clues</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {chronicleOneClues.map((c) => {
          const on = found.includes(c.id);
          return (
            <button
              key={c.id}
              type="button"
              aria-pressed={on}
              onClick={() => setFound((f) => (f.includes(c.id) ? f : [...f, c.id]))}
              className={`rounded-sm border p-4 text-left transition-colors ${
                on ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))]/8' : 'border-border hover:border-[hsl(var(--botanical))]/60'
              }`}
            >
              <span className="flex items-center gap-2 font-display text-xl font-semibold text-[hsl(var(--charcoal))]">
                {on && <Check className="h-4 w-4 text-[hsl(var(--botanical))]" aria-hidden="true" />}
                {c.label}
              </span>
              {on ? (
                <span className="mt-2 block text-sm leading-relaxed text-[hsl(var(--ink))]">{c.body}</span>
              ) : (
                <span className="mt-2 block font-label text-[0.5rem] uppercase text-muted-foreground">Tap to reveal</span>
              )}
            </button>
          );
        })}
      </div>
      <div
        aria-live="polite"
        className={`mt-5 rounded-sm border-l-4 px-4 py-3 transition-opacity ${
          all ? 'border-[hsl(var(--amber))] bg-[hsl(var(--amber))]/10 opacity-100' : 'border-transparent opacity-0'
        }`}
      >
        {all && (
          <>
            <TruthLabel label="fiction" />
            <p className="mt-2 font-display text-2xl italic text-[hsl(var(--burgundy))]">Hazel's curse: fictional.</p>
            <p className="mt-1 text-sm leading-relaxed text-[hsl(var(--ink))]">
              Prolonged leaf wetness, cool and wet conditions, contaminated tools or splashing water, poor sanitation and
              too little drying can all contribute to destructive orchid disease. The supernatural curse and the instant
              greenhouse-wide spread are fiction. The grimoire's cinnamon, soda and soap rhyme belongs to the story — it
              is not a validated, universal black-rot treatment. Suspected black rot calls for isolation, sanitation,
              correcting drying and airflow, and an appropriate disease-management plan.
            </p>
          </>
        )}
      </div>
    </div>
  );
};

export default ChronicleOneClues;
