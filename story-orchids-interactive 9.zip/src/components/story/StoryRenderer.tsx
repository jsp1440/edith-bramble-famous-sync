import React from 'react';
import type { StoryBlock } from '@/lib/content-types';
import { parseInline } from '@/lib/story-parser';
import { getMedia } from '@/lib/content';
import { Flourish, PendingTag } from '@/components/site/Ornaments';
import StoryEffect, { EffectImage } from '@/components/story/StoryEffects';

interface Props {
  blocks: StoryBlock[];
  onDiscover: (id: string) => void;
  onGrower?: (id: string) => void;
  /** Opens an optional science layer (orchid profile or concept) without leaving the story. */
  onScience?: (id: string) => void;
}

const InlineText: React.FC<{ text: string; onDiscover: (id: string) => void; onGrower?: (id: string) => void }> = ({
  text,
  onDiscover,
  onGrower,
}) => (
  <>
    {parseInline(text).map((token, i) => {
      if (token.type === 'strong') return <strong key={i}>{token.value}</strong>;
      if (token.type === 'em') return <em key={i}>{token.value}</em>;
      if (token.type === 'grower') {
        const label = token.italic ? <em>{token.value}</em> : token.value;
        if (!onGrower) return <React.Fragment key={i}>{label}</React.Fragment>;
        return (
          <button
            key={i}
            type="button"
            onClick={() => onGrower(token.id)}
            className="inline cursor-pointer rounded-[2px] text-[hsl(var(--botanical))] underline decoration-[hsl(var(--botanical))]/50 decoration-1 underline-offset-[5px] hover:decoration-[hsl(var(--botanical))]"
            aria-label={`Open Grower Card: ${token.value}`}
          >
            {label}
          </button>
        );
      }
      if (token.type === 'discovery') {
        return (
          <button
            key={i}
            type="button"
            onClick={() => onDiscover(token.id)}
            className="discovery-mark cursor-pointer rounded-[2px] font-medium text-[hsl(var(--botanical))] underline decoration-[hsl(var(--amber))] decoration-dotted underline-offset-4"
            aria-label={`Discover: ${token.value}`}
          >
            {token.value}
          </button>
        );
      }
      return <React.Fragment key={i}>{token.value}</React.Fragment>;
    })}
  </>
);

const StoryRenderer: React.FC<Props> = ({ blocks, onDiscover, onGrower, onScience }) => {
  let paragraphIndex = 0;

  return (
    <div className="story-prose">

      {blocks.map((block, index) => {
        switch (block.type) {
          case 'heading':
            return (
              <h2
                key={index}
                className="clear-both mb-6 mt-14 font-display text-2xl font-semibold tracking-tight text-[hsl(var(--charcoal))] sm:text-3xl"
              >
                {block.text}
              </h2>
            );

          case 'paragraph': {
            paragraphIndex += 1;
            const isOpening = paragraphIndex === 1;
            return (
              <p
                key={index}
                className={`mb-6 text-[hsl(var(--ink))] ${isOpening ? 'drop-cap' : ''}`}
              >
                <InlineText text={block.text} onDiscover={onDiscover} onGrower={onGrower} />
              </p>
            );
          }

          case 'quote':
            return (
              <blockquote
                key={index}
                className="clear-both my-10 border-l-2 border-[hsl(var(--amber))] pl-6 font-display text-xl italic leading-relaxed text-[hsl(var(--botanical))] sm:text-2xl"
              >
                <InlineText text={block.text} onDiscover={onDiscover} onGrower={onGrower} />
              </blockquote>
            );

          case 'verse':
            return (
              <figure
                key={index}
                className="verse-block clear-both my-12 rounded-sm border border-[hsl(var(--amber))]/40 bg-[hsl(var(--amber))]/[0.07] px-6 py-8 text-center"
              >
                {block.title && (
                  <figcaption className="mb-4 font-label text-[0.55rem] uppercase tracking-[0.18em] text-[hsl(var(--moss))]">
                    {block.title} · from the tale
                  </figcaption>
                )}
                <p className="font-display text-xl italic leading-[2] text-[hsl(var(--charcoal))] sm:text-2xl">
                  {block.lines.map((l, li) => (
                    <React.Fragment key={li}>
                      {l}
                      {li < block.lines.length - 1 && <br />}
                    </React.Fragment>
                  ))}
                </p>
              </figure>
            );

          case 'note':
            return (
              <figure
                key={index}
                className="paper-aged clear-both mx-auto my-8 max-w-md -rotate-[0.6deg] rounded-sm border border-[hsl(30_25%_60%)]/50 px-6 py-5 shadow-[0_6px_18px_-10px_hsl(30_30%_20%/0.5)]"
              >
                {block.title && (
                  <figcaption className="mb-2 font-label text-[0.5rem] uppercase tracking-[0.18em] text-[hsl(var(--moss))]">
                    {block.title}
                  </figcaption>
                )}
                <p className="font-ui text-[0.95rem] font-medium uppercase leading-[1.9] tracking-wide text-[hsl(var(--ink))]">
                  {block.lines.map((l, li) => (
                    <React.Fragment key={li}>
                      {l}
                      {li < block.lines.length - 1 && <br />}
                    </React.Fragment>
                  ))}
                </p>
              </figure>
            );

          case 'effect':
            return <StoryEffect key={index} name={block.name} id={block.id} stage={block.stage} />;

          case 'divider':
            return <Flourish key={index} className="clear-both my-12" />;

          case 'image': {
            const asset = getMedia(block.id);
            if (!asset) {
              return (
                <div key={index} className="clear-both my-10 flex justify-center rounded-sm border border-dashed border-border bg-muted/40 p-10">
                  <PendingTag label="Illustration pending" />
                </div>
              );
            }
            if (block.layout === 'wrap-right' || block.layout === 'wrap-left') {
              const side = block.layout === 'wrap-right' ? 'md:float-right md:ml-8' : 'md:float-left md:mr-8';
              return (
                <figure
                  key={index}
                  className={`my-6 w-full md:w-[46%] ${side} ${block.effect === 'stanhopea' ? 'mb-28' : ''}`}
                >
                  <EffectImage
                    src={asset.src}
                    alt={asset.alt}
                    effect={block.effect}
                    className="w-full rounded-sm border border-border/70 object-cover shadow-sm"
                  />
                  {block.caption && (
                    <figcaption className="mt-2 font-label text-[0.6rem] uppercase leading-relaxed text-muted-foreground">
                      {block.caption}
                    </figcaption>
                  )}
                </figure>
              );
            }
            return (
              <figure key={index} className="clear-both my-12 -mx-4 sm:mx-0">
                <EffectImage
                  src={asset.src}
                  alt={asset.alt}
                  effect={block.effect}
                  className="max-h-[70vh] w-full rounded-none border-y border-border/70 object-cover sm:rounded-sm sm:border"
                />
                {block.caption && (
                  <figcaption className="mt-3 px-4 text-center font-label text-[0.6rem] uppercase leading-relaxed text-muted-foreground sm:px-0">
                    {block.caption}
                  </figcaption>
                )}
              </figure>
            );
          }


          case 'audio':
            return (
              <div key={index} className="clear-both my-10 rounded-sm border border-dashed border-border bg-muted/40 p-6 text-center">
                <PendingTag label="Narration slot — recording pending" />
              </div>
            );

          case 'science':
            if (!onScience) return null;
            return (
              <p key={index} className="no-print -mt-3 mb-6 text-right">
                <button
                  type="button"
                  onClick={() => onScience(block.id)}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-sm border border-[hsl(var(--botanical))]/30 bg-[hsl(var(--botanical))]/[0.05] px-3 py-1.5 font-label text-[0.55rem] uppercase tracking-wide text-[hsl(var(--botanical))] transition-colors hover:bg-[hsl(var(--botanical))]/10"
                >
                  {block.label || 'Why does this orchid do that?'}
                  <span aria-hidden="true">→</span>
                </button>
              </p>
            );

          case 'pending':
            return (
              <section
                key={index}
                className="clear-both my-14 rounded-sm border border-dashed border-[hsl(var(--moss))]/50 bg-[hsl(var(--moss))]/5 px-6 py-8 text-center"
              >
                <PendingTag />
                <h3 className="mt-3 font-display text-xl text-[hsl(var(--charcoal))]">{block.title}</h3>
                <p className="mx-auto mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">{block.text}</p>
              </section>
            );

          case 'closing':
            return (
              <div key={index} className="clear-both my-16 text-center">
                <Flourish className="mb-6" />
                <p className="font-display text-2xl italic text-[hsl(var(--botanical))]">{block.text}</p>
              </div>
            );

          default:
            return null;
        }
      })}
    </div>
  );
};

export default StoryRenderer;
