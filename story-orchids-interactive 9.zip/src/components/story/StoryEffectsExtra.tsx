import React, { useEffect, useMemo, useState } from 'react';
import { getMedia } from '@/lib/content';
import { useReducedMotion, useReveal } from '@/components/story/StoryEffects';

/* ------------------------------------------------------------------
   Phase-2 story effects. Each plays once when scrolled into view,
   never blocks scrolling (pointer-events: none on overlays), and has a
   still-state alternative for reduced-motion readers.
------------------------------------------------------------------- */

const EXTRA_CSS = `
@keyframes eb-spore {
  0% { transform: translate(0,0) scale(.6); opacity: 0; }
  15% { opacity: .9; }
  100% { transform: translate(var(--dx), var(--dy)) scale(var(--s)); opacity: 0; }
}
@keyframes eb-hand {
  0%, 100% { opacity: 0; transform: scale(.96); }
  30%, 62% { opacity: .85; transform: scale(1); }
}
@keyframes eb-ring {
  0% { opacity: 0; transform: scale(.6); }
  45% { opacity: .55; }
  100% { opacity: 0; transform: scale(1.35); }
}
`;

const ExtraStyles: React.FC = () => <style>{EXTRA_CSS}</style>;

/* ---------------- Chronicle I: Edith and the spores ---------------- */

const EMPTY_GREENHOUSE =
  'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790391971171_d2c21fcb.jpg';

type SporePhase = 0 | 1 | 2 | 3 | 4 | 5;

export const SporeSequence: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.55);
  const [phase, setPhase] = useState<SporePhase>(0);
  const before = getMedia('scene-spore-cloud');

  useEffect(() => {
    if (!seen || reduced) return;
    const t = [
      window.setTimeout(() => setPhase(1), 200), // a few particles at the infection
      window.setTimeout(() => setPhase(2), 1800), // they multiply and curl through the air
      window.setTimeout(() => setPhase(3), 3800), // the cloud surrounds her and becomes dominant
      window.setTimeout(() => setPhase(4), 6200), // it disperses
      window.setTimeout(() => setPhase(5), 8200), // she is gone
    ];
    return () => t.forEach((x) => window.clearTimeout(x));
  }, [seen, reduced]);

  const particles = useMemo(
    () =>
      Array.from({ length: 56 }, (_, i) => {
        const angle = (i * 137.5 * Math.PI) / 180;
        const dist = 60 + ((i * 53) % 260);
        return {
          left: 42 + ((i * 7) % 18),
          top: 58 + ((i * 11) % 22),
          dx: `${Math.cos(angle) * dist}px`,
          dy: `${Math.sin(angle) * dist * 0.6 - 60}px`,
          s: 1 + ((i * 3) % 5) * 0.5,
          size: 3 + (i % 5) * 2,
          delay: (i % 14) * 0.18,
          dur: 3.2 + (i % 6) * 0.5,
          wave: i < 10 ? 1 : 2,
        };
      }),
    [],
  );

  if (reduced) {
    return (
      <figure className="clear-both my-12 grid gap-3 sm:grid-cols-2">
        {before && <img src={before.src} alt={before.alt} loading="lazy" className="aspect-[16/10] w-full rounded-sm border border-border/70 object-cover" />}
        <img src={EMPTY_GREENHOUSE} alt="The greenhouse at dawn, empty. Edith's shears lie on the floor." loading="lazy" className="aspect-[16/10] w-full rounded-sm border border-border/70 object-cover" />
        <figcaption className="text-center font-label text-[0.6rem] uppercase text-muted-foreground sm:col-span-2">
          The cloud swirled around her — and then she was gone.
        </figcaption>
      </figure>
    );
  }

  return (
    <figure ref={ref} className="relative clear-both my-12 -mx-4 sm:mx-0" aria-label="Dark spores rise from the rot, surround Edith and disperse. When the air clears, the greenhouse is empty.">
      <ExtraStyles />
      <div className="relative aspect-[16/10] overflow-hidden rounded-none border-y border-border/70 bg-[hsl(30_12%_10%)] sm:rounded-sm sm:border">
        {before && (
          <img
            src={before.src}
            alt={before.alt}
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
            style={{ opacity: phase >= 4 ? 0 : 1, filter: phase >= 3 ? 'blur(2px) brightness(.55)' : 'none', transition: 'opacity 2s ease, filter 2s ease' }}
          />
        )}
        <img
          src={EMPTY_GREENHOUSE}
          alt="The greenhouse at dawn, empty. Edith's shears lie on the floor."
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ opacity: phase >= 4 ? 1 : 0, transition: 'opacity 2.4s ease' }}
        />
        {/* dominant cloud */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at 50% 60%, hsl(30 15% 6% / .95), hsl(120 10% 8% / .75) 45%, transparent 75%)',
            opacity: phase === 3 ? 1 : phase === 2 ? 0.35 : 0,
            transform: phase === 3 ? 'scale(1.15)' : 'scale(.7)',
            transition: 'opacity 1.8s ease, transform 2.4s ease',
          }}
        />
      </div>
      {/* particles cross the illustration boundary into the text plane */}
      <div aria-hidden="true" className="no-print pointer-events-none absolute inset-0 z-30 overflow-visible">
        {phase >= 1 &&
          phase <= 4 &&
          particles
            .filter((p) => (phase === 1 ? p.wave === 1 : true))
            .map((p, i) => (
              <span
                key={i}
                className="absolute rounded-full"
                style={
                  {
                    left: `${p.left}%`,
                    top: `${p.top}%`,
                    width: p.size,
                    height: p.size,
                    background: 'radial-gradient(circle, hsl(30 20% 8% / .9), hsl(90 12% 14% / 0))',
                    filter: 'blur(1px)',
                    animation: `eb-spore ${p.dur}s ease-out ${p.delay}s both`,
                    '--dx': p.dx,
                    '--dy': p.dy,
                    '--s': p.s,
                  } as React.CSSProperties
                }
              />
            ))}
      </div>
      <figcaption className="mt-3 px-4 text-center font-label text-[0.6rem] uppercase text-muted-foreground sm:px-0">
        {phase >= 5 ? 'And then the air was clear. The greenhouse was empty.' : 'The cloud swirled around her, and before she could scream, she vanished.'}
      </figcaption>
    </figure>
  );
};

/* ---------------- Hazel: a hand against the outside of the pane ---------------- */

export const HazelHand: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.7);
  const active = seen && !reduced;
  return (
    <div
      ref={ref}
      role="img"
      aria-label="Fogged greenhouse glass at night. For a moment a long-fingered hand presses against the outside of the pane, then is gone."
      className="relative clear-both my-10 aspect-[16/6] overflow-hidden rounded-sm border border-border/70 bg-[linear-gradient(180deg,hsl(210_14%_16%),hsl(200_12%_10%))]"
    >
      <ExtraStyles />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_40%_40%,hsl(40_30%_80%/0.18),transparent_60%)]" />
      <div className="absolute inset-0 backdrop-blur-[2px] bg-[hsl(200_10%_70%/0.12)]" />
      <svg
        viewBox="0 0 120 140"
        className="absolute left-[58%] top-[12%] h-[76%]"
        style={{ opacity: reduced ? 0.35 : 0, animation: active ? 'eb-hand 5.5s ease-in-out 0.6s both' : undefined }}
        aria-hidden="true"
      >
        <path
          d="M40 138c-6-20-10-38-8-56l-6-40c-1-6 7-8 9-2l7 32 2-50c0-7 9-7 9 0l1 48 5-54c1-7 10-6 9 1l-3 54 9-44c2-7 10-5 9 2l-8 48c10-8 20-12 24-8 3 3-12 16-20 30-8 14-10 26-14 39z"
          fill="hsl(200 20% 6% / .75)"
        />
      </svg>
      <span
        aria-hidden="true"
        className="absolute left-[56%] top-[20%] h-[60%] w-[18%] rounded-full border border-[hsl(200_20%_85%/0.3)]"
        style={{ opacity: 0, animation: active ? 'eb-ring 5.5s ease-out 1.2s both' : undefined }}
      />
      <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent_0_24.6%,hsl(30_25%_10%/0.7)_24.6%_25%)]" />
    </div>
  );
};

/* ---------------- Chronicle II: leaf senescence on a mature pseudobulb ---------------- */

export const LeafSenescence: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.7);
  const on = seen || reduced;
  const leafFill = on ? 'hsl(48 70% 58%)' : 'hsl(100 35% 38%)';
  return (
    <div ref={ref} className="clear-both my-8 flex items-center gap-4 rounded-sm border border-[hsl(var(--amber))]/30 bg-[hsl(var(--amber))]/[0.05] p-4">
      <svg viewBox="0 0 120 110" className="h-24 w-28 shrink-0" role="img" aria-label="A Catasetum pseudobulb with its leaves turning from green to yellow, one leaf detaching.">
        <ellipse cx="60" cy="80" rx="14" ry="24" fill="hsl(96 28% 40%)" />
        <path d="M60 58 C 40 40, 22 30, 8 30" stroke={leafFill} strokeWidth="9" strokeLinecap="round" fill="none" style={{ transition: reduced ? undefined : 'stroke 4s ease 0.4s' }} />
        <path d="M60 58 C 76 34, 96 22, 112 20" stroke={leafFill} strokeWidth="9" strokeLinecap="round" fill="none" style={{ transition: reduced ? undefined : 'stroke 4.6s ease 0.8s' }} />
        <path
          d="M60 60 C 70 48, 84 44, 100 48"
          stroke={leafFill}
          strokeWidth="8"
          strokeLinecap="round"
          fill="none"
          style={{
            transform: on && !reduced ? 'translate(8px, 38px) rotate(24deg)' : 'none',
            transformOrigin: '60px 60px',
            opacity: on && !reduced ? 0.7 : 1,
            transition: reduced ? undefined : 'stroke 3s ease 0.2s, transform 2.4s ease-in 5s, opacity 2.4s ease 5s',
          }}
        />
      </svg>
      <p className="text-sm leading-relaxed text-[hsl(var(--ink))]">
        <span className="block font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Seasonal signal · observed biology</span>
        Even yellowing on a completed growth, a plump bulb, and a leaf that lets go cleanly at the joint.
      </p>
    </div>
  );
};

/* ---------------- Chronicle II: an active root tip after watering ---------------- */

export const RootTip: React.FC = () => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.7);
  const on = seen || reduced;
  return (
    <div ref={ref} className="clear-both my-8 flex items-center gap-4 rounded-sm border border-[hsl(var(--botanical))]/25 bg-[hsl(var(--botanical))]/[0.04] p-4">
      <svg viewBox="0 0 140 70" className="h-16 w-32 shrink-0" role="img" aria-label="A root darkening as it takes up water, with a green growing tip extending.">
        <path d="M6 20 C 40 22, 70 40, 110 44" stroke={on ? 'hsl(110 25% 55%)' : 'hsl(40 15% 82%)'} strokeWidth="7" strokeLinecap="round" fill="none" style={{ transition: reduced ? undefined : 'stroke 2.5s ease' }} />
        <path
          d="M110 44 C 118 45, 126 48, 134 52"
          stroke="hsl(100 55% 42%)"
          strokeWidth="6"
          strokeLinecap="round"
          fill="none"
          pathLength={100}
          strokeDasharray="100"
          strokeDashoffset={on ? 0 : 100}
          style={{ transition: reduced ? undefined : 'stroke-dashoffset 4s ease-out 1.2s' }}
        />
      </svg>
      <p className="text-sm leading-relaxed text-[hsl(var(--ink))]">
        <span className="block font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Read the plant · roots</span>
        Silver roots turn green as the velamen fills with water; a green tip means the root is actively growing. Colour is one clue, not a watering rule — it depends on the orchid, its mix and its season.
      </p>
    </div>
  );
};

/* ---------------- Image effect: a flower that may have turned slightly ---------------- */

export const SubtleTurnImage: React.FC<{ src: string; alt: string; className: string }> = ({ src, alt, className }) => {
  const reduced = useReducedMotion();
  const [ref, seen] = useReveal<HTMLDivElement>(0.6);
  const active = seen && !reduced;
  return (
    <div ref={ref} className="[perspective:1400px]">
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        className={className}
        style={{
          transform: active ? 'rotateY(-4deg) rotateZ(0.5deg)' : 'none',
          transformOrigin: '60% 50%',
          transition: 'transform 7s cubic-bezier(.3,0,.2,1) 2s',
        }}
      />
    </div>
  );
};
