import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, ArrowRight } from 'lucide-react';
import { getModule, getMedia } from '@/lib/content';
import type { ModuleEntry } from '@/lib/content-types';
import { Flourish, Kicker, Notice, PendingTag } from '@/components/site/Ornaments';
import PrintButton from '@/components/site/PrintButton';

const layoutShell: Record<string, string> = {
  journal: 'paper-aged rule-line',
  grimoire: 'bg-[hsl(30_12%_15%)] text-[hsl(42_30%_92%)]',
  default: 'paper',
  gallery: 'paper',
};

const EntryCard: React.FC<{ entry: ModuleEntry; dark?: boolean }> = ({ entry, dark }) => {
  const [open, setOpen] = useState(false);
  const asset = getMedia(entry.image);

  return (
    <article
      id={entry.id}
      className={`scroll-mt-24 rounded-sm border p-6 sm:p-8 ${
        dark
          ? 'border-[hsl(var(--amber))]/25 bg-[hsl(30_10%_19%)]'
          : 'border-border/80 bg-[hsl(var(--cream))]'
      }`}
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          {entry.kind && <Kicker className={dark ? '!text-[hsl(var(--amber))]' : ''}>{entry.kind}</Kicker>}
          <h3
            className={`mt-1 font-display text-2xl font-semibold leading-tight ${
              dark ? 'text-[hsl(42_35%_90%)]' : 'text-[hsl(var(--charcoal))]'
            }`}
          >
            {entry.title}
          </h3>
        </div>
        {entry.status === 'pending' && <PendingTag />}
      </div>

      {entry.summary && (
        <p className={`mt-3 text-[0.95rem] italic ${dark ? 'text-[hsl(42_20%_78%)]' : 'text-muted-foreground'}`}>
          {entry.summary}
        </p>
      )}

      {asset && (
        <img
          src={asset.src}
          alt={asset.alt}
          loading="lazy"
          className="mt-5 w-full rounded-sm border border-border/60 object-cover"
        />
      )}

      {entry.meta && entry.meta.length > 0 && (
        <dl className="mt-4 flex flex-wrap gap-x-8 gap-y-2">
          {entry.meta.map((m) => (
            <div key={m.label}>
              <dt className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">{m.label}</dt>
              <dd className={`text-sm ${dark ? 'text-[hsl(42_25%_85%)]' : 'text-[hsl(var(--ink))]'}`}>{m.value}</dd>
            </div>
          ))}
        </dl>
      )}

      {entry.body && (
        <div className="mt-4 space-y-3">
          {entry.body.map((p, i) => (
            <p
              key={i}
              className={`text-[0.98rem] leading-relaxed ${dark ? 'text-[hsl(42_22%_84%)]' : 'text-[hsl(var(--ink))]'}`}
              dangerouslySetInnerHTML={{ __html: p.replace(/\*([^*]+)\*/g, '<em>$1</em>') }}
            />
          ))}
        </div>
      )}

      {entry.list?.map((block) => (
        <div key={block.title} className="mt-5">
          <p className="font-label text-[0.58rem] uppercase text-[hsl(var(--moss))]">{block.title}</p>
          <ul className="mt-2 space-y-1.5">
            {block.items.map((item) => (
              <li
                key={item}
                className={`flex gap-3 text-[0.95rem] leading-relaxed ${dark ? 'text-[hsl(42_22%_84%)]' : 'text-[hsl(var(--ink))]'}`}
              >
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--amber))]" aria-hidden="true" />
                {item}
              </li>
            ))}
          </ul>
        </div>
      ))}

      {entry.variants && (
        <ul className="mt-5 flex flex-wrap gap-2">
          {entry.variants.map((v) => (
            <li key={v} className="rounded-full border border-border px-3 py-1 font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">
              {v}
            </li>
          ))}
        </ul>
      )}

      {entry.practice && (
        <div className="mt-5 rounded-sm border-l-4 border-[hsl(var(--burgundy))]/50 bg-[hsl(var(--burgundy))]/5 px-4 py-3">
          <p className="font-label text-[0.58rem] uppercase text-[hsl(var(--burgundy))]">{entry.practice.title}</p>
          <p className="mt-1.5 text-sm leading-relaxed text-[hsl(var(--ink))]">{entry.practice.body}</p>
        </div>
      )}

      {entry.notes && (
        <div className="mt-5 rounded-sm bg-[hsl(var(--botanical))]/8 px-4 py-3">
          <p className="font-label text-[0.58rem] uppercase text-[hsl(var(--botanical))]">{entry.notes.label}</p>
          <p className="mt-1.5 text-sm italic leading-relaxed text-[hsl(var(--ink))]">{entry.notes.body}</p>
        </div>
      )}

      {entry.media && (
        <div className="mt-5 rounded-sm border border-dashed border-border bg-muted/40 px-4 py-6 text-center">
          {entry.media.src ? (
            entry.media.type === 'audio' ? (
              <audio controls preload="none" src={entry.media.src} className="w-full">
                Your browser does not support audio playback.
              </audio>
            ) : (
              <video controls preload="none" src={entry.media.src} className="w-full rounded-sm" />
            )
          ) : (
            <PendingTag label={`${entry.media.type === 'audio' ? 'Audio' : 'Video'} slot — recording pending`} />
          )}
        </div>
      )}

      {entry.goDeeper && (
        <div className="mt-5">
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            className="no-print flex w-full items-center justify-between gap-3 rounded-sm border border-border px-4 py-3 text-left font-label text-[0.58rem] uppercase text-[hsl(var(--botanical))] transition-colors hover:bg-[hsl(var(--botanical))]/8"
          >
            {entry.goDeeper.title}
            <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden="true" />
          </button>
          {open && (
            <div className="space-y-3 border-l-2 border-[hsl(var(--botanical))]/40 px-4 py-4">
              {entry.goDeeper.body.map((p, i) => (
                <p
                  key={i}
                  className="text-sm leading-relaxed text-[hsl(var(--ink))]"
                  dangerouslySetInnerHTML={{ __html: p.replace(/\*([^*]+)\*/g, '<em>$1</em>') }}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {(entry.links || entry.printable) && (
        <div className="mt-6 flex flex-wrap items-center gap-3">
          {entry.printable && <PrintButton label={entry.printable.label} />}
          {entry.links?.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="group inline-flex items-center gap-2 font-label text-[0.58rem] uppercase text-[hsl(var(--botanical))] hover:underline"
            >
              {link.label}
              <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
            </Link>
          ))}
        </div>
      )}
    </article>
  );
};

const ModulePage: React.FC<{ moduleId: string; children?: React.ReactNode }> = ({ moduleId, children }) => {
  const content = getModule(moduleId);

  if (!content) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <PendingTag label="Module content not found" />
      </div>
    );
  }

  const dark = content.layout === 'grimoire';
  const hero = getMedia(content.heroImage);

  return (
    <div className={dark ? 'bg-[hsl(30_12%_15%)]' : ''}>
      <section className={`relative overflow-hidden border-b border-border/70 ${layoutShell[content.layout || 'default']}`}>
        {hero && (
          <img
            src={hero.src}
            alt=""
            aria-hidden="true"
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover ${dark ? 'opacity-25 candle-flicker' : 'opacity-15'}`}
          />
        )}
        <div className="relative mx-auto max-w-4xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
          {content.kicker && (
            <Kicker className={dark ? '!text-[hsl(var(--amber))]' : ''}>{content.kicker}</Kicker>
          )}
          <h1
            className={`mt-3 font-display text-4xl font-semibold leading-tight sm:text-5xl ${
              dark ? 'text-[hsl(42_35%_92%)]' : 'text-[hsl(var(--charcoal))]'
            }`}
          >
            {content.title}
          </h1>
          {content.subtitle && (
            <p className={`mt-4 max-w-2xl text-lg ${dark ? 'text-[hsl(42_22%_82%)]' : 'text-muted-foreground'}`}>
              {content.subtitle}
            </p>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:px-8">
        {content.intro && (
          <div className="space-y-4">
            {content.intro.map((p, i) => (
              <p
                key={i}
                className={`text-[1.02rem] leading-relaxed ${dark ? 'text-[hsl(42_22%_84%)]' : 'text-[hsl(var(--ink))]'}`}
              >
                {p}
              </p>
            ))}
          </div>
        )}

        {content.notice && (
          <div className="mt-8">
            <Notice tone={content.notice.tone} title={content.notice.title} body={content.notice.body} />
          </div>
        )}

        {children}

        {content.entries && content.entries.length > 0 && (
          <>
            <Flourish className="my-12" />
            <div className="space-y-8">
              {content.entries.map((entry) => (
                <EntryCard key={entry.id} entry={entry} dark={dark} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default ModulePage;
