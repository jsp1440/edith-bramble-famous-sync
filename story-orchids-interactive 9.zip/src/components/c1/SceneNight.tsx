import React, { useEffect, useRef, useState } from 'react';
import { C1_IMAGES, scene, seg, type C1Manuscript } from './c1-data';
import { useInView, useScrollProgress } from './c1-hooks';
import { CreepingRoots, Drops, Fog, Frog, LanternGlow, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; reduced: boolean };

const HAND =
  'M40 200 C 36 170, 30 150, 32 128 C 22 118, 8 100, 4 84 C 2 76, 12 74, 16 82 L 30 104 C 28 80, 24 50, 24 30 C 24 20, 34 20, 35 30 L 40 88 C 40 60, 42 24, 44 10 C 45 0, 56 0, 56 10 L 56 86 C 58 60, 62 30, 66 18 C 68 8, 78 10, 77 20 L 70 90 C 76 70, 84 50, 90 42 C 95 34, 104 38, 100 48 L 84 110 C 82 130, 78 160, 76 200 Z';

/** The one flower that — perhaps — turns a few degrees toward the reader. No face, no eyes. */
const TurningFlower: React.FC<{ reduced: boolean }> = ({ reduced }) => {
  const [ref, inView] = useInView<HTMLDivElement>(0.8);
  const [turned, setTurned] = useState(false);
  useEffect(() => {
    if (!inView || reduced) return;
    const t = window.setTimeout(() => setTurned(true), 2600);
    return () => window.clearTimeout(t);
  }, [inView, reduced]);
  return (
    <div ref={ref} className="h-full w-full [perspective:900px]">
      <div
        className="h-full w-full"
        style={{
          transform: turned ? 'rotateY(-11deg) rotateZ(2.5deg) translateX(-2%)' : 'none',
          transition: 'transform 9s cubic-bezier(.45,0,.2,1)',
          transformOrigin: '50% 90%',
        }}
      >
        <Vignette img={C1_IMAGES.flower} shape="round" className="h-full w-full" />
      </div>
    </div>
  );
};

/* ---------------- Scene 1 — the night before Halloween ---------------- */

export const SceneWatering: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('c1-edith-watering');
  const erniePot = scene('ernie-pot');
  const drift = (k: number) => (reduced ? {} : { transform: `translateY(${(0.5 - p) * k}px)` });

  return (
    <section ref={ref} className="relative bg-[hsl(30_20%_5%)]" aria-label="Inside Edith's greenhouse">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <img
            src={bg.src}
            alt={bg.alt}
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover object-[64%_50%] ${reduced ? '' : 'c1-breathe'}`}
            style={{ filter: `brightness(${0.62 + seg(p, 0, 0.25) * 0.18}) saturate(0.9)` }}
          />
          {!reduced && <LanternGlow x="86%" y="66%" size="30vmax" strength={0.9} />}
          {/* droplets from the can, beside Edith */}
          <Drops count={5} falling className="left-[73%] w-[5%]" />
          <Drops count={8} />
          <Fog density={0.28} tint="30 30% 70%" />
          {/* shade only the left edge, where the text floats — Edith stays clear */}
          <div className="absolute inset-0 bg-[linear-gradient(90deg,hsl(30_25%_4%/0.78),hsl(30_25%_4%/0.25)_45%,transparent_62%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_60%_55%,transparent_50%,hsl(30_25%_4%/0.75)_100%)]" />
        </div>
      </div>

      <MoodZone mood="edith" className="relative z-10 pb-[16vh] pt-[46vh]">
        <StoryText text={m.p[2] || ''} onDiscover={onDiscover} align="left" className="md:max-w-[27em]" />

        {/* Selective close-ups drift along the LEFT margin only, so Edith is never covered */}
        <div className="relative mt-[16vh] h-[96vh] max-w-6xl" aria-label="Close-ups inside the greenhouse">
          <div className="absolute left-[3%] top-0 h-[24vh] w-[24vh] sm:h-[30vh] sm:w-[30vh]" style={drift(60)}>
            <Vignette img={C1_IMAGES.wetLeaf} shape="round" className="h-full w-full" />
          </div>
          <div className="absolute left-[24%] top-[22vh] hidden h-[30vh] w-[22vh] sm:block" style={drift(-40)}>
            <Vignette img={C1_IMAGES.roots} className="h-full w-full" />
          </div>
          <div className="absolute left-[6%] top-[42vh] h-[24vh] w-[24vh] sm:h-[30vh] sm:w-[30vh]" style={drift(80)}>
            <TurningFlower reduced={reduced} />
          </div>
          {/* Ernie, beside a clay pot — not pointed out */}
          <div className="absolute left-[30%] top-[70vh] h-[20vh] w-[20vh] sm:h-[24vh] sm:w-[24vh]" style={drift(-30)}>
            <Vignette img={erniePot} shape="round" className="h-full w-full" />
          </div>
        </div>
      </MoodZone>
    </section>
  );
};

/* ---------------- Hazel's hand on the glass ---------------- */

const HandOnGlass: React.FC<{ active: boolean; reduced: boolean }> = ({ active, reduced }) => {
  const [run, setRun] = useState(0);
  const was = useRef(false);
  useEffect(() => {
    if (active && !was.current) setRun((r) => r + 1);
    was.current = active;
  }, [active]);

  if (reduced) {
    return active ? (
      <svg viewBox="0 0 120 200" aria-hidden="true" className="absolute left-1/2 top-[22%] h-[42vh] -translate-x-1/2 opacity-60">
        <path d={HAND} fill="hsl(210 20% 6%)" />
      </svg>
    ) : null;
  }
  if (!run) return null;
  return (
    <div key={run} aria-hidden="true" className="c1-glass-flex absolute inset-0">
      <svg viewBox="-20 -20 160 240" className="c1-handprint absolute left-1/2 top-[18%] h-[46vh] -translate-x-1/2">
        {/* condensation pulled back around the fingers */}
        <path d={HAND} fill="none" stroke="hsl(210 25% 12% / 0.55)" strokeWidth="16" style={{ filter: 'blur(6px)' }} />
      </svg>
      <svg viewBox="-20 -20 160 240" className="c1-hand absolute left-1/2 top-[18%] h-[46vh] -translate-x-1/2">
        <path d={HAND} fill="hsl(210 20% 5%)" />
        <path d={HAND} fill="none" stroke="hsl(200 20% 80% / 0.25)" strokeWidth="1.2" />
      </svg>
    </div>
  );
};

/* ---------------- Scene 2 + 3 — something outside; Hazel ---------------- */

export const SceneOutside: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const glass = scene('c1-glass-night');
  const hazel = scene('scene-hazel-arrives');
  const warmth = 1 - seg(p, 0, 0.5);
  const shape = seg(p, 0.2, 0.45);
  const suggest = seg(p, 0.42, 0.6);
  const handOn = p > 0.56 && p < 0.9;
  const reveal = seg(p, 0.78, 0.95);

  return (
    <section ref={ref} className="relative h-[380vh] bg-[hsl(210_18%_6%)]" aria-label="Something outside the glass">
      <div className="absolute inset-0">
        <div
          className="sticky top-0 h-[100svh] overflow-hidden"
          role="img"
          aria-label="Inside the greenhouse, facing the fogged west glass at night. A dark shape passes outside; later a long-fingered hand presses against the outside of the pane, then slides away. At last Hazel Nightshade stands in the fog."
        >
          {/* the real greenhouse glass, cooling as warmth drains away */}
          <img
            src={glass.src}
            alt=""
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
            style={{ filter: `brightness(${0.85 - p * 0.25}) saturate(${0.9 - seg(p, 0, 0.5) * 0.5})` }}
          />
          {/* vague dark shape passing in the fog, beyond the glass */}
          <div
            aria-hidden="true"
            className="absolute top-[14%] h-[58%] w-[26%] rounded-[50%] bg-[hsl(210_25%_4%)] blur-3xl"
            style={{ left: `${-30 + shape * 120}%`, opacity: Math.sin(shape * Math.PI) * 0.75 }}
          />
          {/* the suggestion of Hazel */}
          <svg viewBox="0 0 100 200" aria-hidden="true" className="absolute bottom-[22%] left-[60%] h-[62%]" style={{ opacity: Math.sin(suggest * Math.PI) * 0.65, filter: 'blur(5px)' }}>
            <path d="M50 18c7 0 11 6 11 13s-4 12-11 12-11-5-11-12 4-13 11-13Zm-15 30c6-3 24-3 30 0 8 5 12 22 14 50 2 30 6 70 8 102H13c2-32 6-72 8-102 2-28 6-45 14-50Z" fill="hsl(210 20% 4%)" />
          </svg>
          <HandOnGlass active={handOn} reduced={reduced} />
          {/* condensation thickening on the inside */}
          <div className="absolute inset-0 bg-[hsl(205_12%_75%)]" style={{ opacity: seg(p, 0.3, 0.6) * 0.16 }} />
          <Drops count={10} />
          <Fog density={0.25 + p * 0.5} />
          {/* warm lantern light fading away */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_4%_60%,hsl(32_85%_50%/0.4),transparent_45%)]" style={{ opacity: warmth }} />
          <CreepingRoots progress={seg(p, 0.3, 0.9)} className="inset-x-0 bottom-0 h-[30%] w-full" color="hsl(210 10% 60%)" />
          {/* Ernie on the potting bench — he leaves before anything arrives */}
          <Frog className="left-[40%] top-[73%]" hidden={p > 0.36} size={40} />
          {/* Hazel, finally, through fog */}
          <img
            src={hazel.src}
            alt=""
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover ${reduced ? '' : 'c1-cloak'}`}
            style={{ opacity: reveal * 0.88, filter: `blur(${(1 - reveal) * 8}px) brightness(0.7)` }}
          />
        </div>
      </div>

      <MoodZone mood="outside" className="relative z-10">
        <div className="h-[55vh]" />
        <StoryText text={m.p[3] || ''} onDiscover={onDiscover} align="right" />
        <div className="h-[95vh]" />
        <StoryText text={m.p[4] || ''} onDiscover={onDiscover} align="left" />
        <div className="h-[150vh]" />
      </MoodZone>
    </section>
  );
};
