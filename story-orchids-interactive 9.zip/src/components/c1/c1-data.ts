import { getChronicle, getMedia, getStory } from '@/lib/content';
import type { StoryBlock } from '@/lib/content-types';

/* ------------------------------------------------------------------
   Chronicle I — Cinematic Edition: data layer.
   The manuscript text is NOT duplicated here. It is read from the single
   source (src/content/chronicles/chronicle-i.md) and handed to the scenes
   by paragraph index. Only new cinematic imagery is declared below.
------------------------------------------------------------------- */

export const C1_IMAGES = {
  edithMorning: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393225053_d922957b.jpg',
    alt: 'Edith Bramble, silver-haired in a moss-green cardigan, bends over a blackened orchid with pruning snips in the grey morning greenhouse, her watering can at her feet.',
  },
  emptyMorning: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393240085_89efd9de.jpg',
    alt: 'The same greenhouse aisle, empty. The watering can lies on its side on the brick floor beside a pair of snips.',
  },
  /** The SAME plate as `edithMorning` (same camera, same aisle) with Edith removed: tipped can, fallen shears, her notebook. */
  aftermath: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790404627848_fd5fc7e1.webp',
    alt: "The same aisle of Edith's greenhouse, seen from the same place, suddenly empty: her watering can lies tipped over in a small spill of water, her pruning shears lie open on the flagstones beside her notebook, and fine dark dust has settled on the floor.",
  },
  wetLeaf: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393255878_23d41357.jpg',
    alt: 'A glossy Cattleya leaf beaded with water, catching candlelight.',
  },
  roots: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393271777_486ba8b7.jpg',
    alt: 'Silvery orchid aerial roots with green growing tips hanging from a slat basket.',
  },
  flower: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393287550_d6a4cec3.jpg',
    alt: 'A pale Phalaenopsis flower emerging from darkness in candlelight.',
  },
  lesion: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393306257_8f819574.jpg',
    alt: 'A Cattleya pseudobulb with a spreading purplish-black, water-soaked lesion.',
  },
  lantern: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393321279_a5a4b7fb.jpg',
    alt: "A carved jack-o'-lantern glowing on Edith's scarred redwood bench.",
  },
  rottenRoots: {
    src: 'https://d64gsuwffb70l.cloudfront.net/6a86b1e2a25ecaf758848148_1790393337113_64544493.jpg',
    alt: 'Collapsed, blackened orchid roots in fir bark beside a few healthy silver-green roots.',
  },
} as const;

export type C1Image = { src: string; alt: string };

/** Existing Chronicle I scene art, looked up from media.json (single source). */
export function scene(id: string): C1Image {
  const m = getMedia(id);
  return { src: m?.src || '', alt: m?.alt || '' };
}

export interface C1Manuscript {
  /** Paragraphs in manuscript order (inline markers preserved). */
  p: string[];
  verses: { title?: string; lines: string[] }[];
  headings: string[];
  closing: string;
  epigraph?: string;
}

let cached: C1Manuscript | null = null;

export function getC1Manuscript(): C1Manuscript {
  if (cached) return cached;
  const story = getStory(getChronicle('chronicle-i'));
  const blocks: StoryBlock[] = story?.blocks || [];
  const out: C1Manuscript = { p: [], verses: [], headings: [], closing: '', epigraph: story?.frontmatter.epigraph };
  blocks.forEach((b) => {
    if (b.type === 'paragraph') out.p.push(b.text);
    else if (b.type === 'verse') out.verses.push({ title: b.title, lines: b.lines });
    else if (b.type === 'heading') out.headings.push(b.text);
    else if (b.type === 'closing') out.closing = b.text;
  });
  cached = out;
  return out;
}

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
/** Maps progress p from [a,b] onto [0,1]. */
export const seg = (p: number, a: number, b: number) => clamp((p - a) / (b - a));
