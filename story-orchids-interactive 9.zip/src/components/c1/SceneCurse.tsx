import React from 'react';
import { C1_IMAGES, scene, seg, type C1Manuscript } from './c1-data';
import { useScrollProgress } from './c1-hooks';
import { CreepingRoots, Fog, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; reduced: boolean };

/**
 * Scroll-linked: the reader's scrolling advances the curse. Each verse line
 * surfaces in turn while the greenhouse grows wetter, darker and colder.
 * (The spread is fiction; wet tissue, cold and still air are the real-world cues.)
 */
const SceneCurse: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('scene-curse');
  const verse = m.verses[0];
  const dark = seg(p, 0.05, 0.75);
  const lesion = seg(p, 0.2, 0.7);
  const rot = seg(p, 0.35, 0.8);

  return (
    <section ref={ref} className="relative h-[460vh] bg-[hsl(300_10%_4%)]" aria-label="The curse">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <img
            src={bg.src}
            alt={bg.alt}
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover ${reduced ? '' : 'c1-breathe'}`}
            style={{ filter: `brightness(${0.62 - dark * 0.35}) saturate(${0.9 - dark * 0.6}) hue-rotate(${-dark * 12}deg)` }}
          />
          {/* water crawling down the glass */}
          <svg aria-hidden="true" viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
            {[8, 19, 33, 47, 61, 74, 88].map((x, i) => (
              <path
                key={x}
                d={`M${x} 0 C ${x + 1.5} 20, ${x - 1.5} 40, ${x + 1} 60 S ${x - 1} 85, ${x} 100`}
                stroke="hsl(200 15% 75% / 0.28)"
                strokeWidth="0.35"
                fill="none"
                pathLength={100}
                strokeDasharray="100"
                strokeDashoffset={100 - Math.min(100, seg(p, 0.1 + i * 0.04, 0.6 + i * 0.03) * 100)}
              />
            ))}
          </svg>
          {/* condensation darkening */}
          <div className="absolute inset-0 bg-[hsl(290_15%_8%)]" style={{ opacity: dark * 0.45 }} />
          {/* shadows lengthening from the floor */}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[hsl(300_20%_3%)] to-transparent" style={{ height: `${25 + dark * 55}%` }} />
          <Fog density={0.2 + dark * 0.5} tint="280 8% 55%" />
          <CreepingRoots progress={rot} className="inset-x-0 bottom-0 h-[45%] w-full" color="hsl(300 20% 10%)" />

          {/* Close study: a lesion beginning at the base of a leaf */}
          <div className="absolute bottom-[6%] left-[3%] hidden h-[32vh] w-[32vh] sm:block lg:h-[38vh] lg:w-[38vh]" aria-hidden="true">
            <Vignette img={C1_IMAGES.wetLeaf} shape="round" className="absolute inset-0" style={{ opacity: 1 - seg(p, 0.5, 0.75) }} />
            <Vignette img={C1_IMAGES.lesion} shape="round" className="absolute inset-0" style={{ opacity: seg(p, 0.45, 0.75) }} />
            <div
              className="absolute left-[30%] top-[62%] h-1/2 w-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
              style={{
                transform: `translate(-50%,-50%) scale(${lesion * 1.4})`,
                opacity: 1 - seg(p, 0.6, 0.8),
                background: 'radial-gradient(circle, hsl(300 30% 5% / 0.95) 0 35%, hsl(45 55% 30% / 0.45) 50%, transparent 68%)',
              }}
            />
          </div>
          {/* the pumpkin deteriorating */}
          <div className="absolute bottom-[8%] right-[3%] hidden h-[26vh] w-[26vh] sm:block lg:h-[32vh] lg:w-[32vh]" aria-hidden="true">
            <Vignette
              img={C1_IMAGES.lantern}
              shape="round"
              className="h-full w-full"
              style={{
                filter: `saturate(${1 - rot * 0.8}) brightness(${1 - rot * 0.55}) sepia(${rot * 0.6})`,
                transform: `scaleY(${1 - rot * 0.1}) skewX(${rot * 3}deg)`,
                transformOrigin: '50% 100%',
              }}
            />
          </div>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_45%,transparent_30%,hsl(300_15%_3%/0.85)_100%)]" />
        </div>
      </div>

      <MoodZone mood="curse" className="relative z-10">
        <div className="sticky top-[14vh] isolate mx-auto max-w-2xl px-6 py-10 text-center" aria-live="off" style={{ opacity: 1 - seg(p, 0.64, 0.72) }}>
          <span aria-hidden="true" className="c1-wash c1-wash-night" style={{ opacity: seg(p, 0.04, 0.12) }} />
          {verse?.title && (
            <p className="font-label text-[0.58rem] uppercase text-[hsl(300_12%_78%)]" style={{ opacity: seg(p, 0.02, 0.08) }}>
              {verse.title} · whispered in the old tongue
            </p>
          )}
          <blockquote className="mt-5 font-display text-2xl font-medium italic leading-relaxed text-[hsl(42_36%_94%)] [text-shadow:0_2px_16px_hsl(300_30%_3%)] sm:text-3xl">
            {(verse?.lines || []).map((line, i) => {
              const v = reduced ? (p > 0.05 ? 1 : 0) : seg(p, 0.08 + i * 0.1, 0.16 + i * 0.1);
              return (
                <span key={i} className="block" style={{ opacity: v, filter: `blur(${(1 - v) * 6}px)`, transform: `translateY(${(1 - v) * 10}px)` }}>
                  {line}
                </span>
              );
            })}
          </blockquote>
        </div>
        <div className="h-[260vh]" />
        <StoryText text={m.p[5] || ''} onDiscover={onDiscover} />
        <div className="h-[60vh]" />
      </MoodZone>
    </section>
  );
};

export default SceneCurse;
