import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { scene, seg, type C1Manuscript } from './c1-data';
import { useScrollProgress } from './c1-hooks';
import { Drops, Fog, Frog, LanternGlow, Mullions, SceneHeading, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; onScience: (id: string) => void; reduced: boolean };

/* ---------------- Scene 9 — the charm ---------------- */

export const SceneCharm: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('greenhouse-interior');
  const charm = scene('artifact-talisman');
  const lift = seg(p, 0.45, 0.9);
  return (
    <section ref={ref} className="relative bg-[hsl(210_10%_14%)]" aria-label="The power of the charm">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <img
            src={bg.src}
            alt=""
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
            style={{ filter: `brightness(${0.4 + lift * 0.55}) saturate(${0.35 + lift * 0.6})` }}
          />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_80%,hsl(36_70%_55%/0.35),transparent_65%)]" style={{ opacity: lift }} />
          <Drops count={lift > 0.5 ? 6 : 0} />
          <Fog density={0.85 - lift * 0.7} />
          {/* the charm, hung at the door — a restrained glow as the air clears */}
          <div className="absolute left-1/2 top-0 flex -translate-x-1/2 flex-col items-center" aria-hidden="true">
            <div className={`${reduced ? '' : 'c1-pendulum'} relative flex flex-col items-center`}>
              <div className="h-[16vh] w-px bg-[hsl(30_30%_30%)]" />
              <div className="absolute top-[16vh] h-[24vh] w-[24vh] rounded-full bg-[radial-gradient(circle,hsl(42_80%_65%/0.45),transparent_65%)] blur-md sm:h-[28vh] sm:w-[28vh]" style={{ opacity: 0.2 + lift * 0.6 }} />
              <Vignette img={charm} shape="round" className="relative h-[20vh] w-[20vh] sm:h-[24vh] sm:w-[24vh]" />
            </div>
          </div>
        </div>
      </div>
      <MoodZone mood={p > 0.5 ? 'charm' : 'fcos'} className="relative z-10 pb-[40vh] pt-[50vh]">
        <SceneHeading>{m.headings[3]}</SceneHeading>
        <div className="h-[20vh]" />
        <StoryText text={m.p[14] || ''} onDiscover={onDiscover} align="left" />
        <div className="h-[30vh]" />
        <StoryText text={m.p[15] || ''} onDiscover={onDiscover} align="right" />
        <div className="h-[50vh]" />
        <StoryText text={m.p[16] || ''} onDiscover={onDiscover} />
        <p className="mx-auto mt-2 max-w-xl rounded-2xl bg-[hsl(30_14%_6%)]/70 px-5 py-3 text-center font-ui text-sm leading-relaxed text-[hsl(42_30%_92%)] backdrop-blur-sm [text-shadow:0_1px_6px_#000]">
          In the story, the charm is magic. Outside it, no object protects an orchid; what the charm stands for does: knowledge, community and shared experience.
        </p>
      </MoodZone>
    </section>
  );
};

/* ---------------- Scene 10 — the witch returns ---------------- */

export const SceneHazelReturns: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('greenhouse-interior');
  const hazel = scene('scene-witch-returns');
  const shadow = seg(p, 0.04, 0.2);
  const cold = seg(p, 0.15, 0.3);
  const reflect = seg(p, 0.24, 0.34) * (1 - seg(p, 0.36, 0.42));
  const reveal = seg(p, 0.38, 0.5);
  const dissolve = seg(p, 0.8, 0.95);
  const verse = m.verses[2];
  const radius = 70 - dissolve * 70;
  const mask = `radial-gradient(ellipse ${radius}% ${radius + 10}% at 50% 50%, #000 40%, transparent 100%)`;

  return (
    <section ref={ref} className="relative bg-[hsl(220_14%_6%)]" aria-label="The witch returns">
      <div className="absolute inset-0">
        <div
          className="sticky top-0 h-[100svh] overflow-hidden"
          role="img"
          aria-label="A shadow crosses the plants and the light turns cold. A frog slips behind a pot. A reflection appears in the glass where no one stands; then Hazel is there. At the end her edges blend into fog, her cloak becomes shadow, the shadow becomes mist, and the mist drifts out through the roof vents."
        >
          <img src={bg.src} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ filter: `brightness(${0.75 - cold * 0.4}) saturate(${0.8 - cold * 0.5})` }} />
          {/* a shadow passes across the plants */}
          <div className="absolute top-[25%] h-[65%] w-[35%] rounded-[45%] bg-black blur-3xl" style={{ left: `${-40 + shadow * 150}%`, opacity: Math.sin(shadow * Math.PI) * 0.7 }} />
          <div className="absolute inset-0 bg-[hsl(215_40%_20%)] mix-blend-multiply" style={{ opacity: cold * 0.55 }} />
          {/* a reflection where no one stands */}
          <div className="absolute right-[8%] top-[10%] h-[50%] w-[22%] overflow-hidden" style={{ opacity: reflect * 0.4 }}>
            <img src={hazel.src} alt="" className="h-full w-full scale-x-[-1] object-cover blur-[1.5px]" />
          </div>
          {/* Hazel, then her dissolution into fog */}
          <img
            src={hazel.src}
            alt=""
            loading="lazy"
            className={`absolute inset-0 h-full w-full object-cover ${reduced ? '' : 'c1-cloak'}`}
            style={{
              opacity: reveal * (1 - seg(p, 0.9, 0.97)),
              filter: `blur(${dissolve * 14}px) brightness(${0.85 - dissolve * 0.7}) contrast(${1 + dissolve * 0.6})`,
              WebkitMaskImage: mask,
              maskImage: mask,
            }}
          />
          {/* mist leaving through the vents */}
          {!reduced && dissolve > 0 && (
            <div
              aria-hidden="true"
              className="absolute left-1/2 top-1/2 h-[40vh] w-[40vh] rounded-full bg-[radial-gradient(circle,hsl(215_12%_70%/0.55),transparent_70%)] blur-xl"
              style={{ transform: `translate(${-50 + dissolve * 90}%, ${-50 - dissolve * 160}%) scale(${1 + dissolve})`, opacity: Math.sin(dissolve * Math.PI) }}
            />
          )}
          <Mullions opacity={0.35} />
          <Fog density={0.4 + dissolve * 0.3} />
          {/* Ernie, who slips away before she arrives */}
          <Frog className="bottom-[9%] left-[14%]" hidden={p > 0.2} size={42} />
        </div>
      </div>

      <MoodZone mood="hazel" className="relative z-10 pb-[50vh] pt-[45vh]">
        <SceneHeading>{m.headings[4]}</SceneHeading>
        <div className="h-[80vh]" />
        <StoryText text={m.p[17] || ''} onDiscover={onDiscover} align="left" />
        <div className="h-[20vh]" />
        <StoryText text={m.p[18] || ''} onDiscover={onDiscover} align="right" variant="quote" />
        <div className="h-[20vh]" />
        <StoryText text={m.p[19] || ''} onDiscover={onDiscover} align="left" />
        {verse && (
          <blockquote className="mx-auto my-[12vh] max-w-lg px-6 text-center font-display text-2xl italic leading-relaxed text-[hsl(42_30%_90%)] [text-shadow:0_2px_20px_#000] sm:text-3xl">
            <p className="mb-3 font-label text-[0.55rem] not-italic uppercase text-[hsl(215_15%_70%)]">{verse.title}</p>
            {verse.lines.map((l, i) => (
              <span key={i} className="block">
                {l}
              </span>
            ))}
          </blockquote>
        )}
        <StoryText text={m.p[20] || ''} onDiscover={onDiscover} align="right" />
        <div className="h-[70vh]" />
        <StoryText text={m.p[21] || ''} onDiscover={onDiscover} />
        <div className="h-[40vh]" />
      </MoodZone>
    </section>
  );
};

/* ---------------- Ending ---------------- */

export const SceneEnding: React.FC<Props> = ({ m, onDiscover, onScience, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('scene-charm-on-door');
  const settle = seg(p, 0.05, 0.6);
  return (
    <section ref={ref} className="relative bg-[hsl(215_18%_8%)]" aria-label="Ending">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <img src={bg.src} alt={bg.alt} loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ filter: `brightness(${0.35 + settle * 0.55}) saturate(${0.5 + settle * 0.5})` }} />
          <div className="absolute -right-[10%] -top-[10%] h-[60vmax] w-[60vmax] rounded-full bg-[radial-gradient(circle,hsl(210_40%_92%/0.35),transparent_60%)]" style={{ opacity: settle }} />
          {!reduced && <LanternGlow x="50%" y="55%" size="40vmax" strength={0.25 + settle * 0.3} />}
          <div className="absolute inset-0" style={{ transform: `translateY(${-settle * 30}%)` }}>
            <Fog density={0.75 - settle * 0.55} />
          </div>
          <Frog className="bottom-[10%] right-[14%]" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_50%,transparent_40%,hsl(215_20%_4%/0.8)_100%)]" />
        </div>
      </div>
      <MoodZone mood="ending" className="relative z-10 pb-[20vh] pt-[55vh]">
        <StoryText text={m.p[22] || ''} onDiscover={onDiscover} />
        <p className="no-print mx-auto -mt-2 max-w-xl rounded-2xl bg-[hsl(30_14%_6%)]/70 px-5 py-3 text-center font-ui text-sm leading-relaxed text-[hsl(42_30%_92%)] backdrop-blur-sm [text-shadow:0_1px_6px_#000]">
          Story and science part ways here. Good culture lowers the risk of rot; managing black rot itself means isolation, sanitation, removing infected tissue and proper treatment.{' '}
          <button type="button" onClick={() => onScience('black-rot')} className="underline underline-offset-4 hover:text-white">
            What black rot actually is →
          </button>
        </p>
        <div className="h-[25vh]" />
        <StoryText text={m.p[23] || ''} onDiscover={onDiscover} />
        <div className="h-[20vh]" />
        <StoryText text={m.p[24] || ''} onDiscover={onDiscover} />
        <div className="h-[30vh]" />
        <p className="mx-auto max-w-2xl px-6 text-center font-display text-4xl font-semibold italic text-[hsl(42_40%_94%)] [text-shadow:0_2px_30px_hsl(36_60%_40%/0.6)] sm:text-6xl">
          {m.closing || 'No grower is ever alone.'}
        </p>
        <div className="no-print mx-auto mt-16 flex max-w-3xl flex-wrap justify-center gap-3 px-6">
          <a
            href="#science-behind"
            className="inline-flex min-h-[46px] items-center gap-2 rounded-full bg-[hsl(36_55%_62%)] px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(30_20%_10%)] hover:bg-[hsl(36_60%_70%)]"
          >
            Science behind the story <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
          <Link to="/greenhouse" className="inline-flex min-h-[46px] items-center gap-2 rounded-full border border-[hsl(42_30%_85%)]/40 px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(42_30%_92%)] backdrop-blur hover:bg-white/10">
            Visit Edith's greenhouse
          </Link>
          <Link to="/chronicle-2" className="inline-flex min-h-[46px] items-center gap-2 rounded-full border border-[hsl(42_30%_85%)]/40 px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(42_30%_92%)] backdrop-blur hover:bg-white/10">
            Continue to Chronicle II <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Link>
        </div>
      </MoodZone>
    </section>
  );
};
