import React, { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Maximize2, X } from 'lucide-react';
import { scene, type C1Manuscript } from './c1-data';
import { useInView } from './c1-hooks';
import { CreepingRoots, SceneHeading, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';
import { KarenReadsTheSpell, ScienceInsideTheSpell } from './SanitationSpell';
import { GRIMOIRE_LABEL } from '@/content/sanitation-spell';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; onScience: (id: string) => void; reduced: boolean };

const ISSUES = [
  { issue: 'Vol. XIV · No. 9', head: 'Repotting After the Summer Growth', body: 'Repot when new roots are just emerging, not when the plant is in bud. Fresh bark, a pot no larger than the roots need, and a label with the date.' },
  { issue: 'Vol. XIV · No. 10', head: "Members' Plants on the Show Table", body: 'A fine turnout this month: slippers, a spray of Oncidium, and a Cymbidium that its grower insists was "doing nothing" until the nights turned cool.' },
  { issue: 'Vol. XV · No. 1', head: 'From the Potting Bench', body: 'Sterilise blades between plants. Keep new arrivals apart for a few weeks. Write down what you did, and when; your future self will ask.' },
];
const LAST = { issue: 'Vol. XV · No. 2', head: 'Culture Notes: Cool, Wet Nights', body: 'As the fog comes in, water early enough in the day that leaves and crowns are dry by dark. Keep air moving. Watch the new growths.' };

const NewsPage: React.FC<{ issue: string; head: string; body: string; big?: boolean }> = ({ issue, head, body, big }) => (
  <div className="flex h-full flex-col">
    <div className="border-b-2 border-double border-[hsl(30_14%_22%)] pb-2 text-center">
      <p className={`font-label uppercase text-[hsl(30_18%_12%)] ${big ? 'text-lg' : 'text-base'}`}>Five Cities Orchid Society</p>
      <p className={`font-label uppercase text-[hsl(30_16%_18%)] ${big ? 'text-base' : 'text-[1.0625rem]'}`}>Newsletter · {issue}</p>
    </div>
    <h4 className={`mt-4 font-display font-bold leading-tight text-[hsl(30_18%_9%)] ${big ? 'text-4xl' : 'text-3xl sm:text-4xl'}`}>{head}</h4>
    <p className={`mt-3 leading-[1.65] text-[hsl(30_18%_8%)] ${big ? 'text-[1.75rem]' : 'text-[1.375rem] sm:text-[1.5rem]'}`}>{body}</p>
    <div className="mt-auto space-y-1.5 opacity-30" aria-hidden="true">
      {[92, 86, 95, 70].map((w, i) => (
        <div key={i} className="h-1.5 rounded bg-[hsl(30_14%_40%)]" style={{ width: `${w}%` }} />
      ))}
    </div>
  </div>
);

const CursePage: React.FC<{ curse: string[]; morph: boolean; big?: boolean }> = ({ curse, morph, big }) => (
  <>
    <div className="absolute inset-0 p-6 transition-opacity duration-[2600ms] sm:p-8" style={{ opacity: morph ? 0 : 1 }}>
      <NewsPage {...LAST} big={big} />
    </div>
    <div className="absolute inset-0 overflow-y-auto p-6 transition-all duration-[3200ms] sm:p-8" style={{ opacity: morph ? 1 : 0, filter: morph ? 'blur(0)' : 'blur(3px)' }}>
      <p className={`font-hand leading-[1.9] text-[hsl(350_45%_16%)] ${big ? 'text-[1.875rem]' : 'text-[1.375rem] sm:text-[1.625rem]'}`}>
        {curse.map((l, j) => (
          <span key={j} className="block" style={{ transform: `rotate(${(j % 2 ? -1 : 1) * 0.6}deg)` }}>
            {l.replace(/^"|"$/g, '')}
          </span>
        ))}
      </p>
      <p className="mt-6 text-right font-hand text-xl text-[hsl(350_40%_20%)]">— H. N.</p>
    </div>
  </>
);

/** A bundle of FCOS newsletters. Tap, swipe or use arrow keys; the last page is not what it seems. */
const NewsletterStack: React.FC<{ curse: string[]; reduced: boolean }> = ({ curse, reduced }) => {
  const [idx, setIdx] = useState(0);
  const [big, setBig] = useState(false);
  const total = ISSUES.length + 1;
  const [ref, inView] = useInView<HTMLDivElement>(0.5);
  const [morph, setMorph] = useState(false);
  const touch = useRef<number | null>(null);
  const onLast = idx === total - 1;

  useEffect(() => {
    if (!onLast || !(inView || big)) return;
    const t = window.setTimeout(() => setMorph(true), reduced ? 0 : 1600);
    return () => window.clearTimeout(t);
  }, [onLast, inView, big, reduced]);

  useEffect(() => {
    if (!big) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setBig(false);
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  const go = (d: number) => setIdx((i) => Math.min(total - 1, Math.max(0, i + d)));
  const swipe = {
    onTouchStart: (e: React.TouchEvent) => (touch.current = e.touches[0].clientX),
    onTouchEnd: (e: React.TouchEvent) => {
      if (touch.current == null) return;
      const dx = e.changedTouches[0].clientX - touch.current;
      if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
      touch.current = null;
    },
  };

  const Controls = ({ light }: { light?: boolean }) => (
    <div className="no-print mt-5 flex items-center justify-between gap-2">
      <button type="button" onClick={() => go(-1)} disabled={idx === 0} className={`inline-flex min-h-[52px] items-center gap-1 rounded-md border-2 px-4 font-ui text-lg font-semibold disabled:opacity-40 ${light ? 'border-white/60 text-white' : 'border-[hsl(30_14%_24%)] text-[hsl(30_18%_10%)]'}`}>
        <ChevronLeft className="h-5 w-5" /> Back
      </button>
      <span className={`font-ui text-lg font-semibold ${light ? 'text-white' : 'text-[hsl(30_18%_10%)]'}`}>
        Page {idx + 1} of {total}
      </span>
      <button type="button" onClick={() => go(1)} disabled={onLast} className={`inline-flex min-h-[52px] items-center gap-1 rounded-md px-4 font-ui text-lg font-semibold disabled:opacity-40 ${light ? 'bg-white text-[hsl(145_34%_15%)]' : 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'}`}>
        Turn page <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  );

  return (
    <div ref={ref} className="relative mx-auto my-[8vh] w-full max-w-2xl px-5">
      <div className="relative aspect-[2/3] w-full select-none sm:aspect-[5/6]" {...swipe} aria-roledescription="page stack" aria-label={`Society newsletters, page ${idx + 1} of ${total}`}>
        <div className="absolute inset-0 translate-x-2 translate-y-2 rotate-[1.5deg] rounded-sm bg-[hsl(28_25%_22%)] shadow-xl" />
        {Array.from({ length: total }).map((_, i) => {
          if (i < idx - 1 || i > idx + 2) return null;
          const turned = i < idx;
          const depth = i - idx;
          const last = i === total - 1;
          return (
            <div
              key={i}
              aria-hidden={i !== idx}
              onClick={() => i === idx && !last && go(1)}
              className={`paper-aged absolute inset-0 overflow-hidden rounded-sm border border-[hsl(36_20%_70%)] p-6 shadow-md sm:p-8 ${turned && !reduced ? 'c1-page-turn' : ''} ${i === idx && !last ? 'cursor-pointer' : ''}`}
              style={{ zIndex: 20 - Math.abs(depth), transform: turned ? undefined : `rotate(${depth * 1.2}deg) translate(${depth * 3}px, ${depth * 3}px)`, opacity: turned && reduced ? 0 : 1 }}
            >
              {!last ? <NewsPage {...ISSUES[i]} /> : <CursePage curse={curse} morph={morph} />}
            </div>
          );
        })}
      </div>
      <Controls />
      <div className="no-print mt-4 flex justify-center">
        <button type="button" onClick={() => setBig(true)} className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(30_14%_24%)] bg-[hsl(42_45%_97%)] px-5 font-ui text-lg font-semibold text-[hsl(30_18%_10%)] hover:bg-white">
          <Maximize2 className="h-5 w-5" aria-hidden="true" /> Read enlarged
        </button>
      </div>
      {onLast && morph && <p className="mt-5 text-center font-display text-2xl font-semibold italic text-[hsl(350_45%_22%)]">Hiding in plain sight.</p>}

      {big && (
        <div role="dialog" aria-modal="true" aria-label="Enlarged newsletter" className="fixed inset-0 z-[70] flex flex-col items-center justify-center overscroll-contain bg-[hsl(30_20%_6%)]/95 p-4 backdrop-blur-sm" onClick={() => setBig(false)}>
          <div className="relative w-full max-w-2xl" onClick={(e) => e.stopPropagation()}>
            <button type="button" onClick={() => setBig(false)} aria-label="Close and return to the story" className="absolute -top-14 right-0 inline-flex min-h-[48px] items-center gap-2 rounded-md bg-white px-4 font-ui text-lg font-semibold text-[hsl(30_18%_10%)] hover:bg-[hsl(42_45%_92%)]">
              <X className="h-5 w-5" /> Close
            </button>
            <div className="paper-aged relative max-h-[78vh] overflow-y-auto rounded-sm p-6 shadow-2xl sm:p-10" style={{ minHeight: 'min(78vh, 720px)' }} {...swipe}>
              {idx < ISSUES.length ? <NewsPage {...ISSUES[idx]} big /> : <div className="relative h-[60vh]"><CursePage curse={curse} morph={morph} big /></div>}
            </div>
            <Controls light />
          </div>
        </div>
      )}
    </div>
  );
};

/* ---------------- Scene 8 ---------------- */

const SceneGrimoire: React.FC<Props> = ({ m, onDiscover, onScience, reduced }) => {
  const antidote = m.verses[1];
  /* Manuscript look: drop the outer quotation marks, set in four-line stanzas. */
  const verseLines = (antidote?.lines || []).map((l) => l.replace(/^["\u201c]|["\u201d]$/g, ''));
  const moss = scene('ernie-moss');
  return (
    <section className="paper-aged relative overflow-hidden pb-[10vh]" aria-label="The grimoire">
      {/* botanical margins: roots creeping in from both edges */}
      <CreepingRoots progress={1} className="left-0 top-0 hidden h-full w-[14%] opacity-50 md:block" color="hsl(30 18% 40%)" />
      <CreepingRoots progress={1} className="right-0 top-[20%] hidden h-[80%] w-[14%] -scale-x-100 opacity-50 md:block" color="hsl(30 18% 40%)" />
      <MoodZone mood="fcos">
        <div className="pt-[8vh]" />
        <StoryText text={m.p[11] || ''} onDiscover={onDiscover} tone="day" />
        <NewsletterStack curse={m.verses[0]?.lines || []} reduced={reduced} />
        <StoryText text={m.p[12] || ''} onDiscover={onDiscover} tone="day" />

        <div className="mt-[10vh]">
          <SceneHeading tone="day">{m.headings[2]}</SceneHeading>
        </div>

        <figure className="relative mx-auto mt-12 max-w-3xl rotate-[-0.4deg] rounded-sm border border-[hsl(36_20%_70%)] bg-[hsl(40_40%_92%)] px-6 py-12 shadow-lg sm:px-10">
          <div className="absolute -top-6 left-1/2 w-max max-w-[92%] -translate-x-1/2 rotate-[-2deg] rounded-sm border-2 border-[hsl(350_45%_35%)] bg-[hsl(42_40%_96%)] px-4 py-1.5 text-center font-label text-[1rem] uppercase leading-snug text-[hsl(350_45%_30%)]">
            {GRIMOIRE_LABEL[0]}
            <br />
            {GRIMOIRE_LABEL[1]}
          </div>
          {antidote?.title && <figcaption className="mt-2 text-center font-label text-[1.125rem] uppercase text-[hsl(30_14%_24%)]">{antidote.title}</figcaption>}
          <blockquote className="c1-grimoire-verse mt-6 font-hand text-[hsl(350_40%_18%)]">
            {Array.from({ length: Math.ceil(verseLines.length / 4) }).map((_, s) => (
              <div key={s} className={s > 0 ? 'mt-6' : ''}>
                {verseLines.slice(s * 4, s * 4 + 4).map((l, i) => (
                  <span key={i} className="block" style={{ transform: `rotate(${((s * 4 + i) % 2 ? -1 : 1) * 0.4}deg)` }}>
                    {l}
                  </span>
                ))}
                {s === 2 && (
                  <span className="mt-1 flex items-center justify-end gap-2 font-hand text-[1.125rem] leading-normal text-[hsl(350_50%_30%)]">
                    <span className="inline-block h-3 w-2.5 rounded-b-full rounded-t-[60%] bg-[hsl(350_65%_34%)]" aria-hidden="true" />
                    <em>Croton lechleri</em>
                  </span>
                )}
              </div>
            ))}
          </blockquote>
          <p className="c1-edu-note mt-8 border-t border-[hsl(36_20%_70%)] pt-4 font-body text-[hsl(30_16%_16%)]">
            Hazel&rsquo;s rhyme belongs to the story &mdash; but read it closely. Much of it is real orchid sanitation in disguise.
          </p>
          {/* Ernie, peeking from the moss under the bench */}
          <div className="absolute -bottom-16 -right-10 h-28 w-28 sm:-right-24 sm:h-36 sm:w-36" aria-hidden="true">
            <Vignette img={moss} shape="round" className="h-full w-full" />
          </div>
        </figure>

        <KarenReadsTheSpell onDiscover={onDiscover} />
        <ScienceInsideTheSpell onDiscover={onDiscover} onScience={onScience} reduced={reduced} />

        <StoryText text={m.p[13] || ''} onDiscover={onDiscover} tone="day" className="mt-16" />
      </MoodZone>
    </section>
  );
};

export default SceneGrimoire;
