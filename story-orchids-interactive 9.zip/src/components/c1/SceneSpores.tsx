import React, { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { C1_IMAGES, seg, type C1Manuscript } from './c1-data';
import { useIsSmall, useScrollProgress } from './c1-hooks';
import { Fog, StoryText } from './Atmosphere';
import { MoodZone, useSound } from './SoundContext';
import { EDITH_CLIP, FACE, SporeEngine, TL, coverRect, dimAt, type Rect } from './spores-engine';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; onScience: (id: string) => void; reduced: boolean };

/** Once triggered, the event plays at a cinematic pace (~17 s) even if the reader stops; scrolling on can only hurry it. */
const DURATION = 17000;
const TRIGGER = 0.2;
const RESET = 0.1;
const SCROLL_END = 0.74;

type Phase = 'pre' | 'engulf' | 'after';

const DARK = 'hsl(280 16% 4%';

const SceneSpores: React.FC<Props> = ({ m, onDiscover, onScience, reduced }) => {
  const [ref, p, live] = useScrollProgress<HTMLElement>();
  const stageRef = useRef<HTMLDivElement>(null);
  const backRef = useRef<HTMLCanvasElement>(null);
  const frontRef = useRef<HTMLCanvasElement>(null);
  const edithRef = useRef<HTMLImageElement>(null);
  const cutRef = useRef<HTMLImageElement>(null);
  const dimRef = useRef<HTMLDivElement>(null);
  const [rect, setRect] = useState<Rect>({ left: 0, top: 0, width: 0, height: 0 });
  const [phase, setPhase] = useState<Phase>('pre');
  const small = useIsSmall();
  const { cue } = useSound();
  const cueRef = useRef(cue);
  cueRef.current = cue;

  // one shared "cover" rectangle keeps Edith, her cut-out layer, the cloud and the empty plate in register
  useEffect(() => {
    const measure = () => {
      const el = stageRef.current;
      if (el) setRect(coverRect(el.clientWidth, el.clientHeight));
    };
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  useEffect(() => {
    if (reduced) return;
    const back = backRef.current;
    const front = frontRef.current;
    const section = ref.current;
    if (!back || !front || !section) return;
    const bctx = back.getContext('2d');
    const fctx = front.getContext('2d');
    if (!bctx || !fctx) return;

    const eng = new SporeEngine(small);
    let raf = 0;
    let visible = false;
    let last = 0;
    let T = 0;
    let running = false;
    let phaseNow: Phase = 'pre';
    const f = { first: false, puff: false, feet: false, ghost: false, rumble: false, clink: false, hush: false, burst: false };
    let timers: number[] = [];

    const resize = () => {
      eng.dpr = Math.min(window.devicePixelRatio || 1, small ? 1.25 : 1.5);
      [back, front].forEach((c) => {
        c.width = Math.round(c.clientWidth * eng.dpr);
        c.height = Math.round(c.clientHeight * eng.dpr);
      });
      eng.geo = coverRect(back.clientWidth, back.clientHeight);
    };
    resize();

    const setPh = (ph: Phase) => {
      if (ph !== phaseNow) {
        phaseNow = ph;
        setPhase(ph);
      }
    };

    const resetAll = () => {
      T = 0;
      running = false;
      eng.reset();
      (Object.keys(f) as (keyof typeof f)[]).forEach((k) => (f[k] = false));
      timers.forEach((id) => window.clearTimeout(id));
      timers = [];
      setPh('pre');
    };

    const frame = (t: number) => {
      raf = 0;
      const dt = last ? Math.min(50, t - last) : 16.7;
      last = t;
      const pr = live.current;
      if (pr < RESET && (T > 0 || f.first)) resetAll();
      if (!running && pr >= TRIGGER && T < 1) running = true;
      if (running) {
        T = Math.min(1, T + dt / DURATION);
        if (T >= 1) running = false;
      }
      const s = Math.max(T, seg(pr, TRIGGER, SCROLL_END));

      /* ---- story beats ---- */
      if (s >= TL.first && !f.first) {
        f.first = true;
        cueRef.current('whisper');
      }
      if (s >= TL.puff && !f.puff) {
        f.puff = true;
        eng.puff();
        cueRef.current('whisper');
      }
      if (s >= TL.feet && !f.feet) {
        f.feet = true;
        cueRef.current('whisper');
      }
      if (s >= TL.ghostIn && !f.ghost) {
        f.ghost = true;
        if (s < TL.ghostOut) eng.formGhost();
      }
      if (s >= TL.engulf && !f.rumble) {
        f.rumble = true;
        cueRef.current('rumble');
      }
      if (s >= TL.clink && !f.clink) {
        f.clink = true;
        cueRef.current('shears');
      }
      if (s >= TL.implode && !f.hush) {
        f.hush = true;
        cueRef.current('hush');
      }
      if (s >= TL.burst && !f.burst) {
        f.burst = true;
        eng.burst(t);
        cueRef.current('whoomph');
        timers.push(window.setTimeout(() => cueRef.current('creak'), 3600));
        timers.push(window.setTimeout(() => cueRef.current('creak'), 9800));
      }
      setPh(s < TL.puff ? 'pre' : s < TL.burst ? 'engulf' : 'after');

      /* ---- layers: Edith never moves; she is removed only under the complete cloud ---- */
      const gone = seg(s, TL.swap, TL.swapEnd);
      if (edithRef.current) edithRef.current.style.opacity = String(1 - gone);
      if (cutRef.current) cutRef.current.style.opacity = String(1 - gone);
      if (dimRef.current) {
        const flicker = s > 0.4 && s < TL.hidden ? Math.random() * 0.03 : 0;
        dimRef.current.style.opacity = String(dimAt(s) + flicker);
      }

      eng.step(s, t, dt, bctx, fctx, back.width, back.height);
      if (visible) raf = requestAnimationFrame(frame);
    };

    const io = new IntersectionObserver((entries) => {
      visible = entries[0]?.isIntersecting ?? false;
      if (visible && !raf) {
        last = 0;
        raf = requestAnimationFrame(frame);
      }
    });
    io.observe(section);
    window.addEventListener('resize', resize);
    return () => {
      io.disconnect();
      window.removeEventListener('resize', resize);
      if (raf) cancelAnimationFrame(raf);
      timers.forEach((id) => window.clearTimeout(id));
    };
  }, [reduced, small, live, ref]);

  const plate: React.CSSProperties = { left: rect.left, top: rect.top, width: rect.width, height: rect.height };
  const ready = rect.width > 0;

  /* ---------- reduced motion: five still compositions, cross-faded by scroll ---------- */
  const still = p < 0.24 ? 0 : p < 0.32 ? 1 : p < 0.4 ? 2 : p < 0.48 ? 3 : 4;
  const faceMask = `radial-gradient(ellipse 4% 7% at ${FACE.x * 100}% ${FACE.y * 100}%, #000 55%, transparent 100%)`;
  const layer = (on: boolean, background: string, ms = 800): React.CSSProperties => ({ ...plate, opacity: on ? 1 : 0, background, transition: `opacity ${ms}ms ease` });

  return (
    <section ref={ref} className="relative h-[640vh] bg-[hsl(200_6%_14%)]" aria-label="The spores take Edith">
      {/* Layer A: greenhouse, cloud behind Edith, Edith */}
      <div className="absolute inset-0">
        <div
          ref={stageRef}
          className="sticky top-0 h-[100svh] overflow-hidden"
          role="img"
          aria-label="Edith stands at her bench cutting a blackened orchid. A few dark specks appear beneath the benches. Then a sudden puff of black spores blooms from the rotting orchid across the aisle, turns against the air and flows toward her. It curls around her shoes and climbs her skirt, arms and shoulders, passing both behind and in front of her, until she stands inside a swirling storm with only her face and one hand showing through the gaps. For a moment the spores form a tall, indistinct figure behind her, reaching around her, which then collapses into her. The cloud closes over her feet first, then her body, then her face. It contracts to where she stood and bursts outward. As the dust settles, the same aisle is empty: her watering can lies tipped over, her shears and notebook lie on the flagstones, and a last spore settles on the can."
        >
          {ready && (
            <>
              <img src={C1_IMAGES.aftermath.src} alt="" loading="lazy" decoding="async" className="absolute max-w-none" style={plate} />
              <img
                ref={edithRef}
                src={C1_IMAGES.edithMorning.src}
                alt=""
                decoding="async"
                className="absolute max-w-none"
                style={{ ...plate, ...(reduced ? { opacity: still < 4 ? 1 : 0, transition: 'opacity 700ms ease 500ms' } : {}) }}
              />
            </>
          )}

          {reduced ? (
            ready && (
              <>
                {/* 1 — the puff of spores rising from the diseased orchid across the aisle */}
                <div className="absolute max-w-none" style={layer(still === 0, `radial-gradient(ellipse 9% 12% at 36% 72%, ${DARK} / 0.85), transparent 75%), radial-gradient(ellipse 18% 6% at 48% 93%, ${DARK} / 0.55), transparent 80%)`)} />
                {/* 2 — the cloud has found her and climbs; Edith clearly inside it */}
                <div className="absolute max-w-none" style={layer(still === 1, `radial-gradient(ellipse 13% 22% at 66% 82%, ${DARK} / 0.88) 35%, transparent 80%), radial-gradient(ellipse 17% 44% at 69% 60%, transparent 55%, ${DARK} / 0.7) 75%, transparent 100%)`)} />
                {/* 3 — only her face shows through the storm */}
                <div className="absolute max-w-none" style={layer(still === 2, `radial-gradient(ellipse 18% 50% at 69% 58%, ${DARK} / 0.94) 50%, ${DARK} / 0.6) 78%, transparent 100%)`)} />
                <img
                  src={C1_IMAGES.edithMorning.src}
                  alt=""
                  aria-hidden="true"
                  className="absolute max-w-none"
                  style={{ ...plate, opacity: still === 2 ? 0.9 : 0, transition: 'opacity 800ms ease', clipPath: EDITH_CLIP, WebkitClipPath: EDITH_CLIP, WebkitMaskImage: faceMask, maskImage: faceMask }}
                />
                {/* 4 — the cloud closes completely (Edith is removed only beneath it) */}
                <div className="absolute max-w-none" style={layer(still === 3, `radial-gradient(ellipse 17% 50% at 69% 58%, ${DARK} / 0.98) 60%, transparent 100%), radial-gradient(ellipse 20% 16% at 66% 88%, ${DARK} / 0.96) 55%, transparent 100%)`, 1400)} />
                {/* 5 — the empty aisle; a little dust still settling */}
                <div className="absolute max-w-none" style={layer(still === 4, `radial-gradient(ellipse 30% 40% at 67% 65%, ${DARK} / 0.22), transparent 80%)`, 1400)} />
              </>
            )
          ) : (
            <>
              <canvas ref={backRef} className="absolute inset-0 h-full w-full" aria-hidden="true" />
              {ready && (
                /* Edith herself — the SAME painted pixels, cut out and held perfectly still, so the cloud can pass behind her */
                <img
                  ref={cutRef}
                  src={C1_IMAGES.edithMorning.src}
                  alt=""
                  aria-hidden="true"
                  className="absolute max-w-none"
                  style={{ ...plate, clipPath: EDITH_CLIP, WebkitClipPath: EDITH_CLIP }}
                />
              )}
              <div ref={dimRef} aria-hidden="true" className="absolute inset-0 bg-[hsl(250_20%_4%)]" style={{ opacity: 0 }} />
            </>
          )}
          <Fog density={0.12} tint="270 8% 18%" />
        </div>
      </div>

      {/* Story text between the planes. The prose describing her vanishing comes only AFTER the visual silence. */}
      <MoodZone mood={phase === 'pre' ? 'morning' : phase === 'engulf' ? 'engulf' : 'aftermath'} className="relative z-10">
        <div className="h-[40vh]" />
        <StoryText text={m.p[7] || ''} onDiscover={onDiscover} align="left" />
        <div className="h-[405vh]" />
        <StoryText text={m.p[8] || ''} onDiscover={onDiscover} />
        <div className="no-print mx-auto mt-4 flex max-w-xl flex-col items-center gap-3 px-6 pb-[70vh] text-center">
          <button
            type="button"
            onClick={() => onScience('black-rot')}
            className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[hsl(42_30%_85%)]/40 bg-[hsl(30_14%_8%)]/60 px-5 py-2 font-label text-[0.6rem] uppercase text-[hsl(42_30%_90%)] backdrop-blur hover:bg-[hsl(30_14%_14%)]/80"
          >
            Science behind the story <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
          <p className="max-w-xl rounded-2xl bg-[hsl(30_14%_6%)]/70 px-5 py-3 font-ui text-sm leading-relaxed text-[hsl(42_30%_92%)] backdrop-blur-sm [text-shadow:0_1px_6px_#000]">
            The spores in this scene belong to Hazel's curse. Real orchid black rot does not create a cloud capable of engulfing a person.
          </p>
        </div>
      </MoodZone>

      {/* Layer B: the cloud IN FRONT of Edith (and the burst toward the viewer) */}
      <div className="pointer-events-none absolute inset-0 z-20" aria-hidden="true">
        <div className="sticky top-0 h-[100svh] overflow-hidden">{!reduced && <canvas ref={frontRef} className="absolute inset-0 h-full w-full" />}</div>
      </div>
    </section>
  );
};

export default SceneSpores;
