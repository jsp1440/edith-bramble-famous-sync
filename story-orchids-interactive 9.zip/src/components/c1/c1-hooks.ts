import React, { useEffect, useRef, useState } from 'react';
import { clamp } from './c1-data';

export { useReducedMotion } from '@/components/story/StoryEffects';

/**
 * Scroll progress of a tall section through the viewport (0 → 1).
 * For a section taller than the viewport, 0 = its top reaches the top of the
 * screen, 1 = its bottom reaches the bottom. rAF-throttled and quantised so
 * scenes re-render at most ~200 times across their whole length.
 */
export function useScrollProgress<T extends HTMLElement>(): [React.RefObject<T>, number, React.MutableRefObject<number>] {
  const ref = useRef<T>(null);
  const live = useRef(0);
  const [p, setP] = useState(0);

  useEffect(() => {
    let raf = 0;
    const measure = () => {
      raf = 0;
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight || 1;
      const total = r.height - vh;
      const v = total > 0 ? clamp(-r.top / total) : clamp((vh - r.top) / (vh + r.height));
      live.current = v;
      const q = Math.round(v * 200) / 200;
      setP((old) => (old === q ? old : q));
    };
    const on = () => {
      if (!raf) raf = requestAnimationFrame(measure);
    };
    measure();
    window.addEventListener('scroll', on, { passive: true });
    window.addEventListener('resize', on);
    return () => {
      window.removeEventListener('scroll', on);
      window.removeEventListener('resize', on);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return [ref, p, live];
}

/** True while the element is on screen; resets when it leaves (so effects can replay gracefully). */
export function useInView<T extends HTMLElement>(threshold = 0.35, rootMargin = '0px'): [React.RefObject<T>, boolean] {
  const ref = useRef<T>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => setInView(entries[0]?.isIntersecting ?? false), { threshold, rootMargin });
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, rootMargin]);
  return [ref, inView];
}

/** Becomes true the first time the element is seen and stays true. */
export function useSeenOnce<T extends HTMLElement>(threshold = 0.4): [React.RefObject<T>, boolean] {
  const [ref, inView] = useInView<T>(threshold);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (inView) setSeen(true);
  }, [inView]);
  return [ref, seen];
}

export function useIsSmall(): boolean {
  const [small, setSmall] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 767px)');
    setSmall(mq.matches);
    const on = (e: MediaQueryListEvent) => setSmall(e.matches);
    mq.addEventListener?.('change', on);
    return () => mq.removeEventListener?.('change', on);
  }, []);
  return small;
}
