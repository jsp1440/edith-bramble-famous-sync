import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { discoveries } from '@/lib/content';
import { useDiscovery } from '@/contexts/DiscoveryContext';
import ChronicleOneClues from '@/components/story/ChronicleOneClues';
import { Kicker } from '@/components/site/Ornaments';

/** "Science Behind the Story" — shared by the cinematic and fallback Chronicle I pages. */
const Afterword: React.FC<{ onDiscover: (id: string) => void; onScience?: (id: string) => void }> = ({ onDiscover, onScience }) => {
  const { discovered } = useDiscovery();
  const ids = Object.keys(discoveries);
  const btn = 'inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] bg-[hsl(var(--cream))] px-5 font-ui text-lg font-semibold text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))]/10';

  return (
    <section id="science-behind" className="scroll-mt-20 border-t border-border/70 bg-[hsl(var(--cream))]">
      <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
        {/* Chapter-end summary: cream on deep green for maximum legibility */}
        <div className="eb-panel-green rounded-lg p-7 shadow-md sm:p-10">
          <Kicker>Science Behind the Story</Kicker>
          <h2 className="mt-3 font-display text-4xl font-semibold sm:text-5xl">The tale is fiction. The rot is not.</h2>
          <p className="mt-4 max-w-2xl text-xl leading-relaxed">
            The curse, the spores that take Edith, the magic of the antidote rhyme and the charm belong to the story. Everything marked in the text opens a factual door beside it. Doors you did not open are listed here too, so nothing is lost by reading straight through.
          </p>
        </div>

        <div className="mt-10">
          <ChronicleOneClues />
        </div>

        <ul className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {ids.map((id) => {
            const d = discoveries[id];
            const found = discovered.includes(id);
            return (
              <li key={id}>
                <button
                  type="button"
                  onClick={() => onDiscover(id)}
                  className={`flex h-full w-full flex-col rounded-md border-2 p-5 text-left transition-colors ${
                    found ? 'border-[hsl(30_60%_40%)] bg-[hsl(40_70%_93%)]' : 'border-border bg-background hover:border-[hsl(var(--botanical))]'
                  }`}
                >
                  <span className="font-label text-[1.0625rem] uppercase text-[hsl(var(--moss))]">{d.eyebrow}</span>
                  <span className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{d.title}</span>
                  <span className="mt-2 font-ui text-base font-semibold text-[hsl(30_60%_24%)]">{found ? 'Discovered' : 'Not yet found — tap to open'}</span>
                </button>
              </li>
            );
          })}
        </ul>

        <div className="mt-12 flex flex-wrap gap-3">
          <Link to="/chronicle-2" className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-6 font-ui text-lg font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            Continue to Chronicle II <ArrowRight className="h-5 w-5" aria-hidden="true" />
          </Link>
          {onScience && (
            <button type="button" onClick={() => onScience('black-rot')} className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--charcoal))] px-6 font-ui text-lg font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--botanical))]">
              What black rot actually is <ArrowRight className="h-5 w-5" aria-hidden="true" />
            </button>
          )}
          <Link to="/science" className={btn}>Science section</Link>
          <Link to="/greenhouse" className={btn}>Walk Edith's greenhouse</Link>
          <Link to="/cabinet" className={btn}>Collector's Cabinet</Link>
          <Link to="/plant-doctor" className={btn}>Plant Doctor</Link>
        </div>
      </div>
    </section>
  );
};

export default Afterword;
