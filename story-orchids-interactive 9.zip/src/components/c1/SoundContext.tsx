import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { MessageSquare as Captions, MessageSquareOff as CaptionsOff, Volume2, VolumeX } from 'lucide-react';
import { MOOD_CAPTIONS, Soundscape, type Cue, type Mood } from './soundscape';
import { useInView } from './c1-hooks';
import { PREFS_EVENT, loadPrefs, updatePrefs, type ReadingPrefs } from '@/lib/reading-prefs';

const PREF_KEY = 'eb-c1-sound';

interface SoundApi {
  on: boolean;
  /** True if the reader chose sound earlier this session (needs one tap to resume). */
  wanted: boolean;
  mood: Mood;
  enable: () => void;
  disable: () => void;
  setMood: (m: Mood) => void;
  cue: (c: Cue) => void;
}

const Ctx = createContext<SoundApi | null>(null);

export const SoundProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const engine = useRef<Soundscape | null>(null);
  const [on, setOn] = useState(false);
  const [wanted, setWanted] = useState(false);
  const [mood, setMoodState] = useState<Mood>('night');
  const moodRef = useRef<Mood>('night');
  const onRef = useRef(false);

  const startEngine = useCallback(() => {
    if (!engine.current) engine.current = new Soundscape();
    engine.current.setMood(moodRef.current, true);
    engine.current.start();
    onRef.current = true;
    setOn(true);
    setWanted(true);
  }, []);

  const stopEngine = useCallback(() => {
    engine.current?.mute();
    onRef.current = false;
    setOn(false);
    setWanted(false);
  }, []);

  useEffect(() => {
    try {
      // Sound is never auto-played: a saved "On" choice waits for one tap.
      setWanted(sessionStorage.getItem(PREF_KEY) === 'on' || loadPrefs().sound === 'on');
    } catch {
      /* ignore */
    }
    // Reading settings → Sound On/Off (the tap in the settings panel counts as
    // the user gesture browsers require before audio may start).
    const onPrefs = (e: Event) => {
      const p = (e as CustomEvent<ReadingPrefs>).detail;
      if (p.sound === 'on' && !onRef.current) startEngine();
      if (p.sound === 'off' && onRef.current) stopEngine();
    };
    window.addEventListener(PREFS_EVENT, onPrefs);
    return () => {
      window.removeEventListener(PREFS_EVENT, onPrefs);
      engine.current?.dispose();
    };
  }, [startEngine, stopEngine]);

  const enable = useCallback(() => {
    startEngine();
    try {
      sessionStorage.setItem(PREF_KEY, 'on');
    } catch {
      /* ignore */
    }
    if (loadPrefs().sound !== 'on') updatePrefs({ sound: 'on' });
  }, [startEngine]);

  const disable = useCallback(() => {
    stopEngine();
    try {
      sessionStorage.setItem(PREF_KEY, 'off');
    } catch {
      /* ignore */
    }
    if (loadPrefs().sound !== 'off') updatePrefs({ sound: 'off' });
  }, [stopEngine]);

  const setMood = useCallback((m: Mood) => {
    moodRef.current = m;
    setMoodState(m);
    engine.current?.setMood(m);
  }, []);

  const cue = useCallback((c: Cue) => engine.current?.cue(c), []);

  return <Ctx.Provider value={{ on, wanted, mood, enable, disable, setMood, cue }}>{children}</Ctx.Provider>;
};

export function useSound(): SoundApi {
  const v = useContext(Ctx);
  if (!v) {
    return { on: false, wanted: false, mood: 'night', enable: () => {}, disable: () => {}, setMood: () => {}, cue: () => {} };
  }
  return v;
}

/** Invisible marker: when this block is on screen, the soundscape shifts mood. */
export const MoodZone: React.FC<{ mood: Mood; className?: string; children?: React.ReactNode }> = ({ mood, className, children }) => {
  const { setMood } = useSound();
  const [ref, inView] = useInView<HTMLDivElement>(0, '-45% 0px -45% 0px');
  useEffect(() => {
    if (inView) setMood(mood);
  }, [inView, mood, setMood]);
  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
};

/** Fixed, unobtrusive control. Mutes instantly. Captions describe what is audible. */
export const SoundControl: React.FC = () => {
  const { on, wanted, mood, enable, disable } = useSound();
  const [captions, setCaptions] = useState(true);
  return (
    <div className="eb-rv-hide no-print fixed bottom-[5rem] left-4 z-40 flex max-w-[min(24rem,calc(100vw-2rem))] flex-col items-start gap-2" style={{ fontSize: 17 }}>
      {on && captions && (
        <p aria-live="polite" className="rounded-md bg-[hsl(30_14%_8%)]/90 px-3 py-2 font-ui leading-snug text-[hsl(42_40%_94%)] backdrop-blur">
          <span className="mr-1 font-bold text-[hsl(36_70%_76%)]">Sound:</span>
          [{MOOD_CAPTIONS[mood]}]
        </p>
      )}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={on ? disable : enable}
          aria-pressed={on}
          aria-label={on ? 'Mute atmospheric sound' : 'Turn on atmospheric sound'}
          className="inline-flex min-h-[48px] items-center gap-2 rounded-full border-2 border-white/30 bg-[hsl(30_14%_8%)]/85 px-4 font-ui font-semibold text-[hsl(42_40%_95%)] backdrop-blur hover:bg-[hsl(30_14%_14%)]"
        >
          {on ? <Volume2 className="h-5 w-5" aria-hidden="true" /> : <VolumeX className="h-5 w-5" aria-hidden="true" />}
          {on ? 'Sound on' : wanted ? 'Tap to resume sound' : 'Sound off'}
        </button>
        {on && (
          <button
            type="button"
            onClick={() => setCaptions((c) => !c)}
            aria-pressed={captions}
            aria-label={captions ? 'Hide sound captions' : 'Show sound captions'}
            className="inline-flex h-12 w-12 items-center justify-center rounded-full border-2 border-white/30 bg-[hsl(30_14%_8%)]/85 text-[hsl(42_40%_95%)] backdrop-blur"
          >
            {captions ? <Captions className="h-5 w-5" aria-hidden="true" /> : <CaptionsOff className="h-5 w-5" aria-hidden="true" />}
          </button>
        )}
      </div>
    </div>
  );
};
