import React, { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { C1_IMAGES, scene, type C1Image, type C1Manuscript } from './c1-data';
import { useInView } from './c1-hooks';
import { Fog, Frog, FrogLeap, SceneHeading, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; reduced: boolean };

/* ---------------- HELP, traced from the other side of the glass ---------------- */

const LETTERS = [
  'M20 14 V70 M20 42 H48 M48 14 V70',
  'M72 14 H100 M72 14 V70 H100 M72 42 H94',
  'M122 14 V70 H148',
  'M170 70 V14 H188 Q204 14 204 29 Q204 44 188 44 H170',
];

const HelpPane: React.FC<{ reduced: boolean }> = ({ reduced }) => {
  const bg = scene('greenhouse-interior');
  const [ref, inView] = useInView<HTMLDivElement>(0.55);
  const [on, setOn] = useState(false);
  useEffect(() => {
    if (!inView) {
      setOn(false);
      return;
    }
    const t = window.setTimeout(() => setOn(true), 1400);
    return () => window.clearTimeout(t);
  }, [inView]);

  return (
    <div
      ref={ref}
      role="img"
      aria-label="Another pane of glass slowly clouds with condensation. As if traced from the other side, the letters H, E, L, P appear one by one, linger, and slowly fog over again."
      className={`relative my-[12vh] h-[62vh] w-full overflow-hidden ${on || reduced ? 'c1-help-on' : ''}`}
    >
      <img src={bg.src} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ filter: 'brightness(0.55) saturate(0.6)' }} />
      <svg viewBox="0 0 224 84" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full">
        <defs>
          <mask id="c1-help-mask">
            <rect width="224" height="84" fill="white" />
            <g stroke="black" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" fill="none" style={{ filter: 'blur(0.6px)' }}>
              {LETTERS.map((d, i) => (
                <path key={i} d={d} pathLength={100} className="c1-help-stroke" style={reduced ? { strokeDashoffset: 0 } : { animationDelay: `${3.2 + i * 1.6}s` }} />
              ))}
            </g>
          </mask>
          <filter id="c1-grain">
            <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" />
            <feColorMatrix values="0 0 0 0 0.85  0 0 0 0 0.88  0 0 0 0 0.9  0 0 0 0.35 0" />
            <feComposite in2="SourceGraphic" operator="in" />
          </filter>
        </defs>
        {/* condensation forming, with the traced letters wiped out of it */}
        <g className="c1-help-fog" mask="url(#c1-help-mask)" style={reduced ? { opacity: 1 } : undefined}>
          <rect width="224" height="84" fill="hsl(200 12% 84% / 0.82)" />
          <rect width="224" height="84" filter="url(#c1-grain)" />
        </g>
        {/* ...and fogging over again */}
        {!reduced && <rect width="224" height="84" fill="hsl(200 12% 84% / 0.82)" className="c1-help-refog" />}
      </svg>
      <div className="pointer-events-none absolute inset-0 bg-[repeating-linear-gradient(90deg,transparent_0_calc(33.3%-3px),hsl(30_20%_12%/0.8)_calc(33.3%-3px)_33.3%)]" />
    </div>
  );
};

/* ---------------- Wipe the condensation ---------------- */

const WipeGlass: React.FC = () => {
  const ref = useRef<HTMLCanvasElement>(null);
  const paint = () => {
    const c = ref.current;
    if (!c) return;
    c.width = c.clientWidth;
    c.height = c.clientHeight;
    const g = c.getContext('2d');
    if (!g) return;
    g.globalCompositeOperation = 'source-over';
    g.fillStyle = 'rgba(214, 222, 226, 0.86)';
    g.fillRect(0, 0, c.width, c.height);
  };
  useEffect(paint, []);
  const wipe = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.pointerType === 'mouse' && e.buttons === 0 && e.type === 'pointermove') return;
    const c = ref.current;
    const g = c?.getContext('2d');
    if (!c || !g) return;
    const r = c.getBoundingClientRect();
    g.globalCompositeOperation = 'destination-out';
    const grd = g.createRadialGradient(e.clientX - r.left, e.clientY - r.top, 0, e.clientX - r.left, e.clientY - r.top, 26);
    grd.addColorStop(0, 'rgba(0,0,0,1)');
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = grd;
    g.beginPath();
    g.arc(e.clientX - r.left, e.clientY - r.top, 26, 0, Math.PI * 2);
    g.fill();
  };
  return (
    <div className="relative h-56 overflow-hidden rounded-sm">
      <img src={C1_IMAGES.flower.src} alt="Behind the condensation: a pale orchid flower." className="absolute inset-0 h-full w-full object-cover" />
      <canvas ref={ref} onPointerDown={wipe} onPointerMove={wipe} className="absolute inset-0 h-full w-full cursor-crosshair touch-none" aria-label="Fogged glass. Drag to wipe a clear patch." />
      <button type="button" onClick={paint} className="absolute bottom-2 right-2 rounded-full bg-black/50 px-3 py-1 font-label text-[0.5rem] uppercase text-white">
        Fog it again
      </button>
    </div>
  );
};

/* ---------------- Explorable greenhouse ---------------- */

type Spot = { id: string; x: string; y: string; label: string; title: string; body: string; img?: C1Image; wipe?: boolean };

const SPOTS: Spot[] = [
  { id: 'leaf', x: '30%', y: '58%', label: 'Inspect an infected leaf', title: 'An infected leaf', body: 'Dark, water-soaked and spreading from the base. In a real greenhouse, a lesion that grows this quickly is a reason to isolate the plant and look closely, not to wait and see.', img: C1_IMAGES.lesion },
  { id: 'root', x: '64%', y: '34%', label: 'Look at a root', title: 'A root, close up', body: 'Healthy orchid roots are firm and silvery or green at the tips. Collapsed, brown-black roots have stopped working, and the plant can no longer take up water through them.', img: C1_IMAGES.rottenRoots },
  { id: 'pot', x: '78%', y: '72%', label: 'Check a pot', title: 'A cultural clue', body: "The bark is still wet from last night's watering, hours into a cold, still night. Water that lingers into cool darkness is one of the conditions many rot organisms favour.", img: C1_IMAGES.wetLeaf },
  { id: 'glass', x: '50%', y: '18%', label: 'Touch the condensation', title: 'Condensation', body: 'Drag across the pane to wipe a clear patch.', wipe: true },
];

const Explore: React.FC = () => {
  const bg = scene('greenhouse-interior');
  const [open, setOpen] = useState<Spot | null>(null);
  return (
    <div className="relative mx-auto my-[10vh] w-full max-w-6xl px-0 sm:px-6">
      <p className="px-6 pb-3 text-center font-label text-[0.55rem] uppercase text-[hsl(30_14%_30%)]">Walk the greenhouse with them · tap what catches your eye</p>
      <div className="relative aspect-[4/3] w-full overflow-hidden sm:aspect-[16/9]" style={{ WebkitMaskImage: 'linear-gradient(transparent, #000 8%, #000 92%, transparent)', maskImage: 'linear-gradient(transparent, #000 8%, #000 92%, transparent)' }}>
        <img src={bg.src} alt={bg.alt} loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ filter: 'saturate(0.7) brightness(0.95)' }} />
        <Fog density={0.25} tint="200 10% 96%" />
        {SPOTS.map((s) => (
          <button
            key={s.id}
            type="button"
            onClick={() => setOpen(s)}
            aria-label={s.label}
            className="group absolute flex h-11 w-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center"
            style={{ left: s.x, top: s.y }}
          >
            <span className="absolute h-6 w-6 animate-ping rounded-full border border-white/60 [animation-duration:3s]" />
            <span className="h-3 w-3 rounded-full bg-white/85 shadow-[0_0_10px_rgba(255,255,255,0.9)] transition-transform group-hover:scale-125" />
          </button>
        ))}
        {/* Ernie, watching the society investigate */}
        <Frog className="bottom-[14%] left-[9%]" size={42} />
        {open && (
          <div role="dialog" aria-modal="false" aria-label={open.title} className="absolute inset-x-3 bottom-3 z-30 max-h-[85%] overflow-y-auto rounded-sm bg-[hsl(42_40%_96%)]/95 p-5 shadow-2xl backdrop-blur sm:inset-x-auto sm:right-4 sm:top-4 sm:bottom-auto sm:w-[26rem]">
            <div className="flex items-start justify-between gap-3">
              <h3 className="font-display text-xl font-semibold text-[hsl(30_14%_16%)]">{open.title}</h3>
              <button type="button" onClick={() => setOpen(null)} aria-label="Close" className="rounded-full p-1 hover:bg-black/5">
                <X className="h-4 w-4" />
              </button>
            </div>
            {open.img && <Vignette img={open.img} className="mx-auto my-2 h-40 w-40" shape="round" />}
            {open.wipe && <div className="my-3"><WipeGlass /></div>}
            <p className="text-sm leading-relaxed text-[hsl(30_14%_22%)]">{open.body}</p>
          </div>
        )}
      </div>
    </div>
  );
};

/* ---------------- Scene 7 ---------------- */

const SceneSociety: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const arrive = scene('scene-society-arrives');
  return (
    <section className="relative bg-[linear-gradient(180deg,hsl(200_8%_80%),hsl(40_30%_92%)_30%,hsl(40_33%_94%))]" aria-label="The Orchid Society arrives">
      <MoodZone mood="fcos">
        <div className="relative h-[92svh] w-full overflow-hidden">
          <img src={arrive.src} alt={arrive.alt} loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ filter: 'brightness(1.05) saturate(0.85)' }} />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[hsl(40_30%_92%)]" />
          <div className="absolute inset-x-0 bottom-[8%]">
            <SceneHeading tone="day">{m.headings[1]}</SceneHeading>
          </div>
        </div>
        <StoryText text={m.p[9] || ''} onDiscover={onDiscover} tone="day" />
        <HelpPane reduced={reduced} />
        <div className="relative mx-auto max-w-3xl">
          <StoryText text={m.p[10] || ''} onDiscover={onDiscover} tone="day" />
          <FrogLeap className="-bottom-2 right-6" />
        </div>
        <Explore />
      </MoodZone>
    </section>
  );
};

export default SceneSociety;
