import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { getMedia } from '@/lib/content';
import { parseInline } from '@/lib/story-parser';
import { useInView, useReducedMotion } from './c1-hooks';
import type { C1Image } from './c1-data';

/* ---------------- Story text on the living page ---------------- */

export const C1Inline: React.FC<{ text: string; onDiscover: (id: string) => void }> = ({ text, onDiscover }) => (
  <>
    {parseInline(text).map((t, i) => {
      if (t.type === 'discovery' || t.type === 'grower')
        return (
          <button
            key={i}
            type="button"
            onClick={() => onDiscover(t.id)}
            className="discovery-mark cursor-pointer rounded-[2px] px-0.5 text-inherit underline decoration-[hsl(36_60%_60%)]/60 decoration-dotted underline-offset-4"
          >
            {t.value}
          </button>
        );
      if (t.type === 'em') return <em key={i}>{t.value}</em>;
      if (t.type === 'strong') return <strong key={i}>{t.value}</strong>;
      return <React.Fragment key={i}>{t.value}</React.Fragment>;
    })}
  </>
);

/**
 * A paragraph that floats in the scene without a box. Readability comes from
 * a feathered, localised charcoal wash with a gentle backdrop blur (never a
 * card), a soft text shadow, a narrow measure (~45–70 characters) and
 * responsive novel-sized type (see .c1-story in index.css).
 */
export const StoryText: React.FC<{
  text: string;
  onDiscover: (id: string) => void;
  tone?: 'night' | 'day';
  align?: 'left' | 'center' | 'right';
  dropCap?: boolean;
  /** 'quote' = important quotation, set larger in italic display type. */
  variant?: 'body' | 'quote';
  className?: string;
}> = ({ text, onDiscover, tone = 'night', align = 'center', dropCap, variant = 'body', className = '' }) => {
  const [ref, inView] = useInView<HTMLParagraphElement>(0.2);
  const pos = align === 'left' ? 'mx-auto md:ml-[6%] md:mr-auto' : align === 'right' ? 'mx-auto md:mr-[6%] md:ml-auto' : 'mx-auto';
  const night = tone === 'night';
  return (
    <p
      ref={ref}
      className={`relative isolate ${pos} my-8 px-6 py-6 sm:px-10 ${
        variant === 'quote' ? 'c1-story-quote font-display italic' : 'c1-story font-body'
      } ${night ? 'c1-story-night' : 'c1-story-day'} transition-[opacity,transform,filter] duration-[1400ms] ease-out ${
        inView ? 'translate-y-0 opacity-100 [filter:none]' : 'translate-y-4 opacity-0 blur-[2px]'
      } ${night ? '[text-shadow:0_1px_2px_hsl(30_30%_4%/0.95),0_2px_14px_hsl(30_30%_4%/0.8)]' : '[text-shadow:0_1px_8px_hsl(42_40%_96%/0.9)]'} ${
        dropCap ? 'drop-cap' : ''
      } ${className}`}
    >
      <span aria-hidden="true" className={`c1-wash ${night ? 'c1-wash-night' : 'c1-wash-day'}`} />
      <C1Inline text={text} onDiscover={onDiscover} />
    </p>
  );
};

export const SceneHeading: React.FC<{ children: React.ReactNode; tone?: 'night' | 'day' }> = ({ children, tone = 'night' }) => {
  const [ref, inView] = useInView<HTMLHeadingElement>(0.4);
  return (
    <h2
      ref={ref}
      className={`mx-auto max-w-2xl px-6 text-center font-display text-4xl font-semibold italic tracking-wide transition-all duration-[1800ms] sm:text-5xl ${
        inView ? 'opacity-100 blur-0 tracking-wide' : 'opacity-0 blur-md tracking-[0.3em]'
      } ${tone === 'night' ? 'text-[hsl(42_36%_92%)] [text-shadow:0_2px_24px_hsl(30_30%_4%)]' : 'text-[hsl(30_14%_16%)]'}`}
    >
      {children}
    </h2>
  );
};

/** Frameless image: edges dissolve into the scene through a radial mask. */
export const Vignette: React.FC<{ img: C1Image; className?: string; shape?: 'round' | 'soft'; style?: React.CSSProperties; imgClassName?: string }> = ({
  img,
  className = '',
  shape = 'soft',
  style,
  imgClassName = '',
}) => {
  const mask =
    shape === 'round'
      ? 'radial-gradient(circle at 50% 50%, #000 52%, transparent 70%)'
      : 'radial-gradient(ellipse at 50% 50%, #000 45%, transparent 72%)';
  return (
    <div className={`pointer-events-none ${className}`} style={{ WebkitMaskImage: mask, maskImage: mask, ...style }}>
      <img src={img.src} alt={img.alt} loading="lazy" decoding="async" className={`h-full w-full object-cover ${imgClassName}`} />
    </div>
  );
};

/* ---------------- Fog ---------------- */

export const Fog: React.FC<{ density?: number; tint?: string; className?: string }> = ({ density = 0.6, tint = '210 12% 82%', className = '' }) => {
  const reduced = useReducedMotion();
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} style={{ opacity: density }}>
      <div
        className={`absolute -inset-[20%] ${reduced ? '' : 'c1-fog-a'}`}
        style={{ background: `radial-gradient(ellipse 60% 40% at 30% 65%, hsl(${tint} / 0.55), transparent 70%)` }}
      />
      <div
        className={`absolute -inset-[20%] ${reduced ? '' : 'c1-fog-b'}`}
        style={{ background: `radial-gradient(ellipse 50% 35% at 72% 40%, hsl(${tint} / 0.45), transparent 70%)` }}
      />
      <div
        className={`absolute -inset-[20%] ${reduced ? '' : 'c1-fog-c'}`}
        style={{ background: `radial-gradient(ellipse 80% 30% at 50% 90%, hsl(${tint} / 0.5), transparent 70%)` }}
      />
    </div>
  );
};

/** Greenhouse glazing bars laid over a scene. */
export const Mullions: React.FC<{ opacity?: number }> = ({ opacity = 0.55 }) => (
  <div
    aria-hidden="true"
    className="pointer-events-none absolute inset-0"
    style={{
      opacity,
      backgroundImage:
        'repeating-linear-gradient(90deg, transparent 0 calc(20% - 3px), hsl(30 20% 8%) calc(20% - 3px) 20%), linear-gradient(transparent calc(38% - 2px), hsl(30 20% 8%) calc(38% - 2px) 38%, transparent 38%)',
    }}
  />
);

/** Water drops sliding down glass or falling from a can. */
export const Drops: React.FC<{ count?: number; className?: string; falling?: boolean }> = ({ count = 7, className = '', falling }) => {
  const reduced = useReducedMotion();
  if (reduced) return null;
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute inset-0 ${className}`}>
      {Array.from({ length: count }).map((_, i) => (
        <span
          key={i}
          className={falling ? 'c1-drop-fall absolute h-2.5 w-1 rounded-full bg-[hsl(200_40%_85%)]/80' : 'c1-drop-slide absolute h-3 w-[3px] rounded-full bg-[hsl(200_30%_90%)]/45'}
          style={{
            left: `${(i * 37 + 11) % 100}%`,
            top: falling ? '30%' : `${(i * 23) % 50}%`,
            animationDelay: `${(i * 1.7) % 9}s`,
            animationDuration: falling ? `${1.4 + (i % 3) * 0.3}s` : `${7 + (i % 4) * 2}s`,
          }}
        />
      ))}
    </div>
  );
};

/** Warm candle glow that flickers. */
export const LanternGlow: React.FC<{ x: string; y: string; size?: string; strength?: number }> = ({ x, y, size = '38vmax', strength = 1 }) => (
  <div
    aria-hidden="true"
    className="candle-flicker pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full mix-blend-screen"
    style={{ left: x, top: y, width: size, height: size, opacity: strength, background: 'radial-gradient(circle, hsl(32 90% 55% / 0.45), hsl(24 80% 40% / 0.15) 40%, transparent 68%)' }}
  />
);

/** Roots that creep behind the text, drawn as the reader scrolls. */
export const CreepingRoots: React.FC<{ progress: number; color?: string; className?: string }> = ({ progress, color = 'hsl(90 10% 72%)', className = '' }) => (
  <svg aria-hidden="true" viewBox="0 0 400 300" preserveAspectRatio="none" className={`pointer-events-none absolute ${className}`}>
    {[
      'M0 300 C 40 240, 30 200, 80 170 S 150 120, 140 60',
      'M60 300 C 90 250, 130 240, 150 200 S 210 150, 260 150',
      'M400 300 C 360 250, 380 210, 330 180 S 270 120, 290 40',
      'M300 300 C 280 260, 240 250, 220 210',
    ].map((d, i) => (
      <path
        key={i}
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={i % 2 ? 2.2 : 3.2}
        strokeLinecap="round"
        pathLength={100}
        strokeDasharray="100"
        strokeDashoffset={100 - Math.min(100, progress * 130 - i * 8)}
        opacity={0.55}
      />
    ))}
  </svg>
);

/* ---------------- Ernie — the greenhouse frog (unexplained easter egg) ---------------- */

/**
 * Ernie is a painted frog, not an icon: a tight, feathered crop of his
 * illustrated portrait, so he sits on benches and moss like part of the art.
 */
export const ErnieSprite: React.FC<{ size?: number; className?: string }> = ({ size = 48, className = '' }) => {
  const img = getMedia('ernie-portrait');
  const w = size;
  const h = Math.round(size / 1.35);
  const mask = 'radial-gradient(ellipse 50% 50% at 50% 52%, #000 56%, transparent 80%)';
  return (
    <span
      aria-hidden="true"
      className={`relative block overflow-hidden ${className}`}
      style={{ width: w, height: h, WebkitMaskImage: mask, maskImage: mask }}
    >
      {img && (
        <img
          src={img.src}
          alt=""
          loading="lazy"
          decoding="async"
          className="absolute max-w-none"
          style={{ width: w * 2.4, height: w * 2.4, left: -w * 0.65, top: h / 2 - w * 1.2 }}
        />
      )}
    </span>
  );
};

export const Frog: React.FC<{ className?: string; hidden?: boolean; label?: string; size?: number }> = ({
  className = '',
  hidden,
  label = 'Ernie, a small greenhouse frog',
  size = 46,
}) => {
  const reduced = useReducedMotion();
  const [gone, setGone] = useState(false);
  return (
    <button
      type="button"
      aria-label={label}
      title={gone ? undefined : ''}
      onClick={() => setGone(true)}
      className={`absolute z-20 transition-all duration-700 ${gone ? (reduced ? 'opacity-0' : 'c1-frog-away') : 'c1-frog-idle'} ${
        hidden ? 'pointer-events-none translate-y-3 opacity-0' : 'opacity-95'
      } ${className}`}
    >
      <ErnieSprite size={size} className="drop-shadow-[0_3px_3px_rgb(0_0_0/0.55)]" />
    </button>
  );
};

/**
 * Ernie's single dimensional leap. He sits on the page; once in view he
 * notices the reader, crouches, and leaps toward the viewer — growing,
 * blurring, casting a widening shadow — and drops out past the bottom of the
 * screen. Plays once per session per `storageKey`.
 */
export const FrogLeap: React.FC<{ className?: string; storageKey?: string; size?: number }> = ({
  className = '',
  storageKey = 'eb-c1-frog-leap',
  size = 46,
}) => {
  const reduced = useReducedMotion();
  const [ref, inView] = useInView<HTMLDivElement>(0.9);
  const [phase, setPhase] = useState<'sit' | 'leap' | 'gone'>('sit');
  const [rect, setRect] = useState<DOMRect | null>(null);
  const done = useRef(false);

  useEffect(() => {
    try {
      if (sessionStorage.getItem(storageKey) === '1') done.current = true;
    } catch {
      /* ignore */
    }
  }, [storageKey]);

  useEffect(() => {
    if (!inView || reduced || done.current || phase !== 'sit') return;
    const t = window.setTimeout(() => {
      if (!ref.current) return;
      setRect(ref.current.getBoundingClientRect());
      setPhase('leap');
      done.current = true;
      try {
        sessionStorage.setItem(storageKey, '1');
      } catch {
        /* ignore */
      }
      window.setTimeout(() => setPhase('gone'), 2300);
    }, 1400);
    return () => window.clearTimeout(t);
  }, [inView, reduced, phase, ref, storageKey]);

  return (
    <div ref={ref} className={`absolute ${className}`} style={{ width: size, height: Math.round(size / 1.35) }}>
      {phase === 'sit' && <ErnieSprite size={size} className="c1-frog-idle drop-shadow-[0_3px_3px_rgb(0_0_0/0.55)]" />}
      {phase === 'leap' &&
        rect &&
        createPortal(
          <div aria-hidden="true" className="pointer-events-none fixed z-[60] [perspective:600px]" style={{ left: rect.left, top: rect.top, width: rect.width, height: rect.height }}>
            <div className="c1-frog-leap-shadow absolute left-1/2 top-full h-3 w-full -translate-x-1/2 rounded-full bg-black/40 blur-sm" />
            <div className="c1-frog-leap h-full w-full">
              <ErnieSprite size={size} />
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
};
