import React, { useCallback, useMemo, useState } from 'react';
import { useDiscovery } from '@/contexts/DiscoveryContext';
import DiscoveryDrawer from '@/components/story/DiscoveryDrawer';
import ScienceDrawer from '@/components/science/ScienceDrawer';
import { getC1Manuscript } from './c1-data';
import { useReducedMotion } from './c1-hooks';
import { SoundControl, SoundProvider } from './SoundContext';
import Opening from './Opening';
import { SceneOutside, SceneWatering } from './SceneNight';
import SceneCurse from './SceneCurse';
import SceneMorning from './SceneMorning';
import SceneSpores from './SceneSpores';
import SceneSociety from './SceneSociety';
import SceneGrimoire from './SceneGrimoire';
import { SceneCharm, SceneEnding, SceneHazelReturns } from './SceneFinale';
import Afterword from './Afterword';
import ReadingPlace from '@/components/site/ReadingPlace';
import { ReadingViewToggle } from '@/components/site/ReadingControls';

/**
 * CHRONICLE I — THE NIGHT OF THE BLACK ROT · Cinematic Interactive Edition.
 * The manuscript (chronicle-i.md) supplies every word of the story; the page
 * itself becomes the greenhouse around it. Science stays in optional drawers.
 */
const CinematicChronicleOne: React.FC = () => {
  const m = useMemo(() => getC1Manuscript(), []);
  const reduced = useReducedMotion();
  const { discover } = useDiscovery();
  const [active, setActive] = useState<string | null>(null);
  const [science, setScience] = useState<string | null>(null);

  const onDiscover = useCallback(
    (id: string) => {
      discover(id);
      setActive(id);
    },
    [discover],
  );

  const props = { m, onDiscover, onScience: setScience, reduced };

  return (
    <SoundProvider>
      <article className="relative overflow-x-clip bg-[hsl(215_20%_4%)]" aria-label="The Night of the Black Rot">
        <Opening {...props} />
        <SceneWatering {...props} />
        <SceneOutside {...props} />
        <SceneCurse {...props} />
        <SceneMorning {...props} />
        <SceneSpores {...props} />
        <SceneSociety {...props} />
        <SceneGrimoire {...props} />
        <SceneCharm {...props} />
        <SceneHazelReturns {...props} />
        <SceneEnding {...props} />
        <Afterword onDiscover={onDiscover} onScience={setScience} />
      </article>
      <SoundControl />
      <ReadingPlace storageKey="eb-c1-place" />
      <ReadingViewToggle floating />
      <DiscoveryDrawer discoveryId={active} onClose={() => setActive(null)} />
      <ScienceDrawer id={science} onClose={() => setScience(null)} />
    </SoundProvider>
  );
};

export default CinematicChronicleOne;
