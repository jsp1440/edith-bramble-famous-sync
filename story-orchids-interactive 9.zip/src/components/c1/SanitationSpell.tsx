import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowRight, ChevronDown, ExternalLink, Flame } from 'lucide-react';
import {
  EVIDENCE_KEY,
  KAREN_TRANSITION,
  OOMYCETE_NOTE,
  SPELL_IMAGE,
  SPELL_INTRO,
  SPELL_SOURCES,
  SPELL_STEPS,
} from '@/content/sanitation-spell';
import { useSeenOnce } from './c1-hooks';
import { C1Inline, StoryText } from './Atmosphere';

type Fn = (id: string) => void;

/* ---------------- Karen reads the spell ---------------- */

export const KarenReadsTheSpell: React.FC<{ onDiscover: Fn }> = ({ onDiscover }) => (
  <div className="mt-16">
    {KAREN_TRANSITION.map((t, i) => (
      <StoryText key={i} text={t.text} onDiscover={onDiscover} tone="day" variant={t.quote ? 'quote' : 'body'} />
    ))}
  </div>
);

/* ---------------- ISOLATE ↓ … → horizontal mnemonic (plays once) ---------------- */

const WORDS = SPELL_STEPS.map((s) => s.word);

const MnemonicReveal: React.FC<{ reduced: boolean }> = ({ reduced }) => {
  const [ref, seen] = useSeenOnce<HTMLDivElement>(0.5);
  const [count, setCount] = useState(reduced ? WORDS.length : 0);
  const [row, setRow] = useState(reduced);
  const stackRef = useRef<HTMLDivElement>(null);
  const rowRef = useRef<HTMLDivElement>(null);
  const [h, setH] = useState<{ stack: number; row: number }>({ stack: 0, row: 0 });

  useLayoutEffect(() => {
    const measure = () => setH({ stack: stackRef.current?.scrollHeight || 0, row: rowRef.current?.scrollHeight || 0 });
    measure();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    if (ro) {
      stackRef.current && ro.observe(stackRef.current);
      rowRef.current && ro.observe(rowRef.current);
    }
    window.addEventListener('resize', measure);
    return () => {
      ro?.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, []);

  useEffect(() => {
    if (reduced) {
      setCount(WORDS.length);
      setRow(true);
      return;
    }
    if (!seen || row) return;
    if (count < WORDS.length) {
      const t = window.setTimeout(() => setCount((c) => c + 1), count === 0 ? 250 : 560);
      return () => window.clearTimeout(t);
    }
    const t = window.setTimeout(() => setRow(true), 1100);
    return () => window.clearTimeout(t);
  }, [seen, count, row, reduced]);

  const height = row ? h.row : h.stack;

  return (
    <div ref={ref} className="relative mx-auto my-10">
      <p className="sr-only">{WORDS.join(', ')}.</p>
      <div
        aria-hidden="true"
        className="relative overflow-hidden transition-[height] duration-[900ms] ease-in-out"
        style={{ height: height || undefined }}
      >
        {/* vertical cascade */}
        <div
          ref={stackRef}
          className={`absolute inset-x-0 top-0 flex flex-col items-center py-2 transition-opacity duration-700 ${row ? 'pointer-events-none opacity-0' : 'opacity-100'}`}
        >
          {WORDS.map((w, i) => (
            <React.Fragment key={w}>
              {i > 0 && (
                <ArrowDown
                  className="my-1 h-5 w-5 text-[hsl(350_40%_36%)] transition-opacity duration-500"
                  style={{ opacity: i < count ? 0.8 : 0 }}
                />
              )}
              <span
                className="c1-mnemonic-word text-[hsl(30_18%_12%)] transition-all duration-700"
                style={{ opacity: i < count ? 1 : 0, transform: i < count ? 'none' : 'translateY(10px)', filter: i < count ? 'none' : 'blur(3px)' }}
              >
                {w}
              </span>
            </React.Fragment>
          ))}
        </div>
        {/* the horizontal mnemonic */}
        <div
          ref={rowRef}
          className={`absolute inset-x-0 top-0 flex flex-wrap items-center justify-center gap-x-3 gap-y-3 px-2 py-5 transition-opacity duration-700 sm:gap-x-4 ${row ? 'opacity-100' : 'opacity-0'}`}
        >
          {WORDS.map((w, i) => (
            <React.Fragment key={w}>
              {i > 0 && <ArrowRight className="h-5 w-5 shrink-0 text-[hsl(350_40%_36%)]" />}
              <span className={`c1-mnemonic-word text-[hsl(30_18%_12%)] ${row && !reduced ? 'c1-step-in' : ''}`} style={{ animationDelay: `${i * 90}ms` }}>
                {w}
              </span>
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};

/* ---------------- Where the rot ends — where to cut ---------------- */

const CutDiagram: React.FC = () => (
  <figure className="mt-6 rounded-md border border-[hsl(36_20%_74%)] bg-[hsl(42_44%_98%)] p-4 sm:p-6">
    <svg viewBox="0 0 640 200" role="img" aria-labelledby="cut-diagram-title" className="h-auto w-full">
      <title id="cut-diagram-title">
        An orchid leaf with black rot at its tip. A dashed line marks the visible edge of the rot; the cut is made further back, in apparently healthy green tissue.
      </title>
      <defs>
        <linearGradient id="leaf-rot" x1="0" x2="1" y1="0" y2="0">
          <stop offset="0" stopColor="hsl(20 20% 8%)" />
          <stop offset="0.3" stopColor="hsl(20 22% 12%)" />
          <stop offset="0.4" stopColor="hsl(30 30% 26%)" />
          <stop offset="0.47" stopColor="hsl(70 20% 38%)" />
          <stop offset="0.55" stopColor="hsl(110 26% 36%)" />
          <stop offset="1" stopColor="hsl(115 30% 32%)" />
        </linearGradient>
      </defs>
      {/* leaf */}
      <path d="M20 100 C 90 30, 300 18, 470 40 C 560 52, 620 80, 630 100 C 620 120, 560 148, 470 160 C 300 182, 90 170, 20 100 Z" fill="url(#leaf-rot)" />
      <path d="M24 100 C 220 96, 430 98, 630 100" stroke="hsl(80 20% 70% / 0.45)" strokeWidth="2" fill="none" />
      {/* visible edge of the rot */}
      <line x1="262" y1="20" x2="262" y2="182" stroke="hsl(36 60% 60%)" strokeWidth="3" strokeDasharray="8 7" />
      {/* the cut: beyond the line, into healthy tissue */}
      <line x1="360" y1="12" x2="360" y2="190" stroke="hsl(350 55% 42%)" strokeWidth="4" />
      <path d="M270 190 L 352 190" stroke="hsl(350 55% 42%)" strokeWidth="2.5" markerEnd="url(#arrow)" />
      <defs>
        <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 z" fill="hsl(350 55% 42%)" />
        </marker>
      </defs>
    </svg>
    <figcaption className="c1-edu-note mt-4 grid gap-2 text-[hsl(30_16%_14%)] sm:grid-cols-3">
      <span className="flex items-start gap-2">
        <span className="mt-2 h-3 w-5 shrink-0 rounded-sm bg-[hsl(20_20%_10%)]" aria-hidden="true" /> Blackened, infected tissue
      </span>
      <span className="flex items-start gap-2">
        <span className="mt-2 h-0 w-5 shrink-0 border-t-[3px] border-dashed border-[hsl(36_60%_52%)]" aria-hidden="true" /> The visible edge of the rot
      </span>
      <span className="flex items-start gap-2">
        <span className="mt-2 h-0 w-5 shrink-0 border-t-4 border-[hsl(350_55%_42%)]" aria-hidden="true" /> Cut here — into apparently healthy tissue
      </span>
    </figcaption>
  </figure>
);

/* ---------------- The whole reveal ---------------- */

const toneClass = {
  science: 'border-[hsl(122_22%_34%)] bg-[hsl(110_24%_94%)]',
  grower: 'border-[hsl(350_40%_40%)] bg-[hsl(350_40%_96%)]',
  story: 'border-[hsl(30_14%_40%)] bg-[hsl(40_30%_92%)]',
};

export const ScienceInsideTheSpell: React.FC<{ onDiscover: Fn; onScience: Fn; reduced: boolean }> = ({ onDiscover, onScience, reduced }) => {
  const [open, setOpen] = useState(false);
  return (
    <section aria-labelledby="science-inside-spell" className="relative mx-auto mt-16 max-w-4xl px-4 sm:px-6">
      <div className="rounded-lg border border-[hsl(36_20%_72%)] bg-[hsl(42_44%_97%)] px-5 py-10 shadow-[0_10px_40px_-18px_hsl(30_30%_20%/0.45)] sm:px-10 sm:py-14">
        <div className="mx-auto max-w-[760px] text-center">
          <p className="font-label text-[0.8rem] uppercase text-[hsl(var(--botanical))]">{SPELL_INTRO.eyebrow}</p>
          <h3 id="science-inside-spell" className="c1-edu-h mt-3 font-display font-semibold text-[hsl(30_18%_12%)]">
            {SPELL_INTRO.title}
          </h3>
          <p className="c1-edu-lead mt-5 font-display italic text-[hsl(30_18%_14%)]">{SPELL_INTRO.opening}</p>
        </div>

        <MnemonicReveal reduced={reduced} />

        <figure className="mx-auto max-w-3xl overflow-hidden rounded-md border border-[hsl(36_20%_72%)]">
          <img src={SPELL_IMAGE.src} alt={SPELL_IMAGE.alt} loading="lazy" decoding="async" className="aspect-[3/2] w-full object-cover" />
          <figcaption className="c1-edu-note bg-[hsl(40_30%_92%)] px-4 py-3 italic text-[hsl(30_16%_18%)]">{SPELL_IMAGE.caption}</figcaption>
        </figure>

        <ol className="mx-auto mt-12 max-w-[760px] space-y-12">
          {SPELL_STEPS.map((s, i) => (
            <li key={s.word} className="relative pl-14 sm:pl-16">
              <span
                aria-hidden="true"
                className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-full border-2 border-[hsl(var(--botanical))] font-label text-[1.125rem] text-[hsl(var(--botanical))] sm:h-12 sm:w-12"
              >
                {i + 1}
              </span>
              <h4 className="c1-edu-sub font-label uppercase text-[hsl(30_18%_12%)]">{s.word}</h4>
              <p className="c1-edu-note mt-1 font-display italic text-[hsl(350_36%_30%)]">Hazel wrote: “{s.verse}”</p>
              {s.body.map((b, j) => (
                <p key={j} className="c1-edu mt-3">
                  <C1Inline text={b} onDiscover={onDiscover} />
                </p>
              ))}
              {s.safety && (
                <p role="note" className="c1-edu-note mt-4 flex items-start gap-3 rounded-md border-l-4 border-[hsl(24_80%_45%)] bg-[hsl(36_80%_94%)] px-4 py-3 text-[hsl(24_40%_16%)]">
                  <Flame className="mt-1 h-5 w-5 shrink-0 text-[hsl(24_80%_42%)]" aria-hidden="true" />
                  <span>
                    <strong>Safety: </strong>
                    {s.safety}
                  </span>
                </p>
              )}
              {s.diagram && <CutDiagram />}
              {s.aside && (
                <div className="mt-6 rounded-md border border-[hsl(350_40%_40%)]/40 bg-[hsl(350_40%_97%)] p-5 sm:p-6">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="relative h-4 w-3 shrink-0 rounded-b-full rounded-t-[60%] bg-[hsl(350_65%_34%)]" aria-hidden="true" />
                    <p className="c1-edu-sub font-display font-semibold italic text-[hsl(350_45%_24%)]">{s.aside.title}</p>
                    <span className="rounded-full border border-[hsl(350_40%_40%)]/50 px-3 py-0.5 font-ui text-[1rem] text-[hsl(350_45%_26%)]">{s.aside.tag}</span>
                  </div>
                  {s.aside.body.map((b, j) => (
                    <p key={j} className="c1-edu mt-3">
                      <C1Inline text={b} onDiscover={onDiscover} />
                    </p>
                  ))}
                </div>
              )}
            </li>
          ))}
        </ol>

        {/* Evidence key */}
        <div className="mx-auto mt-14 grid max-w-[760px] gap-3">
          {EVIDENCE_KEY.map((e) => (
            <div key={e.label} className={`rounded-md border-l-4 px-5 py-4 ${toneClass[e.tone]}`}>
              <p className="font-label text-[0.8rem] uppercase text-[hsl(30_18%_16%)]">{e.label}</p>
              <p className="c1-edu-note mt-1 text-[hsl(30_18%_12%)]">{e.items}</p>
            </div>
          ))}
        </div>

        {/* Why an ordinary fungicide may not be enough */}
        <div className="mx-auto mt-10 max-w-[760px] rounded-md border border-[hsl(36_20%_72%)] bg-white/60">
          <button
            type="button"
            aria-expanded={open}
            aria-controls="oomycete-note"
            onClick={() => setOpen((o) => !o)}
            className="flex min-h-[56px] w-full items-center justify-between gap-4 px-5 py-4 text-left font-display text-[1.5rem] font-semibold text-[hsl(30_18%_12%)] hover:bg-black/[0.03]"
          >
            {OOMYCETE_NOTE.title}
            <ChevronDown className={`h-6 w-6 shrink-0 transition-transform ${open ? 'rotate-180' : ''}`} aria-hidden="true" />
          </button>
          {open && (
            <div id="oomycete-note" className="border-t border-[hsl(36_20%_78%)] px-5 pb-5">
              {OOMYCETE_NOTE.body.map((b, j) => (
                <p key={j} className="c1-edu mt-4">
                  <C1Inline text={b} onDiscover={onDiscover} />
                </p>
              ))}
            </div>
          )}
        </div>

        {/* Sources */}
        <div className="no-print mx-auto mt-8 flex max-w-[760px] flex-wrap items-center gap-x-6 gap-y-2">
          {SPELL_SOURCES.map((s) => (
            <a
              key={s.href}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-2 font-ui text-[1rem] text-[hsl(var(--botanical))] underline decoration-dotted underline-offset-4 hover:text-[hsl(var(--moss))]"
            >
              {s.label} <ExternalLink className="h-4 w-4" aria-hidden="true" />
            </a>
          ))}
          <button
            type="button"
            onClick={() => onScience('black-rot')}
            className="inline-flex min-h-[44px] items-center gap-2 font-ui text-[1rem] text-[hsl(var(--botanical))] underline decoration-dotted underline-offset-4 hover:text-[hsl(var(--moss))]"
          >
            What black rot actually is <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        {/* The takeaway */}
        <div className="mx-auto mt-14 max-w-[760px] border-t border-[hsl(36_20%_74%)] pt-10 text-center">
          <p className="c1-mnemonic-stack font-label uppercase text-[hsl(30_18%_12%)]">
            {WORDS.map((w) => (
              <span key={w} className="block">
                {w}.
              </span>
            ))}
          </p>
          <p className="c1-edu-lead mt-6 font-display font-semibold italic text-[hsl(var(--botanical))]">{SPELL_INTRO.closing}</p>
        </div>
      </div>
    </section>
  );
};
