import React from 'react';
import { C1_IMAGES, scene, seg, type C1Image, type C1Manuscript } from './c1-data';
import { useInView, useScrollProgress, useSeenOnce } from './c1-hooks';
import { Fog, SceneHeading, StoryText, Vignette } from './Atmosphere';
import { MoodZone } from './SoundContext';

type Props = { m: C1Manuscript; onDiscover: (id: string) => void; reduced: boolean };

const Reveal: React.FC<{ img: C1Image; caption: string; side: 'left' | 'right'; size?: string }> = ({ img, caption, side, size = 'h-[40vh] w-[40vh] sm:h-[52vh] sm:w-[52vh]' }) => {
  const [ref, inView] = useInView<HTMLDivElement>(0.45);
  return (
    <figure ref={ref} className={`relative flex flex-col ${side === 'left' ? 'items-start md:ml-[10%]' : 'items-end md:mr-[10%]'} px-4`}>
      <div className={`${size} transition-all duration-[1600ms] ease-out ${inView ? 'scale-100 opacity-100 blur-0' : 'scale-95 opacity-0 blur-md'}`}>
        <Vignette img={img} className="h-full w-full" />
      </div>
      <figcaption className={`-mt-6 font-hand text-xl text-[hsl(30_20%_12%)] transition-opacity delay-700 duration-1000 ${inView ? 'opacity-100' : 'opacity-0'}`}>{caption}</figcaption>
    </figure>
  );
};

/** A single blackened leaf that detaches and falls in front of the text. */
const FallingDeadLeaf: React.FC<{ reduced: boolean }> = ({ reduced }) => {
  const [ref, seen] = useSeenOnce<HTMLDivElement>(1);
  if (reduced) return null;
  return (
    <div ref={ref} aria-hidden="true" className="pointer-events-none relative z-30 mx-auto h-0 max-w-xl">
      <svg viewBox="0 0 40 90" className={`absolute left-[58%] top-0 h-28 w-12 opacity-0 ${seen ? 'leaf-fall' : ''}`} style={{ animationDuration: '8s' }}>
        <path d="M20 2C8 20 4 50 20 88 36 50 32 20 20 2Z" fill="hsl(40 30% 22%)" />
        <path d="M20 40C12 46 10 64 20 88 30 64 28 46 20 40Z" fill="hsl(300 25% 7%)" />
        <path d="M20 6v80" stroke="hsl(40 30% 14%)" strokeWidth="1.2" />
      </svg>
    </div>
  );
};

const SceneMorning: React.FC<Props> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const bg = scene('greenhouse-interior');
  const wide = scene('scene-black-rot');
  const sick = seg(p, 0.25, 0.8);

  return (
    <section ref={ref} className="relative bg-[hsl(200_8%_86%)]" aria-label="The morning horror">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          <img
            src={bg.src}
            alt={bg.alt}
            loading="lazy"
            className="absolute inset-0 h-full w-full object-cover"
            style={{ filter: `brightness(${1.05 - sick * 0.35}) saturate(${1 - sick * 0.7}) sepia(${sick * 0.25})` }}
          />
          {/* the wider greenhouse — damage everywhere, revealed last */}
          <img src={wide.src} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover mix-blend-multiply" style={{ opacity: seg(p, 0.72, 0.9) * 0.75 }} />
          <div className="absolute inset-0 bg-[hsl(200_15%_92%)]" style={{ opacity: 0.45 - sick * 0.3 }} />
          <Fog density={0.35} tint="200 10% 95%" />
        </div>
      </div>

      <MoodZone mood="morning" className="relative z-10 pb-[30vh] pt-[45vh]">
        <SceneHeading tone="day">{m.headings[0]}</SceneHeading>
        <div className="h-[40vh]" />
        <Reveal img={C1_IMAGES.wetLeaf} caption="A leaf." side="right" size="h-[30vh] w-[30vh] sm:h-[38vh] sm:w-[38vh]" />
        <div className="h-[18vh]" />
        <Reveal img={C1_IMAGES.lesion} caption="A lesion." side="left" />
        <div className="h-[18vh]" />
        <Reveal img={C1_IMAGES.rottenRoots} caption="A root." side="right" />
        <div className="h-[18vh]" />
        <Reveal img={wide} caption="Another plant." side="left" />
        <div className="h-[50vh]" />
        <FallingDeadLeaf reduced={reduced} />
        <StoryText text={m.p[6] || ''} onDiscover={onDiscover} tone="day" />
      </MoodZone>
    </section>
  );
};

export default SceneMorning;
