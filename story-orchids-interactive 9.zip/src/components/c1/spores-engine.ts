import { clamp, seg } from './c1-data';

/* ------------------------------------------------------------------
   Edith's disappearance — geometry + particle engine.

   EDITH NEVER MOVES. The only thing that moves is Hazel's spore cloud.
   Everything is expressed in fractions of the painted plate
   (C1_IMAGES.edithMorning, 1376×768). The aftermath plate is the SAME
   camera with Edith removed and is drawn into the same rectangle, so the
   swap happens in place — and only while the cloud completely hides her.
------------------------------------------------------------------- */

export const IW = 1376;
export const IH = 768;
export const POS_X = 0.74;
export const POS_Y = 0.5;

export type Pt = { x: number; y: number };
export type Rect = { left: number; top: number; width: number; height: number };

export function coverRect(w: number, h: number): Rect {
  const k = Math.max(w / IW, h / IH);
  const width = IW * k;
  const height = IH * k;
  return { left: (w - width) * POS_X, top: (h - height) * POS_Y, width, height };
}

/* ---------------- landmarks (plate fractions) ---------------- */
export const FEET: Pt = { x: 0.648, y: 0.915 };
const HEAD_X = 0.722;
export const CENTER: Pt = { x: 0.69, y: 0.58 };
export const FACE: Pt = { x: 0.738, y: 0.325 };
export const HAND: Pt = { x: 0.8, y: 0.45 };
/** beneath the drooping black-rotted orchid on the left bench — where the cloud is born */
export const ORIGIN: Pt = { x: 0.36, y: 0.735 };
/** portrait fallback: beneath the right-hand bench, below the orchid she is cutting */
const ORIGIN_R: Pt = { x: 0.84, y: 0.82 };
/** top of the tipped watering can in the aftermath plate */
const CAN_TOP: Pt = { x: 0.624, y: 0.762 };
const BODY_HALF_W = 0.07;
const BODY_H = 0.68;

export const EDITH_CLIP =
  'polygon(69.4% 23.4%, 72.5% 23.5%, 76% 30%, 75.4% 35.5%, 78% 40%, 81.4% 43%, 82% 46.5%, 79% 48.5%, 77.5% 52%, 78.2% 57.5%, 75% 59%, 71.6% 65%, 70.9% 77%, 65% 78%, 64.7% 91%, 62.3% 92%, 60.3% 80%, 60.2% 63.8%, 61% 43%, 65.4% 34.5%, 68.7% 31.9%, 68.3% 25.4%)';
const EDITH_POLY: number[][] = (EDITH_CLIP.match(/[\d.]+% [\d.]+%/g) || []).map((s) => s.split(' ').map((v) => parseFloat(v) / 100));

function inPoly(x: number, y: number, poly: number[][]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

/* ---------------- timeline (s = 0 → 1) ---------------- */
export const TL = {
  first: 0.015, // a few dark specks: did you see that?
  puff: 0.08, // the PUFF — the cloud is born
  turn: 0.17, // it changes direction, toward Edith
  feet: 0.29, // reaches her shoes
  shoulders: 0.42, // has climbed to her shoulders
  ghostIn: 0.58, // the spores form a figure
  ghostOut: 0.665, // …which collapses into Edith
  ghostGone: 0.7,
  engulf: 0.7, // closes over her, feet first
  clink: 0.752, // shears hit the stone (heard, hidden by the cloud)
  hand: 0.798,
  face: 0.812, // the last glimpse of her face
  hidden: 0.833, // she is completely hidden
  swap: 0.836, // Edith → empty plate (under the cloud)
  swapEnd: 0.852,
  implode: 0.842,
  burst: 0.88, // WHUMP
};

export const hMax = (s: number) => 0.04 + 1.06 * seg(s, TL.feet - 0.02, TL.shoulders + 0.06);
export const ghostAmt = (s: number) => seg(s, TL.ghostIn, TL.ghostIn + 0.04) * (1 - seg(s, TL.ghostOut, TL.ghostGone));
export const dimAt = (s: number) => (0.3 * seg(s, TL.puff, 0.45) + 0.3 * seg(s, TL.engulf, TL.hidden)) * (1 - seg(s, TL.burst, 1));

type Kind = 'mote' | 'mist' | 'near';
type Mode = 'idle' | 'cloud' | 'orbit' | 'ghost' | 'burst';
interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  s: number;
  a: number;
  aMax: number;
  kind: Kind;
  mode: Mode;
  front: boolean;
  seed: number;
  glint: boolean;
  ox: number;
  oy: number;
  th: number;
  h: number;
  hPref: number;
  r: number;
  w: number;
  gi: number;
  grow: number;
}
interface Occ {
  x: number;
  y: number;
  t0: number;
  hf: number;
  face: boolean;
  hand: boolean;
  floor: boolean;
  R: number;
}
type GPt = { x: number; y: number; front: boolean };

function sprite(size: number, hsl: string, a0: number, a1: number) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, `hsla(${hsl}, ${a0})`);
  grd.addColorStop(0.45, `hsla(${hsl}, ${a1})`);
  grd.addColorStop(1, `hsla(${hsl}, 0)`);
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  return c;
}
function ringSprite(size: number) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const g = c.getContext('2d')!;
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, 'hsla(275, 14%, 6%, 0)');
  grd.addColorStop(0.55, 'hsla(275, 14%, 6%, 0)');
  grd.addColorStop(0.74, 'hsla(275, 14%, 6%, 0.55)');
  grd.addColorStop(1, 'hsla(275, 14%, 6%, 0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  return c;
}

/** A vague, tall, spore-formed figure standing just behind Edith: veiled head, long arms reaching around her. */
function ghostShape(): GPt[] {
  const pts: GPt[] = [];
  const add = (x: number, y: number, front = false) => pts.push({ x, y, front });
  const bez = (a: Pt, b: Pt, c: Pt, d: Pt, n: number, front: (u: number) => boolean, spread: number) => {
    for (let i = 0; i < n; i++) {
      const u = i / (n - 1);
      const m = 1 - u;
      const x = m * m * m * a.x + 3 * m * m * u * b.x + 3 * m * u * u * c.x + u * u * u * d.x;
      const y = m * m * m * a.y + 3 * m * m * u * b.y + 3 * m * u * u * c.y + u * u * u * d.y;
      add(x + (Math.random() - 0.5) * spread, y + (Math.random() - 0.5) * spread * 1.6, front(u));
    }
  };
  // veiled head (with two hollow "eyes" and a hint of a mouth left empty)
  for (let i = 0; i < 90; i++) {
    const an = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random());
    const x = 0.704 + Math.cos(an) * 0.021 * r;
    const y = 0.163 + Math.sin(an) * 0.046 * r;
    const hollow = Math.hypot((x - 0.697) / 0.005, (y - 0.158) / 0.009) < 1 || Math.hypot((x - 0.712) / 0.005, (y - 0.158) / 0.009) < 1 || Math.hypot((x - 0.705) / 0.006, (y - 0.188) / 0.006) < 1;
    if (!hollow) add(x, y);
  }
  // neck / veil falling to the shoulders
  bez({ x: 0.704, y: 0.2 }, { x: 0.7, y: 0.225 }, { x: 0.708, y: 0.24 }, { x: 0.705, y: 0.262 }, 16, () => false, 0.012);
  // shoulders
  bez({ x: 0.648, y: 0.3 }, { x: 0.675, y: 0.255 }, { x: 0.735, y: 0.255 }, { x: 0.765, y: 0.295 }, 30, () => false, 0.01);
  // long left arm, reaching down past her
  bez({ x: 0.648, y: 0.3 }, { x: 0.6, y: 0.34 }, { x: 0.57, y: 0.46 }, { x: 0.585, y: 0.58 }, 46, (u) => u > 0.82, 0.01);
  // fingers
  [-0.012, 0, 0.012].forEach((d) => bez({ x: 0.585, y: 0.58 }, { x: 0.586 + d, y: 0.6 }, { x: 0.588 + d * 1.4, y: 0.615 }, { x: 0.59 + d * 1.8, y: 0.635 }, 6, () => true, 0.004));
  // long right arm, curling OVER Edith's shoulder toward her hand
  bez({ x: 0.765, y: 0.295 }, { x: 0.84, y: 0.29 }, { x: 0.875, y: 0.4 }, { x: 0.815, y: 0.47 }, 50, (u) => u > 0.62, 0.01);
  [-0.01, 0, 0.01].forEach((d) => bez({ x: 0.815, y: 0.47 }, { x: 0.805, y: 0.48 + d }, { x: 0.795, y: 0.49 + d }, { x: 0.785, y: 0.5 + d * 1.5 }, 6, () => true, 0.004));
  // the body / gown behind Edith, dissolving toward the floor
  for (let i = 0; i < 140; i++) {
    const v = Math.pow(Math.random(), 0.8);
    const y = 0.3 + v * 0.6;
    const half = 0.035 + (y < 0.46 ? 0 : (y - 0.46) * 0.17);
    const side = Math.random() < 0.5 ? -1 : 1;
    const edge = Math.random() < 0.7;
    const x = 0.705 + side * (edge ? half * (0.85 + Math.random() * 0.2) : Math.random() * half);
    if (Math.random() > v * 0.55) add(x, y);
  }
  return pts;
}

export class SporeEngine {
  private parts: P[] = [];
  private occ: Occ[] = [];
  private ghost: GPt[] = ghostShape();
  private moteDark = sprite(32, '275, 16%, 5%', 0.95, 0.65);
  private moteLight = sprite(32, '160, 10%, 80%', 0.7, 0.25);
  private mist = sprite(128, '272, 12%, 7%', 0.55, 0.28);
  private core = sprite(128, '280, 18%, 4%', 0.97, 0.78);
  private ring = ringSprite(256);
  private maxMotes: number;
  private maxMist: number;
  private burstCount: number;
  private puffCount: number;
  private small: boolean;
  private burstAt = 0;
  private lander: { x: number; y: number; t0: number } | null = null;
  geo: Rect = { left: 0, top: 0, width: 0, height: 0 };
  dpr = 1;

  constructor(small: boolean) {
    this.small = small;
    this.maxMotes = small ? 380 : 900;
    this.maxMist = small ? 30 : 70;
    this.burstCount = small ? 360 : 1000;
    this.puffCount = small ? 260 : 620;
    this.buildOccluder();
  }

  reset() {
    this.parts = [];
    this.burstAt = 0;
    this.lander = null;
  }

  /** The dense part of the cloud that finally hides her: sampled inside her silhouette + the floor around her feet. */
  private buildOccluder() {
    const sx = this.small ? 0.015 : 0.012;
    const sy = sx * 1.75;
    const R = 0.032;
    for (let y = 0.22; y <= 0.93; y += sy) {
      for (let x = 0.595; x <= 0.83; x += sx) {
        const jx = x + (Math.random() - 0.5) * sx * 0.6;
        const jy = y + (Math.random() - 0.5) * sy * 0.6;
        if (!inPoly(jx, jy, EDITH_POLY)) continue;
        const hf = clamp((FEET.y - jy) / (FEET.y - 0.23));
        // soft blobs reach R beyond their centre, so the last openings are protected by a ring that closes inward
        const dFace = Math.hypot((jx - FACE.x) / (0.022 + R), (jy - FACE.y) / (0.045 + R * 1.79));
        const dHand = Math.hypot((jx - HAND.x) / (0.02 + R), (jy - HAND.y) / (0.035 + R * 1.79));
        const face = dFace < 1;
        const hand = !face && dHand < 1;
        const base = TL.engulf + 0.085 * hf;
        const t0 = face ? Math.max(base, TL.face - 0.016 * dFace) : hand ? Math.max(base, TL.hand - 0.016 * dHand) : base;
        this.occ.push({ x: jx, y: jy, t0, hf, face, hand, floor: false, R });
      }
    }
    // the pool of cloud around her feet also hides the upright can (the tipped one waits in the empty plate)
    const fx = this.small ? 0.028 : 0.02;
    for (let y = 0.74; y <= 1.0; y += 0.034) {
      for (let x = 0.52; x <= 0.81; x += fx) {
        this.occ.push({ x: x + (Math.random() - 0.5) * 0.01, y: y + (Math.random() - 0.5) * 0.015, t0: TL.engulf + 0.01 + Math.random() * 0.03, hf: 0, face: false, hand: false, floor: true, R: 0.048 });
      }
    }
  }

  private pt(o: Pt): Pt {
    return { x: (this.geo.left + o.x * this.geo.width) * this.dpr, y: (this.geo.top + o.y * this.geo.height) * this.dpr };
  }
  private get W() {
    return this.geo.width * this.dpr;
  }

  private make(kind: Kind, x: number, y: number, extra: Partial<P> = {}): P {
    const d = this.dpr;
    const big = Math.random() < 0.08;
    const an = Math.random() * Math.PI * 2;
    const rr = Math.sqrt(Math.random());
    return {
      x,
      y,
      vx: 0,
      vy: 0,
      s: kind === 'mist' ? this.W * (0.03 + Math.random() * 0.06) : (big ? 3.8 + Math.random() * 2.5 : 0.9 + Math.random() * 2.3) * d,
      a: 0,
      aMax: 1,
      kind,
      mode: 'idle',
      front: Math.random() < 0.4,
      seed: Math.random() * 1000,
      glint: kind === 'mote' && Math.random() < 0.05,
      ox: Math.cos(an) * rr,
      oy: Math.sin(an) * rr * 0.75,
      th: Math.random() * Math.PI * 2,
      h: 0,
      hPref: 0.05 + Math.random() * 1.1,
      r: 0.5 + Math.random() * 1.4,
      w: (0.02 + Math.random() * 0.03) * (Math.random() < 0.85 ? 1 : -1),
      gi: -1,
      grow: 0,
      ...extra,
    };
  }

  /** Stage 1: a few specks where no one is looking — under the benches, round the sick orchid, between pots. */
  private idleSpawn(): P {
    const zones = [
      { x: 0.2, y: 0.8, w: 0.3, h: 0.15 },
      { x: 0.3, y: 0.63, w: 0.12, h: 0.14 },
      { x: 0.8, y: 0.76, w: 0.15, h: 0.18 },
      { x: 0.1, y: 0.6, w: 0.5, h: 0.08 },
      { x: 0.5, y: 0.86, w: 0.1, h: 0.12 },
    ];
    const z = zones[Math.floor(Math.random() * zones.length)];
    const q = this.pt({ x: z.x + Math.random() * z.w, y: z.y + Math.random() * z.h });
    const p = this.make('mote', q.x, q.y, { aMax: 0.55 + Math.random() * 0.35 });
    p.s = (0.8 + Math.random() * 1.6) * this.dpr;
    return p;
  }

  /** Stage 2: THE PUFF. Hundreds of fine spores bloom out of the rot in one soft, slow-motion breath. */
  puff() {
    const o = this.pt(this.src.o);
    const d = this.dpr;
    for (let i = 0; i < this.puffCount; i++) {
      const an = Math.random() * Math.PI * 2;
      const sp = (1.5 + Math.pow(Math.random(), 0.6) * 9) * d;
      const p = this.make('mote', o.x + (Math.random() - 0.5) * 14 * d, o.y + (Math.random() - 0.5) * 10 * d, { mode: 'cloud' });
      p.vx = Math.cos(an) * sp;
      p.vy = Math.sin(an) * sp * 0.8 - 1.6 * d;
      p.a = 0.9;
      this.parts.push(p);
    }
    const nm = this.small ? 16 : 34;
    for (let i = 0; i < nm; i++) {
      const an = Math.random() * Math.PI * 2;
      const sp = (0.8 + Math.random() * 3) * d;
      const p = this.make('mist', o.x, o.y, { mode: 'cloud', grow: 1 });
      p.s = this.W * (0.015 + Math.random() * 0.02);
      p.vx = Math.cos(an) * sp;
      p.vy = Math.sin(an) * sp * 0.7 - 0.8 * d;
      p.a = 0.8;
      p.ox *= 0.7;
      p.oy *= 0.7;
      this.parts.push(p);
    }
    // the stage-1 specks are swept into it
    this.parts.forEach((q) => {
      if (q.mode === 'idle') {
        q.mode = 'cloud';
        q.aMax = 1;
      }
    });
  }

  /** Stage 5: part of the cloud assembles into a figure. */
  formGhost() {
    const n = this.ghost.length;
    let k = 0;
    this.parts.forEach((q) => {
      if (q.mode === 'orbit' && q.kind === 'mote' && Math.random() < 0.45) {
        q.mode = 'ghost';
        q.gi = k++ % n;
      }
    });
    const extra = this.small ? 220 : 520;
    const c = this.pt(CENTER);
    for (let i = 0; i < extra; i++) {
      const p = this.make('mote', c.x + (Math.random() - 0.5) * this.W * 0.2, c.y + (Math.random() - 0.5) * this.W * 0.25, { mode: 'ghost' });
      p.gi = Math.floor(Math.random() * n);
      this.parts.push(p);
    }
  }

  /** Stage 7: release. The dense cloud becomes flying mist; everything is flung outward, some toward the camera. */
  burst(t: number) {
    this.burstAt = t;
    const c = this.pt(CENTER);
    const d = this.dpr;
    const W = this.W;
    this.parts.forEach((q) => {
      const dx = q.x - c.x;
      const dy = q.y - c.y;
      const dist = Math.hypot(dx, dy) || 1;
      const sp = (5 + Math.random() * 18) * d;
      q.vx = (dx / dist) * sp;
      q.vy = (dy / dist) * sp * 0.85;
      q.mode = 'burst';
      q.a = Math.max(q.a, 0.85);
    });
    // the occluder itself turns into mist that rushes out and thins
    const imp = 1;
    this.occ.forEach((o, i) => {
      if (this.small && i % 2) return;
      const ox = this.pt(o).x;
      const oy = this.pt(o).y;
      const px = ox + (c.x - ox) * imp * 0.55;
      const py = oy + (c.y - oy) * imp * 0.55;
      const dx = px - c.x;
      const dy = py - c.y;
      const dist = Math.hypot(dx, dy) || 1;
      const sp = (4 + Math.random() * 12) * d;
      const p = this.make('mist', px, py, { mode: 'burst', front: Math.random() < 0.6 });
      p.s = W * o.R * 2.2;
      p.vx = (dx / dist) * sp + (Math.random() - 0.5) * 4 * d;
      p.vy = (dy / dist) * sp * 0.8 - Math.random() * 2 * d;
      p.a = 0.95;
      p.grow = 1;
      this.parts.push(p);
    });
    for (let i = 0; i < this.burstCount; i++) {
      const an = Math.random() * Math.PI * 2;
      const sp = (3 + Math.pow(Math.random(), 0.7) * 30) * d;
      const p = this.make('mote', c.x + (Math.random() - 0.5) * 30 * d, c.y + (Math.random() - 0.5) * 70 * d, { mode: 'burst' });
      p.s = (0.8 + Math.random() * 2.4) * d;
      p.vx = Math.cos(an) * sp;
      p.vy = Math.sin(an) * sp * 0.8;
      p.a = 1;
      p.front = Math.random() < 0.5;
      this.parts.push(p);
    }
    // a few particles come right at the viewer — huge, soft, out of focus
    const nn = this.small ? 12 : 26;
    for (let i = 0; i < nn; i++) {
      const an = Math.random() * Math.PI * 2;
      const sp = (6 + Math.random() * 16) * d;
      const p = this.make(Math.random() < 0.6 ? 'near' : 'mist', c.x + (Math.random() - 0.5) * 40 * d, c.y + (Math.random() - 0.5) * 60 * d, { mode: 'burst', front: true });
      p.kind = 'near';
      p.s = W * (0.01 + Math.random() * 0.02);
      p.vx = Math.cos(an) * sp;
      p.vy = Math.sin(an) * sp * 0.7;
      p.a = 0.5 + Math.random() * 0.3;
      p.grow = 2;
      this.parts.push(p);
    }
  }

  /** Where the cloud is born. On narrow (portrait) screens the left bench is cropped away, so it rises from beneath the right bench instead. */
  private get src(): { o: Pt; c: Pt } {
    const visLeft = this.geo.width ? -this.geo.left / this.geo.width : 0;
    return visLeft > 0.3 ? { o: ORIGIN_R, c: { x: 0.8, y: 1.0 } } : { o: ORIGIN, c: { x: 0.47, y: 0.99 } };
  }

  /** where the travelling cloud's heart is (plate px) */
  private head(s: number): Pt {
    const { o, c } = this.src;
    const P0 = { x: o.x, y: o.y - 0.06 };
    const P1 = c;
    const P2 = FEET;
    const u0 = seg(s, TL.turn, TL.feet);
    const u = u0 * u0 * (3 - 2 * u0);
    const m = 1 - u;
    return this.pt({ x: m * m * P0.x + 2 * m * u * P1.x + u * u * P2.x, y: m * m * P0.y + 2 * m * u * P1.y + u * u * P2.y });
  }

  private orbitTarget(q: P, s: number, t: number): Pt {
    const { geo, dpr } = this;
    const imp = seg(s, TL.implode, TL.burst);
    const turb = this.turb(s);
    const bodyW = BODY_HALF_W * geo.width * dpr;
    const bodyH = BODY_H * geo.height * dpr;
    const hh = clamp(q.h, 0, 1);
    const xFrac = FEET.x + (HEAD_X - FEET.x) * hh;
    // tighter round her ankles, wider at the skirt and shoulders
    const girth = 0.55 + 0.6 * Math.sin(Math.min(1, hh * 1.3) * Math.PI * 0.5);
    const r = q.r * bodyW * girth * (1 + 0.22 * Math.sin(t * 0.0022 + q.seed)) * (q.h > 1 ? 1.3 : 1);
    let x = (geo.left + xFrac * geo.width) * dpr + Math.cos(q.th) * r + Math.sin(t * 0.003 + q.seed) * 5 * dpr * (1 + turb);
    let y = (geo.top + FEET.y * geo.height) * dpr - q.h * bodyH + Math.sin(q.th * 2 + q.seed) * 7 * dpr * (1 + turb);
    if (imp > 0) {
      const c = this.pt(CENTER);
      x += (c.x - x) * imp * 0.9;
      y += (c.y - y) * imp * 0.9;
    }
    // openings in the cloud: her face and one hand stay visible until the very end
    if (q.front) {
      const gaps: [Pt, number, boolean][] = [
        [FACE, 0.036, s < TL.face],
        [HAND, 0.032, s < TL.hand],
      ];
      for (const [g, rad, open] of gaps) {
        if (!open) continue;
        const c = this.pt(g);
        const R = rad * geo.width * dpr * (q.kind === 'mist' ? 2.2 : 1);
        const dx = x - c.x;
        const dy = y - c.y;
        const dd = Math.hypot(dx, dy) || 1;
        if (dd < R) {
          x = c.x + (dx / dd) * R;
          y = c.y + (dy / dd) * R;
        }
      }
    }
    return { x, y };
  }

  private turb(s: number) {
    return 0.25 + 1.1 * seg(s, TL.feet, TL.shoulders) * (1 - seg(s, TL.hidden, TL.burst));
  }

  step(s: number, t: number, dt: number, back: CanvasRenderingContext2D, front: CanvasRenderingContext2D, Wc: number, Hc: number) {
    const { dpr, geo } = this;
    const k = dt / 16.7;
    const turb = this.turb(s);
    const imp = seg(s, TL.implode, TL.burst);
    const hm = hMax(s);
    const g = ghostAmt(s);
    const feet = this.pt(FEET);
    const bodyW = BODY_HALF_W * geo.width * dpr;
    const W = this.W;
    const floorY = this.pt({ x: 0, y: 0.97 }).y;

    /* ---- population ---- */
    if (s < TL.puff) {
      const target = Math.round((this.small ? 26 : 60) * seg(s, TL.first, TL.puff));
      let n = 0;
      for (const q of this.parts) if (q.mode === 'idle') n++;
      if (n < target && Math.random() < 0.35) this.parts.push(this.idleSpawn());
    } else if (s >= TL.feet && s < TL.hidden) {
      const tm = this.maxMotes * (0.55 + 0.45 * seg(s, TL.feet, TL.engulf));
      const tf = this.maxMist * (0.4 + 0.6 * seg(s, TL.feet, TL.engulf));
      let m = 0;
      let f = 0;
      for (const q of this.parts) {
        if (q.mode !== 'orbit' && q.mode !== 'ghost' && q.mode !== 'cloud') continue;
        if (q.kind === 'mote') m++;
        else if (q.kind === 'mist') f++;
      }
      let spawned = 0;
      while (m < tm && spawned < 14) {
        const p = this.make('mote', feet.x + (Math.random() - 0.5) * bodyW * 2, feet.y + (Math.random() - 0.5) * 20 * dpr, { mode: 'orbit' });
        p.h = Math.random() * 0.1;
        this.parts.push(p);
        m++;
        spawned++;
      }
      while (f < tf && spawned < 18) {
        const p = this.make('mist', feet.x + (Math.random() - 0.5) * bodyW * 2, feet.y, { mode: 'orbit' });
        p.h = Math.random() * hm;
        this.parts.push(p);
        f++;
        spawned++;
      }
    }

    back.clearRect(0, 0, Wc, Hc);
    front.clearRect(0, 0, Wc, Hc);

    /* ---- a darkness gathering BEHIND her (depth) ---- */
    if (s > TL.feet - 0.03 && s < TL.burst) {
      const c = this.pt(CENTER);
      const a = 0.12 + 0.6 * seg(s, TL.feet, TL.shoulders + 0.1);
      back.globalAlpha = a;
      const bw = bodyW * 3.6;
      const bh = BODY_H * geo.height * dpr * 1.2 * Math.max(0.25, hm * 0.9);
      back.drawImage(this.core, c.x - bw / 2, feet.y - bh, bw, bh + 20 * dpr);
    }

    /* ---- the spectral figure's faint shroud (behind her) ---- */
    if (g > 0) {
      back.globalAlpha = 0.22 * g;
      const hd = this.pt({ x: 0.704, y: 0.165 });
      const sz = W * 0.07;
      back.drawImage(this.mist, hd.x - sz / 2, hd.y - sz / 2, sz, sz * 1.3);
      const sh = this.pt({ x: 0.705, y: 0.33 });
      back.drawImage(this.mist, sh.x - W * 0.08, sh.y - W * 0.05, W * 0.16, W * 0.1);
    }

    const mistBoost = 0.55 + 0.8 * seg(s, TL.shoulders, TL.hidden);
    const collapse = seg(s, TL.ghostOut, TL.ghostGone);
    const cpt = this.pt(CENTER);

    for (let i = this.parts.length - 1; i >= 0; i--) {
      const q = this.parts[i];
      if (q.mode === 'idle') {
        q.vx += Math.cos(q.y * 0.01 + t * 0.0006 + q.seed) * 0.02 * k;
        q.vy += (Math.sin(q.x * 0.01 + t * 0.0005 + q.seed) * 0.02 - 0.004) * k;
        q.vx *= 0.95;
        q.vy *= 0.95;
        q.x += q.vx * dpr * k;
        q.y += q.vy * dpr * k;
      } else if (q.mode === 'cloud') {
        // blooms outward, then is steered as one body toward Edith
        const hd = this.head(s);
        const rad = W * (0.03 + 0.07 * seg(s, TL.puff, TL.turn) - 0.035 * seg(s, TL.turn, TL.feet));
        const tx = hd.x + q.ox * rad + Math.sin(t * 0.0021 + q.seed) * rad * 0.25;
        const ty = hd.y + q.oy * rad + Math.cos(t * 0.0017 + q.seed) * rad * 0.2;
        const K = 0.0008 + 0.012 * seg(s, TL.turn - 0.03, TL.turn + 0.05);
        q.vx += (tx - q.x) * K * k;
        q.vy += (ty - q.y) * K * k;
        // churn round its own heart
        const dx = q.x - hd.x;
        const dy = q.y - hd.y;
        q.vx += -dy * 0.0025 * k;
        q.vy += dx * 0.0025 * k;
        const damp = Math.pow(0.93, k);
        q.vx *= damp;
        q.vy *= damp;
        q.x += q.vx * k;
        q.y += q.vy * k;
        if (q.grow && q.s < W * 0.1) q.s *= 1 + 0.006 * k;
        if (s >= TL.feet - 0.02) {
          const d2 = Math.hypot(feet.x - q.x, feet.y - q.y);
          if (d2 < bodyW * 1.8 || s >= TL.feet + 0.03) {
            q.mode = 'orbit';
            q.th = Math.atan2(q.y - feet.y, q.x - feet.x);
            q.h = 0.01 + Math.random() * 0.05;
          }
        }
      } else if (q.mode === 'orbit') {
        q.th += q.w * (1 + turb * 1.6) * k;
        const hT = imp > 0 ? 0.55 : Math.min(q.hPref, hm);
        q.h += (hT - q.h) * 0.02 * k;
        const tg = this.orbitTarget(q, s, t);
        q.x += (tg.x - q.x) * 0.12 * k;
        q.y += (tg.y - q.y) * 0.12 * k;
        q.front = Math.sin(q.th) > 0;
      } else if (q.mode === 'ghost') {
        const gp = this.ghost[q.gi] || this.ghost[0];
        let tg = this.pt(gp);
        tg.x += Math.sin(t * 0.004 + q.seed) * 2.5 * dpr;
        tg.y += Math.cos(t * 0.0035 + q.seed) * 2.5 * dpr;
        if (collapse > 0) tg = { x: tg.x + (cpt.x - tg.x) * collapse * 0.92, y: tg.y + (cpt.y - tg.y) * collapse * 0.92 };
        q.x += (tg.x - q.x) * 0.09 * k;
        q.y += (tg.y - q.y) * 0.09 * k;
        q.front = gp.front;
        if (s >= TL.ghostGone) {
          q.mode = 'orbit';
          q.h = clamp((feet.y - q.y) / (BODY_H * geo.height * dpr), 0, 1.1);
          q.th = Math.atan2(0, q.x - feet.x);
        }
      } else {
        // burst: rush outward, lose momentum, drift and settle
        q.x += q.vx * k;
        q.y += q.vy * k;
        const drag = Math.pow(q.kind === 'near' ? 0.97 : 0.91, k);
        q.vx *= drag;
        q.vy *= drag;
        if (q.kind === 'mote') {
          if (Math.hypot(q.vx, q.vy) < 1.2 * dpr) {
            q.vx += Math.sin(t * 0.001 + q.seed) * 0.02 * dpr * k;
            q.vy += 0.02 * dpr * k;
            q.a -= 0.004 * k;
          }
          if (q.y > floorY) {
            q.y = floorY;
            q.vy = 0;
            q.vx *= 0.6;
            q.a -= 0.006 * k;
          }
        } else if (q.kind === 'mist') {
          q.s *= 1 + 0.01 * k;
          q.a -= 0.0075 * k;
        } else {
          q.s *= 1 + 0.045 * k;
          q.a -= 0.014 * k;
        }
      }
      if (q.mode !== 'burst') q.a = Math.min(q.aMax, q.a + 0.03 * k);
      if (q.a <= 0 || q.x < -300 * dpr || q.x > Wc + 300 * dpr || q.y < -300 * dpr || q.y > Hc + 300 * dpr) {
        this.parts.splice(i, 1);
        continue;
      }
      const ctx = q.front ? front : back;
      let size: number;
      let alpha: number;
      let img: HTMLCanvasElement;
      if (q.kind === 'mote') {
        img = q.glint ? this.moteLight : this.moteDark;
        size = q.s * (q.front ? 1.35 : 0.85);
        alpha = q.a * (q.glint ? 0.25 + 0.2 * Math.sin(t * 0.01 + q.seed) : 0.92);
        if (q.mode === 'orbit' && g > 0) alpha *= 1 - 0.45 * g;
      } else if (q.kind === 'mist') {
        img = this.mist;
        size = q.s * (q.front ? 1.15 : 0.9);
        alpha = q.a * (q.mode === 'burst' ? 0.55 : (q.front ? 0.22 : 0.36) * mistBoost * (1 - 0.4 * g));
      } else {
        img = this.mist;
        size = q.s;
        alpha = q.a * 0.45;
      }
      ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
      ctx.drawImage(img, q.x - size / 2, q.y - size / 2, size, size);
    }

    /* ---- the storm's dark swirls over her (with openings); then the engulfment, feet first ---- */
    if (s > 0.34 && s < TL.burst) {
      const storm = 0.36 * seg(s, 0.34, 0.46) * (1 - 0.6 * g);
      const stride = this.small ? 3 : 4;
      for (let i = 0; i < this.occ.length; i++) {
        const o = this.occ[i];
        let a = 0;
        // sparse, moving patches only — Edith stays clearly visible through the gaps
        if (i % stride === 0 && !o.floor && o.hf <= hm && s < TL.hidden) {
          const n = Math.sin(o.x * 60 + t * 0.0021 + o.y * 7) * Math.sin(o.y * 34 - t * 0.0016 + o.x * 11);
          a = (storm * Math.max(0, n - 0.25)) / 0.75;
          if (o.face || o.hand) a = 0;
        }
        a = Math.max(a, seg(s, o.t0, o.t0 + 0.02));
        if (a <= 0.01) continue;
        let p = this.pt(o);
        if (imp > 0) p = { x: p.x + (cpt.x - p.x) * imp * 0.55, y: p.y + (cpt.y - p.y) * imp * 0.55 };
        const R = W * o.R * (1 - imp * 0.25) * (1 + 0.08 * Math.sin(t * 0.003 + o.x * 40));
        front.globalAlpha = Math.min(1, a * 0.9);
        front.drawImage(this.core, p.x - R, p.y - R, R * 2, R * 2);
      }
    }

    /* ---- the shock ring of the release ---- */
    if (this.burstAt) {
      const u = (t - this.burstAt) / 900;
      if (u < 1) {
        const R = W * (0.05 + 0.5 * (1 - Math.pow(1 - u, 3)));
        front.globalAlpha = 0.8 * (1 - u);
        front.drawImage(this.ring, cpt.x - R, cpt.y - R * 0.8, R * 2, R * 1.6);
      }
      // one last spore drifts down and settles on the overturned watering can
      if (!this.lander && t - this.burstAt > 2600) this.lander = { ...this.pt({ x: 0.655, y: 0.5 }), t0: t };
    }
    if (this.lander) {
      const u = clamp((t - this.lander.t0) / 4200);
      const e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
      const end = this.pt(CAN_TOP);
      const x = this.lander.x + (end.x - this.lander.x) * e + Math.sin(u * Math.PI * 3) * W * 0.012 * (1 - u);
      const y = this.lander.y + (end.y - this.lander.y) * e;
      const sz = 3.4 * dpr;
      front.globalAlpha = 0.95;
      front.drawImage(this.moteDark, x - sz, y - sz, sz * 2, sz * 2);
    }

    back.globalAlpha = 1;
    front.globalAlpha = 1;
  }
}
