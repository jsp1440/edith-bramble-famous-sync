import React, { useEffect, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { scene, seg, type C1Manuscript } from './c1-data';
import { useScrollProgress } from './c1-hooks';
import { Fog, LanternGlow, StoryText } from './Atmosphere';
import { MoodZone, useSound } from './SoundContext';

const TITLE = 'THE NIGHT OF THE BLACK ROT';

/** Near-darkness, moving coastal fog; the greenhouse surfaces as the opening text appears. */
const Opening: React.FC<{ m: C1Manuscript; onDiscover: (id: string) => void; reduced: boolean }> = ({ m, onDiscover, reduced }) => {
  const [ref, p] = useScrollProgress<HTMLElement>();
  const [mounted, setMounted] = useState(false);
  const { enable, disable } = useSound();
  const cliffs = scene('scene-fog-cliffs');

  useEffect(() => {
    const t = window.setTimeout(() => setMounted(true), 120);
    return () => window.clearTimeout(t);
  }, []);

  const reveal = seg(p, 0.12, 0.7);
  const enter = (withSound: boolean) => {
    if (withSound) enable();
    else disable();
    document.getElementById('c1-first-words')?.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'center' });
  };

  return (
    <section ref={ref} className="relative h-[250vh] bg-[hsl(215_20%_4%)]" aria-label="Opening">
      <div className="absolute inset-0">
        <div className="sticky top-0 h-[100svh] overflow-hidden">
          {/* The greenhouse on the cliffs, emerging from fog */}
          <img
            src={cliffs.src}
            alt={cliffs.alt}
            className="absolute inset-0 h-full w-full object-cover transition-opacity duration-[3000ms]"
            style={{
              opacity: mounted ? 0.14 + reveal * 0.7 : 0,
              filter: `blur(${(1 - reveal) * 9}px) saturate(${0.5 + reveal * 0.5}) brightness(${0.55 + reveal * 0.4})`,
              transform: `scale(${1.12 - reveal * 0.1})`,
            }}
          />
          {/* Faint cliff + glasshouse outline for the first seconds of darkness */}
          <svg
            aria-hidden="true"
            viewBox="0 0 1200 600"
            preserveAspectRatio="xMidYMax slice"
            className="absolute inset-0 h-full w-full transition-opacity duration-[4000ms]"
            style={{ opacity: mounted ? 0.55 * (1 - reveal) : 0 }}
          >
            <path d="M0 470 C 180 440, 260 470, 380 430 S 560 380, 700 420 S 980 470, 1200 440 V600 H0Z" fill="hsl(215 18% 7%)" />
            <g stroke="hsl(40 30% 70%)" strokeWidth="1.2" fill="none" opacity="0.5">
              <path d="M560 420 V340 L640 290 L720 340 V420" />
              <path d="M580 420 V350 M600 420 V338 M620 420 V326 M660 420 V326 M680 420 V338 M700 420 V350 M560 370 H720" />
            </g>
            <rect x="620" y="380" width="40" height="40" fill="hsl(34 90% 55%)" opacity="0.18" />
          </svg>
          {!reduced && <LanternGlow x="52%" y="64%" size="26vmax" strength={0.35 + reveal * 0.5} />}
          <Fog density={0.95 - reveal * 0.4} />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_50%,transparent_30%,hsl(215_20%_3%/0.85)_100%)]" />
        </div>
      </div>

      <MoodZone mood="night" className="relative z-10">
        <div className="flex h-[100svh] flex-col items-center justify-center px-4 text-center">
          <h1 className="font-display text-[2.1rem] font-semibold leading-tight text-[hsl(42_36%_92%)] [text-shadow:0_0_30px_hsl(200_20%_80%/0.35)] sm:text-6xl lg:text-7xl" aria-label={TITLE}>
            {TITLE.split('').map((ch, i) => (
              <span
                key={i}
                aria-hidden="true"
                className="c1-letter"
                style={{
                  opacity: mounted ? 1 : 0,
                  filter: mounted ? 'blur(0)' : 'blur(14px)',
                  transform: mounted ? 'translateY(0)' : 'translateY(6px)',
                  transitionDelay: `${400 + ((i * 137) % 23) * 90}ms`,
                  whiteSpace: 'pre',
                }}
              >
                {ch}
              </span>
            ))}
          </h1>
          <p
            className="mt-5 font-display text-xl italic text-[hsl(36_45%_78%)] transition-all duration-[2500ms] sm:text-2xl"
            style={{ opacity: mounted ? 0.95 : 0, filter: mounted ? 'blur(0)' : 'blur(8px)', transitionDelay: '2600ms' }}
          >
            A Tale of Orchids and Halloween
          </p>
          <div
            className="no-print mt-12 flex flex-wrap items-center justify-center gap-3 transition-opacity duration-[1800ms]"
            style={{ opacity: mounted ? 1 : 0, transitionDelay: '3600ms' }}
          >
            <button
              type="button"
              onClick={() => enter(false)}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-full border border-[hsl(42_30%_85%)]/40 px-6 py-3 font-label text-[0.62rem] uppercase text-[hsl(42_30%_90%)] backdrop-blur-sm transition-colors hover:bg-[hsl(42_30%_90%)]/10"
            >
              <VolumeX className="h-4 w-4" aria-hidden="true" /> Enter quietly
            </button>
            <button
              type="button"
              onClick={() => enter(true)}
              className="inline-flex min-h-[46px] items-center gap-2 rounded-full bg-[hsl(36_55%_62%)] px-6 py-3 font-label text-[0.62rem] uppercase text-[hsl(30_20%_10%)] transition-colors hover:bg-[hsl(36_60%_70%)]"
            >
              <Volume2 className="h-4 w-4" aria-hidden="true" /> Enter with sound
            </button>
          </div>
          <p className="mt-4 font-ui text-[0.68rem] text-[hsl(42_20%_70%)]/80" style={{ opacity: mounted ? 1 : 0, transition: 'opacity 2s 4200ms' }}>
            Sound is off unless you choose it. Captions describe everything you would hear.
          </p>
        </div>

        <div className="pb-[30vh] pt-[30vh]">
          <div id="c1-first-words">
            <StoryText text={m.p[0] || ''} onDiscover={onDiscover} dropCap />
          </div>
          <div className="h-[18vh]" />
          <StoryText text={m.p[1] || ''} onDiscover={onDiscover} variant="quote" />
        </div>
      </MoodZone>
    </section>
  );
};

export default Opening;
