import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Eye, Footprints, Globe2, Lightbulb, Sprout } from 'lucide-react';
import type { CharacterProfile } from '@/lib/content-types';
import { getMedia, getChronicle } from '@/lib/content';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { explorePath } from '@/lib/feature-genius';

/* One card in the story cast. Story-only content: no biography, no personal details. */

const Emblem: React.FC<{ c: CharacterProfile; tall?: boolean }> = ({ c, tall }) => {
  const asset = getMedia(c.image) ?? getMedia(c.emblem);
  const ratio = tall ? 'aspect-[4/5]' : 'aspect-[4/3]';
  if (asset) {
    return (
      <figure>
        <div className={`${ratio} overflow-hidden rounded-md border-2 border-[hsl(var(--botanical))]/20 bg-[hsl(var(--cream))]`}>
          <img src={asset.src} alt={asset.alt} loading="lazy" decoding="async" className="h-full w-full object-cover" />
        </div>
        {!c.image && (
          <figcaption className="mt-2 font-ui text-[1rem] italic text-[hsl(var(--ink))]">From their moment in the story</figcaption>
        )}
      </figure>
    );
  }
  // Illustrated fallback: never a blank box.
  return (
    <div className={`${ratio} relative flex items-center justify-center overflow-hidden rounded-md border-2 border-[hsl(var(--botanical))]/20 bg-[radial-gradient(circle_at_30%_20%,hsl(96_30%_88%),hsl(150_25%_78%))]`} aria-hidden="true">
      <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full opacity-40 text-[hsl(var(--botanical))]">
        <path d="M60 110 C58 80 50 60 30 40 M60 110 C62 80 72 58 92 36 M60 110 L60 20" stroke="currentColor" strokeWidth="1.5" fill="none" />
        <ellipse cx="30" cy="40" rx="14" ry="6" transform="rotate(-35 30 40)" fill="currentColor" />
        <ellipse cx="92" cy="36" rx="14" ry="6" transform="rotate(35 92 36)" fill="currentColor" />
      </svg>
      <span className="relative font-display text-7xl font-semibold text-[hsl(var(--botanical))]">{c.name.charAt(0)}</span>
    </div>
  );
};

const Beat: React.FC<{ icon: React.ReactNode; label: string; children: React.ReactNode }> = ({ icon, label, children }) => (
  <div>
    <p className="flex items-center gap-2 font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">
      {icon}
      {label}
    </p>
    <p className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{children}</p>
  </div>
);

const CastCard: React.FC<{ c: CharacterProfile; featured?: boolean }> = ({ c, featured }) => {
  const profiles = (c.profiles ?? []).map((id) => getProfile(id)).filter(Boolean);
  const iconCls = 'h-5 w-5 shrink-0';

  return (
    <article
      id={c.id}
      className={`scroll-mt-28 rounded-xl border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5 shadow-md sm:p-7 ${
        featured ? 'grid gap-6 md:grid-cols-[minmax(0,15rem)_1fr] md:gap-8' : 'flex flex-col gap-5'
      }`}
    >
      <Emblem c={c} tall={featured} />

      <div className="flex flex-1 flex-col">
        <p className="font-label text-[1rem] uppercase text-[hsl(var(--moss))]">{c.role}</p>
        <h3 className="mt-1 font-display text-3xl font-semibold text-[hsl(var(--charcoal))] sm:text-4xl">{c.name}</h3>
        {c.orchid && (
          <p className="mt-2 inline-flex items-start gap-2 font-ui text-[1.125rem] font-semibold text-[hsl(var(--botanical))]">
            <Sprout className={`${iconCls} mt-0.5`} aria-hidden="true" />
            <span><span className="sr-only">Orchid or horticultural focus: </span>{c.orchid}</span>
          </p>
        )}
        <p className="mt-3 font-display text-[1.375rem] italic leading-snug text-[hsl(var(--burgundy))]">{c.tagline}</p>

        <div className="mt-5 space-y-4">
          {c.notices && <Beat icon={<Eye className={iconCls} aria-hidden="true" />} label="What they notice">{c.notices}</Beat>}
          {c.moment && <Beat icon={<BookOpen className={iconCls} aria-hidden="true" />} label="Their moment in the story">{c.moment}</Beat>}
          {c.teaches && <Beat icon={<Lightbulb className={iconCls} aria-hidden="true" />} label="What they teach us">{c.teaches}</Beat>}
        </div>

        <div className="mt-auto pt-6">
          <div className="flex flex-wrap gap-3">
            {c.clue && (
              <Link
                to={c.clue.to}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 py-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
              >
                <Footprints className="h-5 w-5 shrink-0" aria-hidden="true" />
                Follow the clue: {c.clue.label}
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </Link>
            )}
            {c.explore && c.explore.length > 0 && (
              <Link
                to={explorePath(c.explore[0])}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] bg-white px-5 py-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))]/10"
              >
                <Globe2 className="h-5 w-5 shrink-0" aria-hidden="true" />
                Explore their orchids
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </Link>
            )}
          </div>
          {c.explore && c.explore.length > 1 && (
            <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
              <span className="font-semibold">Also explore: </span>
              {c.explore.slice(1).map((n, i) => (
                <React.Fragment key={n}>
                  {i > 0 && ' · '}
                  <Link to={explorePath(n)} className="font-semibold italic text-[hsl(var(--botanical))] underline underline-offset-4">{n}</Link>
                </React.Fragment>
              ))}
            </p>
          )}

          {profiles.length > 0 && (
            <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
              <span className="font-semibold">Culture profile{profiles.length > 1 ? 's' : ''}: </span>
              {profiles.map((p, i) => (
                <React.Fragment key={p!.id}>
                  {i > 0 && ' · '}
                  <Link to={profilePath(p!.id)} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                    {p!.name}
                  </Link>
                </React.Fragment>
              ))}
            </p>
          )}

          <div className="mt-4 border-t-2 border-border/60 pt-3">
            <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">Appears in</p>
            {c.chronicles.length > 0 ? (
              <ul className="mt-1 space-y-1">
                {c.chronicles.map((id) => {
                  const ch = getChronicle(id);
                  return ch ? (
                    <li key={id}>
                      <Link to={`/chronicle/${ch.slug}`} className="text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                        Chronicle {ch.number} — {ch.title}
                      </Link>
                    </li>
                  ) : null;
                })}
              </ul>
            ) : (
              <p className="mt-1 text-[1.0625rem] text-[hsl(var(--ink))]">A Chronicle not yet published — no story details yet.</p>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};

export default CastCard;
