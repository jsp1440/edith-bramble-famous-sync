import React, { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, FileSearch, Flag } from 'lucide-react';
import { ARCHITECTURE, ZONES, ZONE_GUIDE, zoneShort } from '@/content/edith-greenhouse';
import { microclimates, getGrowerCard } from '@/lib/content';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { EvidencePending } from '@/components/evidence/EvidenceUI';
import GrowerCardDialog from '@/components/story/GrowerCardDialog';
import { ActivityHeader, GreenhouseStepBar, StepFooter } from '@/components/greenhouse/GreenhouseShell';

const S = 10;
const PAD = 14;

/** The ONE canonical floor plan. Short labels only; details appear after selection. */
export const CanonicalPlan: React.FC<{ selected: string; onSelect: (id: string) => void }> = ({ selected, onSelect }) => {
  const { central, ends } = ARCHITECTURE;
  return (
    <svg viewBox={`${-PAD} ${-PAD - 10} ${48 * S + PAD * 2} ${24 * S + PAD * 2 + 10}`} className="w-full rounded-md border-2 border-border bg-[hsl(44_40%_96%)]" role="group" aria-label="Floor plan of Edith's greenhouse. Select a zone.">
      <text x={24 * S} y={-12} textAnchor="middle" fontSize="12" fill="hsl(30 20% 14%)" fontWeight="700">NORTH</text>
      <rect x={0} y={4 * S} width={ends.lengthFt * S} height={ends.widthFt * S} fill="hsl(190 25% 92%)" stroke="hsl(30 20% 25%)" strokeWidth="2" />
      <rect x={8 * S} y={0} width={central.lengthFt * S} height={central.widthFt * S} fill="hsl(150 20% 93%)" stroke="hsl(30 20% 25%)" strokeWidth="2.5" />
      <rect x={40 * S} y={4 * S} width={ends.lengthFt * S} height={ends.widthFt * S} fill="hsl(30 40% 92%)" stroke="hsl(30 20% 25%)" strokeWidth="2" />
      <rect x={22 * S} y={18 * S} width={14 * S} height={6 * S} fill="none" stroke="hsl(30 20% 35%)" strokeDasharray="5 4" strokeWidth="1.5" />
      {ZONES.map((z) => {
        const on = z.id === selected;
        return (
          <g key={z.id} role="button" tabIndex={0} aria-pressed={on} aria-label={z.name} onClick={() => onSelect(z.id)} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), onSelect(z.id))} className="cursor-pointer focus:outline-none">
            <rect x={z.plan.x * S + 2} y={z.plan.y * S + 2} width={z.plan.w * S - 4} height={z.plan.h * S - 4} rx="4"
              fill={on ? 'hsl(150 40% 22%)' : z.id === 'hanging' ? 'hsl(300 20% 60% / 0.25)' : 'hsl(96 25% 80% / 0.8)'}
              stroke={on ? 'hsl(44 70% 60%)' : 'hsl(150 30% 30%)'} strokeWidth={on ? 3 : 1.2} strokeDasharray={z.id === 'hanging' ? '4 3' : undefined} />
            <text x={(z.plan.x + z.plan.w / 2) * S} y={(z.plan.y + z.plan.h / 2) * S + 5} textAnchor="middle" fontSize="13" fontWeight="700" fill={on ? 'hsl(44 60% 95%)' : 'hsl(30 25% 12%)'} pointerEvents="none">
              {zoneShort(z.id)}
            </text>
          </g>
        );
      })}
      <rect x={26 * S} y={16 * S - 3} width={3 * S} height={6} fill="hsl(30 50% 35%)" />
      <circle cx={0} cy={8 * S} r="7" fill="hsl(210 30% 40%)" />
      <text x={27.5 * S} y={17.5 * S} textAnchor="middle" fontSize="11" fill="hsl(30 20% 14%)">Door</text>
    </svg>
  );
};

const Row: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (
  <div className="rounded-md border-2 border-border/70 bg-white/70 p-4">
    <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">{label}</p>
    <p className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{children}</p>
  </div>
);

const WalkTheGreenhouse: React.FC = () => {
  // Optional deep link, e.g. /greenhouse/walk?zone=wet-bench (used by "Follow the clue" on the Characters page).
  const [params] = useSearchParams();
  const initialZone = ZONES.some((z) => z.id === params.get('zone')) ? (params.get('zone') as string) : ZONES[0].id;
  const [sel, setSel] = useState(initialZone);
  const [card, setCard] = useState<string | null>(null);
  const zone = ZONES.find((z) => z.id === sel)!;
  const g = ZONE_GUIDE[zone.id];
  const cards = microclimates.find((m) => m.id === zone.id)?.cards ?? [];

  return (
    <div>
      <GreenhouseStepBar current="walk" />
      <ActivityHeader step="Step 1 · Walk the greenhouse" title="Edith's greenhouse: one house, many microclimates">
        A greenhouse is not one environment. Sun exposure, glazing, benches, plants, airflow, height and proximity to doors and vents create
        different growing conditions within the same structure. Edith uses those differences instead of trying to eliminate them.
      </ActivityHeader>

      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        <p className="mb-3 text-[1.125rem] font-semibold text-[hsl(var(--ink))]">Tap a zone on the plan — or choose one below.</p>
        <CanonicalPlan selected={sel} onSelect={setSel} />
        <p className="mt-2 text-[1rem] text-[hsl(var(--ink))]">
          One fictional building, about {ARCHITECTURE.overall.lengthFt} × {ARCHITECTURE.overall.widthFt} ft. The dashed band over the aisle marks hanging
          baskets overhead; the dashed box outside the door is the lath house.
        </p>
        <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Choose a zone">
          {ZONES.map((z) => (
            <button key={z.id} type="button" onClick={() => setSel(z.id)} aria-pressed={z.id === sel}
              className={`min-h-[48px] rounded-md border-2 px-4 font-ui text-[1.0625rem] font-semibold ${z.id === sel ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border bg-white/60 text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]'}`}>
              {zoneShort(z.id)}
            </button>
          ))}
        </div>

        <article aria-live="polite" className="mt-8 rounded-md border-2 border-[hsl(var(--botanical))]/30 bg-[hsl(var(--cream))] p-5 sm:p-8">
          <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">You are standing in</p>
          <h2 className="mt-1 font-display text-3xl font-semibold text-[hsl(var(--charcoal))] sm:text-4xl">{zone.name}</h2>

          <h3 className="mt-6 font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">What is different here?</h3>
          <p className="mt-1 text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">{zone.microclimate} {zone.whyDifferent}</p>

          {g && (
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <Row label="Light">{g.light}</Row>
              <Row label="Temperature">{g.temperature}</Row>
              <Row label="Moisture">{g.moisture}</Row>
              <Row label="Airflow">{g.airflow}</Row>
            </div>
          )}
          <p className="mt-2 text-[1rem] italic text-[hsl(var(--ink))]">Relative descriptions of a fictional greenhouse — no measured values are claimed.</p>

          <div className="mt-6 grid gap-5 md:grid-cols-2">
            <div>
              <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Seasonal role</h3>
              <p className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{g?.seasonalRole} {zone.autumn}</p>
            </div>
            <div>
              <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Orchids that may use this area</h3>
              <ul className="mt-1 list-disc pl-6 text-[1.1875rem] text-[hsl(var(--ink))]">{zone.orchids.map((o) => <li key={o}>{o}</li>)}</ul>
            </div>
            <div>
              <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Why Edith puts them here</h3>
              <p className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{g?.whyEdith}</p>
            </div>
            <div>
              <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">What Edith watches</h3>
              <p className="mt-1 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{zone.edithWatches}</p>
            </div>
          </div>

          <div className="mt-7 border-t-2 border-border/70 pt-5">
            <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Related culture profiles</h3>
            {zone.relatedProfiles.length ? (
              <div className="mt-2 flex flex-wrap gap-2">
                {zone.relatedProfiles.map((id) => {
                  const p = getProfile(id);
                  return p ? (
                    <Link key={id} to={profilePath(id, 'culture')} className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
                      {p.name} <ArrowRight className="h-4 w-4" aria-hidden="true" />
                    </Link>
                  ) : null;
                })}
              </div>
            ) : (
              <p className="mt-1 text-[1.125rem] text-[hsl(var(--ink))]">No Culture Library profile yet for the orchids in this zone.</p>
            )}
            {cards.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-3">
                {cards.map((id) => {
                  const c = getGrowerCard(id);
                  return c ? (
                    <button key={id} type="button" onClick={() => setCard(id)} className="min-h-[44px] font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                      Grower Card: {c.title.split(':')[0]}
                    </button>
                  ) : null;
                })}
              </div>
            )}
          </div>

          <div className="mt-6">
            <EvidencePending label="Sources / evidence">
              This zone describes a fictional greenhouse, so the setting itself needs no citation. Factual claims about the orchids that use it
              live in their Culture Library profiles, where every statement has its own evidence indicator.
              <span className="mt-3 flex flex-wrap gap-2">
                {zone.relatedProfiles[0] && (
                  <Link to={profilePath(zone.relatedProfiles[0], 'evidence')} className="inline-flex min-h-[44px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--botanical))]">
                    <FileSearch className="h-4 w-4" aria-hidden="true" /> View sources
                  </Link>
                )}
                <Link to={`/report-evidence${zone.relatedProfiles[0] ? `?profile=${zone.relatedProfiles[0]}` : ''}`} className="inline-flex min-h-[44px] items-center gap-2 rounded-md border-2 border-border px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--ink))]">
                  <Flag className="h-4 w-4" aria-hidden="true" /> Suggest a correction
                </Link>
              </span>
            </EvidencePending>
          </div>
        </article>
      </div>

      <GrowerCardDialog cardId={card} onClose={() => setCard(null)} />
      <StepFooter current="walk" />
    </div>
  );
};

export default WalkTheGreenhouse;
