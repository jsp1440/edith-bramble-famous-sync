import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Check, X } from 'lucide-react';
import { CLIMATE_AXES, REGIONS, getProfile, listProfiles, profilePath } from '@/lib/orchid-continuum';

/* COMPARE TWO ORCHIDS
   Compares two profiles on shared axes. "Shared" = within one step on the
   1–5 scale. The 1–5 values are DRAFT TEACHING VALUES from the profiles,
   not measurements. */

type Pair = { a: string; b: string; label: string } | { pending: true; label: string; note: string };

const FEATURED: Pair[] = [
  { a: 'sarcochilus', b: 'cymbidium', label: 'Sarcochilus vs Cymbidium' },
  { a: 'phragmipedium', b: 'catasetinae', label: 'Phragmipedium vs Catasetum' },
  { a: 'dendrobium-nobile', b: 'dendrobium-phalaenanthe', label: 'Nobile-type vs Phalaenanthe-type Dendrobium' },
  { a: 'stanhopea', b: 'laelia-anceps', label: 'Stanhopea vs an upright epiphyte (Laelia anceps)' },
  { pending: true, label: 'Deciduous vs evergreen Lycaste', note: 'The Culture Library has a deciduous Lycaste profile but no evergreen Lycaste profile yet, so this comparison waits for one. We do not invent the missing profile.' },
];

const Picker: React.FC<{ value: string; onChange: (v: string) => void; label: string }> = ({ value, onChange, label }) => (
  <label className="block">
    <span className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--moss))]">{label}</span>
    <select value={value} onChange={(e) => onChange(e.target.value)}
      className="mt-1 block min-h-[52px] w-full rounded-md border-2 border-border bg-background px-3 text-[1.125rem] text-[hsl(var(--ink))]">
      {listProfiles().map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
    </select>
  </label>
);

const H: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <h3 className="font-ui text-[1.125rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">{children}</h3>
);

const NeighborsExplorer: React.FC<{ showHeading?: boolean }> = ({ showHeading = true }) => {
  const [a, setA] = useState('sarcochilus');
  const [b, setB] = useState('cymbidium');
  const [pendingNote, setPendingNote] = useState<string | null>(null);
  const pa = getProfile(a);
  const pb = getProfile(b);
  if (!pa || !pb) return null;

  const rows = CLIMATE_AXES.map((ax) => {
    const va = pa.climate[ax.key];
    const vb = pb.climate[ax.key];
    return { ...ax, va, vb, shared: Math.abs(va - vb) <= 1 };
  });
  const sharedRows = rows.filter((r) => r.shared);
  const diffRows = rows.filter((r) => !r.shared);
  const sameGenus = pa.acceptedName.split(' ')[0] === pb.acceptedName.split(' ')[0] && pa.id !== pb.id;
  const sameRegion = pa.origin.regions.some((r) => pb.origin.regions.includes(r));
  const containerDiffers = [pa.id, pb.id].includes('stanhopea') && pa.id !== pb.id;

  return (
    <section id="neighbors" className="scroll-mt-24">
      {showHeading && (
        <>
          <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))] sm:text-4xl">Why are these orchids neighbors?</h2>
          <p className="mt-3 max-w-3xl text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">
            Greenhouse neighbors are chosen by environmental compatibility, not simply by taxonomic name or geographic origin.
          </p>
        </>
      )}

      <div className="mt-5 flex flex-wrap gap-2">
        {FEATURED.map((f) => (
          <button key={f.label} type="button"
            onClick={() => { if ('pending' in f) { setPendingNote(f.note); } else { setPendingNote(null); setA(f.a); setB(f.b); } }}
            className={`min-h-[48px] rounded-md border-2 px-4 text-left font-ui text-[1.0625rem] font-semibold ${'pending' in f ? 'border-dashed border-[hsl(30_20%_40%)] text-[hsl(var(--ink))]' : (f.a === a && f.b === b ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border bg-white/60 text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]')}`}>
            {f.label}{'pending' in f ? ' — profile pending' : ''}
          </button>
        ))}
      </div>
      {pendingNote && (
        <p className="mt-3 rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] px-4 py-3 text-[1.125rem] text-[hsl(var(--ink))]">
          <strong>Evidence pending.</strong> {pendingNote}
        </p>
      )}

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        <Picker value={a} onChange={(v) => { setPendingNote(null); setA(v); }} label="First orchid" />
        <Picker value={b} onChange={(v) => { setPendingNote(null); setB(v); }} label="Second orchid" />
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {[pa, pb].map((p) => (
          <div key={p.id} className="rounded-md border-2 border-border bg-[hsl(var(--cream))] p-5">
            <p className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</p>
            <p className="mt-1 text-[1.0625rem] text-[hsl(var(--ink))]">{p.origin.regions.map((r) => REGIONS[r].label).join(' · ')}</p>
            <p className="mt-2 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">{p.habitat[0]?.value}</p>
            <Link to={profilePath(p.id)} className="mt-3 inline-flex min-h-[44px] items-center gap-1 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
              Culture profile <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        ))}
      </div>

      <div className="mt-6 overflow-hidden rounded-md border-2 border-border">
        {rows.map((r) => (
          <div key={r.key} className="grid gap-3 border-b-2 border-border/60 bg-white/70 px-4 py-4 last:border-0 md:grid-cols-[11rem_1fr_1fr_8rem] md:items-center">
            <span className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--moss))]">{r.label}</span>
            {[{ v: r.va, s: pa.climate.summary[r.key], n: pa.name }, { v: r.vb, s: pb.climate.summary[r.key], n: pb.name }].map((x, i) => (
              <div key={i}>
                <p className="text-[0.95rem] font-semibold text-[hsl(var(--ink))] md:hidden">{x.n}</p>
                <div className="flex items-center gap-2" aria-label={`${x.n}: ${x.s}`}>
                  <span className="text-[0.9rem] text-[hsl(var(--ink))]">{r.low}</span>
                  <span className="relative h-2 flex-1 rounded-full bg-border">
                    <span className="absolute top-1/2 h-4 w-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[hsl(var(--botanical))]" style={{ left: `${((x.v - 1) / 4) * 100}%` }} />
                  </span>
                  <span className="text-[0.9rem] text-[hsl(var(--ink))]">{r.high}</span>
                </div>
                <p className="mt-1 text-[1rem] text-[hsl(var(--ink))]">{x.s}</p>
              </div>
            ))}
            <span className={`inline-flex items-center gap-1 font-ui text-[1rem] font-bold ${r.shared ? 'text-[hsl(var(--botanical))]' : 'text-[hsl(var(--burgundy))]'}`}>
              {r.shared ? <Check className="h-5 w-5" aria-hidden="true" /> : <X className="h-5 w-5" aria-hidden="true" />}
              {r.shared ? 'Shared' : 'Differs'}
            </span>
          </div>
        ))}
      </div>
      <p className="mt-2 text-[1rem] italic text-[hsl(var(--ink))]">Positions are draft teaching values from the profiles, not measurements.</p>

      {pa.id === pb.id ? (
        <p className="mt-5 text-[1.25rem] text-[hsl(var(--ink))]">Choose two different orchids.</p>
      ) : (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-md border-2 border-border bg-white/70 p-5">
            <H>What they share</H>
            <p className="mt-1 text-[1.1875rem] text-[hsl(var(--ink))]">{sharedRows.length ? sharedRows.map((r) => r.label.toLowerCase()).join(', ') : 'Very little on these five axes.'}</p>
          </div>
          <div className="rounded-md border-2 border-border bg-white/70 p-5">
            <H>What differs</H>
            <p className="mt-1 text-[1.1875rem] text-[hsl(var(--ink))]">
              {diffRows.length ? diffRows.map((r) => r.label.toLowerCase()).join(', ') : 'Nothing large on these five axes.'}
              {containerDiffers ? ' — and the container: one needs an open hanging basket.' : ''}
            </p>
          </div>
          <div className="rounded-md border-2 border-[hsl(var(--botanical))]/40 bg-[hsl(var(--botanical))]/[0.05] p-5 md:col-span-2">
            <H>Why they may or may not be good neighbors</H>
            <p className="mt-1 text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">
              {sharedRows.length >= 4
                ? `Likely good neighbors: ${sharedRows.length} of 5 conditions overlap${sameRegion ? '' : ', even though they come from different parts of the world'}.`
                : sameGenus
                  ? `Same genus, different life: only ${sharedRows.length} of 5 conditions overlap. A shared name does not mean shared culture.`
                  : `Probably poor neighbors: only ${sharedRows.length} of 5 conditions overlap. They are better served by different microclimates.`}{' '}
              Even good neighbors are watered and watched as individuals.
            </p>
          </div>
          <div className="rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] p-5 md:col-span-2">
            <H>What additional information would help</H>
            <ul className="mt-1 list-disc pl-6 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
              <li>Which species or hybrid each plant actually is — groups vary internally.</li>
              <li>Each plant's current growth stage and seasonal state.</li>
              <li>Your local climate and growing system.</li>
              <li>Sourced habitat evidence — both profiles are drafts awaiting source-checking.</li>
            </ul>
          </div>
        </div>
      )}
    </section>
  );
};

export default NeighborsExplorer;
