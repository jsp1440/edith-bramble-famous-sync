import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Home, BookOpen } from 'lucide-react';

/* The guided greenhouse journey. Every step is reachable directly;
   Back / Next only suggest an order. */
export const GH_STEPS = [
  { id: 'home', to: '/greenhouse', label: 'Greenhouse home', short: 'Home' },
  { id: 'walk', to: '/greenhouse/walk', label: 'Walk the greenhouse', short: 'Walk' },
  { id: 'hazel', to: '/greenhouse/hazel-vs-edith', label: 'Hazel vs. Edith', short: 'Hazel vs. Edith' },
  { id: 'bench', to: '/greenhouse/build-a-bench', label: 'Build a bench', short: 'Build a bench' },
  { id: 'compare', to: '/greenhouse/compare', label: 'Compare two orchids', short: 'Compare' },
  { id: 'library', to: '/culture-library', label: 'Orchid Culture Library', short: 'Culture Library' },
] as const;

export type GhStepId = (typeof GH_STEPS)[number]['id'];

/** Sticky "where am I" bar shown on every greenhouse activity. */
export const GreenhouseStepBar: React.FC<{ current: GhStepId }> = ({ current }) => (
  <nav aria-label="Greenhouse activities" className="border-b-2 border-[hsl(var(--botanical))]/20 bg-[hsl(var(--cream))]">
    <ol className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 py-2 sm:px-6">
      {GH_STEPS.map((s, i) => (
        <li key={s.id} className="shrink-0">
          <NavLink
            to={s.to}
            end
            aria-current={s.id === current ? 'step' : undefined}
            className={`inline-flex min-h-[44px] items-center gap-2 rounded-md px-3 font-ui text-[1rem] font-semibold transition-colors sm:text-[1.0625rem] ${
              s.id === current
                ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10'
            }`}
          >
            {i > 0 && i < GH_STEPS.length - 1 && (
              <span aria-hidden="true" className={`flex h-6 w-6 items-center justify-center rounded-full border-2 text-[0.85rem] ${s.id === current ? 'border-[hsl(var(--cream))]' : 'border-[hsl(var(--botanical))]/50'}`}>
                {i}
              </span>
            )}
            {s.id === 'home' && <Home className="h-4 w-4" aria-hidden="true" />}
            {s.id === 'library' && <BookOpen className="h-4 w-4" aria-hidden="true" />}
            {s.short}
          </NavLink>
        </li>
      ))}
    </ol>
  </nav>
);

/** Activity title block: WHERE AM I / WHAT AM I DOING. */
export const ActivityHeader: React.FC<{ step: string; title: string; question?: string; children?: React.ReactNode }> = ({ step, title, question, children }) => (
  <header className="mx-auto max-w-4xl px-4 pb-6 pt-10 sm:px-6 sm:pt-14">
    <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">{step}</p>
    <h1 className="mt-2 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">{title}</h1>
    {question && <p className="mt-3 font-display text-[1.6rem] italic text-[hsl(var(--botanical))]">{question}</p>}
    {children && <div className="mt-4 max-w-3xl text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">{children}</div>}
  </header>
);

/** WHAT CAN I DO NEXT: Back / Greenhouse home / Next. */
export const StepFooter: React.FC<{ current: GhStepId }> = ({ current }) => {
  const i = GH_STEPS.findIndex((s) => s.id === current);
  const prev = i > 0 ? GH_STEPS[i - 1] : null;
  const next = i < GH_STEPS.length - 1 ? GH_STEPS[i + 1] : null;
  return (
    <nav aria-label="Next step" className="mx-auto mt-14 max-w-6xl px-4 pb-16 sm:px-6">
      <div className="grid gap-3 border-t-2 border-border pt-8 sm:grid-cols-3">
        {prev ? (
          <Link to={prev.to} className="inline-flex min-h-[56px] items-center gap-2 rounded-md border-2 border-border px-5 font-ui text-[1.125rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10">
            <ArrowLeft className="h-5 w-5" aria-hidden="true" /> Back: {prev.label}
          </Link>
        ) : <span />}
        <Link to="/greenhouse" className="inline-flex min-h-[56px] items-center justify-center gap-2 rounded-md border-2 border-border px-5 font-ui text-[1.125rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10">
          <Home className="h-5 w-5" aria-hidden="true" /> Greenhouse home
        </Link>
        {next ? (
          <Link to={next.to} className="inline-flex min-h-[56px] items-center justify-end gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 text-right font-ui text-[1.125rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            Next: {next.label} <ArrowRight className="h-5 w-5" aria-hidden="true" />
          </Link>
        ) : <span />}
      </div>
      <p className="mt-5 text-center text-[1.0625rem] text-[hsl(var(--ink))]">
        Return to the story:{' '}
        <Link to="/chronicle-2" className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">Chronicle II</Link>
        {' · '}
        <Link to="/chronicle-1" className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">Chronicle I</Link>
      </p>
    </nav>
  );
};
