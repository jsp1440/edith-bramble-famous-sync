import React from 'react';
import type { GreenhouseZone } from '@/lib/content-types';

/* A simple, keyboard-accessible plan of the greenhouse.
   Zone rectangles are data-driven so new zones can be added later. */
const LAYOUT: Record<string, { x: number; y: number; w: number; h: number }> = {
  'south-gallery': { x: 8, y: 96, w: 300, h: 54 },
  'north-walk': { x: 8, y: 14, w: 300, h: 54 },
  'ficus-canopy': { x: 316, y: 14, w: 108, h: 54 },
  'thermal-bench': { x: 316, y: 96, w: 108, h: 54 },
  'west-room': { x: 432, y: 14, w: 100, h: 136 },
  'potting-room': { x: 8, y: 158, w: 150, h: 40 },
  'old-bench': { x: 166, y: 158, w: 158, h: 40 },
};

interface Props {
  zones: GreenhouseZone[];
  activeId: string;
  onSelect: (id: string) => void;
}

const GreenhouseMap: React.FC<Props> = ({ zones, activeId, onSelect }) => (
  <div className="overflow-x-auto rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-3 sm:p-5">
    <svg
      viewBox="0 0 540 206"
      className="h-auto w-full min-w-[480px]"
      role="group"
      aria-label="Plan of Edith's greenhouse. Select an area to read about it."
    >
      <rect x="2" y="2" width="536" height="202" fill="hsl(var(--cream))" stroke="hsl(var(--moss))" strokeWidth="1.5" />
      {/* central aisle */}
      <rect x="8" y="72" width="300" height="20" fill="hsl(var(--moss)/0.10)" />
      <text x="158" y="86" textAnchor="middle" className="font-label" fontSize="8" fill="hsl(var(--moss))">
        CENTRAL AISLE
      </text>

      {zones.map((zone) => {
        const box = LAYOUT[zone.id];
        if (!box) return null;
        const active = zone.id === activeId;
        return (
          <g
            key={zone.id}
            role="button"
            tabIndex={0}
            aria-pressed={active}
            aria-label={`${zone.name}. ${zone.tagline}`}
            onClick={() => onSelect(zone.id)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(zone.id);
              }
            }}
            className="cursor-pointer focus:outline-none"
          >
            <rect
              x={box.x}
              y={box.y}
              width={box.w}
              height={box.h}
              rx="2"
              fill={active ? 'hsl(var(--botanical)/0.85)' : 'hsl(var(--botanical)/0.10)'}
              stroke={active ? 'hsl(var(--botanical))' : 'hsl(var(--moss)/0.55)'}
              strokeWidth="1.2"
            />
            <text
              x={box.x + box.w / 2}
              y={box.y + box.h / 2 + 1}
              textAnchor="middle"
              fontSize="9.5"
              className="font-label uppercase"
              fill={active ? 'hsl(var(--cream))' : 'hsl(var(--charcoal))'}
            >
              {zone.name.replace(/^The /, '')}
            </text>
            <text
              x={box.x + box.w / 2}
              y={box.y + box.h / 2 + 13}
              textAnchor="middle"
              fontSize="7"
              fill={active ? 'hsl(var(--cream)/0.85)' : 'hsl(var(--moss))'}
            >
              {zone.tagline}
            </text>
          </g>
        );
      })}
      <text x="530" y="200" textAnchor="end" fontSize="7" fill="hsl(var(--moss))">
        N ↑ — glazing to south
      </text>
    </svg>
  </div>
);

export default GreenhouseMap;
