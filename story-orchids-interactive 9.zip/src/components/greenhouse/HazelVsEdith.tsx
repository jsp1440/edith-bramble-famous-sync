import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { getMedia } from '@/lib/content';
import { profilePath } from '@/lib/orchid-continuum';
import { ActivityHeader, GreenhouseStepBar, StepFooter } from '@/components/greenhouse/GreenhouseShell';

type Spot = { id: string; x: number; y: number; title: string; body: string; profile?: string };

const HAZEL_SPOTS: Spot[] = [
  { id: 'h-pots', x: 18, y: 78, title: 'Uniform pots', body: 'These pots are beautifully uniform — but the plants inside them do not necessarily share the same ecological requirements.' },
  { id: 'h-baskets', x: 14, y: 40, title: 'Baskets lowered to one line', body: 'Tidy at eye level. But a basket hung this low, with a bench beneath it, leaves no room for inflorescences that grow downward.', profile: 'stanhopea' },
  { id: 'h-height', x: 80, y: 60, title: 'Grouped by height and bloom', body: 'Plants of matching height sit together because they look good together — not because they want the same light, water or temperature.' },
  { id: 'h-ficus', x: 52, y: 36, title: 'The Ficus clipped neat', body: 'A pruned canopy looks orderly, but it lets in light that the mounted plants beneath it were sheltered from.' },
  { id: 'h-missing', x: 50, y: 72, title: 'Where are the resting plants?', body: 'Nothing here is leafless. Dormant plants were treated as untidy and moved or "corrected" — even though their rest was normal.', profile: 'catasetinae' },
];

const EDITH_SPOTS: Spot[] = [
  { id: 'e-wet', x: 14, y: 74, title: 'The wet slipper bench', body: 'Different watering needs are intentionally separated. Trays and moss mark the bench that is kept consistently moist.', profile: 'phragmipedium' },
  { id: 'e-dry', x: 12, y: 46, title: 'The dry-rest shelf', body: 'Leafless does not necessarily mean unhealthy. Some orchids are entering a normal seasonal rest.', profile: 'catasetinae' },
  { id: 'e-baskets', x: 86, y: 30, title: 'Baskets hung high', body: 'These baskets hang because some inflorescences must grow downward, through and below the container.', profile: 'stanhopea' },
  { id: 'e-mounts', x: 58, y: 46, title: 'Mounts under the Ficus', body: 'Mounted plants take the dappled shade and moving air under the canopy, and dry quickly between waterings.' },
  { id: 'e-bright', x: 84, y: 62, title: 'The bright bench', body: 'Plants that need more light sit along the brighter glazing. Pot and plant sizes vary because the plants do.', profile: 'dendrobium-nobile' },
  { id: 'e-lath', x: 50, y: 56, title: 'Out to the lath house', body: 'Some plants live outside or are in transition, using coastal nights as a seasonal cue.', profile: 'cymbidium' },
];

const HazelVsEdith: React.FC = () => {
  const [pos, setPos] = useState(50);
  const [spots, setSpots] = useState(true);
  const [active, setActive] = useState<Spot | null>(null);
  const box = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const hazel = getMedia('gh-hazel-order');
  const edith = getMedia('gh-edith-biology');
  if (!hazel || !edith) return null;

  const moveTo = (clientX: number) => {
    const r = box.current?.getBoundingClientRect();
    if (!r) return;
    setPos(Math.max(0, Math.min(100, ((clientX - r.left) / r.width) * 100)));
  };

  const visible = [
    ...HAZEL_SPOTS.filter((s) => s.x < pos).map((s) => ({ ...s, side: 'hazel' as const })),
    ...EDITH_SPOTS.filter((s) => s.x > pos).map((s) => ({ ...s, side: 'edith' as const })),
  ];

  const viewBtn = (label: string, v: number) => (
    <button type="button" onClick={() => setPos(v)} aria-pressed={pos === v}
      className={`min-h-[48px] rounded-md border-2 px-4 font-ui text-[1.0625rem] font-semibold ${pos === v ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border bg-white/60 text-[hsl(var(--ink))]'}`}>
      {label}
    </button>
  );

  return (
    <div>
      <GreenhouseStepBar current="hazel" />
      <ActivityHeader step="Step 2 · Hazel vs. Edith" title="Health does not always look uniform">
        The same greenhouse, seen from the same doorway. Drag across the picture. Then tap the markers to see what changed — and why.
      </ActivityHeader>

      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          {viewBtn("Hazel's version", 100)}
          {viewBtn('Side by side', 50)}
          {viewBtn("Edith's version", 0)}
          <label className="ml-auto inline-flex min-h-[48px] items-center gap-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">
            <input type="checkbox" checked={spots} onChange={(e) => setSpots(e.target.checked)} className="h-5 w-5 accent-[hsl(var(--botanical))]" />
            Show markers
          </label>
        </div>

        <p className="mb-3 max-w-3xl text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">
          <strong>What you are comparing:</strong> the left side shows <strong>before</strong> — Hazel's greenhouse, ordered by appearance. The right side shows <strong>after</strong> — Edith's greenhouse, ordered by biology. Drag the round handle, use the slider below, or use the arrow keys.
        </p>
        <div
          ref={box}
          role="slider"
          tabIndex={0}
          aria-label="Compare Hazel's greenhouse (before) with Edith's greenhouse (after)"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(pos)}
          aria-valuetext={`${Math.round(pos)}% Hazel's greenhouse showing`}
          onKeyDown={(e) => {
            if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') { e.preventDefault(); setPos((p) => Math.max(0, p - 5)); }
            if (e.key === 'ArrowRight' || e.key === 'ArrowUp') { e.preventDefault(); setPos((p) => Math.min(100, p + 5)); }
            if (e.key === 'Home') { e.preventDefault(); setPos(0); }
            if (e.key === 'End') { e.preventDefault(); setPos(100); }
          }}
          className="relative aspect-[3/2] touch-pan-y select-none overflow-hidden rounded-md border-2 border-border focus-visible:outline focus-visible:outline-4 focus-visible:outline-offset-4 focus-visible:outline-[hsl(var(--botanical))]"
          onPointerDown={(e) => { if ((e.target as HTMLElement).closest('button')) return; dragging.current = true; moveTo(e.clientX); }}
          onPointerMove={(e) => dragging.current && moveTo(e.clientX)}
          onPointerUp={() => (dragging.current = false)}
          onPointerLeave={() => (dragging.current = false)}
        >
          <img src={edith.src} alt={edith.alt} className="absolute inset-0 h-full w-full object-cover" draggable={false} />
          <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
            <img src={hazel.src} alt={hazel.alt} className="absolute inset-0 h-full w-full object-cover" draggable={false} />
          </div>
          <div className="pointer-events-none absolute inset-y-0 w-1.5 -translate-x-1/2 bg-[hsl(var(--cream))] shadow-[0_0_10px_rgba(0,0,0,0.6)]" style={{ left: `${pos}%` }} aria-hidden="true">
            <span className="absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center gap-0.5 rounded-full border-4 border-[hsl(var(--botanical))] bg-[hsl(var(--cream))] text-[hsl(var(--botanical))] shadow-xl">
              <ChevronLeft className="h-6 w-6" strokeWidth={3} />
              <ChevronRight className="h-6 w-6" strokeWidth={3} />
            </span>
          </div>
          {pos > 12 && (
            <span className="pointer-events-none absolute left-3 top-3 max-w-[45%] rounded-md bg-[hsl(var(--charcoal))]/90 px-3 py-2 font-ui text-[1rem] font-bold uppercase leading-tight text-[hsl(var(--cream))] sm:text-[1.0625rem]">
              Before · Hazel's greenhouse<span className="block font-semibold normal-case">Ordered by appearance</span>
            </span>
          )}
          {pos < 88 && (
            <span className="pointer-events-none absolute right-3 top-3 max-w-[45%] rounded-md bg-[hsl(var(--botanical))]/95 px-3 py-2 text-right font-ui text-[1rem] font-bold uppercase leading-tight text-[hsl(var(--cream))] sm:text-[1.0625rem]">
              After · Edith's greenhouse<span className="block font-semibold normal-case">Ordered by biology</span>
            </span>
          )}
          {spots && visible.map((s, i) => (
            <button key={s.id} type="button" onClick={() => setActive(s)} aria-label={`${s.side === 'hazel' ? "Hazel's greenhouse" : "Edith's greenhouse"}: ${s.title}`}
              className={`absolute flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-[3px] border-white font-ui text-[1.125rem] font-bold text-white shadow-lg transition-transform hover:scale-110 ${s.side === 'hazel' ? 'bg-[hsl(var(--charcoal))]' : 'bg-[hsl(var(--botanical))]'} ${active?.id === s.id ? 'ring-4 ring-[hsl(var(--amber))]' : ''}`}
              style={{ left: `${s.x}%`, top: `${s.y}%` }}>
              {i + 1}
            </button>
          ))}
        </div>
        <label className="mt-4 block">
          <span className="flex flex-wrap items-center justify-between gap-x-3 font-ui text-[1.0625rem] font-bold text-[hsl(var(--ink))]">
            <span>← Show more of Edith's (after)</span>
            <span>Show more of Hazel's (before) →</span>
          </span>
          <input type="range" min={0} max={100} value={Math.round(pos)} onChange={(e) => setPos(Number(e.target.value))} aria-label="Move the dividing line between Hazel's greenhouse (before) and Edith's greenhouse (after)" className="mt-1 w-full" />
        </label>
        <p className="mt-1 text-[1rem] text-[hsl(var(--ink))]">Story illustrations — AI generated. They teach an idea; they are not photographs of a real collection.</p>

        <div aria-live="polite" className="mt-6 min-h-[8rem] rounded-md border-2 border-[hsl(var(--botanical))]/30 bg-[hsl(var(--cream))] p-5 sm:p-6">
          {active ? (
            <>
              <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">{HAZEL_SPOTS.some((s) => s.id === active.id) ? "Hazel's greenhouse" : "Edith's greenhouse"}</p>
              <h2 className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))] sm:text-3xl">{active.title}</h2>
              <p className="mt-2 text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">{active.body}</p>
              {active.profile && (
                <Link to={profilePath(active.profile, 'culture')} className="mt-3 inline-flex min-h-[48px] items-center rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))]">
                  View the culture profile →
                </Link>
              )}
            </>
          ) : (
            <p className="text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">Tap a numbered marker on the picture to read what it shows.</p>
          )}
        </div>

        <section className="mt-10 text-center">
          <p className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))] sm:text-4xl">Health does not always look uniform.</p>
          <p className="mx-auto mt-4 max-w-2xl font-display text-[1.5rem] italic leading-relaxed text-[hsl(var(--botanical))]">
            Hazel organized what she could see.<br />Edith organized for what each orchid needed.
          </p>
        </section>
      </div>
      <StepFooter current="hazel" />
    </div>
  );
};

export default HazelVsEdith;
