import React, { useState } from 'react';
import { microclimates, getGrowerCard, getMedia } from '@/lib/content';
import GrowerCardDialog from '@/components/story/GrowerCardDialog';

/* ---------- Edith's Autumn Map: eight microclimates ---------- */

export const MicroclimateMap: React.FC = () => {
  const [activeId, setActiveId] = useState(microclimates[0].id);
  const [card, setCard] = useState<string | null>(null);
  const zone = microclimates.find((m) => m.id === activeId) || microclimates[0];

  return (
    <div>
      <div className="overflow-hidden rounded-sm border border-border/80 bg-[hsl(40_30%_90%)]">
        <svg viewBox="0 0 440 190" className="w-full" role="group" aria-label="Plan of Edith's greenhouse microclimates">
          <rect x="4" y="22" width="352" height="164" fill="hsl(40 30% 95%)" stroke="hsl(30 20% 45%)" strokeWidth="1.5" />
          <text x="8" y="15" className="fill-[hsl(30_20%_35%)] font-label" fontSize="7">WEST · COOLS FIRST</text>
          <text x="280" y="15" className="fill-[hsl(30_20%_35%)] font-label" fontSize="7">OUTSIDE · LATH</text>
          <line x1="356" y1="22" x2="356" y2="186" stroke="hsl(30 20% 45%)" strokeDasharray="3 3" />
          {microclimates.map((m) => {
            const on = m.id === activeId;
            return (
              <g
                key={m.id}
                role="button"
                tabIndex={0}
                aria-pressed={on}
                aria-label={m.name}
                onClick={() => setActiveId(m.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setActiveId(m.id);
                  }
                }}
                className="cursor-pointer outline-none"
              >
                <rect
                  x={m.x}
                  y={m.y}
                  width={m.w}
                  height={m.h}
                  rx="2"
                  fill={on ? 'hsl(122 18% 29%)' : 'hsl(96 20% 80%)'}
                  stroke="hsl(122 18% 29%)"
                  strokeWidth={on ? 2 : 0.8}
                  className="transition-colors"
                />
                <text
                  x={m.x + m.w / 2}
                  y={m.y + m.h / 2 + 3}
                  textAnchor="middle"
                  fontSize="7.5"
                  className={on ? 'fill-[hsl(42_44%_97%)]' : 'fill-[hsl(30_14%_22%)]'}
                  style={{ fontFamily: 'Cinzel, serif' }}
                >
                  {m.name.length > 18 ? m.name.split(' ').slice(0, 2).join(' ') : m.name}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        {microclimates.map((m) => (
          <button
            key={m.id}
            type="button"
            onClick={() => setActiveId(m.id)}
            aria-pressed={m.id === activeId}
            className={`rounded-sm border px-3 py-2 font-label text-[0.52rem] uppercase ${
              m.id === activeId
                ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'border-border bg-background text-[hsl(var(--ink))]'
            }`}
          >
            {m.name}
          </button>
        ))}
      </div>

      <article aria-live="polite" className="mt-6 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6">
        <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">{zone.summary}</p>
        <h3 className="mt-1 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">{zone.name}</h3>
        <p className="mt-3 max-w-prose leading-relaxed text-[hsl(var(--ink))]">{zone.detail}</p>
        <p className="mt-4 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Example orchids</p>
        <ul className="mt-2 flex flex-wrap gap-2">
          {zone.orchids.map((o) => (
            <li key={o} className="rounded-full border border-border bg-background px-3 py-1 text-xs italic text-[hsl(var(--ink))]">
              {o}
            </li>
          ))}
        </ul>
        {zone.cards.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-3 border-t border-border/70 pt-4">
            {zone.cards.map((id) => {
              const c = getGrowerCard(id);
              if (!c) return null;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setCard(id)}
                  className="font-label text-[0.52rem] uppercase text-[hsl(var(--botanical))] underline underline-offset-4"
                >
                  Grower Card: {c.title.split(':')[0]}
                </button>
              );
            })}
          </div>
        )}
      </article>
      <GrowerCardDialog cardId={card} onClose={() => setCard(null)} />
    </div>
  );
};

/* ---------- Before / after: Hazel's uniform greenhouse vs Edith's ---------- */

export const BeforeAfter: React.FC = () => {
  const [pos, setPos] = useState(50);
  const before = getMedia('c2-perfect');
  const after = getMedia('c2-zone-map');
  if (!before || !after) return null;
  return (
    <div>
      <div className="relative aspect-[3/2] overflow-hidden rounded-sm border border-border/80">
        <img src={after.src} alt={after.alt} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 overflow-hidden" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
          <img src={before.src} alt={before.alt} className="absolute inset-0 h-full w-full object-cover" />
        </div>
        <div className="absolute inset-y-0 w-0.5 bg-[hsl(var(--cream))]" style={{ left: `${pos}%` }} aria-hidden="true" />
        <span className="absolute left-3 top-3 rounded-sm bg-[hsl(var(--charcoal))]/80 px-2 py-1 font-label text-[0.5rem] uppercase text-[hsl(var(--cream))]">Hazel: one climate</span>
        <span className="absolute right-3 top-3 rounded-sm bg-[hsl(var(--botanical))]/90 px-2 py-1 font-label text-[0.5rem] uppercase text-[hsl(var(--cream))]">Edith: many climates</span>
      </div>
      <label className="mt-3 block">
        <span className="sr-only">Compare Hazel's greenhouse and Edith's restored greenhouse</span>
        <input type="range" min={0} max={100} value={pos} onChange={(e) => setPos(Number(e.target.value))} className="w-full accent-[hsl(var(--botanical))]" />
      </label>
    </div>
  );
};

/* ---------- Build-a-Bench mini-game ---------- */

const plants = [
  { id: 'phrag', name: 'Phragmipedium', answer: 'wet-bench', why: 'Consistent root moisture — no dry rest.' },
  { id: 'cata', name: 'Catasetum (leafless)', answer: 'dry-rest', why: 'Leaves have fallen; it is in a dry winter rest.' },
  { id: 'den-warm', name: 'Phalaenanthe-type Dendrobium', answer: 'warm-zone', why: 'Warm-growing and evergreen.' },
  { id: 'den-nobile', name: 'Nobile-type Dendrobium', answer: 'cool-west', why: 'Mature canes benefit from a cooler autumn.' },
  { id: 'stan', name: 'Stanhopea', answer: 'hanging', why: 'Spikes grow down through an open basket.' },
  { id: 'cym', name: 'Cymbidium', answer: 'outdoor-lath', why: 'Cool coastal nights can cue spikes.' },
];

export const BuildABench: React.FC = () => {
  const [placed, setPlaced] = useState<Record<string, string>>({});
  const [checked, setChecked] = useState(false);
  const zones = microclimates.filter((m) => plants.some((p) => p.answer === m.id));
  const score = plants.filter((p) => placed[p.id] === p.answer).length;

  return (
    <div className="rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-5 sm:p-6">
      <ul className="space-y-3">
        {plants.map((p) => {
          const right = placed[p.id] === p.answer;
          return (
            <li key={p.id} className="grid gap-2 sm:grid-cols-[14rem_1fr] sm:items-center">
              <span className="font-display text-lg text-[hsl(var(--charcoal))]">{p.name}</span>
              <div>
                <select
                  value={placed[p.id] || ''}
                  onChange={(e) => {
                    setChecked(false);
                    setPlaced((s) => ({ ...s, [p.id]: e.target.value }));
                  }}
                  aria-label={`Zone for ${p.name}`}
                  className="w-full rounded-sm border border-border bg-background px-3 py-2.5 text-sm"
                >
                  <option value="">Choose a zone…</option>
                  {zones.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.name}
                    </option>
                  ))}
                </select>
                {checked && (
                  <p className={`mt-1 text-sm ${right ? 'text-[hsl(var(--botanical))]' : 'text-[hsl(var(--burgundy))]'}`}>
                    {right ? 'Sensible. ' : `Edith would use the ${microclimates.find((m) => m.id === p.answer)?.name}. `}
                    {p.why}
                  </p>
                )}
              </div>
            </li>
          );
        })}
      </ul>
      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={() => setChecked(true)}
          disabled={Object.keys(placed).length < plants.length}
          className="rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))] disabled:opacity-50"
        >
          Explain my choices
        </button>
        <button
          type="button"
          onClick={() => {
            setPlaced({});
            setChecked(false);
          }}
          className="rounded-sm border border-border px-4 py-2.5 font-label text-[0.55rem] uppercase text-[hsl(var(--ink))]"
        >
          Reset
        </button>
        {checked && (
          <span className="font-display text-lg italic text-[hsl(var(--botanical))]" role="status">
            {score} of {plants.length} placed as Edith would. Real greenhouses allow for judgement.
          </span>
        )}
      </div>
    </div>
  );
};
