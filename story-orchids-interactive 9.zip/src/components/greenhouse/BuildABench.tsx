import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, RotateCcw, Scale, Eye } from 'lucide-react';
import { ZONES, zoneShort } from '@/content/edith-greenhouse';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { atlasPath, explorePath } from '@/lib/feature-genius';
import { ActivityHeader, GreenhouseStepBar, StepFooter } from '@/components/greenhouse/GreenhouseShell';

type Fit = 'good' | 'possible' | 'poor' | 'info';
type Factor = 'temperature' | 'moisture' | 'light' | 'airflow' | 'seasonal state' | 'growth stage' | 'container';
type Verdict = { fit: Fit; why: string; factors: Factor[] };
type BenchPlant = { id: string; name: string; state: string; profile: string; fits: Record<string, Verdict>; otherwise: Verdict };

const FIT_UI: Record<Fit, { label: string; icon: React.ElementType; tone: string }> = {
  good: { label: 'Good fit', icon: CheckCircle2, tone: 'border-[hsl(150_40%_28%)] bg-[hsl(150_30%_92%)] text-[hsl(150_45%_16%)]' },
  possible: { label: 'Possible with conditions', icon: AlertTriangle, tone: 'border-[hsl(38_60%_38%)] bg-[hsl(44_70%_91%)] text-[hsl(30_60%_18%)]' },
  poor: { label: 'Poor fit', icon: XCircle, tone: 'border-[hsl(0_45%_38%)] bg-[hsl(0_50%_94%)] text-[hsl(0_55%_22%)]' },
  info: { label: 'Needs more information', icon: HelpCircle, tone: 'border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] text-[hsl(30_25%_14%)]' },
};

/* Edith's reasoning for HER fictional greenhouse. Orchid-biology claims
   behind these choices are in the linked Culture Library profiles, each
   with its own evidence status. Species, hybrids and local climates vary. */
const PLANTS: BenchPlant[] = [
  {
    id: 'phrag', name: 'Phragmipedium', state: 'In active growth', profile: 'phragmipedium',
    fits: {
      'wet-bench': { fit: 'good', why: 'Consistently moist media with moving air is how Edith grows the Phragmipediums in her collection. Species and hybrids differ, so she still watches each plant.', factors: ['moisture', 'airflow'] },
      'warm-zone': { fit: 'possible', why: 'Possible if watering stays consistent. How much warmth suits it depends on the species or hybrid.', factors: ['temperature', 'moisture'] },
      'cool-west': { fit: 'info', why: 'Some Phragmipedium grow cooler than others. Which species or hybrid is it?', factors: ['temperature'] },
      'dry-rest': { fit: 'poor', why: 'A dry rest is exactly what Edith does not give this plant — the wet bench exists for it.', factors: ['moisture', 'seasonal state'] },
      hanging: { fit: 'poor', why: 'Open baskets high in the house dry fast; consistent moisture would be very hard to keep.', factors: ['moisture', 'container'] },
    },
    otherwise: { fit: 'info', why: 'Edith would ask how moisture could be kept consistent there before choosing it.', factors: ['moisture'] },
  },
  {
    id: 'cata', name: 'Catasetum', state: 'Leafless, growth mature', profile: 'catasetinae',
    fits: {
      'dry-rest': { fit: 'good', why: 'The leaves have fallen after a completed growth, so it moves where it will not be watered with everything else — until new growth appears.', factors: ['seasonal state', 'moisture', 'growth stage'] },
      'wet-bench': { fit: 'poor', why: 'Constant moisture during rest is the one thing Edith is trying to avoid for this plant.', factors: ['moisture', 'seasonal state'] },
      hanging: { fit: 'possible', why: 'Possible if the basket is left out of the watering round while the plant rests.', factors: ['moisture', 'container'] },
      'warm-zone': { fit: 'possible', why: 'Warmth is not the problem — watering is. Possible if it is excluded from the routine.', factors: ['temperature', 'moisture'] },
    },
    otherwise: { fit: 'info', why: 'Is the leaf drop a normal seasonal rest, or a sign of a problem? Check the pseudobulb and roots first.', factors: ['seasonal state', 'growth stage'] },
  },
  {
    id: 'den-warm', name: 'Phalaenanthe-type Dendrobium', state: 'Evergreen, in leaf', profile: 'dendrobium-phalaenanthe',
    fits: {
      'warm-zone': { fit: 'good', why: 'A warm, protected, stable position suits this warm-growing, evergreen type.', factors: ['temperature'] },
      cattleya: { fit: 'possible', why: 'The light can suit; possible if it stays warm enough as the south bench cools at night.', factors: ['light', 'temperature'] },
      'cool-west': { fit: 'poor', why: 'The cool autumn contrast a nobile-type uses is the treatment this group is not given.', factors: ['temperature', 'seasonal state'] },
      'dry-rest': { fit: 'poor', why: 'It keeps its leaves and is not entering a hard dry rest.', factors: ['moisture', 'seasonal state'] },
      'outdoor-lath': { fit: 'poor', why: 'Coastal autumn nights outdoors are cooler than Edith gives this plant.', factors: ['temperature'] },
    },
    otherwise: { fit: 'info', why: 'Edith would check how warm that spot stays at night before choosing it.', factors: ['temperature'] },
  },
  {
    id: 'den-nobile', name: 'Nobile-type Dendrobium', state: 'Canes mature', profile: 'dendrobium-nobile',
    fits: {
      'cool-west': { fit: 'good', why: 'Mature canes get the cooler autumn nights Edith uses as a seasonal cue for this group.', factors: ['temperature', 'seasonal state', 'growth stage'] },
      cattleya: { fit: 'possible', why: 'Bright light suits; possible if nights there cool enough in autumn.', factors: ['light', 'temperature'] },
      'outdoor-lath': { fit: 'possible', why: 'Possible on the coast while autumn nights are cool but not extreme.', factors: ['temperature', 'light'] },
      'warm-zone': { fit: 'poor', why: 'Kept warm through autumn, it misses the seasonal contrast Edith relies on for this group.', factors: ['temperature', 'seasonal state'] },
      'wet-bench': { fit: 'poor', why: 'Constantly moist media is not how Edith treats mature canes in autumn.', factors: ['moisture', 'seasonal state'] },
    },
    otherwise: { fit: 'info', why: 'Are the canes mature yet? Edith changes treatment only once growth has finished.', factors: ['growth stage'] },
  },
  {
    id: 'stan', name: 'Stanhopea', state: 'Spikes forming', profile: 'stanhopea',
    fits: {
      hanging: { fit: 'good', why: 'Its inflorescences grow downward through and below an open basket; hanging high leaves room beneath.', factors: ['container', 'growth stage'] },
      ficus: { fit: 'possible', why: 'Possible if hung in an open basket under the canopy with clear space below.', factors: ['container', 'light'] },
    },
    otherwise: { fit: 'poor', why: 'On a bench in a solid pot, spikes that grow downward have nowhere to go. The container matters as much as the spot.', factors: ['container'] },
  },
  {
    id: 'cym', name: 'Cymbidium', state: 'Autumn, before spiking', profile: 'cymbidium',
    fits: {
      'outdoor-lath': { fit: 'good', why: 'Outdoor light and cool coastal nights, protected from extremes, are how Edith grows hers.', factors: ['temperature', 'light', 'seasonal state'] },
      'cool-west': { fit: 'possible', why: 'Possible if it gets enough light; indoors it may get less night contrast.', factors: ['light', 'temperature'] },
      cattleya: { fit: 'possible', why: 'Bright enough; possible if nights there still cool.', factors: ['light', 'temperature'] },
      'warm-zone': { fit: 'poor', why: 'Kept warm, it loses the cool autumn nights Edith uses for it.', factors: ['temperature', 'seasonal state'] },
      staging: { fit: 'info', why: 'Staging is temporary. Where is the plant going next?', factors: ['seasonal state'] },
    },
    otherwise: { fit: 'info', why: 'Edith would ask whether that spot gets enough light and cool nights.', factors: ['light', 'temperature'] },
  },
];

/* STEP 2 — WHY? Placement alone is not enough. Each plant asks the reader to
   name the observable biology behind a good placement. Wrong reasons are
   answered with another observation to make, never a bare red X. */
type WhyOption = { text: string; correct?: boolean; feedback: string };
type WhyStep = { options: WhyOption[]; monitor: string; taxon: string };
const WHY: Record<string, WhyStep> = {
  phrag: {
    taxon: 'Phragmipedium',
    monitor: 'Pot weight, leaves beginning to fold, fresh root tips, and potting mix that is starting to break down.',
    options: [
      { text: 'It has no pseudobulb, and its leaves fold when the pot dries — it has little stored water to fall back on.', correct: true, feedback: 'Yes. Without a storage organ, steady root-zone moisture — with air around the roots — is what keeps many Phragmipediums growing.' },
      { text: 'Its leaves are green, so it wants a lot of water.', feedback: 'Look again: green leaves alone do not tell you about water needs — a Cattleya has green leaves too. What storage organ is missing on this plant?' },
      { text: 'Slipper orchids always grow standing in water.', feedback: 'Look at the roots: they are fuzzy and need oxygen. Many Phragmipediums like steady moisture, not stagnant water — and some species grow drier.' },
    ],
  },
  cata: {
    taxon: 'Catasetum',
    monitor: 'Pseudobulb firmness, then the first new shoot at the base — and wait for its new roots before watering resumes.',
    options: [
      { text: 'The growth is finished and the leaves have fallen; the plump pseudobulb is holding the season’s water while it rests.', correct: true, feedback: 'Yes. Leaf fall after a completed growth marks the start of rest, so it is kept out of the watering round.' },
      { text: 'The leaves fell because it is dying, so let it dry out.', feedback: 'Look again at the pseudobulb: firm and plump means alive and storing. This is rest, not death.' },
      { text: 'Yellow leaves meant it was thirsty.', feedback: 'That was Hazel’s reading. Feel the pot: it was heavy and wet. Even yellowing on a mature growth is the plant getting ready to rest.' },
    ],
  },
  'den-warm': {
    taxon: 'Dendrobium bigibbum',
    monitor: 'Leaf drop or spotting after cool nights — a warning sign for this type.',
    options: [
      { text: 'Its canes stay leafy for years — a warm-lowland plant that is not built for a cold, dry rest.', correct: true, feedback: 'Yes. Evergreen canes that keep working leaves fit an ancestry where winter never turns cold.' },
      { text: 'Every Dendrobium needs a cool winter to flower.', feedback: 'Look at the nobile-type beside it: same genus, different planet. That one rests; this one keeps its leaves all year.' },
      { text: 'It only needs warmth while it is in flower.', feedback: 'Look at the older canes: they still carry leaves from past seasons. That is a year-round warm grower.' },
    ],
  },
  'den-nobile': {
    taxon: 'Dendrobium nobile',
    monitor: 'Swelling nodes along the canes (buds or keikis — wait and see) and frost risk on the coldest nights.',
    options: [
      { text: 'The canes have finished — a final leaf has formed at the tip — so cooler, brighter, drier nights now help it set buds.', correct: true, feedback: 'Yes. Mature canes plus seasonal cooling is the autumn transition this group comes from.' },
      { text: 'Cool air makes every orchid flower.', feedback: 'Look at the warm-type Dendrobium nearby: the same chill would hurt it. It is this group’s origin, not a universal rule.' },
      { text: 'It is losing a few old leaves, so it needs more fertilizer.', feedback: 'Check the canes: mature, with a terminal leaf. Growers report that late nitrogen tends to give keikis instead of flowers.' },
    ],
  },
  stan: {
    taxon: 'Stanhopea',
    monitor: 'Spike tips pushing through the bottom of the basket — keep the space underneath clear.',
    options: [
      { text: 'Its flower spikes grow downward through the root mass, so it needs an open basket with room below.', correct: true, feedback: 'Yes. The container is part of the biology: in a solid pot the spike meets a wall.' },
      { text: 'It likes to be up high where it is warmer.', feedback: 'Look underneath the plant: that is where the spikes are heading. The open basket, not the height, is the key.' },
      { text: 'Hanging plants need less water.', feedback: 'Look again: Stanhopeas generally want regular moisture. The reason for the basket is the downward spike.' },
    ],
  },
  cym: {
    taxon: 'Cymbidium',
    monitor: 'Round, firm shoots at the base (likely a spike) versus shoots that flatten into leaves (a new growth) — and frost forecasts.',
    options: [
      { text: 'It is a mature growth before spiking; bright light and cool coastal autumn nights are associated with spike initiation in many standard types.', correct: true, feedback: 'Yes. The lath house delivers light, moving air and night cooling that a uniformly warm greenhouse cannot.' },
      { text: 'Cymbidiums are hardy, so cold cannot hurt them.', feedback: 'Look again: frost is still an enemy. Cool nights, yes; freezing, no.' },
      { text: 'Outside it gets rain, so it needs less care.', feedback: 'Look at what the lath gives instead: light, moving air and cool nights. Watering still follows the plant.' },
    ],
  },
};

const WhyPanel: React.FC<{ plantId: string; zoneId: string }> = ({ plantId, zoneId }) => {
  const step = WHY[plantId];
  const [pick, setPick] = useState<number | null>(null);
  if (!step) return null;
  const chosen = pick !== null ? step.options[pick] : null;
  return (
    <fieldset key={zoneId} className="mt-4 rounded-md border-2 border-[hsl(var(--charcoal))]/30 bg-white p-4">
      <legend className="px-1 font-ui text-[1.1875rem] font-bold text-[hsl(var(--charcoal))]">Now: why does this place work? Choose the observation.</legend>
      <div className="mt-2 grid gap-2">
        {step.options.map((o, i) => (
          <button key={i} type="button" aria-pressed={pick === i} onClick={() => setPick(i)}
            className={`min-h-[56px] rounded-md border-2 px-4 py-3 text-left text-[1.125rem] leading-snug ${pick === i ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))]/10 font-semibold' : 'border-[hsl(var(--charcoal))]/30 bg-white hover:border-[hsl(var(--botanical))]'}`}>
            {o.text}
          </button>
        ))}
      </div>
      {chosen && (
        <div aria-live="polite" className={`mt-3 rounded-md border-2 p-4 ${chosen.correct ? 'border-[hsl(150_40%_28%)] bg-[hsl(150_30%_94%)] text-[hsl(150_45%_14%)]' : 'border-[hsl(38_60%_38%)] bg-[hsl(44_70%_93%)] text-[hsl(30_60%_16%)]'}`}>
          <p className="flex items-center gap-2 font-ui text-[1.125rem] font-bold uppercase tracking-wide">
            {chosen.correct ? <CheckCircle2 className="h-5 w-5" aria-hidden="true" /> : <Eye className="h-5 w-5" aria-hidden="true" />}
            {chosen.correct ? 'Good reasoning' : 'Look again'}
          </p>
          <p className="mt-2 text-[1.1875rem] leading-relaxed">{chosen.feedback}</p>
          {chosen.correct ? (
            <>
              <p className="mt-3 text-[1.125rem]"><strong>What to watch next:</strong> {step.monitor}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Link to={explorePath(step.taxon)} className="inline-flex min-h-[48px] items-center rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">Explore this orchid</Link>
                <Link to={atlasPath(step.taxon)} className="inline-flex min-h-[48px] items-center rounded-md border-2 border-current px-4 font-ui text-[1.0625rem] font-semibold">Atlas</Link>
                <a href={`https://www.biodiversitylibrary.org/search?searchTerm=${encodeURIComponent(step.taxon)}`} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[48px] items-center rounded-md border-2 border-current px-4 font-ui text-[1.0625rem] font-semibold">Literature</a>
              </div>
            </>
          ) : (
            <p className="mt-2 text-[1.0625rem] font-semibold">Choose another reason above.</p>
          )}
        </div>
      )}
    </fieldset>
  );
};

const OPTIONS = ZONES.filter((z) => z.kind === 'growing' || z.id === 'staging');

const BuildABench: React.FC = () => {
  const [placed, setPlaced] = useState<Record<string, string>>({});
  const [round, setRound] = useState(0);
  const done = Object.keys(placed).length;

  return (
    <div>
      <GreenhouseStepBar current="bench" />
      <ActivityHeader step="Step 3 · Build a bench" title="Build a bench" question="Where would you put them — and why?">
        First choose a place for each orchid. If the place suits it, you will then be asked <strong>why</strong>: pick the observation about
        the plant that makes that place right. There is often more than one reasonable place.
      </ActivityHeader>

      <div key={round} className="mx-auto max-w-5xl space-y-5 px-4 sm:px-6">
        {PLANTS.map((p) => {
          const zoneId = placed[p.id];
          const v = zoneId ? p.fits[zoneId] ?? p.otherwise : null;
          const ui = v ? FIT_UI[v.fit] : null;
          const Icon = ui?.icon;
          const prof = getProfile(p.profile);
          const askWhy = v && (v.fit === 'good' || v.fit === 'possible');
          return (
            <section key={p.id} className="rounded-md border-2 border-border bg-white/70 p-5 sm:p-6">
              <div className="grid gap-3 sm:grid-cols-[1fr_minmax(0,18rem)] sm:items-center">
                <div>
                  <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</h2>
                  <p className="text-[1.125rem] text-[hsl(var(--ink))]">Right now: <strong>{p.state}</strong></p>
                </div>
                <label className="flex flex-col gap-1 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]">
                  1. Where should it go?
                  <select value={zoneId || ''} onChange={(e) => setPlaced((s) => ({ ...s, [p.id]: e.target.value }))}
                    className="min-h-[52px] w-full rounded-md border-2 border-border bg-background px-3 text-[1.125rem] font-normal text-[hsl(var(--ink))]">
                    <option value="">Choose a place…</option>
                    {OPTIONS.map((z) => <option key={z.id} value={z.id}>{zoneShort(z.id)}</option>)}
                  </select>
                </label>
              </div>

              {v && ui && Icon && (
                <div aria-live="polite" className={`mt-4 rounded-md border-2 p-4 ${ui.tone}`}>
                  <p className="flex items-center gap-2 font-ui text-[1.125rem] font-bold uppercase tracking-wide">
                    <Icon className="h-5 w-5" aria-hidden="true" /> {ui.label} · {zoneShort(zoneId)}
                  </p>
                  <p className="mt-2 text-[1.1875rem] leading-relaxed">{v.why}</p>
                  <p className="mt-2 text-[1rem]"><strong>Look at:</strong> {v.factors.join(' · ')}</p>
                  {!askWhy && <p className="mt-2 text-[1.0625rem] font-semibold">Try another place using that observation.</p>}
                  <div className="mt-3 flex flex-wrap gap-2">
                    {prof && (
                      <Link to={profilePath(p.profile, 'culture')} className="inline-flex min-h-[44px] items-center rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1rem] font-semibold text-[hsl(var(--cream))]">View culture profile</Link>
                    )}
                    <Link to={profilePath(p.profile, 'evidence')} className="inline-flex min-h-[44px] items-center rounded-md border-2 border-current px-4 font-ui text-[1rem] font-semibold">View sources</Link>
                  </div>
                </div>
              )}
              {askWhy && <WhyPanel key={zoneId} plantId={p.id} zoneId={zoneId} />}
            </section>
          );
        })}

        <div className="flex flex-wrap items-center gap-3 rounded-md bg-[hsl(var(--botanical))]/[0.06] p-5">
          <p className="text-[1.1875rem] text-[hsl(var(--ink))]">{done} of {PLANTS.length} placed. Real greenhouses allow for judgement.</p>
          <button type="button" onClick={() => { setPlaced({}); setRound((r) => r + 1); }} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-border bg-white px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">
            <RotateCcw className="h-4 w-4" aria-hidden="true" /> Start again
          </button>
          <Link to="/greenhouse/compare" className="ml-auto inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            <Scale className="h-5 w-5" aria-hidden="true" /> Compare two orchids
          </Link>
        </div>
        <p className="text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
          These verdicts describe Edith's reasoning in her fictional coastal greenhouse. The orchid biology behind them lives in each Culture
          Library profile, where every statement shows its evidence status. Orchid culture varies among species, hybrids, climates and growing systems.
          The calendar tells you what to watch for; the orchid tells you what is happening.
        </p>
      </div>
      <StepFooter current="bench" />
    </div>
  );
};

export default BuildABench;
