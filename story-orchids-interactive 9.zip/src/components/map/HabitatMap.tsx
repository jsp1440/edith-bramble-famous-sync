import React from 'react';
import { Link } from 'react-router-dom';
import { Globe2 } from 'lucide-react';
import type { OrchidProfile } from '@/lib/orchid-types';
import type { MapRecord } from '@/lib/evidence-types';
import { DistributionMap } from '@/components/science/OrchidProfileView';
import AtlasMap from '@/components/explore/AtlasMap';
import { PROFILE_TAXON, explorePath, useOrchidExplorer } from '@/lib/feature-genius';

/* ------------------------------------------------------------------
   Culture-profile map. Uses the interactive Atlas (documented records,
   hex-binned for conservation privacy). The Google Maps basemap stays
   available as a future provider once the Maps API is enabled on the
   gateway project (see basemap-static edge function).
------------------------------------------------------------------- */

const HabitatMap: React.FC<{ profile: OrchidProfile; records?: MapRecord[] }> = ({ profile }) => {
  const taxon = PROFILE_TAXON[profile.id] ?? profile.acceptedName.split(' (')[0];
  const { data, state } = useOrchidExplorer(taxon);

  return (
    <div className="space-y-5">
      {state === 'loading' && <p className="rounded-lg border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-white p-6 text-center text-[1.125rem]">Loading the Atlas…</p>}
      {state === 'error' && <p className="rounded-lg border-2 border-[hsl(var(--burgundy))] bg-white p-5 text-[1.125rem]">The Atlas could not be reached just now. Please try again shortly.</p>}
      {state === 'ok' && data?.found && data.taxon && (
        <>
          <p className="text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
            Documented records of <em>{data.taxon.name}</em> ({data.occurrences.total.toLocaleString()} in total). Drag the map, or use the buttons.
          </p>
          <AtlasMap taxonKey={data.taxon.key} taxonName={data.taxon.name} initial={data.view} />
        </>
      )}
      <Link
        to={explorePath(taxon)}
        className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
      >
        <Globe2 className="h-5 w-5" aria-hidden="true" /> Explore this orchid — photographs, records and Atlas
      </Link>
      <details className="rounded-lg border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-white p-5">
        <summary className="cursor-pointer font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">Teaching sketch — not a scientific range map</summary>
        <p className="mt-2 text-[1.0625rem] text-[hsl(var(--ink))]">A hand-placed sketch of the broad regions named in this profile. It has no data behind it.</p>
        <div className="mt-3 max-w-xl">
          <DistributionMap profile={profile} />
        </div>
      </details>
    </div>
  );
};

export default HabitatMap;
