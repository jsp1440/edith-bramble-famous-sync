import React, { useEffect } from 'react';
import { Link, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { DiscoveryProvider } from '@/contexts/DiscoveryContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { ReadingProvider } from '@/contexts/ReadingContext';
import AuthModal from '@/components/auth/AuthModal';
import SiteHeader from '@/components/site/SiteHeader';
import SiteFooter from '@/components/site/SiteFooter';
import HomePage from '@/components/pages/HomePage';
import LibraryPage from '@/components/pages/LibraryPage';
import ChroniclePage from '@/components/pages/ChroniclePage';
import CabinetPage from '@/components/pages/CabinetPage';
import ColoringPage from '@/components/pages/ColoringPage';
import GoDeeperPage from '@/components/pages/GoDeeperPage';
import AboutPage from '@/components/pages/AboutPage';
import AdminPage from '@/components/pages/AdminPage';
import SciencePage from '@/components/pages/SciencePage';
import GreenhousePage, { GreenhouseComparePage } from '@/components/pages/GreenhousePage';
import NotebookPage from '@/components/pages/NotebookPage';
import CharactersPage from '@/components/pages/CharactersPage';
import GrowPage from '@/components/pages/GrowPage';
import DiagnosticBenchPage from '@/components/pages/DiagnosticBenchPage';
import ColorGreenhousePage from '@/components/pages/ColorGreenhousePage';
import AutumnKitchenPage from '@/components/pages/AutumnKitchenPage';
import FcosPage from '@/components/pages/FcosPage';
import ModulePage from '@/components/modules/ModulePage';
import CultureLibraryPage from '@/components/pages/CultureLibraryPage';
import WalkTheGreenhouse from '@/components/greenhouse/WalkTheGreenhouse';
import HazelVsEdith from '@/components/greenhouse/HazelVsEdith';
import BuildABench from '@/components/greenhouse/BuildABench';
import { ExpertReviewPage, HowWeHandleEvidencePage, ReportEvidencePage } from '@/components/pages/EvidencePages';
import OrchidExplorerPage from '@/components/pages/OrchidExplorerPage';
import SpeciesDossierPage from '@/components/pages/SpeciesDossierPage';

const ScrollToTop: React.FC = () => {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const t = window.setTimeout(() => {
        document.getElementById(hash.slice(1))?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 120);
      return () => window.clearTimeout(t);
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [pathname, hash]);
  return null;
};


const MissingPage: React.FC = () => (
  <div className="mx-auto max-w-2xl px-4 py-28 text-center">
    <p className="font-label uppercase text-[hsl(var(--moss))]">Nothing on this bench</p>
    <h1 className="mt-3 font-display text-4xl font-semibold text-[hsl(var(--charcoal))]">
      That page has not been potted yet
    </h1>
    <p className="mt-4 text-[1.25rem] text-[hsl(var(--ink))]">
      The path you followed does not exist in this greenhouse. The Library is a good place to start again.
    </p>
    <Link
      to="/library"
      className="mt-8 inline-flex min-h-[52px] items-center rounded-md bg-[hsl(var(--botanical))] px-6 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
    >
      Chronicle Library
    </Link>
  </div>
);

const AppLayout: React.FC = () => (
  <ReadingProvider>
  <AuthProvider>
    <DiscoveryProvider>
      <div className="flex min-h-screen flex-col">
        <ScrollToTop />
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-[hsl(var(--botanical))] focus:px-5 focus:py-3 focus:font-ui focus:text-lg focus:font-semibold focus:text-[hsl(var(--cream))]"
        >
          Skip to content
        </a>
        <SiteHeader />
        <main id="main" className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/chronicles" element={<HomePage />} />
            <Route path="/library" element={<LibraryPage />} />
            <Route path="/chronicle-1" element={<ChroniclePage slug="chronicle-i" />} />
            <Route path="/chronicle-2" element={<ChroniclePage slug="chronicle-ii" />} />
            <Route path="/chronicle/:slug" element={<ChroniclePage />} />
            <Route path="/greenhouse" element={<GreenhousePage />} />
            <Route path="/greenhouse/walk" element={<WalkTheGreenhouse />} />
            <Route path="/greenhouse/hazel-vs-edith" element={<HazelVsEdith />} />
            <Route path="/greenhouse/build-a-bench" element={<BuildABench />} />
            <Route path="/greenhouse/compare" element={<GreenhouseComparePage />} />
            <Route path="/edith-greenhouse" element={<Navigate to="/greenhouse/walk" replace />} />
            <Route path="/culture-library" element={<CultureLibraryPage />} />
            <Route path="/culture-library/:profileId" element={<CultureLibraryPage />} />
            <Route path="/how-we-handle-evidence" element={<HowWeHandleEvidencePage />} />
            <Route path="/report-evidence" element={<ReportEvidencePage />} />
            <Route path="/expert-review" element={<ExpertReviewPage />} />
            <Route path="/science" element={<SciencePage />} />
            <Route path="/science/orchids" element={<CultureLibraryPage />} />
            <Route path="/science/orchids/:profileId" element={<CultureLibraryPage />} />
            <Route path="/science/:conceptId" element={<SciencePage />} />
            <Route path="/notebook" element={<NotebookPage />} />
            <Route path="/characters" element={<CharactersPage />} />
            <Route path="/explore" element={<OrchidExplorerPage />} />
            <Route path="/explore/:taxon" element={<OrchidExplorerPage />} />
            <Route path="/species/:key" element={<SpeciesDossierPage />} />
            <Route path="/species/:key/:slug" element={<SpeciesDossierPage />} />
            <Route path="/grow" element={<GrowPage />} />
            <Route path="/diagnostic-bench" element={<DiagnosticBenchPage />} />
            <Route path="/color" element={<ColorGreenhousePage />} />
            <Route path="/fcos" element={<FcosPage />} />

            <Route path="/journal" element={<ModulePage moduleId="journal" />} />
            <Route path="/grimoire" element={<ModulePage moduleId="grimoire" />} />
            <Route path="/potting-bench" element={<ModulePage moduleId="potting-bench" />} />
            <Route path="/plant-doctor" element={<ModulePage moduleId="plant-doctor" />} />
            <Route path="/kitchen" element={<AutumnKitchenPage />} />
            <Route path="/edith-kitchen" element={<ModulePage moduleId="kitchen" />} />

            <Route path="/herbarium" element={<ModulePage moduleId="herbarium" />} />
            <Route path="/plates" element={<ModulePage moduleId="plates" />} />
            <Route path="/watch-listen" element={<ModulePage moduleId="watch-listen" />} />
            <Route path="/coloring" element={<ColoringPage />} />
            <Route path="/cabinet" element={<CabinetPage />} />
            <Route path="/go-deeper" element={<GoDeeperPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="*" element={<MissingPage />} />
          </Routes>
        </main>
        <SiteFooter />
        <AuthModal />
      </div>
    </DiscoveryProvider>
  </AuthProvider>
  </ReadingProvider>
);

export default AppLayout;
