import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { getMedia } from '@/lib/content';
import { dataSource, getProfile, listProfiles } from '@/lib/orchid-continuum';
import OrchidProfileView from '@/components/science/OrchidProfileView';
import NeighborsExplorer from '@/components/greenhouse/NeighborsExplorer';

const CHAIN = ['Origin', 'Habitat', 'Conditions', 'Adaptation', 'Anatomy', 'Function', 'What the grower sees', 'Culture'];

/* The Science Greenhouse: index of orchid science profiles, and each profile page. */
const OrchidProfilePage: React.FC = () => {
  const { profileId } = useParams();
  const profile = getProfile(profileId);

  if (profileId && !profile) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-28 text-center">
        <h1 className="font-display text-3xl text-[hsl(var(--charcoal))]">No profile on this bench yet</h1>
        <Link to="/science/orchids" className="mt-6 inline-block font-label text-[0.6rem] uppercase text-[hsl(var(--botanical))] underline">
          All orchid profiles
        </Link>
      </div>
    );
  }

  if (profile) {
    const img = getMedia(profile.image);
    return (
      <article className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14">
        <Link to="/science/orchids" className="inline-flex items-center gap-2 font-label text-[0.58rem] uppercase text-[hsl(var(--moss))] hover:text-[hsl(var(--botanical))]">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" /> The Science Greenhouse
        </Link>
        <header className="mt-6 grid gap-6 sm:grid-cols-[1fr_12rem] sm:items-end">
          <div>
            <p className="font-label text-[0.58rem] uppercase text-[hsl(var(--amber))]">Why does this orchid do that?</p>
            <h1 className="mt-2 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">{profile.name}</h1>
          </div>
          {img && (
            <figure>
              <img src={img.src} alt={img.alt} className="aspect-square w-full rounded-sm border border-border/70 object-cover" />
              <figcaption className="mt-1 font-label text-[0.46rem] uppercase text-muted-foreground">Illustration · not a photograph</figcaption>
            </figure>
          )}
        </header>
        <div className="mt-8">
          <OrchidProfileView profile={profile} />
        </div>
      </article>
    );
  }

  return (
    <div>
      <header className="border-b border-border/70 bg-[linear-gradient(180deg,hsl(150_14%_14%),hsl(160_12%_20%))]">
        <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-20">
          <p className="font-label text-[0.6rem] uppercase text-[hsl(36_60%_72%)]">The Science Greenhouse</p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight text-[hsl(42_40%_95%)] sm:text-6xl">Why does this orchid do that?</h1>
          <p className="mt-4 max-w-2xl font-display text-xl italic text-[hsl(36_40%_82%)]">
            To understand how to grow an orchid, first ask where it came from. The label tells you what it is. The plant tells you how it lives.
          </p>
          <ol className="mt-8 flex flex-wrap items-center gap-2" aria-label="The causal chain">
            {CHAIN.map((c, i) => (
              <li key={c} className="flex items-center gap-2">
                <span className="rounded-sm border border-[hsl(36_40%_70%)]/40 px-2.5 py-1 font-label text-[0.5rem] uppercase text-[hsl(42_30%_88%)]">{c}</span>
                {i < CHAIN.length - 1 && <ArrowRight className="h-3 w-3 text-[hsl(36_50%_70%)]" aria-hidden="true" />}
              </li>
            ))}
          </ol>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {listProfiles().map((p) => {
            const img = getMedia(p.image);
            return (
              <li key={p.id}>
                <Link to={`/science/orchids/${p.id}`} className="group flex h-full flex-col overflow-hidden rounded-sm border border-border/80 bg-[hsl(var(--cream))] hover:border-[hsl(var(--botanical))]/60">
                  {img && <img src={img.src} alt="" aria-hidden="true" loading="lazy" className="aspect-[4/3] w-full object-cover" />}
                  <span className="flex flex-1 flex-col p-4">
                    <span className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">{p.rank}</span>
                    <span className="mt-1 font-display text-xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</span>
                    <span className="mt-1 text-sm text-muted-foreground">{p.hook}</span>
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>

        <div className="mt-16 rounded-sm border border-border/80 bg-background p-5 sm:p-8">
          <NeighborsExplorer />
        </div>

        <aside className="mt-12 rounded-sm border border-dashed border-border bg-muted/40 p-5 text-sm leading-relaxed text-muted-foreground">
          <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Data source · {dataSource.name}</p>
          <p className="mt-2">
            Profiles are hand-written drafts awaiting review. The data layer is built so that the Orchid Continuum (taxonomy,
            distribution, provenance-aware imagery, observations) and the American Orchid Society culture-sheet links can be
            connected later without changing these pages. No endpoints or citations have been invented.
          </p>
        </aside>
      </div>
    </div>
  );
};

export default OrchidProfilePage;
