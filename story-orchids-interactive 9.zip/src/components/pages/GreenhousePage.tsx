import React from 'react';
import { Link } from 'react-router-dom';
import { Footprints, Scale, LayoutGrid, BookOpen, ArrowRight, Info } from 'lucide-react';
import { getMedia, greenhouse } from '@/lib/content';
import { ARCHITECTURE, ENVIRONMENT, GREENHOUSE_CREDIT, ORIENTATION_NOTES } from '@/content/edith-greenhouse';
import NeighborsExplorer from '@/components/greenhouse/NeighborsExplorer';
import { ActivityHeader, GreenhouseStepBar, StepFooter } from '@/components/greenhouse/GreenhouseShell';

const CHOICES = [
  { n: 1, to: '/greenhouse/walk', icon: Footprints, title: 'Walk the greenhouse', body: "Explore Edith's microclimates." },
  { n: 2, to: '/greenhouse/hazel-vs-edith', icon: Scale, title: 'Hazel vs. Edith', body: 'See what happens when visual order replaces biological organization.' },
  { n: 3, to: '/greenhouse/build-a-bench', icon: LayoutGrid, title: 'Build a bench', body: 'Decide where different orchids belong and discover why.' },
  { n: 4, to: '/culture-library', icon: BookOpen, title: 'Orchid Culture Library', body: 'Leave the story and explore reusable orchid culture information, evidence and sources.' },
];

const GreenhousePage: React.FC = () => {
  const hero = getMedia(greenhouse.heroImage);
  const scenes = greenhouse.zones.flatMap((z) => z.scenes.map((s) => ({ ...s, zone: z.name })));

  return (
    <>
      <section className="relative isolate overflow-hidden border-b border-border/70">
        {hero && (
          <>
            <img src={hero.src} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-b from-[hsl(150_14%_10%)]/82 via-[hsl(150_14%_12%)]/70 to-[hsl(150_14%_10%)]/92" />
            <div className="fog-drift pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_40%_80%,hsl(40_30%_88%/0.22),transparent_65%)]" />
          </>
        )}
        <div className="relative mx-auto max-w-4xl px-4 py-20 sm:px-6 sm:py-24">
          <h1 className="font-display text-5xl font-semibold leading-tight text-[hsl(42_40%_95%)] sm:text-7xl">Edith's Greenhouse</h1>
          <p className="mt-4 font-ui text-[1.25rem] font-bold uppercase tracking-[0.12em] text-[hsl(36_60%_78%)] sm:text-[1.4rem]">One greenhouse. Many microclimates.</p>
          <p className="mt-6 max-w-3xl text-[1.3125rem] leading-relaxed text-[hsl(42_25%_92%)]">
            Edith grows hundreds of orchids under one roof, but she does not treat the greenhouse as one uniform environment. Light,
            temperature, airflow, moisture and season create different microclimates throughout the collection. Explore the greenhouse to see
            why each orchid lives where it does.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-14">
        <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">What would you like to do?</h2>
        <p className="mt-2 text-[1.1875rem] text-[hsl(var(--ink))]">Follow the numbers for a guided visit, or jump straight to whatever interests you.</p>
        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          {CHOICES.map((c) => (
            <Link key={c.to} to={c.to}
              className={`group flex min-h-[11rem] flex-col justify-between rounded-lg border-2 p-6 transition-all hover:-translate-y-0.5 hover:shadow-lg sm:p-7 ${c.n === 4 ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border bg-white/70 text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]'}`}>
              <div className="flex items-start gap-4">
                <span className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-full ${c.n === 4 ? 'bg-[hsl(var(--cream))]/15' : 'bg-[hsl(var(--botanical))]/10 text-[hsl(var(--botanical))]'}`}>
                  <c.icon className="h-7 w-7" aria-hidden="true" />
                </span>
                <div>
                  <p className={`font-ui text-[1rem] font-bold uppercase tracking-wide ${c.n === 4 ? 'text-[hsl(44_60%_85%)]' : 'text-[hsl(var(--moss))]'}`}>{c.n === 4 ? 'Leave the story' : `Step ${c.n}`}</p>
                  <h3 className={`mt-1 font-display text-[1.75rem] font-semibold leading-tight ${c.n === 4 ? '' : 'text-[hsl(var(--charcoal))]'}`}>{c.title}</h3>
                  <p className="mt-2 text-[1.1875rem] leading-relaxed">{c.body}</p>
                </div>
              </div>
              <span className="mt-4 inline-flex items-center gap-2 self-end font-ui text-[1.0625rem] font-semibold">
                {c.n === 4 ? 'Open the library' : 'Start'} <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </span>
            </Link>
          ))}
        </div>

        <details className="group mt-12 rounded-md border-2 border-border/70 bg-white/50">
          <summary className="flex min-h-[56px] cursor-pointer items-center gap-2 px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">
            <Info className="h-5 w-5 text-[hsl(var(--botanical))]" aria-hidden="true" /> About this fictional greenhouse
          </summary>
          <div className="space-y-5 px-5 pb-6 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
            <p>{GREENHOUSE_CREDIT.text}</p>
            <p><strong>Greenhouse design.</strong> {ENVIRONMENT.architecturalInspiration} About {ARCHITECTURE.overall.lengthFt} × {ARCHITECTURE.overall.widthFt} ft overall: a {ARCHITECTURE.central.lengthFt} × {ARCHITECTURE.central.widthFt} ft central house about {ARCHITECTURE.central.heightFt} ft high, with two {ARCHITECTURE.ends.lengthFt} × {ARCHITECTURE.ends.widthFt} ft end rooms about {ARCHITECTURE.ends.heightFt} ft high.</p>
            <p><strong>Fictional local environment — Pismo Beach.</strong> {ENVIRONMENT.fictionalLocal}</p>
            <p><strong>{greenhouse.climate.title}.</strong> {greenhouse.climate.body}{' '}
              <Link to={greenhouse.climate.link.to} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">{greenhouse.climate.link.label}</Link>
            </p>
            <ul className="space-y-1">{ORIENTATION_NOTES.map((o) => <li key={o.side}><strong>{o.side}:</strong> {o.note}</li>)}</ul>
            {scenes.length > 0 && (
              <div>
                <p className="font-semibold">Story moments in this greenhouse</p>
                <ul className="mt-1 space-y-2">
                  {scenes.map((s) => (
                    <li key={s.note.slice(0, 24)}>
                      {s.note}{' '}
                      <Link to={`/chronicle/${s.chronicle}`} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">Read the scene</Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </details>
      </div>
    </>
  );
};

export const GreenhouseComparePage: React.FC = () => (
  <div>
    <GreenhouseStepBar current="compare" />
    <ActivityHeader step="Step 4 · Compare two orchids" title="Why are these orchids neighbors?">
      Greenhouse neighbors are chosen by environmental compatibility, not simply by taxonomic name or geographic origin. Pick two orchids and
      compare temperature, moisture, light, airflow and seasonality.
    </ActivityHeader>
    <div className="mx-auto max-w-5xl px-4 sm:px-6">
      <NeighborsExplorer showHeading={false} />
      <div className="mt-8 flex flex-wrap gap-3">
        <Link to="/greenhouse/build-a-bench" className="inline-flex min-h-[48px] items-center rounded-md border-2 border-border px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">← Back to Build a bench</Link>
        <Link to="/culture-library" className="inline-flex min-h-[48px] items-center rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">Explore culture profiles →</Link>
      </div>
    </div>
    <StepFooter current="compare" />
  </div>
);

export default GreenhousePage;
