import React, { useCallback, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Compass } from 'lucide-react';
import { getChronicle, getMedia, getStory, discoveries } from '@/lib/content';
import { useDiscovery } from '@/contexts/DiscoveryContext';
import StoryRenderer from '@/components/story/StoryRenderer';
import DiscoveryDrawer from '@/components/story/DiscoveryDrawer';
import ScienceDrawer from '@/components/science/ScienceDrawer';
import ChapteredChroniclePage from '@/components/pages/ChapteredChroniclePage';
import CinematicChronicleOne from '@/components/c1/CinematicChronicleOne';
import Afterword from '@/components/c1/Afterword';
import { Flourish, Kicker, Notice, PendingTag } from '@/components/site/Ornaments';

const ChroniclePage: React.FC<{ slug?: string }> = ({ slug: slugProp }) => {
  const params = useParams();
  const slug = slugProp || params.slug;
  const chronicle = getChronicle(slug);
  const story = getStory(chronicle);
  const { discover, discovered } = useDiscovery();
  const [active, setActive] = useState<string | null>(null);
  const [science, setScience] = useState<string | null>(null);

  const onDiscover = useCallback(
    (id: string) => {
      discover(id);
      setActive(id);
    },
    [discover],
  );

  if (chronicle?.id === 'chronicle-i') return <CinematicChronicleOne />;
  if (chronicle?.id === 'chronicle-ii') return <ChapteredChroniclePage />

  if (!chronicle) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-28 text-center">
        <h1 className="font-display text-3xl text-[hsl(var(--charcoal))]">This Chronicle is not on the shelf</h1>
        <Link to="/library" className="mt-6 inline-block font-label text-[0.6rem] uppercase text-[hsl(var(--botanical))] underline">
          Return to the Library
        </Link>
      </div>
    );
  }

  const cover = getMedia(chronicle.cover);
  const halloween = chronicle.accent === 'halloween';
  const discoveryIds = Object.keys(discoveries);

  return (
    <article>
      <header className="relative isolate overflow-hidden border-b border-border/70">
        {cover && (
          <>
            <img src={cover.src} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover" />
            <div
              className={`absolute inset-0 ${
                halloween
                  ? 'bg-gradient-to-b from-[hsl(30_14%_10%)]/88 via-[hsl(348_20%_12%)]/78 to-[hsl(30_14%_10%)]/92'
                  : 'bg-[hsl(30_12%_12%)]/80'
              }`}
            />
            <div className="fog-drift pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_50%_85%,hsl(40_30%_88%/0.22),transparent_65%)]" />
          </>
        )}
        <div className="relative mx-auto max-w-3xl px-4 py-20 text-center sm:px-6 sm:py-28">
          <Kicker className="!text-[hsl(36_60%_72%)]">Chronicle {chronicle.number} · {chronicle.season}</Kicker>
          <h1 className="mt-4 font-display text-4xl font-semibold leading-tight text-[hsl(42_40%_95%)] sm:text-6xl">
            {chronicle.title}
          </h1>
          <p className="mt-3 font-display text-xl italic text-[hsl(36_50%_78%)] sm:text-2xl">{chronicle.subtitle}</p>
          {story?.frontmatter.epigraph && (
            <>
              <Flourish className="my-8 opacity-70" />
              <blockquote className="mx-auto max-w-xl font-display text-lg italic leading-relaxed text-[hsl(42_25%_86%)]">
                “{story.frontmatter.epigraph}”
                {story.frontmatter.epigraphSource && (
                  <footer className="mt-3 font-label text-[0.55rem] uppercase not-italic text-[hsl(36_45%_70%)]">
                    — {story.frontmatter.epigraphSource}
                  </footer>
                )}
              </blockquote>
            </>
          )}
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14">
        <div className="no-print mb-10 flex flex-wrap items-center justify-between gap-4">
          <Link
            to="/library"
            className="inline-flex items-center gap-2 font-label text-[0.58rem] uppercase text-[hsl(var(--moss))] hover:text-[hsl(var(--botanical))]"
          >
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />
            Library
          </Link>
          <p className="inline-flex items-center gap-2 font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">
            <Compass className="h-3.5 w-3.5 text-[hsl(var(--amber))]" aria-hidden="true" />
            {discovered.length} of {discoveryIds.length} discoveries found
          </p>
        </div>

        {story?.frontmatter.notice && (
          <div className="mb-10">
            <Notice tone="info" title="A note on this text" body={story.frontmatter.notice} />
          </div>
        )}

        {story ? (
          <StoryRenderer blocks={story.blocks} onDiscover={onDiscover} onScience={setScience} />
        ) : (
          <div className="rounded-sm border border-dashed border-border bg-muted/40 p-12 text-center">
            <PendingTag label="Manuscript pending" />
            <p className="mt-4 text-sm text-muted-foreground">
              This Chronicle is reserved. Its manuscript file has not been added yet.
            </p>
          </div>
        )}
      </div>

      <Afterword onDiscover={onDiscover} onScience={setScience} />

      <DiscoveryDrawer discoveryId={active} onClose={() => setActive(null)} />
      <ScienceDrawer id={science} onClose={() => setScience(null)} />
    </article>
  );
};

export default ChroniclePage;
