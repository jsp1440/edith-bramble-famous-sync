import React from 'react';
import { Link } from 'react-router-dom';
import { site } from '@/lib/content';
import { Flourish, Kicker, Notice, SectionHeading } from '@/components/site/Ornaments';

const Code: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <code className="rounded-sm bg-[hsl(var(--secondary))] px-1.5 py-0.5 font-ui text-[0.78rem] text-[hsl(var(--ink))]">
    {children}
  </code>
);

const Block: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <section className="rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6 sm:p-8">
    <h3 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{title}</h3>
    <div className="mt-4 space-y-3 text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">{children}</div>
  </section>
);

const AboutPage: React.FC = () => (
  <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
    <SectionHeading
      kicker="For editors and contributors"
      title="About & contributing"

      subtitle="Content lives in Markdown and JSON. Presentation lives in React components. The two never mix — which is why new Chronicles need no code."
      align="center"
    />

    <Flourish className="my-12" />

    <div className="space-y-8">
      <Block title="Content directory map">
        <pre className="overflow-x-auto rounded-sm border border-border bg-[hsl(var(--secondary))]/60 p-4 font-ui text-xs leading-relaxed text-[hsl(var(--ink))]">{`src/content/
├── site.json               site identity, navigation, FCOS info
├── chronicles.json         the six-volume manifest
├── media.json              every image: id → src + alt + credit
├── discoveries.json        story markers → drawers, modules, cards
├── cards.json              Collector's Cabinet (character/artifact/orchid)
├── chronicles/
│   └── chronicle-i.md      manuscript (frontmatter + story blocks)
└── modules/
    ├── journal.json        Edith's Greenhouse Journal
    ├── grimoire.json       Hazel Nightshade's Grimoire
    ├── potting-bench.json  Edith's Potting Bench
    ├── plant-doctor.json   Plant Doctor
    ├── kitchen.json        Edith's Kitchen
    ├── coloring.json       Coloring Studio (three levels)
    ├── herbarium.json      Edith's Herbarium
    ├── plates.json         Botanical Plates
    ├── watch-listen.json   Multimedia slots
    └── go-deeper.json      Orchid Continuum / Calyx boundary`}</pre>
      </Block>

      <Block title="Adding Chronicle II (or III … VI)">
        <ol className="list-decimal space-y-2 pl-5">
          <li>
            Register every new illustration in <Code>media.json</Code> with an <Code>id</Code>, <Code>src</Code> and a
            descriptive <Code>alt</Code>.
          </li>
          <li>
            Create <Code>src/content/chronicles/chronicle-ii.md</Code> using the story syntax below.
          </li>
          <li>
            In <Code>chronicles.json</Code>, change that volume's <Code>status</Code> to <Code>"live"</Code>, set{' '}
            <Code>contentFile</Code> to the new filename, and set <Code>cover</Code> to a media id.
          </li>
          <li>
            Add any new discovery markers to <Code>discoveries.json</Code> and any new cards to <Code>cards.json</Code>.
          </li>
          <li>Deploy. No component, route or stylesheet needs to change.</li>
        </ol>
      </Block>

      <Block title="The story syntax">
        <p>A manuscript is Markdown with frontmatter and a handful of directives:</p>
        <pre className="overflow-x-auto rounded-sm border border-border bg-[hsl(var(--secondary))]/60 p-4 font-ui text-xs leading-relaxed text-[hsl(var(--ink))]">{`---
id: chronicle-ii
title: Pending Title
number: II
epigraph: "A line of verse."
epigraphSource: Attribution
notice: Optional editorial note shown above the story.
---

## Scene One — Heading

Ordinary paragraphs of prose. *Italic* and **bold** work.
Inline discoveries look like {{talisman|the talisman}} and open a drawer.

> A pull quote.

[divider]

::: image id="media-id" layout="full" caption="Caption text" :::
::: image id="media-id" layout="wrap-right" caption="Wrapped image" :::
::: audio id="narration-id" :::

::: pending title="Scenes Four to Nine" :::
Text explaining what is still to come.
:::

::: closing :::
No grower is ever alone.
:::`}</pre>
        <p>
          Layouts available for images: <Code>full</Code>, <Code>wrap-right</Code>, <Code>wrap-left</Code>,{' '}
          <Code>inline</Code>.
        </p>
      </Block>

      <Block title="Adding a module entry, card or coloring sheet">
        <p>
          Every module page renders from its JSON file. Append an object to <Code>entries</Code> with an{' '}
          <Code>id</Code>, <Code>title</Code>, optional <Code>kind</Code>, <Code>summary</Code>, <Code>body</Code>{' '}
          (array of paragraphs), <Code>list</Code>, <Code>goDeeper</Code>, <Code>notes</Code>, <Code>practice</Code>,{' '}
          <Code>links</Code>, <Code>printable</Code> and <Code>status</Code> (<Code>live</Code> or{' '}
          <Code>pending</Code>).
        </p>
        <p>
          Cards go in <Code>cards.json</Code> — set <Code>discoverable: true</Code> to lock a card until a reader finds
          it in a Chronicle. Coloring sheets go under the matching level in <Code>coloring.json</Code>.
        </p>
      </Block>

      <Block title="Editorial standards">
        <ul className="list-disc space-y-2 pl-5">
          <li>Never invent scientific claims, remedies, recipes or Society history to fill a gap. Mark it pending.</li>
          <li>Label grower tradition as grower practice, distinct from validated treatment.</li>
          <li>Keep fiction visibly separate from horticultural guidance — the Grimoire says so on its own page.</li>
          <li>
            Never encourage collection of wild orchids, rare or protected species, or plants from protected land.
            Observe, photograph, and sketch wild orchids. Do not collect them.
          </li>
          <li>Every image needs meaningful alt text at the point it is registered in <Code>media.json</Code>.</li>
        </ul>
      </Block>

      <Notice
        tone="info"
        title="Ownership and portability"
        body="All content is plain Markdown and JSON, all code is standard React, TypeScript, Vite and Tailwind. There is no proprietary CMS and no vendor lock-in — the repository is the canonical source of truth and can be exported, forked or self-hosted at any time."
      />

      <div className="rounded-sm border border-border/80 bg-[hsl(var(--botanical))]/6 p-8 text-center">
        <Kicker>{site.fcos.name}</Kicker>
        <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-[hsl(var(--ink))]">
          {site.fcos.membershipNote}
        </p>
        <Link
          to="/library"
          className="mt-6 inline-block rounded-sm bg-[hsl(var(--botanical))] px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
        >
          Back to the Library
        </Link>
      </div>
    </div>
  </div>
);

export default AboutPage;
