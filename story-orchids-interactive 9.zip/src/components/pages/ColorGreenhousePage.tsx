import React, { useState } from 'react';
import { Printer } from 'lucide-react';
import { printables, getMedia, growerCards } from '@/lib/content';
import { Kicker } from '@/components/site/Ornaments';

type Level = 'all' | 'kids' | 'botanical';

const checklist = [
  'What is growing?',
  'What is maturing?',
  'What is yellowing naturally?',
  'Are the roots active?',
  'Does this group rest?',
  'Does it need a temperature cue?',
];

const printOnly = (id: string) => {
  const el = document.getElementById(id);
  el?.classList.add('print-target');
  document.body.setAttribute('data-print-target', id);
  window.print();
  window.setTimeout(() => {
    el?.classList.remove('print-target');
    document.body.removeAttribute('data-print-target');
  }, 500);
};


const ColorGreenhousePage: React.FC = () => {
  const [level, setLevel] = useState<Level>('all');
  const [name, setName] = useState('');
  const shown = printables.filter((p) => level === 'all' || p.level === level);
  const bookmarks = growerCards.filter((c) => c.image?.startsWith('gc-')).slice(0, 6);

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <div className="no-print">
        <Kicker>Printable · US Letter</Kicker>
        <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
          Coloring Greenhouse
        </h1>
        <p className="mt-4 max-w-2xl text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
          Black-line pages at two levels — KIDS and BOTANICAL — plus Edith's autumn checklist, plant-label bookmarks and
          an Orchid Detective certificate. Each item prints on its own page.
        </p>
        <div className="mt-6 flex flex-wrap gap-2" role="tablist" aria-label="Difficulty">
          {(['all', 'kids', 'botanical'] as Level[]).map((l) => (
            <button
              key={l}
              type="button"
              role="tab"
              aria-selected={level === l}
              onClick={() => setLevel(l)}
              className={`rounded-sm px-4 py-2 font-label text-[0.58rem] uppercase ${
                level === l ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border border-border text-[hsl(var(--ink))]'
              }`}
            >
              {l === 'all' ? 'All pages' : l}
            </button>
          ))}
        </div>
      </div>

      <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((p) => {
          const img = getMedia(p.image);
          return (
            <li key={p.id} id={p.id} className="print-item print-sheet flex flex-col rounded-sm border border-border/80 bg-white p-4">
              {img && <img src={img.src} alt={img.alt} loading="lazy" className="aspect-[3/4] w-full object-contain" />}
              <p className="mt-3 font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">{p.level}</p>
              <h2 className="font-display text-xl font-semibold text-[hsl(var(--charcoal))]">{p.title}</h2>
              <p className="mt-1 flex-1 text-sm text-[hsl(var(--ink))]">{p.caption}</p>
              <button
                type="button"
                onClick={() => printOnly(p.id)}
                className="no-print mt-3 inline-flex items-center justify-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--cream))]"
              >
                <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Print this page
              </button>
            </li>
          );
        })}
      </ul>

      <section className="mt-16 grid gap-6 lg:grid-cols-2">
        <div id="checklist" className="print-item print-sheet rounded-sm border border-border/80 bg-white p-6">
          <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">One-page checklist</p>
          <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Edith's Autumn Orchid Check</h2>
          <ol className="mt-4 space-y-3">
            {checklist.map((q) => (
              <li key={q} className="flex items-center gap-3 border-b border-dashed border-border pb-3 text-[1.02rem] text-[hsl(var(--ink))]">
                <span className="h-5 w-5 shrink-0 rounded-sm border-2 border-[hsl(var(--botanical))]" aria-hidden="true" />
                {q}
              </li>
            ))}
          </ol>
          <p className="mt-4 font-display text-lg italic text-[hsl(var(--botanical))]">Watch the plant before the calendar.</p>
          <button type="button" onClick={() => printOnly('checklist')} className="no-print mt-4 inline-flex items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--cream))]">
            <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Print checklist
          </button>
        </div>

        <div id="certificate" className="print-item print-sheet rounded-sm border-4 border-double border-[hsl(var(--botanical))] bg-white p-6 text-center">
          <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Five Cities Orchid Society</p>
          <h2 className="mt-2 font-display text-4xl font-semibold text-[hsl(var(--charcoal))]">Orchid Detective</h2>
          <p className="mt-3 text-[hsl(var(--ink))]">This certifies that</p>
          <p className="mx-auto mt-2 min-h-[2.5rem] max-w-xs border-b-2 border-[hsl(var(--charcoal))] font-display text-3xl italic text-[hsl(var(--botanical))]">
            {name}
          </p>
          <p className="mt-3 text-sm text-[hsl(var(--ink))]">looked closely, looked again tomorrow, and learned to tell a seasonal signal from a cultural warning.</p>
          <p className="mt-4 font-display text-xl italic text-[hsl(var(--burgundy))]">Come Grow With Us!</p>
          <label className="no-print mx-auto mt-4 block max-w-xs text-left text-sm">
            <span className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">Detective's name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} maxLength={40} className="mt-1 w-full rounded-sm border border-border px-3 py-2" />
          </label>
          <button type="button" onClick={() => printOnly('certificate')} className="no-print mt-4 inline-flex items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--cream))]">
            <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Print certificate
          </button>
        </div>
      </section>

      <section id="bookmarks" className="print-item mt-16">
        <div className="no-print flex flex-wrap items-end justify-between gap-3">
          <div>
            <Kicker>Plant-label bookmarks</Kicker>
            <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Cut along the edges</h2>
          </div>
          <button type="button" onClick={() => printOnly('bookmarks')} className="inline-flex items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--cream))]">
            <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Print bookmarks
          </button>
        </div>
        <ul className="mt-6 grid grid-cols-3 gap-3 sm:grid-cols-6">
          {bookmarks.map((c) => {
            const img = getMedia(c.image);
            return (
              <li key={c.id} className="print-sheet flex flex-col overflow-hidden rounded-t-[2rem] border border-dashed border-[hsl(var(--charcoal))]/50 bg-white">
                {img && <img src={img.src} alt="" aria-hidden="true" className="aspect-[1/2] w-full object-cover" />}
                <p className="px-2 py-2 text-center font-display text-sm italic leading-tight text-[hsl(var(--charcoal))]">{c.taxon.split('(')[0]}</p>
                <p className="border-t border-dashed border-border px-2 py-2 text-center font-label text-[0.45rem] uppercase text-[hsl(var(--moss))]">
                  Watch the plant before the calendar.
                </p>
              </li>
            );
          })}
        </ul>
      </section>
    </div>
  );
};

export default ColorGreenhousePage;
