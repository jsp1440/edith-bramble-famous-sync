import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowRight, BookOpen, ExternalLink, Globe2, Images, Mountain, Sprout, X } from 'lucide-react';
import AtlasMap from '@/components/explore/AtlasMap';
import FeaturedGenus from '@/components/explore/FeaturedGenus';
import { FEATURED_TAXA, MONTHS, countryName, explorePath, sized, useOrchidExplorer, type FGImage } from '@/lib/feature-genius';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { dossierPath } from '@/lib/continuum';

const Section: React.FC<{ id?: string; icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ id, icon, title, children }) => (
  <section id={id} className="scroll-mt-32 rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white p-5 shadow-sm sm:p-7">
    <h2 className="flex items-center gap-3 font-display text-3xl font-semibold text-[hsl(var(--botanical))]">
      {icon}
      {title}
    </h2>
    <div className="mt-4">{children}</div>
  </section>
);

const Gallery: React.FC<{ images: FGImage[]; genusLevel: boolean }> = ({ images, genusLevel }) => {
  const [open, setOpen] = useState<FGImage | null>(null);
  return (
    <>
      <p className="max-w-3xl text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
        {genusLevel ? 'Representative species, photographed by naturalists and botanists.' : 'Photographs of this species.'} Tap a picture to see it
        larger with its credit.
      </p>
      <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {images.map((im) => (
          <li key={im.src}>
            <button
              type="button"
              onClick={() => setOpen(im)}
              className="group block w-full overflow-hidden rounded-lg border-2 border-[hsl(var(--charcoal))]/25 bg-[hsl(var(--cream))] text-left"
            >
              <div className="aspect-square overflow-hidden bg-[hsl(96_20%_85%)]">
                <img
                  src={sized(im.src)}
                  alt={`${im.species}, photographed in ${im.country ?? 'the wild or cultivation'}`}
                  loading="lazy"
                  decoding="async"
                  onError={(e) => ((e.currentTarget.closest('li') as HTMLElement).style.display = 'none')}
                  className="h-full w-full object-cover transition-transform group-hover:scale-105"
                />
              </div>
              <p className="px-3 py-2 font-display text-[1.125rem] italic leading-snug text-[hsl(var(--charcoal))]">{im.species}</p>
            </button>
          </li>
        ))}
      </ul>
      {open && (
        <div role="dialog" aria-modal="true" aria-label={open.species} className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4" onClick={() => setOpen(null)}>
          <figure className="max-h-full w-full max-w-4xl overflow-auto rounded-xl bg-[hsl(var(--cream))] p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <figcaption className="font-display text-2xl italic text-[hsl(var(--charcoal))]">{open.species}</figcaption>
              <button type="button" onClick={() => setOpen(null)} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--charcoal))] px-4 font-ui font-semibold">
                <X className="h-5 w-5" aria-hidden="true" /> Close
              </button>
            </div>
            <img src={sized(open.src, 'large')} alt={open.species} className="mt-3 max-h-[70vh] w-full rounded-md object-contain" />
            <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
              Photo: {open.creator ?? 'unknown photographer'} · {open.license} · {open.source}
              {open.country ? ` · ${open.country}` : ''} ·{' '}
              <a href={open.recordUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">
                View the record
              </a>
            </p>
          </figure>
        </div>
      )}
    </>
  );
};

const ExplorerIndex: React.FC = () => (
  <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
    <p className="font-label uppercase text-[hsl(var(--moss))]">Feature Genius</p>
    <h1 className="mt-2 font-display text-5xl font-semibold text-[hsl(var(--charcoal))]">Explore the orchids of the Chronicles</h1>
    <p className="mt-4 max-w-3xl text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">
      Start with today's Featured Genus: browse every accepted species nine at a time, then open any species' Dossier for its pictures, Atlas map, literature and culture.
    </p>
    <div className="mt-8">
      <FeaturedGenus />
    </div>
    <h2 className="mt-12 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Orchids named in the stories</h2>
    <ul className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {FEATURED_TAXA.map((t) => (
        <li key={t.name}>
          <Link to={explorePath(t.name)} className="flex h-full min-h-[96px] items-center justify-between gap-3 rounded-xl border-2 border-[hsl(var(--charcoal))]/30 bg-white p-5 hover:border-[hsl(var(--botanical))]">
            <span>
              <span className="block font-display text-2xl italic font-semibold text-[hsl(var(--botanical))]">{t.name}</span>
              <span className="mt-1 block text-[1.0625rem] text-[hsl(var(--ink))]">{t.note}</span>
            </span>
            <ArrowRight className="h-6 w-6 shrink-0 text-[hsl(var(--botanical))]" aria-hidden="true" />
          </Link>
        </li>
      ))}
    </ul>
  </div>
);

const OrchidExplorerPage: React.FC = () => {
  const { taxon } = useParams();
  const name = taxon ? decodeURIComponent(taxon) : null;
  const { data, state } = useOrchidExplorer(name);
  if (!name) return <ExplorerIndex />;

  const featured = FEATURED_TAXA.find((t) => t.name.toLowerCase() === name.toLowerCase());
  const profile = featured?.profile ? getProfile(featured.profile) : undefined;
  const t = data?.taxon;
  const genusLevel = t ? t.rank !== 'SPECIES' : true;
  const maxCountry = Math.max(1, ...(data?.occurrences.countries.map((c) => c.count) ?? [1]));
  const maxMonth = Math.max(1, ...(data?.occurrences.months.map((m) => m.count) ?? [1]));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link to="/explore" className="font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
        ← All orchids in Feature Genius
      </Link>

      <header className="mt-4">
        <p className="font-label uppercase text-[hsl(var(--moss))]">Feature Genius · {t ? t.rank.toLowerCase() : 'orchid'}</p>
        <h1 className="mt-2 font-display text-5xl font-semibold italic text-[hsl(var(--charcoal))] sm:text-6xl">{t?.name ?? name}</h1>
        {t && (
          <p className="mt-3 text-[1.1875rem] text-[hsl(var(--ink))]">
            <strong>Accepted name:</strong> {t.scientificName}
            {t.synonymOf && ` (you searched a synonym)`} · Family {t.family}
            {t.genus && t.rank === 'SPECIES' ? ` · Genus ${t.genus}` : ''}
          </p>
        )}
        {featured && <p className="mt-2 text-[1.1875rem] text-[hsl(var(--ink))]"><strong>In the Chronicles:</strong> {featured.note}</p>}
        <div className="mt-5 flex flex-wrap gap-3">
          <a href="#atlas" className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            <Globe2 className="h-5 w-5" aria-hidden="true" /> Explore in Atlas
          </a>
          {profile && (
            <Link to={profilePath(profile.id)} className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(var(--botanical))] bg-white px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))]">
              <Sprout className="h-5 w-5" aria-hidden="true" /> Culture profile: {profile.name}
            </Link>
          )}
          {t && t.rank === 'SPECIES' && (
            <Link to={dossierPath(t.key, t.name)} className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(var(--charcoal))] bg-white px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]">
              <BookOpen className="h-5 w-5" aria-hidden="true" /> Open Species Dossier
            </Link>
          )}
        </div>
        {t && t.rank === 'GENUS' && (
          <div className="mt-8">
            <FeaturedGenus key={t.name} initialGenus={t.name} />
          </div>
        )}
      </header>

      {state === 'loading' && <p className="mt-10 rounded-xl border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-white p-8 text-center text-[1.25rem]">Gathering photographs and records for {name}…</p>}
      {state === 'error' && (
        <p className="mt-10 rounded-xl border-2 border-[hsl(var(--burgundy))] bg-white p-6 text-[1.1875rem]">
          The orchid data service could not be reached just now. Please try again in a moment.
        </p>
      )}
      {state === 'ok' && data && !data.found && (
        <p className="mt-10 rounded-xl border-2 border-[hsl(var(--charcoal))]/40 bg-white p-6 text-[1.1875rem]">No accepted orchid name matched “{name}”.</p>
      )}

      {state === 'ok' && data?.found && t && (
        <div className="mt-8 space-y-6">
          <Section icon={<Images className="h-7 w-7" aria-hidden="true" />} title={genusLevel ? 'See the genus' : 'See the orchid'}>
            {data.images.length > 0 ? (
              <Gallery images={data.images} genusLevel={genusLevel} />
            ) : (
              <p className="text-[1.125rem] text-[hsl(var(--ink))]">No openly licensed photographs were found for this name. The records and map below still apply.</p>
            )}
          </Section>

          {data.summary && (
            <Section icon={<BookOpen className="h-7 w-7" aria-hidden="true" />} title="In brief">
              <p className="max-w-3xl text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">{data.summary.text}</p>
              <p className="mt-3 text-[1rem] text-[hsl(var(--ink))]">
                Source: {data.summary.source} ({data.summary.license}).{' '}
                {data.summary.url && <a href={data.summary.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">Read more</a>}
              </p>
            </Section>
          )}

          <div className="grid gap-6 lg:grid-cols-2">
            <Section icon={<Globe2 className="h-7 w-7" aria-hidden="true" />} title="Where it has been documented">
              <p className="text-[1.0625rem] text-[hsl(var(--ink))]">{data.occurrences.total.toLocaleString()} records in total. Countries with the most records:</p>
              <ul className="mt-3 space-y-2">
                {data.occurrences.countries.map((c) => (
                  <li key={c.code} className="grid grid-cols-[minmax(0,9rem)_1fr_auto] items-center gap-3 text-[1.0625rem]">
                    <span className="truncate font-semibold text-[hsl(var(--charcoal))]">{countryName(c.code)}</span>
                    <span className="h-3 rounded-full bg-[hsl(var(--botanical))]" style={{ width: `${Math.max(4, (c.count / maxCountry) * 100)}%` }} />
                    <span className="tabular-nums">{c.count}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-[1rem] text-[hsl(var(--ink))]">Records include cultivated plants and some countries are documented far more often than others.</p>
            </Section>

            <Section icon={<Mountain className="h-7 w-7" aria-hidden="true" />} title="Elevation and season of records">
              {data.elevation ? (
                <p className="text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
                  Most sampled records with an elevation fall between <strong>{Math.round(data.elevation.low)} m</strong> and{' '}
                  <strong>{Math.round(data.elevation.high)} m</strong> (middle value about {Math.round(data.elevation.median)} m; from {data.elevation.n} records).
                </p>
              ) : (
                <p className="text-[1.125rem] text-[hsl(var(--ink))]">Too few records report elevation to summarise it honestly.</p>
              )}
              {data.occurrences.months.length > 0 && (
                <>
                  <p className="mt-4 font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">Month each record was made</p>
                  <div className="mt-2 flex h-32 items-end gap-1" aria-hidden="true">
                    {MONTHS.map((m, i) => {
                      const v = data.occurrences.months.find((x) => x.month === i + 1)?.count ?? 0;
                      return (
                        <div key={m} className="flex flex-1 flex-col items-center gap-1">
                          <div className="w-full rounded-t bg-[hsl(var(--moss))]" style={{ height: `${(v / maxMonth) * 100}px` }} />
                          <span className="font-ui text-[0.95rem] text-[hsl(var(--ink))]">{m.charAt(0)}</span>
                        </div>
                      );
                    })}
                  </div>
                  <p className="mt-2 text-[1rem] text-[hsl(var(--ink))]">The month a record was made is <strong>not</strong> the flowering season.</p>
                </>
              )}
            </Section>
          </div>

          <Section id="atlas" icon={<Globe2 className="h-7 w-7" aria-hidden="true" />} title="Atlas">
            <AtlasMap taxonKey={t.key} taxonName={t.name} initial={data.view} />
          </Section>

          <Section icon={<ExternalLink className="h-7 w-7" aria-hidden="true" />} title="Go deeper">
            <ul className="space-y-3 text-[1.125rem]">
              <li>
                <a href={t.gbifUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                  Full taxonomy and every record (GBIF)
                </a>
              </li>
              {profile && (
                <li>
                  <Link to={profilePath(profile.id)} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                    How Edith grows it — {profile.name} culture profile
                  </Link>
                </li>
              )}
              <li className="text-[hsl(var(--ink))]">
                <strong>Orchid Continuum:</strong>{' '}
                {data.continuum.status === 'connected'
                  ? `Atlas records loaded for the genus ${data.continuum.genus}.`
                  : 'the deeper Orchid Continuum Atlas link will appear here once its public endpoint is connected. The records above come from GBIF, the open biodiversity network.'}
              </li>
            </ul>
            <p className="mt-4 text-[1rem] text-[hsl(var(--ink))]">Data retrieved {new Date(data.retrievedAt).toLocaleDateString()}.</p>
          </Section>
        </div>
      )}
    </div>
  );
};

export default OrchidExplorerPage;
