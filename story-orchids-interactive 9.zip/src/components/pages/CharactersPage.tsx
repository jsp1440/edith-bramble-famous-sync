import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Info } from 'lucide-react';
import { characters, getChronicle, getMedia } from '@/lib/content';
import { Kicker } from '@/components/site/Ornaments';
import CastCard from '@/components/characters/CastCard';

/* The STORY CAST of the Edith Bramble Chronicles — not a directory of real people.
   Each card carries only what the character does, notices and teaches in the fiction. */

const FILTERS = [
  { id: 'all', label: 'Everyone' },
  { id: 'chronicle-i', label: 'Chronicle I' },
  { id: 'chronicle-ii', label: 'Chronicle II' },
] as const;

const SECTIONS = [
  { group: 'principal', title: 'At the heart of the story', blurb: 'Edith, her greenhouse’s adversary, and the people who read the clues first.' },
  { group: 'society', title: 'Around the potting bench', blurb: 'Society members who each notice one thing the others miss — follow their clue into the greenhouse.' },
  { group: 'future', title: 'Waiting in a future Chronicle', blurb: 'Named, but not yet part of a published story.' },
] as const;

const CharactersPage: React.FC = () => {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]['id']>('all');
  const visible = useMemo(
    () => (filter === 'all' ? characters : characters.filter((c) => c.chronicles.includes(filter))),
    [filter],
  );
  const hero = getMedia('c2-halloween');

  return (
    <div>
      {/* Opening, like the cast page of an illustrated novel */}
      <header className="relative overflow-hidden border-b-2 border-border/70">
        {hero && <img src={hero.src} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-25" />}
        <div className="absolute inset-0 bg-gradient-to-b from-[hsl(var(--cream))]/70 via-[hsl(var(--cream))]/85 to-[hsl(var(--cream))]" aria-hidden="true" />
        <div className="relative mx-auto max-w-5xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
          <Kicker>The cast</Kicker>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-6xl">
            Characters of the Edith Bramble Chronicles
          </h1>
          <p className="mt-5 max-w-2xl text-[1.25rem] leading-relaxed text-[hsl(var(--ink))]">
            Who found which clue, who knew about the Dendrobiums, and who refused to let the wet bench become a slogan. Each card
            follows a character through the story — and then lets you follow their clue into Edith’s greenhouse.
          </p>

          {/* Jump-to index */}
          <nav aria-label="Jump to a character" className="mt-7 flex flex-wrap gap-2">
            {characters.map((c) => (
              <a key={c.id} href={`#${c.id}`} className="min-h-[44px] rounded-full border-2 border-border bg-white/70 px-4 py-2 font-ui text-[1rem] font-semibold text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]">
                {c.name}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div role="group" aria-label="Show characters from" className="flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                aria-pressed={filter === f.id}
                onClick={() => setFilter(f.id)}
                className={`min-h-[48px] rounded-md border-2 px-4 font-ui text-[1.0625rem] font-semibold ${
                  filter === f.id
                    ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                    : 'border-border bg-white/60 text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]'
                }`}
              >
                {f.id === 'all' ? f.label : `${f.label}${getChronicle(f.id) ? ` · ${getChronicle(f.id)!.title}` : ''}`}
              </button>
            ))}
          </div>
          <p className="text-[1.0625rem] text-[hsl(var(--ink))]">{visible.length} characters</p>
        </div>

        {SECTIONS.map((s) => {
          const list = visible.filter((c) => c.group === s.group);
          if (!list.length) return null;
          return (
            <section key={s.group} className="mt-12" aria-labelledby={`cast-${s.group}`}>
              <h2 id={`cast-${s.group}`} className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))] sm:text-4xl">{s.title}</h2>
              <p className="mt-2 max-w-2xl text-[1.1875rem] text-[hsl(var(--ink))]">{s.blurb}</p>
              <div className={`mt-6 grid gap-6 ${s.group === 'principal' ? '' : 'md:grid-cols-2'}`}>
                {list.map((c) => (
                  <CastCard key={c.id} c={c} featured={s.group === 'principal'} />
                ))}
              </div>
            </section>
          );
        })}

        <p className="mt-12 max-w-2xl text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">
          Other Society members, partners and friends appear in the Chronicles as ordinary members of the cast. They do not need a
          card to belong at the potting bench.
        </p>

        {/* ONE short, unobtrusive note — not repeated on every card */}
        <aside className="mt-8 flex max-w-3xl gap-3 rounded-md border-2 border-border/70 bg-white/60 px-5 py-4" role="note">
          <Info className="mt-1 h-5 w-5 shrink-0 text-[hsl(var(--moss))]" aria-hidden="true" />
          <div>
            <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">About the cast</p>
            <p className="mt-1 text-[1.0625rem] leading-relaxed text-[hsl(var(--ink))]">
              The Edith Bramble Chronicles are works of fiction. Some supporting characters celebrate the personalities, interests and
              camaraderie of the orchid community, while events, dialogue and characterization belong to the fictional world of the
              Chronicles.
            </p>
          </div>
        </aside>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link to="/chronicles" className="inline-flex min-h-[48px] items-center rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]">
            Read the Chronicles
          </Link>
          <Link to="/greenhouse" className="inline-flex min-h-[48px] items-center rounded-md border-2 border-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))]">
            Enter Edith’s greenhouse
          </Link>
          <Link to="/cabinet" className="inline-flex min-h-[48px] items-center rounded-md border-2 border-border px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))]">
            Collector’s Cabinet
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CharactersPage;
