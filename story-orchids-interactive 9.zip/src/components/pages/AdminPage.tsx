import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Lock, ShieldCheck, FileText, LogOut, ExternalLink } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { chronicles, site, getModule, cards } from '@/lib/content';
import { Flourish, Kicker, Notice, PendingTag, SectionHeading } from '@/components/site/Ornaments';
import ReviewQueue from '@/components/evidence/ReviewQueue';

const moduleIds = site.modules.map((m) => m.id).filter((id) => id !== 'library' && id !== 'cabinet');

const AdminPage: React.FC = () => {
  const { user, profile, loading, isEditor, openAuth, signOut, setRole } = useAuth();
  const [tab, setTab] = useState<'evidence' | 'chronicles' | 'entries' | 'cards'>('evidence');
  const [busy, setBusy] = useState(false);

  const entries = useMemo(
    () =>
      moduleIds.flatMap((id) => {
        const mod = getModule(id);
        if (!mod?.entries) return [];
        return mod.entries.map((entry) => ({
          moduleId: id,
          moduleTitle: mod.title,
          path: site.modules.find((m) => m.id === id)?.path || '/',
          ...entry,
        }));
      }),
    [],
  );

  if (loading) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-28 text-center">
        <p className="font-label text-[0.6rem] uppercase text-[hsl(var(--moss))]">Checking credentials…</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <Lock className="mx-auto h-6 w-6 text-[hsl(var(--moss))]" aria-hidden="true" />
        <h1 className="mt-4 font-display text-4xl font-semibold text-[hsl(var(--charcoal))]">
          The editor's workspace
        </h1>
        <p className="mx-auto mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
          This room is for Society editors. Reading the Chronicles never requires an account — sign in only if you
          maintain the content.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={openAuth}
            className="rounded-sm bg-[hsl(var(--botanical))] px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
          >
            Editor sign in
          </button>
          <Link
            to="/library"
            className="rounded-sm border border-border px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
          >
            Back to the Library
          </Link>
        </div>
      </div>
    );
  }

  if (!isEditor) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-4xl font-semibold text-[hsl(var(--charcoal))]">Editor access required</h1>
        <p className="mx-auto mt-4 max-w-md text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
          You are signed in as <strong>{profile?.email}</strong> with the role{' '}
          <strong>{profile?.role || 'member'}</strong>. Editor access protects the evidence review queue, which holds
          contributors' contact details, so it must be granted by a Society administrator.
        </p>
      </div>
    );
  }

  const tabs = [
    { id: 'evidence' as const, label: 'Evidence & review queue' },
    { id: 'chronicles' as const, label: `Chronicles (${chronicles.length})` },
    { id: 'entries' as const, label: `Module entries (${entries.length})` },
    { id: 'cards' as const, label: `Cards (${cards.length})` },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
      <SectionHeading
        kicker="Editor workspace"
        title="Content overview"
        subtitle="Every Chronicle, module entry and card currently published, with its status. Content itself lives in the repository — this workspace is where editors review what exists and what is still pending."
      />

      <div className="mt-8 flex flex-wrap items-center justify-between gap-4 rounded-sm border border-border/80 bg-[hsl(var(--cream))] px-5 py-4">
        <div className="flex items-center gap-3">
          <ShieldCheck className="h-5 w-5 text-[hsl(var(--botanical))]" aria-hidden="true" />
          <div>
            <p className="font-display text-lg text-[hsl(var(--charcoal))]">
              {profile?.display_name || profile?.email}
            </p>
            <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">
              {profile?.email} · role: {profile?.role}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {profile?.role === 'editor' && (
            <button
              type="button"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                await setRole('member');
                setBusy(false);
              }}
              className="rounded-sm border border-border px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
            >
              Step down to member
            </button>
          )}
          <button
            type="button"
            onClick={signOut}
            className="inline-flex items-center gap-2 rounded-sm border border-border px-4 py-2 font-label text-[0.55rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--burgundy))]/10"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
            Sign out
          </button>
        </div>
      </div>

      <div className="mt-8 flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`rounded-sm border px-4 py-2 font-label text-[0.55rem] uppercase transition-colors ${
              tab === t.id
                ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'border-border text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <Flourish className="my-10" />

      {tab === 'evidence' && <ReviewQueue />}

      {tab === 'chronicles' && (
        <ul className="space-y-3">
          {chronicles.map((c) => (
            <li
              key={c.id}
              className="flex flex-wrap items-center justify-between gap-4 rounded-sm border border-border/80 bg-[hsl(var(--cream))] px-5 py-4"
            >
              <div>
                <Kicker>Chronicle {c.number} · {c.season}</Kicker>
                <p className="mt-1 font-display text-xl text-[hsl(var(--charcoal))]">{c.title}</p>
                <p className="text-xs text-muted-foreground">
                  {c.contentFile ? `src/content/chronicles/${c.contentFile}` : 'No manuscript file yet'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {c.status === 'live' ? (
                  <span className="rounded-full bg-[hsl(var(--botanical))]/12 px-3 py-1 font-label text-[0.52rem] uppercase text-[hsl(var(--botanical))]">
                    Live
                  </span>
                ) : (
                  <PendingTag label="Coming soon" />
                )}
                {c.status === 'live' && (
                  <Link
                    to={`/chronicle/${c.slug}`}
                    className="inline-flex items-center gap-1.5 font-label text-[0.52rem] uppercase text-[hsl(var(--botanical))] hover:underline"
                  >
                    View <ExternalLink className="h-3 w-3" aria-hidden="true" />
                  </Link>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}

      {tab === 'entries' && (
        <div className="overflow-x-auto rounded-sm border border-border/80">
          <table className="w-full min-w-[40rem] border-collapse bg-[hsl(var(--cream))] text-left">
            <thead>
              <tr className="border-b border-border/70">
                <th className="px-4 py-3 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Module</th>
                <th className="px-4 py-3 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Entry</th>
                <th className="px-4 py-3 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Kind</th>
                <th className="px-4 py-3 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Status</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry) => (
                <tr key={`${entry.moduleId}-${entry.id}`} className="border-b border-border/50 last:border-0">
                  <td className="px-4 py-3 text-xs text-muted-foreground">
                    <Link to={entry.path} className="hover:text-[hsl(var(--botanical))]">
                      {entry.moduleTitle}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-sm text-[hsl(var(--ink))]">{entry.title}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{entry.kind || '—'}</td>
                  <td className="px-4 py-3">
                    {entry.status === 'pending' ? (
                      <PendingTag />
                    ) : (
                      <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--botanical))]">Live</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'cards' && (
        <ul className="grid gap-3 sm:grid-cols-2">
          {cards.map((card) => (
            <li
              key={card.id}
              className="flex items-center justify-between gap-4 rounded-sm border border-border/80 bg-[hsl(var(--cream))] px-4 py-3"
            >
              <div>
                <p className="font-display text-lg text-[hsl(var(--charcoal))]">{card.name}</p>
                <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">
                  {card.class} · {card.rarity}
                </p>
              </div>
              {card.pending ? <PendingTag label="Data pending" /> : (
                <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--botanical))]">Complete</span>
              )}
            </li>
          ))}
        </ul>
      )}

      <div className="mt-12">
        <Notice
          tone="info"
          title="How editing works"
          body="Chronicles, module entries and cards are stored as Markdown and JSON in the repository, which stays the canonical source of truth. This workspace gives editors an authenticated overview of everything published and everything still marked pending; the profiles table and its editor role are the gate that future in-app editing will build on."
        />
      </div>

      <p className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
        <FileText className="h-3.5 w-3.5" aria-hidden="true" />
        Full authoring instructions live on the{' '}
        <Link to="/about" className="text-[hsl(var(--botanical))] underline">
          About &amp; contributing
        </Link>{' '}
        page.
      </p>
    </div>
  );
};

export default AdminPage;
