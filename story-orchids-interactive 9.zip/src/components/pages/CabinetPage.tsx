import React, { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { cards } from '@/lib/content';
import { useDiscovery } from '@/contexts/DiscoveryContext';
import TradingCard from '@/components/cards/TradingCard';
import { Flourish, Kicker, SectionHeading } from '@/components/site/Ornaments';
import PrintButton from '@/components/site/PrintButton';

const classes = [
  { id: 'all', label: 'All cards' },
  { id: 'character', label: 'Characters' },
  { id: 'artifact', label: 'Artifacts' },
  { id: 'orchid', label: 'Orchids' },
];

const CabinetPage: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const initial = params.get('class') || 'all';
  const [filter, setFilter] = useState(initial);
  const { discovered, discover } = useDiscovery();

  const visible = useMemo(
    () => (filter === 'all' ? cards : cards.filter((c) => c.class === filter)),
    [filter],
  );

  const setClass = (id: string) => {
    setFilter(id);
    if (id === 'all') params.delete('class');
    else params.set('class', id);
    setParams(params, { replace: true });
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
      <SectionHeading
        kicker="Collect, print, trade"
        title="Collector's Cabinet"
        subtitle="Character, artifact and orchid cards. Orchid cards carry verified data only — where a species has not been confirmed, the card says so instead of guessing."
        align="center"
      />

      <div className="no-print mt-10 flex flex-wrap items-center justify-center gap-2">
        {classes.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setClass(c.id)}
            className={`rounded-sm border px-4 py-2 font-label text-[0.58rem] uppercase transition-colors ${
              filter === c.id
                ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'border-border text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8'
            }`}
          >
            {c.label}
          </button>
        ))}
        <PrintButton label="Print this sheet" />
      </div>

      <p className="no-print mt-4 text-center text-xs text-muted-foreground">
        {discovered.length > 0
          ? `${discovered.length} discovery marker${discovered.length === 1 ? '' : 's'} found while reading.`
          : 'Some cards are discovered by reading the Chronicles — or reveal them here directly.'}
      </p>

      <Flourish className="my-12" />

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {visible.map((card) => {
          const locked =
            Boolean(card.discoverable) &&
            !discovered.includes(card.id) &&
            !(card.unlockedBy && discovered.includes(card.unlockedBy));

          return (
            <TradingCard
              key={card.id}
              card={card}
              locked={locked}
              onReveal={() => discover(card.id)}
            />
          );
        })}
      </div>

      <div className="mt-14 rounded-sm border border-dashed border-border bg-muted/40 p-6">
        <Kicker>Card schema</Kicker>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Cards are defined in <code className="font-ui text-xs">/src/content/cards.json</code>. Orchid cards use the
          fields scientific name, range, habitat, elevation, temperature, pollination and interesting fact. Add a card by
          appending one object — the cabinet, the print layout and any discovery link pick it up automatically.
        </p>
      </div>
    </div>
  );
};

export default CabinetPage;
