import React, { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { scienceConcepts, getScienceConcept, chronicles } from '@/lib/content';
import ScienceCard, { ProvenanceLabel } from '@/components/science/ScienceCard';
import { Flourish, Kicker, Notice } from '@/components/site/Ornaments';

const SciencePage: React.FC = () => {
  const { conceptId } = useParams();
  const focused = getScienceConcept(conceptId);
  const [filter, setFilter] = useState<string>('all');

  const kinds = useMemo(() => Array.from(new Set(scienceConcepts.map((c) => c.kind))), []);
  const list = useMemo(
    () => (filter === 'all' ? scienceConcepts : scienceConcepts.filter((c) => c.kind === filter)),
    [filter],
  );

  if (focused) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <Link
          to="/science"
          className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))] underline underline-offset-4"
        >
          All science topics
        </Link>
        <div className="mt-6">
          <ScienceCard concept={focused} defaultOpen />
        </div>
      </div>
    );
  }

  const chronicleI = chronicles.find((c) => c.id === 'chronicle-i');

  return (
    <>
      <section className="border-b border-border/70 bg-[hsl(var(--botanical))]/6">
        <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 sm:py-20">
          <Kicker>Level three · optional at every step</Kicker>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
            Science Behind the Stories
          </h1>
          <p className="mt-5 max-w-2xl text-[1.05rem] leading-relaxed text-[hsl(var(--ink))]">
            Nothing here is required in order to enjoy a Chronicle. It is here for the reader who finishes a story and
            wants to know whether any of that could really happen — and, mostly, how much of it already does.
          </p>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            Every topic opens at three depths. Start with <strong>Basic</strong>, go to <strong>Deeper</strong> for the
            mechanism, or <strong>Scientific</strong> for the technical account.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <ProvenanceLabel label="observed" />
            <span className="text-xs text-muted-foreground">Established botanical or horticultural knowledge.</span>
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <ProvenanceLabel label="fiction" />
            <span className="text-xs text-muted-foreground">An invention of the Edith Bramble universe.</span>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
        <Notice
          tone="caution"
          title="Real orchid science, separately from the fiction"
          body="Curses do not cause plant disease; pathogens do. Where a traditional remedy appears in these pages it is described as a grower practice rather than a validated treatment. Always follow product labels, test on one plant first, and confirm a diagnosis before treating a collection."
        />

        <Link
          to="/science/orchids"
          className="mt-8 block rounded-sm border-2 border-[hsl(var(--botanical))]/40 bg-[hsl(var(--botanical))]/[0.05] p-6 hover:border-[hsl(var(--botanical))]"
        >
          <Kicker>New · The Science Greenhouse</Kicker>
          <p className="mt-2 font-display text-2xl text-[hsl(var(--charcoal))]">Why does this orchid do that?</p>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Nine orchid science profiles from Chronicle II — origin, habitat, adaptation, Read the Plant, seasonal life,
            culture — plus “Why are these orchids neighbors?”
          </p>
        </Link>

        {chronicleI && (
          <div className="mt-8 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6">
            <Kicker>Chronicle {chronicleI.number}</Kicker>
            <p className="mt-2 font-display text-2xl text-[hsl(var(--charcoal))]">{chronicleI.title}</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              The topics tagged to this Chronicle explain what a real greenhouse would have been going through on that
              foggy night — cool wet conditions, water moulds, drying time and airflow.
            </p>
            <Link
              to={`/chronicle/${chronicleI.slug}`}
              className="mt-4 inline-block font-label text-[0.55rem] uppercase text-[hsl(var(--botanical))] underline underline-offset-4"
            >
              Read the story first
            </Link>
          </div>
        )}

        <div className="mt-10 flex flex-wrap gap-2" role="group" aria-label="Filter topics by kind">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`rounded-sm border px-3 py-2 font-label text-[0.55rem] uppercase ${
              filter === 'all'
                ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'border-border bg-background text-[hsl(var(--ink))]'
            }`}
          >
            All topics
          </button>
          {kinds.map((k) => (
            <button
              key={k}
              type="button"
              onClick={() => setFilter(k)}
              className={`rounded-sm border px-3 py-2 font-label text-[0.55rem] uppercase ${
                filter === k
                  ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                  : 'border-border bg-background text-[hsl(var(--ink))]'
              }`}
            >
              {k}
            </button>
          ))}
        </div>

        <div className="mt-6 space-y-4">
          {list.map((c) => (
            <ScienceCard key={c.id} concept={c} />
          ))}
        </div>

        <Flourish className="my-14" />

        <div className="flex flex-wrap gap-3">
          <Link
            to="/plant-doctor"
            className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
          >
            Plant Doctor
          </Link>
          <Link
            to="/notebook"
            className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
          >
            The Grower's Notebook
          </Link>
          <Link
            to="/go-deeper"
            className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
          >
            Go Deeper
          </Link>
        </div>
      </div>
    </>
  );
};

export default SciencePage;
