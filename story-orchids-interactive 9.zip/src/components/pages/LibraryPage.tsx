import React from 'react';
import { chronicles } from '@/lib/content';
import { Flourish, SectionHeading } from '@/components/site/Ornaments';
import ChronicleCard from '@/components/site/ChronicleCard';

const LibraryPage: React.FC = () => (
  <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
    <SectionHeading
      kicker="The bookshelf"
      title="Chronicle Library"
      subtitle="Two Chronicles are open. Another envelope remains in Edith's greenhouse."
      align="center"
    />
    <Flourish className="my-12" />
    <ul className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
      {chronicles.map((c) => (
        <li key={c.id}>
          <ChronicleCard c={c} />
        </li>
      ))}
    </ul>
  </div>
);

export default LibraryPage;
