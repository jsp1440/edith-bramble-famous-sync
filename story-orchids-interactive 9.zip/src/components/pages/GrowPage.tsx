import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { growerCards, glossary } from '@/lib/content';
import { GrowerCardBody } from '@/components/story/GrowerCardDialog';
import { Kicker, Notice } from '@/components/site/Ornaments';
import RootViewer from '@/components/grow/RootViewer';
import SeasonWheel from '@/components/grow/SeasonWheel';

const GrowPage: React.FC = () => {
  const { hash } = useLocation();
  const [term, setTerm] = useState<string | null>(null);

  useEffect(() => {
    if (!hash) return;
    const el = document.getElementById(hash.slice(1));
    if (el) window.setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
  }, [hash]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <Kicker>Practical culture library</Kicker>
      <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
        Grow: the orchids of Chronicle II
      </h1>
      <p className="mt-4 max-w-2xl text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
        Short, practical Grower Cards for the plants that carry the story. They describe groups in general — species,
        parentage, potting medium, water quality, local microclimate and the individual plant all matter.
      </p>
      <div className="mt-6 max-w-3xl">
        <Notice
          tone="info"
          title="Broad guidance, not rigid rules"
          body="Phrases like “many nobile-type Dendrobiums” are deliberate. No page here claims that all orchids need the same seasonal care — the whole of Chronicle II argues the opposite. Watch the plant before the calendar."
        />
      </div>

      <ul className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {growerCards.map((c) => (
          <li key={c.id} id={c.id} className="scroll-mt-28 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-5">
            <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">{c.taxon}</p>
            <h2 className="mb-3 mt-1 font-display text-2xl font-semibold leading-tight text-[hsl(var(--charcoal))]">{c.title}</h2>
            <GrowerCardBody card={c} />
          </li>
        ))}
      </ul>

      <section className="mt-16 grid gap-8 lg:grid-cols-2">
        <RootViewer />
        <SeasonWheel />
      </section>

      <section className="mt-16">
        <Kicker>Glossary</Kicker>
        <h2 className="mt-2 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Words the growers use</h2>
        <div className="mt-6 flex flex-wrap gap-2">
          {glossary.map((g) => (
            <button
              key={g.term}
              type="button"
              aria-expanded={term === g.term}
              onClick={() => setTerm(term === g.term ? null : g.term)}
              className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                term === g.term
                  ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                  : 'border-border bg-background text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]/60'
              }`}
            >
              {g.term}
            </button>
          ))}
        </div>
        <p aria-live="polite" className="mt-4 min-h-[3rem] max-w-2xl text-[1rem] leading-relaxed text-[hsl(var(--ink))]">
          {term ? (
            <>
              <strong className="font-display text-lg">{term}.</strong> {glossary.find((g) => g.term === term)?.body}
            </>
          ) : (
            <span className="text-muted-foreground">Tap a word to see its meaning.</span>
          )}
        </p>
      </section>

      <div className="mt-12 flex flex-wrap gap-3">
        <Link to="/chronicle-2" className="rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))]">
          Read Chronicle II
        </Link>
        <Link to="/diagnostic-bench" className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
          Marian's Diagnostic Bench
        </Link>
        <Link to="/greenhouse#microclimates" className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
          Edith's Autumn Map
        </Link>
      </div>
    </div>
  );
};

export default GrowPage;
