import React from 'react';
import { useSearchParams } from 'react-router-dom';
import ModulePage from '@/components/modules/ModulePage';
import { isDeepIntegrationEnabled } from '@/lib/goDeeper';
import { Kicker, PendingTag } from '@/components/site/Ornaments';

const GoDeeperPage: React.FC = () => {
  const [params] = useSearchParams();
  const subject = params.get('subject');
  const id = params.get('id');
  const enabled = isDeepIntegrationEnabled();

  return (
    <ModulePage moduleId="go-deeper">
      <section className="mt-8 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6 sm:p-8">
        <Kicker>Adapter status</Kicker>
        <div className="mt-3 flex flex-wrap items-center gap-3">
          <span
            className={`inline-flex items-center gap-2 rounded-full px-3 py-1 font-label text-[0.55rem] uppercase ${
              enabled
                ? 'bg-[hsl(var(--botanical))]/12 text-[hsl(var(--botanical))]'
                : 'bg-[hsl(var(--burgundy))]/10 text-[hsl(var(--burgundy))]'
            }`}
          >
            <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
            {enabled ? 'Connected' : 'Offline — no provider configured'}
          </span>
          {!enabled && <PendingTag label="Integration pending" />}
        </div>

        {(subject || id) && (
          <dl className="mt-5 grid gap-3 sm:grid-cols-2">
            <div>
              <dt className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Requested subject</dt>
              <dd className="text-sm text-[hsl(var(--ink))]">{subject || '—'}</dd>
            </div>
            <div>
              <dt className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Identifier</dt>
              <dd className="text-sm text-[hsl(var(--ink))]">{id || '—'}</dd>
            </div>
          </dl>
        )}

        <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
          This request was received by the boundary and intentionally not answered. No external data is fetched,
          cached, or invented while the Orchid Continuum / Calyx endpoint is unavailable.
        </p>
      </section>
    </ModulePage>
  );
};

export default GoDeeperPage;
