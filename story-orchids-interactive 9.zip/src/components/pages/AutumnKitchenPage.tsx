import React, { useState } from 'react';
import { Clock, Printer, Users } from 'lucide-react';
import { recipes, getMedia } from '@/lib/content';
import { Kicker, Notice } from '@/components/site/Ornaments';

const AutumnKitchenPage: React.FC = () => {
  const [done, setDone] = useState<Record<string, boolean>>({});
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <Kicker className="no-print">Kitchen at Edith's</Kicker>
      <h1 className="no-print mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
        Autumn Kitchen
      </h1>
      <p className="no-print mt-4 max-w-2xl text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
        Something warm for the potting bench, whether or not you grow a single orchid. Four complete recipe cards —
        including the apple-blackberry tart that disappeared at the end of Chronicle II.
      </p>
      <div className="no-print mt-6 max-w-3xl">
        <Notice
          tone="caution"
          title="The kitchen is not the greenhouse"
          body="These recipes are food only. No kitchen ingredient here — cinnamon included — is offered as an orchid pesticide or fungicide."
        />
      </div>

      <div className="mt-12 space-y-10">
        {recipes.map((r) => {
          const img = getMedia(r.image);
          return (
            <article key={r.id} className="print-sheet grid gap-6 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-5 sm:p-7 lg:grid-cols-[minmax(0,22rem)_1fr]">
              <div>
                {img && <img src={img.src} alt={img.alt} loading="lazy" className="aspect-[4/3] w-full rounded-sm border border-border/70 object-cover" />}
                <dl className="mt-4 grid grid-cols-3 gap-2 text-center">
                  {[
                    { icon: Users, label: 'Yield', v: r.yield },
                    { icon: Clock, label: 'Prep', v: r.prep },
                    { icon: Clock, label: 'Cook', v: r.cook },
                  ].map(({ icon: Icon, label, v }) => (
                    <div key={label} className="rounded-sm border border-border/70 bg-background p-2">
                      <dt className="flex items-center justify-center gap-1 font-label text-[0.48rem] uppercase text-[hsl(var(--moss))]">
                        <Icon className="h-3 w-3" aria-hidden="true" /> {label}
                      </dt>
                      <dd className="mt-1 text-xs leading-snug text-[hsl(var(--ink))]">{v}</dd>
                    </div>
                  ))}
                </dl>
              </div>
              <div>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <h2 className="font-display text-3xl font-semibold leading-tight text-[hsl(var(--charcoal))]">{r.title}</h2>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    className="no-print inline-flex items-center gap-1.5 rounded-sm border border-border px-3 py-1.5 font-label text-[0.5rem] uppercase text-[hsl(var(--ink))]"
                  >
                    <Printer className="h-3.5 w-3.5" aria-hidden="true" /> Print
                  </button>
                </div>
                <p className="mt-1 font-display text-lg italic text-[hsl(var(--burgundy))]">{r.blurb}</p>
                <div className="mt-5 grid gap-6 md:grid-cols-2">
                  <div>
                    <h3 className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Ingredients</h3>
                    <ul className="mt-2 space-y-1.5">
                      {r.ingredients.map((ing) => {
                        const k = r.id + ing;
                        return (
                          <li key={ing}>
                            <label className="flex cursor-pointer items-start gap-2 text-sm leading-relaxed text-[hsl(var(--ink))]">
                              <input
                                type="checkbox"
                                checked={!!done[k]}
                                onChange={() => setDone((d) => ({ ...d, [k]: !d[k] }))}
                                className="mt-1 h-4 w-4 accent-[hsl(var(--botanical))]"
                              />
                              <span className={done[k] ? 'text-muted-foreground line-through' : ''}>{ing}</span>
                            </label>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Method</h3>
                    <ol className="mt-2 list-decimal space-y-2 pl-5 text-sm leading-relaxed text-[hsl(var(--ink))]">
                      {r.steps.map((s) => (
                        <li key={s}>{s}</li>
                      ))}
                    </ol>
                  </div>
                </div>
                {r.variation && <p className="mt-4 text-sm text-[hsl(var(--ink))]"><strong>Variation:</strong> {r.variation}</p>}
                <p className="mt-3 rounded-sm bg-muted/60 px-3 py-2 text-xs text-[hsl(var(--ink))]">
                  <strong>Allergens:</strong> {r.allergens} Follow standard food-safety practice; cool and refrigerate leftovers promptly.
                </p>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};

export default AutumnKitchenPage;
