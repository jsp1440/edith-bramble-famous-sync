import React, { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { BookOpen, CheckCircle2, ExternalLink, Globe2, ImageOff, Images, Library, ListChecks, Mountain, Network, ShieldAlert, Sprout, Unplug, Users, X } from 'lucide-react';
import AtlasMap from '@/components/explore/AtlasMap';
import ClaimReview from '@/components/explore/ClaimReview';
import { FEATURED_TAXA, MONTHS, countryName, useOrchidExplorer } from '@/lib/feature-genius';
import { EVIDENCE_LABEL, ocToMedia, sizedSrc, useDossierExtras, useMediaPage, type Claim, type MediaRecord } from '@/lib/continuum';
import { getProfile, profilePath, sectionStatement } from '@/lib/orchid-continuum';
import { sectionAvailable, useOcSpeciesDossier, useOcSpeciesMedia, type OcDossier } from '@/lib/oc-direct';

const Section: React.FC<{ id: string; icon: React.ReactNode; title: string; children: React.ReactNode }> = ({ id, icon, title, children }) => (
  <section id={id} className="scroll-mt-32 rounded-xl border-2 border-[hsl(var(--charcoal))]/25 bg-white p-5 shadow-sm sm:p-7">
    <h2 className="flex items-center gap-3 font-display text-3xl font-semibold text-[hsl(var(--botanical))]">{icon}{title}</h2>
    <div className="mt-4 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">{children}</div>
  </section>
);

const Unknown: React.FC<{ what?: string }> = ({ what }) => (
  <p className="rounded-md border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-[hsl(40_30%_96%)] p-3 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]">
    UNKNOWN / NOT AVAILABLE{what ? ` — ${what}` : ''}
  </p>
);

/** One Orchid Continuum dossier section, exactly as the Continuum reports it. */
const OcBlock: React.FC<{ d: OcDossier | null; k: string; label: string }> = ({ d, k, label }) => {
  const s = d?.sections[k];
  if (!d || !s) return null;
  const ok = sectionAvailable(d, k);
  const src = s.receipts[0];
  return (
    <div className="mt-3 rounded-md border-2 border-[hsl(var(--botanical))]/40 bg-[hsl(var(--cream))] p-3">
      <p className="font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">Orchid Continuum · {label} · {s.state}</p>
      {ok ? (
        <>
          <p className="mt-1">{sectionStatement(s) || s.summary}</p>
          {src && <p className="mt-1 text-[1rem]">Source: {src.source_name || src.source_id}{src.license ? ` · ${src.license}` : ''}{src.evidence_state ? ` · evidence ${src.evidence_state}` : ''}{src.notes ? ` · ${src.notes}` : ''}</p>}
        </>
      ) : (
        <p className="mt-1 font-semibold">UNKNOWN / NOT AVAILABLE{s.unavailable_reason ? ` — ${s.unavailable_reason}` : ''}</p>
      )}
    </div>
  );
};

type Basis = 'HUMAN_OBSERVATION' | 'PRESERVED_SPECIMEN';

const Gallery: React.FC<{ taxonKey: number | null; name: string }> = ({ taxonKey, name }) => {
  const [basis, setBasis] = useState<Basis>('HUMAN_OBSERVATION');
  const [offset, setOffset] = useState(0);
  const [gbif, setGbif] = useState<MediaRecord[]>([]);
  const [open, setOpen] = useState<MediaRecord | null>(null);
  const [failed, setFailed] = useState<Set<string>>(new Set());
  const { data, state } = useMediaPage(taxonKey, basis, offset, 12);
  const oc = useOcSpeciesMedia(name || null, basis);

  useEffect(() => { setOffset(0); setGbif([]); }, [basis, taxonKey]);
  useEffect(() => {
    if (!data) return;
    setGbif((prev) => {
      const seen = new Set(prev.map((p) => p.src));
      return data.offset === 0 ? data.items : [...prev, ...data.items.filter((i) => !seen.has(i.src))];
    });
  }, [data]);

  /* OC first, GBIF after, deduplicated by URL; images that fail to load are removed. */
  const items = useMemo(() => {
    const ocItems = (oc.data?.items ?? []).map((m) => ocToMedia(m, taxonKey ?? 0));
    const seen = new Set<string>();
    return [...ocItems, ...gbif].filter((m) => !failed.has(m.src) && !seen.has(m.src) && seen.add(m.src));
  }, [oc.data, gbif, failed, taxonKey]);
  const ocCount = (oc.data?.items ?? []).filter((m) => !failed.has(m.src)).length;
  const gbifTotal = data?.total ?? 0;
  const settled = oc.state !== 'loading' && (state === 'ok' || state === 'error' || !taxonKey);

  return (
    <>
      <p className="mb-3 font-semibold text-[hsl(var(--charcoal))]">Orchid Continuum media is preferred; GBIF remains fallback.</p>
      <div className="flex flex-wrap gap-2" role="group" aria-label="Kind of image">
        {([['HUMAN_OBSERVATION', 'Living plant photographs'], ['PRESERVED_SPECIMEN', 'Herbarium specimens']] as const).map(([b, l]) => (
          <button key={b} type="button" aria-pressed={basis === b} onClick={() => setBasis(b)}
            className={`min-h-[52px] rounded-md border-2 px-4 font-ui text-[1.0625rem] font-semibold ${basis === b ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-[hsl(var(--charcoal))]/40 bg-white'}`}>
            {basis === b ? '● ' : ''}{l}
          </button>
        ))}
      </div>
      <p className="mt-3">
        {!settled && !items.length ? 'Loading images from Orchid Continuum and fallback records…' : items.length ? `${ocCount} from Orchid Continuum · ${gbifTotal.toLocaleString()} openly licensed GBIF records of this exact taxon. Showing ${items.length}.` : ''}
      </p>
      {oc.state === 'error' && oc.error && (
        <p className="mt-2 rounded-md border-2 border-[hsl(var(--burgundy))] p-3 text-[1rem]">Orchid Continuum media request failed ({oc.error.kind.toUpperCase()}{oc.error.status ? ` ${oc.error.status}` : ''}: {oc.error.message}). Fallback records are shown; this is not a finding that no image exists.</p>
      )}
      {settled && items.length === 0 && (
        <div className="mt-3 flex items-center gap-3 rounded-lg border-2 border-dashed border-[hsl(var(--charcoal))]/40 p-5 font-ui font-semibold"><ImageOff className="h-6 w-6" aria-hidden="true" /> No image available of this kind in Orchid Continuum or the fallback records. No other orchid is substituted.</div>
      )}
      <ul className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {items.map((im) => (
          <li key={im.src}>
            <button type="button" onClick={() => setOpen(im)} className="block w-full overflow-hidden rounded-lg border-2 border-[hsl(var(--charcoal))]/25 text-left hover:border-[hsl(var(--botanical))]">
              <span className="block aspect-square overflow-hidden bg-[hsl(40_25%_88%)]">
                <img src={sizedSrc(im.src, 'small')} alt={`${im.identifiedAs ?? name}${im.country ? `, ${im.country}` : ''} — ${EVIDENCE_LABEL[im.evidenceClass]}`} loading="lazy" decoding="async"
                  onError={() => setFailed((f) => new Set(f).add(im.src))} className="h-full w-full object-cover" />
              </span>
              <span className="block px-2 py-1.5 text-[0.98rem] leading-snug text-[hsl(var(--charcoal))]">{im.provider === 'Orchid Continuum' ? 'Orchid Continuum' : im.country ?? 'GBIF · location withheld'} · {im.license}</span>
            </button>
          </li>
        ))}
      </ul>
      {gbif.length < gbifTotal && (
        <button type="button" disabled={state === 'loading'} onClick={() => setOffset(gbif.length)} className="mt-4 min-h-[52px] rounded-md border-2 border-[hsl(var(--botanical))] bg-white px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] disabled:opacity-50">
          {state === 'loading' ? 'Loading…' : 'Show 12 more'}
        </button>
      )}
      {open && (
        <div role="dialog" aria-modal="true" aria-label={open.identifiedAs ?? name} className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4" onClick={() => setOpen(null)}>
          <figure className="max-h-full w-full max-w-4xl overflow-auto rounded-xl bg-[hsl(var(--cream))] p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <figcaption className="font-display text-2xl italic text-[hsl(var(--charcoal))]">{open.identifiedAs ?? name}</figcaption>
              <button type="button" onClick={() => setOpen(null)} className="inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 border-[hsl(var(--charcoal))] px-4 font-ui font-semibold"><X className="h-5 w-5" aria-hidden="true" /> Close</button>
            </div>
            <img src={sizedSrc(open.src, 'large')} alt={`${open.identifiedAs ?? name} — ${EVIDENCE_LABEL[open.evidenceClass]}`} className="mt-3 max-h-[70vh] w-full rounded-md object-contain" />
            <p className="mt-3 text-[1.0625rem]">
              <strong>{EVIDENCE_LABEL[open.evidenceClass]}</strong> · {open.creator ?? 'not credited by source'} · {open.license} · {open.source}{open.country ? ` · ${open.country}` : ''}{open.ocTaxonId ? ` · OC taxon ${open.ocTaxonId}` : ''} ·{' '}
              <a href={open.recordUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">View the record</a>
            </p>
          </figure>
        </div>
      )}
    </>
  );
};

const SpeciesDossierPage: React.FC = () => {
  const { key, slug } = useParams();
  const taxonKey = Number(key) || null;
  const guessed = (slug || '').replace(/-/g, ' ').replace(/^./, (c) => c.toUpperCase());
  const { data, state } = useOrchidExplorer(guessed || null);
  const { data: extra } = useDossierExtras(taxonKey);
  const t = data?.taxon;
  const name = t?.name ?? guessed;
  const genus = t?.genus ?? name.split(' ')[0];
  const isSpecies = name.trim().split(/\s+/).length >= 2;
  const oc = useOcSpeciesDossier(isSpecies ? name : null);
  const d = oc.data;
  const av = (k: string) => sectionAvailable(d, k);
  const featured = FEATURED_TAXA.find((f) => f.name.toLowerCase() === name.toLowerCase()) ?? FEATURED_TAXA.find((f) => f.name.toLowerCase() === genus.toLowerCase());
  const profile = featured?.profile ? getProfile(featured.profile) : undefined;
  const profileIsGenus = featured ? featured.name.toLowerCase() !== name.toLowerCase() : false;
  const mapKey = t?.key ?? taxonKey;
  const maxM = Math.max(1, ...(data?.occurrences?.months.map((m) => m.count) ?? [1]));

  const claims: Claim[] = useMemo(() => {
    const c: Claim[] = [];
    if (d && av('calyx_narrative')) c.push({ id: `oc:${d.taxonId}:narrative`, text: sectionStatement(d.sections.calyx_narrative).split('. ')[0].replace(/\.$/, '') + '.', source: `Orchid Continuum species dossier (taxon ${d.taxonId})`, evidenceClass: `oc ${d.sections.calyx_narrative.state}`, reviewState: 'unreviewed' });
    if (data?.summary?.text) c.push({ id: `${mapKey}:summary`, text: `${data.summary.text.split('. ')[0].replace(/\.$/, '')}.`, source: 'Wikipedia summary', evidenceClass: 'encyclopedia summary', reviewState: 'unreviewed' });
    if (data?.elevation) c.push({ id: `${mapKey}:elevation`, text: `Most sampled GBIF records of ${name} that report elevation fall between ${Math.round(data.elevation.low)} m and ${Math.round(data.elevation.high)} m.`, source: 'GBIF occurrence records (computed summary)', evidenceClass: 'occurrence-record summary', reviewState: 'unreviewed' });
    profile?.culture.slice(0, 3).forEach((cl) => c.push({ id: `${profile.id}:culture:${cl.label}`, text: `${cl.label}: ${cl.value}`, source: `Edith Bramble Culture Library${profileIsGenus ? ' (genus-level guidance)' : ''}`, evidenceClass: profile.evidence.evidenceType, reviewState: profile.evidence.reviewState }));
    return c;
    // av derives from d
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, d, profile, mapKey, name, profileIsGenus]);

  /* Evidence table: Orchid Continuum dossier availability first, then existing fallback. */
  const OC = 'Orchid Continuum dossier';
  const pick = (ocKey: string | string[], fallbackOk: boolean, fallbackSrc: string): [boolean, string] => {
    const keys = Array.isArray(ocKey) ? ocKey : [ocKey];
    const hit = keys.find((k) => av(k));
    if (hit) return [true, `${OC} · ${d!.sections[hit].state}`];
    return [fallbackOk, fallbackOk ? `${fallbackSrc} (fallback)` : d ? `${OC}: not yet assembled` : 'Not available'];
  };
  const facets: [string, boolean, string][] = [
    ['Accepted name & taxonomy', ...(d ? [true, `${OC} · taxon ${d.taxonId}`] as [boolean, string] : [!!t, 'GBIF Backbone (fallback)'] as [boolean, string])],
    ['Synonyms', ...pick('nomenclature', !!extra?.synonyms?.length, 'GBIF Backbone')],
    ['Images', ...pick(['living_media', 'historical_media'], true, 'GBIF-mediated open records')],
    ['Summary', ...pick('calyx_narrative', !!data?.summary, 'Wikipedia')],
    ['Geography & Atlas', ...pick(['distribution', 'atlas_summary'], !!data?.occurrences?.total, 'GBIF occurrences')],
    ['Elevation', ...pick('atlas_summary', !!data?.elevation, 'GBIF occurrences')],
    ['Culture', ...pick('cultivation', !!profile, 'Culture Library')],
    ['Conservation status', ...pick('conservation', !!extra?.conservation, 'IUCN via GBIF')],
    ['Literature', ...pick('literature', !!extra?.literature?.total, 'GBIF literature index')],
    ['Morphology / anatomy', ...pick('morphology', false, '')],
    ['Physiology / phenology', ...pick('phenology', false, '')],
    ['Pollination', ...pick('pollinators', false, '')],
    ['Mycorrhiza', ...pick('mycorrhizae', false, '')],
    ['Ecological interactions', ...pick('ecology', false, '')],
    ['Knowledge graph', ...pick('knowledge_graph', false, '')],
    ['Identification Matrix', ...pick('identification_matrix', !!d?.matrixUrl, 'Orchid Continuum Matrix link')],
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <Link to="/explore" className="font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">← Featured Genus & all orchids</Link>
      <header className="mt-4">
        <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]">Species Dossier · {t?.rank?.toLowerCase() ?? 'taxon'}</p>
        <h1 className="mt-2 font-display text-5xl font-semibold italic text-[hsl(var(--charcoal))] sm:text-6xl">{d?.acceptedName || name}</h1>
        {d ? (
          <p className="mt-3 text-[1.1875rem]"><strong>Accepted name (Orchid Continuum):</strong> {d.fullScientificName}{d.authorship ? ` ${d.authorship}` : ''} · Genus <em>{genus}</em>{d.synonyms.length ? ` · Synonyms: ${d.synonyms.join('; ')}` : ''}</p>
        ) : t && <p className="mt-3 text-[1.1875rem]"><strong>Accepted name:</strong> {t.scientificName} · Status {t.status?.toLowerCase()} · Genus <em>{genus}</em> · Family {t.family}</p>}
        {!!extra?.vernacular?.length && <p className="mt-1 text-[1.125rem]"><strong>Common names:</strong> {extra.vernacular.join(', ')}</p>}

        <div role="status" className={`mt-4 flex items-start gap-3 rounded-lg border-2 p-4 ${d ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--cream))]' : 'border-[hsl(var(--charcoal))]/40 bg-white'}`}>
          {d ? <CheckCircle2 className="mt-0.5 h-6 w-6 shrink-0 text-[hsl(var(--botanical))]" aria-hidden="true" /> : <Unplug className="mt-0.5 h-6 w-6 shrink-0" aria-hidden="true" />}
          <div className="text-[1.0625rem]">
            {oc.state === 'loading' && <p className="font-semibold">Orchid Continuum: resolving canonical taxon…</p>}
            {d && (
              <p className="font-semibold">
                Orchid Continuum: connected · canonical taxon {d.taxonId}
                {d.resolution === 'ambiguous-exact' && d.candidates.length > 1 ? ` (the Continuum lists ${d.candidates.length} canonical records with this exact name: ${d.candidates.join(', ')}; showing the most complete)` : ''}
                {' · '}<a href={d.dossierUrl} target="_blank" rel="noopener noreferrer" className="underline">Open in Orchid Continuum</a>
              </p>
            )}
            {(oc.state === 'error' || (oc.state === 'ok' && !d) || (!isSpecies && state !== 'loading')) && (
              <p className="font-semibold">Orchid Continuum: canonical dossier unavailable; public fallback records remain visible.</p>
            )}
            {oc.state === 'error' && oc.error && <p className="mt-1">Request failed — {oc.error.kind.toUpperCase()}{oc.error.status ? ` ${oc.error.status}` : ''} · {oc.error.url} · {oc.error.message}</p>}
          </div>
        </div>

        <nav aria-label="Dossier sections" className="mt-5 flex flex-wrap gap-2">
          {[['images', 'Images'], ['atlas', 'Atlas'], ['literature', 'Literature'], ['culture', 'Culture'], ['science', 'Biology'], ['evidence', 'Evidence & review']].map(([id, l]) => (
            <a key={id} href={`#${id}`} className="inline-flex min-h-[52px] items-center rounded-md border-2 border-[hsl(var(--botanical))] bg-white px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))] hover:text-[hsl(var(--cream))]">{l}</a>
          ))}
        </nav>
      </header>

      {state === 'error' && <p className="mt-8 rounded-xl border-2 border-[hsl(var(--burgundy))] bg-white p-6 text-[1.1875rem]">The public fallback data service could not be reached just now. Please try again in a moment.</p>}
      {state === 'loading' && <p className="mt-8 rounded-xl border-2 border-dashed border-[hsl(var(--charcoal))]/40 bg-white p-6 text-center text-[1.25rem]">Gathering records for {name}…</p>}

      <div className="mt-8 space-y-6">
        <Section id="images" icon={<Images className="h-7 w-7" aria-hidden="true" />} title="Images">
          <Gallery taxonKey={taxonKey} name={isSpecies ? name : ''} />
        </Section>

        <Section id="summary" icon={<BookOpen className="h-7 w-7" aria-hidden="true" />} title="Summary & names">
          {av('calyx_narrative') && <OcBlock d={d} k="calyx_narrative" label="summary" />}
          {data?.summary ? (
            <>
              <p className="mt-3 max-w-3xl">{data.summary.text}</p>
              <p className="mt-2 text-[1rem]">Source: {data.summary.source} ({data.summary.license}). {data.summary.url && <a href={data.summary.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">Read more</a>}</p>
            </>
          ) : !av('calyx_narrative') && <Unknown what="no reviewed summary for this taxon" />}
          <h3 className="mt-5 font-ui text-[1.125rem] font-bold text-[hsl(var(--charcoal))]">Synonyms & nomenclature</h3>
          <OcBlock d={d} k="nomenclature" label="nomenclature" />
          {extra?.synonyms?.length ? <p className="mt-2"><em>{extra.synonyms.map((s) => s.name).join('; ')}</em> <span className="text-[1rem]">(GBIF Backbone)</span></p> : !av('nomenclature') && <Unknown what="no synonyms listed" />}
        </Section>

        <div className="grid gap-6 lg:grid-cols-2">
          <Section id="geography" icon={<Globe2 className="h-7 w-7" aria-hidden="true" />} title="Geography">
            <OcBlock d={d} k="distribution" label="distribution" />
            {data?.occurrences?.countries.length ? (
              <>
                <p className="mt-3">GBIF public records: {data.occurrences.total.toLocaleString()}. Most records from:</p>
                <p className="mt-2 font-semibold text-[hsl(var(--charcoal))]">{data.occurrences.countries.slice(0, 8).map((c) => countryName(c.code)).join(' · ')}</p>
                <p className="mt-2 text-[1rem]">Records include cultivated plants; some countries are sampled far more than others.</p>
              </>
            ) : !av('distribution') && <Unknown what="no georeferenced records" />}
          </Section>
          <Section id="elevation" icon={<Mountain className="h-7 w-7" aria-hidden="true" />} title="Elevation & season of records">
            <OcBlock d={d} k="atlas_summary" label="atlas summary" />
            {data?.elevation ? <p className="mt-3">GBIF sampled records with elevation: <strong>{Math.round(data.elevation.low)}–{Math.round(data.elevation.high)} m</strong> (middle ~{Math.round(data.elevation.median)} m, n={data.elevation.n}).</p> : !av('atlas_summary') && <Unknown what="too few records report elevation" />}
            {!!data?.occurrences?.months.length && (
              <>
                <div className="mt-3 flex h-24 items-end gap-1" aria-hidden="true">
                  {MONTHS.map((m, i) => { const v = data.occurrences.months.find((x) => x.month === i + 1)?.count ?? 0; return <div key={m} className="flex flex-1 flex-col items-center gap-1"><div className="w-full rounded-t bg-[hsl(var(--moss))]" style={{ height: `${(v / maxM) * 80}px` }} /><span className="text-[0.95rem]">{m.charAt(0)}</span></div>; })}
                </div>
                <p className="mt-2 text-[1rem]">Month a record was made — <strong>not</strong> a flowering calendar.</p>
              </>
            )}
          </Section>
        </div>

        <Section id="atlas" icon={<Globe2 className="h-7 w-7" aria-hidden="true" />} title="Atlas">
          <p className="mb-3 text-[1.0625rem]"><strong>Map:</strong> GBIF public occurrence visualization (generalised hexagons). <strong>Orchid Continuum Atlas synthesis:</strong> {av('atlas_summary') ? 'shown in “Elevation & season” above.' : 'not yet assembled for this taxon.'}</p>
          {mapKey ? <AtlasMap key={`${mapKey}:${data?.view ? 'v' : 'n'}`} taxonKey={mapKey} taxonName={name} initial={data?.view ?? null} /> : <Unknown />}
          <p className="mt-3 text-[1rem]">Precise localities (including sensitive species) are never exposed.</p>
        </Section>

        <Section id="science" icon={<Network className="h-7 w-7" aria-hidden="true" />} title="Biology & ecology (Orchid Continuum)">
          {d ? (
            <div className="grid gap-x-4 sm:grid-cols-2">
              {[['morphology', 'Morphology / anatomy'], ['phenology', 'Physiology / phenology'], ['pollinators', 'Pollination'], ['mycorrhizae', 'Mycorrhiza'], ['ecology', 'Ecological interactions'], ['knowledge_graph', 'Knowledge graph'], ['identification_matrix', 'Identification Matrix'], ['research_gaps', 'Unresolved knowledge gaps']].map(([k, l]) =>
                d.sections[k] ? <OcBlock key={k} d={d} k={k} label={l} /> : <div key={k} className="mt-3"><Unknown what={`${l}: not part of this dossier`} /></div>)}
            </div>
          ) : <Unknown what={oc.state === 'loading' ? 'loading the Orchid Continuum dossier' : 'no canonical Orchid Continuum dossier for this name'} />}
          {d?.matrixUrl && <p className="mt-3"><a href={d.matrixUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-[hsl(var(--botanical))] underline">Open in the Identification Matrix <ExternalLink className="h-4 w-4" aria-hidden="true" /></a></p>}
        </Section>

        <Section id="culture" icon={<Sprout className="h-7 w-7" aria-hidden="true" />} title="Culture">
          <OcBlock d={d} k="cultivation" label="cultivation" />
          {profile ? (
            <>
              <p className="mt-3">{profileIsGenus ? `Genus-level guidance from the ${profile.name} profile — species within ${genus} vary.` : `From the ${profile.name} culture profile.`}</p>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">{profile.culture.slice(0, 6).map((c) => <li key={c.label} className="rounded-md border-2 border-[hsl(var(--charcoal))]/20 p-3"><strong>{c.label}:</strong> {c.value}</li>)}</ul>
              <Link to={profilePath(profile.id)} className="mt-4 inline-flex min-h-[52px] items-center rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">Open the full culture profile</Link>
            </>
          ) : !av('cultivation') && <Unknown what="no culture profile for this taxon yet" />}
        </Section>

        <div className="grid gap-6 lg:grid-cols-2">
          <Section id="conservation" icon={<ShieldAlert className="h-7 w-7" aria-hidden="true" />} title="Conservation">
            <OcBlock d={d} k="conservation" label="conservation" />
            {extra?.conservation ? <p className="mt-3"><strong>{extra.conservation.category.replace(/_/g, ' ').toLowerCase()}</strong>{extra.conservation.code ? ` (${extra.conservation.code})` : ''} · {extra.conservation.source}</p> : !av('conservation') && <Unknown what="no assessment returned" />}
          </Section>
          <Section id="literature" icon={<Library className="h-7 w-7" aria-hidden="true" />} title="Literature">
            <OcBlock d={d} k="literature" label="literature" />
            {extra?.literature?.items.length ? (
              <ul className="mt-3 space-y-2">{extra.literature.items.slice(0, 6).map((p, i) => <li key={i}>{p.url ? <a href={p.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">{p.title}</a> : p.title}{p.year ? ` (${p.year})` : ''}{p.source ? ` · ${p.source}` : ''} <span className="text-[1rem]">(GBIF literature index)</span></li>)}</ul>
            ) : !av('literature') && <Unknown what="no indexed papers cite this taxon" />}
            <p className="mt-3"><a href={`https://www.biodiversitylibrary.org/search?searchTerm=${encodeURIComponent(name)}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-[hsl(var(--botanical))] underline">Search the Biodiversity Heritage Library <ExternalLink className="h-4 w-4" aria-hidden="true" /></a></p>
          </Section>
        </div>

        <Section id="status" icon={<ListChecks className="h-7 w-7" aria-hidden="true" />} title="What we know — and what we don't">
          <ul className="grid gap-2 sm:grid-cols-2">
            {facets.map(([f, ok, src]) => (
              <li key={f} className="flex items-start justify-between gap-3 rounded-md border-2 border-[hsl(var(--charcoal))]/20 p-3">
                <span className="font-semibold text-[hsl(var(--charcoal))]">{f}</span>
                <span className="shrink-0 text-right text-[1rem]">{ok ? 'Available' : 'Not available'}<br /><span className="text-[0.95rem]">{src}</span></span>
              </li>
            ))}
          </ul>
          {t?.gbifUrl && <p className="mt-3"><a href={t.gbifUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--botanical))] underline">Full taxonomy and every record (GBIF)</a></p>}
        </Section>

        <Section id="evidence" icon={<Users className="h-7 w-7" aria-hidden="true" />} title="Evidence & community review">
          <ClaimReview claims={claims} taxonKey={mapKey} taxonName={name} />
        </Section>
      </div>
    </div>
  );
};

export default SpeciesDossierPage;
