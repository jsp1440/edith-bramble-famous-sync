import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { PlayCircle } from 'lucide-react';
import { notebook, getScienceConcept, getChronicle } from '@/lib/content';
import { Kicker, PendingTag } from '@/components/site/Ornaments';

const NotebookPage: React.FC = () => {
  const [category, setCategory] = useState('all');
  const entries = useMemo(
    () => (category === 'all' ? notebook.entries : notebook.entries.filter((e) => e.category === category)),
    [category],
  );

  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <Kicker>{notebook.kicker}</Kicker>
      <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
        {notebook.title}
      </h1>
      {notebook.intro.map((p, i) => (
        <p key={i} className="mt-4 max-w-3xl text-[1rem] leading-relaxed text-[hsl(var(--ink))]">
          {p}
        </p>
      ))}

      <div className="mt-9 flex flex-wrap gap-2" role="group" aria-label="Filter by category">
        <button
          type="button"
          onClick={() => setCategory('all')}
          className={`rounded-sm border px-3 py-2 font-label text-[0.55rem] uppercase ${
            category === 'all'
              ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
              : 'border-border bg-background text-[hsl(var(--ink))]'
          }`}
        >
          All
        </button>
        {notebook.categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setCategory(c.id)}
            className={`rounded-sm border px-3 py-2 font-label text-[0.55rem] uppercase ${
              category === c.id
                ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                : 'border-border bg-background text-[hsl(var(--ink))]'
            }`}
          >
            {c.title}
          </button>
        ))}
      </div>

      <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {entries.map((entry) => {
          const cat = notebook.categories.find((c) => c.id === entry.category);
          const science = getScienceConcept(entry.science);
          const chronicle = getChronicle(entry.chronicle || undefined);
          return (
            <li key={entry.id} className="flex flex-col rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-5">
              <Kicker className="!text-[0.52rem]">{cat?.title}</Kicker>
              <h2 className="mt-2 font-display text-xl font-semibold leading-snug text-[hsl(var(--charcoal))]">
                {entry.title}
              </h2>
              <p className="mt-1 text-sm text-[hsl(var(--moss))]">{entry.topic}</p>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">{entry.description}</p>

              <dl className="mt-4 space-y-1 text-xs text-muted-foreground">
                <div className="flex gap-2">
                  <dt className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">Speaker</dt>
                  <dd>{entry.speaker || 'Pending'}</dd>
                </div>
                {entry.season && (
                  <div className="flex gap-2">
                    <dt className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">Season</dt>
                    <dd>{entry.season}</dd>
                  </div>
                )}
                <div className="flex gap-2">
                  <dt className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">Genera</dt>
                  <dd>{entry.genera.length ? entry.genera.join(', ') : 'Pending'}</dd>
                </div>
              </dl>

              <div className="mt-4 flex flex-wrap gap-2">
                {entry.videoUrl ? (
                  <a
                    href={entry.videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-sm bg-[hsl(var(--botanical))] px-3 py-2 font-label text-[0.52rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
                  >
                    <PlayCircle className="h-3.5 w-3.5" aria-hidden="true" />
                    Watch video
                  </a>
                ) : (
                  <span className="inline-flex items-center">
                    <PendingTag label="Video pending" />
                  </span>
                )}
                {science && (
                  <Link
                    to={`/science/${science.id}`}
                    className="rounded-sm border border-border px-3 py-2 font-label text-[0.52rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
                  >
                    Related science
                  </Link>
                )}
                {chronicle && chronicle.status === 'live' && (
                  <Link
                    to={`/chronicle/${chronicle.slug}`}
                    className="rounded-sm border border-border px-3 py-2 font-label text-[0.52rem] uppercase text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/8"
                  >
                    Related Chronicle
                  </Link>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default NotebookPage;
