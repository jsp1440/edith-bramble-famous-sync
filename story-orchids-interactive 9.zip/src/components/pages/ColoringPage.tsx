import React from 'react';
import { getModule, getMedia } from '@/lib/content';
import type { ColoringLevel } from '@/lib/content-types';
import { Flourish, Kicker, PendingTag, SectionHeading } from '@/components/site/Ornaments';
import PrintButton from '@/components/site/PrintButton';

const ColoringPage: React.FC = () => {
  const content = getModule('coloring');
  const levels = (content?.levels || []) as ColoringLevel[];

  return (
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
      <SectionHeading
        kicker={content?.kicker}
        title={content?.title || 'Coloring Studio'}
        subtitle={content?.subtitle}
        align="center"
      />
      {content?.intro && (
        <div className="mx-auto mt-6 max-w-2xl space-y-3 text-center">
          {content.intro.map((p, i) => (
            <p key={i} className="text-[0.98rem] leading-relaxed text-muted-foreground">
              {p}
            </p>
          ))}
        </div>
      )}

      {levels.map((level) => (
        <section key={level.id} id={level.id} className="mt-16 scroll-mt-24">
          <Flourish className="mb-10" />
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <Kicker>Level</Kicker>
              <h2 className="mt-1 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">{level.title}</h2>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">{level.description}</p>
            </div>
          </div>

          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {level.sheets.map((sheet) => {
              const asset = getMedia(sheet.image);
              return (
                <article
                  key={sheet.id}
                  className="print-sheet flex flex-col overflow-hidden rounded-sm border border-border/80 bg-white"
                >
                  {asset ? (
                    <img
                      src={asset.src}
                      alt={asset.alt}
                      loading="lazy"
                      className="aspect-[3/4] w-full bg-white object-contain"
                    />
                  ) : (
                    <div className="flex aspect-[3/4] w-full items-center justify-center border-b border-dashed border-border bg-muted/30">
                      <PendingTag label="Sheet pending" />
                    </div>
                  )}
                  <div className="flex flex-1 flex-col border-t border-border/70 p-4">
                    <h3 className="font-display text-lg font-semibold text-[hsl(var(--charcoal))]">{sheet.title}</h3>
                    {sheet.note && <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{sheet.note}</p>}
                    {sheet.fact && (
                      <p className="mt-3 rounded-sm bg-[hsl(var(--botanical))]/8 p-3 text-xs leading-relaxed text-[hsl(var(--ink))]">
                        <span className="font-label text-[0.5rem] uppercase text-[hsl(var(--botanical))]">Fact</span>
                        <br />
                        {sheet.fact}
                      </p>
                    )}
                    {asset && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        <PrintButton label="Print" />
                        <PrintButton
                          label="Download"
                          downloadHref={asset.src}
                          downloadName={`${sheet.id}.jpg`}
                        />
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      ))}

      <p className="mt-16 text-center text-xs text-muted-foreground">
        All sheets print black-and-white on A4 or US Letter. Add a sheet by appending it to{' '}
        <code className="font-ui">/src/content/modules/coloring.json</code>.
      </p>
    </div>
  );
};

export default ColoringPage;
