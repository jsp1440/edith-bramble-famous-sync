import React from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Scale, Warehouse, ShieldQuestion, MessageSquarePlus } from 'lucide-react';
import { getMedia } from '@/lib/content';
import { CLIMATE_AXES, LIBRARY_PATH, getProfile, listProfiles, profilePath } from '@/lib/orchid-continuum';
import { profileStatus, aosSheetsFor } from '@/lib/evidence';
import CultureProfileTabs, { ReportCta } from '@/components/library/CultureProfileTabs';
import { ReviewBadge, OcPendingPanel } from '@/components/evidence/EvidenceUI';
import type { OrchidProfile } from '@/lib/orchid-types';

const Hero: React.FC<{ kicker: string; title: string; sub: string; children?: React.ReactNode }> = ({ kicker, title, sub, children }) => (
  <header className="bg-[hsl(var(--botanical))]">
    <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6 sm:py-20">
      <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(44_60%_85%)]">{kicker}</p>
      <h1 className="mt-3 max-w-3xl font-display text-4xl font-semibold leading-tight text-[hsl(44_50%_97%)] sm:text-6xl">{title}</h1>
      <p className="mt-4 max-w-3xl text-[1.3125rem] leading-relaxed text-[hsl(44_45%_93%)]">{sub}</p>
      {children}
    </div>
  </header>
);

/* ---------------- Comparison mode ---------------- */

const ComparePage: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const all = listProfiles();
  const a = getProfile(params.get('a')) ?? all[0];
  const b = getProfile(params.get('b')) ?? all[1];
  const set = (k: 'a' | 'b', v: string) => {
    const n = new URLSearchParams(params);
    n.set(k, v);
    setParams(n, { replace: true });
  };
  const Col: React.FC<{ p: OrchidProfile }> = ({ p }) => (
    <div className="space-y-4">
      <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</h2>
      <p className="text-[1.1875rem] text-[hsl(var(--ink))]">{p.origin.summary}</p>
      <div className="rounded-md border-2 border-border bg-white/60 p-4">
        <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--botanical))]">Seasonal cycle</p>
        <ul className="mt-2 space-y-2 text-[1.0625rem] text-[hsl(var(--ink))]">
          {p.seasonal.map((s) => (
            <li key={s.phase}><strong>{s.phase}</strong> ({s.when}): {s.note}</li>
          ))}
        </ul>
      </div>
      <div className="rounded-md border-2 border-border bg-white/60 p-4">
        <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--botanical))]">Observable plant signals</p>
        <ul className="mt-2 list-disc space-y-1 pl-5 text-[1.0625rem] text-[hsl(var(--ink))]">
          {p.growerSees.map((g) => <li key={g}>{g}</li>)}
        </ul>
      </div>
      <Link to={profilePath(p.id)} className="inline-flex min-h-[48px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">
        Open full profile <ArrowRight className="h-5 w-5" aria-hidden="true" />
      </Link>
    </div>
  );
  return (
    <div>
      <Hero kicker="Comparison mode" title="Why one recipe cannot fit every orchid" sub="Choose two orchids and compare geography, seasonality, temperature strategy, dormancy, water strategy and what the plant shows you." />
      <div className="mx-auto max-w-6xl space-y-8 px-4 py-12 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2">
          {(['a', 'b'] as const).map((k) => (
            <label key={k} className="block">
              <span className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">Orchid {k.toUpperCase()}</span>
              <select value={(k === 'a' ? a : b).id} onChange={(e) => set(k, e.target.value)} className="mt-1 block min-h-[52px] w-full rounded-md border-2 border-border bg-white px-3 text-[1.125rem] text-[hsl(var(--ink))]">
                {all.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </label>
          ))}
        </div>
        <section className="rounded-md border-2 border-border bg-white/60 p-5 sm:p-6">
          <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">Strategy at a glance</h2>
          <p className="mt-1 text-[1.0625rem] text-[hsl(var(--ink))]">
            These 1–5 positions are FCOS draft interpretations for teaching, not measured climate data. Evidence pending.
          </p>
          <div className="mt-4 space-y-5">
            {CLIMATE_AXES.map((ax) => (
              <div key={ax.key}>
                <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">{ax.label}</p>
                {[a, b].map((p, i) => (
                  <div key={p.id + i} className="mt-2 grid grid-cols-[8rem_1fr] items-center gap-3 sm:grid-cols-[14rem_1fr]">
                    <span className="truncate text-[1rem] text-[hsl(var(--ink))]">{p.name}</span>
                    <div className="relative h-4 rounded-full bg-[hsl(var(--muted))]">
                      <div className={`absolute inset-y-0 left-0 rounded-full ${i ? 'bg-[hsl(30_55%_35%)]' : 'bg-[hsl(var(--botanical))]'}`} style={{ width: `${(p.climate[ax.key] / 5) * 100}%` }} />
                    </div>
                  </div>
                ))}
                <div className="mt-1 flex justify-between text-[1rem] text-[hsl(var(--ink))] sm:pl-[14.75rem]"><span>{ax.low}</span><span>{ax.high}</span></div>
              </div>
            ))}
          </div>
        </section>
        <OcPendingPanel what="Elevation and occurrence comparisons" />
        <div className="grid gap-10 lg:grid-cols-2">
          <Col p={a} />
          <Col p={b} />
        </div>
      </div>
    </div>
  );
};

/* ---------------- Library ---------------- */

const CultureLibraryPage: React.FC = () => {
  const { profileId } = useParams();
  if (profileId === 'compare') return <ComparePage />;
  const profile = getProfile(profileId);

  if (profileId && !profile) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-28 text-center">
        <h1 className="font-display text-4xl text-[hsl(var(--charcoal))]">No profile on this bench yet</h1>
        <Link to={LIBRARY_PATH} className="mt-6 inline-block text-[1.125rem] font-semibold text-[hsl(var(--botanical))] underline">All culture profiles</Link>
      </div>
    );
  }

  if (profile) {
    const img = getMedia(profile.image);
    return (
      <article className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
        <Link to={LIBRARY_PATH} className="inline-flex min-h-[44px] items-center gap-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline-offset-4 hover:underline">
          <ArrowLeft className="h-5 w-5" aria-hidden="true" /> Orchid Culture Library
        </Link>
        <header className="mt-6 grid gap-6 sm:grid-cols-[1fr_13rem] sm:items-end">
          <div>
            <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(var(--botanical))]">Culture profile · {profile.rank}</p>
            <h1 className="mt-2 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">{profile.name}</h1>
          </div>
          {img && (
            <figure>
              <img src={img.src} alt={img.alt} className="aspect-square w-full rounded-md border-2 border-border object-cover" />
              <figcaption className="mt-1.5 text-[1rem] font-semibold text-[hsl(var(--ink))]">Story illustration — AI generated. Not a scientific photograph.</figcaption>
            </figure>
          )}
        </header>
        <div className="mt-8">
          <CultureProfileTabs profile={profile} />
        </div>
      </article>
    );
  }

  return (
    <div>
      <Hero
        kicker="Five Cities Orchid Society · Orchid Continuum"
        title="Orchid Culture Library"
        sub="Evidence-linked orchid culture, ecology and seasonal growing guidance from the Five Cities Orchid Society and Orchid Continuum."
      >
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/culture-library/compare?a=dendrobium-nobile&b=dendrobium-phalaenanthe" className="inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(44_60%_94%)] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(var(--botanical))]">
            <Scale className="h-5 w-5" aria-hidden="true" /> Compare orchids
          </Link>
          <Link to="/greenhouse" className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(44_50%_90%)] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(44_50%_97%)]">
            <Warehouse className="h-5 w-5" aria-hidden="true" /> Explore Edith's greenhouse
          </Link>
          <Link to="/expert-review" className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(44_50%_90%)] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(44_50%_97%)]">
            <MessageSquarePlus className="h-5 w-5" aria-hidden="true" /> Expert review
          </Link>
          <Link to="/how-we-handle-evidence" className="inline-flex min-h-[52px] items-center gap-2 rounded-md border-2 border-[hsl(44_50%_90%)] px-5 font-ui text-[1.125rem] font-semibold text-[hsl(44_50%_97%)]">
            <ShieldQuestion className="h-5 w-5" aria-hidden="true" /> How we handle evidence
          </Link>
        </div>
      </Hero>

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6">
        <div className="mb-8 max-w-3xl rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] p-5 text-[1.1875rem] leading-relaxed text-[hsl(var(--ink))]">
          <strong>Honest status:</strong> every profile below is an FCOS curated draft prepared with AI assistance. None is yet source-checked
          or expert-reviewed. Each statement is marked so you can see what is supported and what still needs evidence.
        </div>
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {listProfiles().map((p) => {
            const img = getMedia(p.image);
            const st = profileStatus(p);
            return (
              <li key={p.id}>
                <Link to={profilePath(p.id)} className="group flex h-full flex-col overflow-hidden rounded-md border-2 border-border bg-[hsl(var(--cream))] hover:border-[hsl(var(--botanical))]">
                  {img && <img src={img.src} alt="" aria-hidden="true" loading="lazy" className="aspect-[4/3] w-full object-cover" />}
                  <span className="flex flex-1 flex-col gap-2 p-5">
                    <span className="flex flex-wrap items-center gap-2">
                      <ReviewBadge state={st.state} />
                      {aosSheetsFor(p.id).length > 0 && <span className="rounded-md border-2 border-[hsl(var(--botanical))] px-2 py-0.5 font-ui text-[1rem] font-semibold text-[hsl(var(--botanical))]">AOS sheet linked</span>}
                    </span>
                    <span className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">{p.name}</span>
                    <span className="text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">{p.hook}</span>
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
        <div className="mt-14">
          <ReportCta />
        </div>
      </div>
    </div>
  );
};

export default CultureLibraryPage;
