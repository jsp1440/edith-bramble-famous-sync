import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { site, getMedia } from '@/lib/content';
import { Kicker } from '@/components/site/Ornaments';

const FcosPage: React.FC = () => {
  const charm = getMedia('scene-charm-on-door');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [sms, setSms] = useState(true);
  const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [error, setError] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setState('sending');
    try {
      const res = await fetch('https://famous.ai/api/crm/6a86b1e2a25ecaf758848148/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          name: name.trim() || undefined,
          phone: phone.trim() || undefined,
          sms_opt_in: sms === true,
          source: 'join',
          tags: ['fcos-interest', 'edith-bramble-chronicles', 'newsletter'],
        }),
      });
      if (!res.ok) throw new Error('failed');
      setState('done');
    } catch {
      setState('error');
      setError('Something went wrong. Please try again in a moment.');
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
      <div className="grid gap-10 lg:grid-cols-[1fr_minmax(0,22rem)] lg:items-start">
        <div>
          <Kicker>The community behind the Chronicles</Kicker>
          <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
            {site.fcos.name}
          </h1>
          <p className="mt-4 font-display text-2xl italic text-[hsl(var(--botanical))]">Come Grow With Us!</p>
          {site.fcos.about.map((p) => (
            <p key={p} className="mt-4 max-w-prose text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
              {p}
            </p>
          ))}
          <p className="mt-4 max-w-prose text-[1.02rem] leading-relaxed text-[hsl(var(--ink))]">
            In both Chronicles the greenhouse is saved the same way: a group of growers who each know something, pooling
            it, and paying attention. That part is not fiction.
          </p>
          <p className="mt-4 text-sm text-muted-foreground">{site.fcos.membershipNote}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/about" className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
              About this project
            </Link>
            <Link to="/notebook" className="rounded-sm border border-border px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--ink))]">
              The Grower's Notebook
            </Link>
          </div>
        </div>
        {charm && <img src={charm.src} alt={charm.alt} className="w-full rounded-sm border border-border/70 object-cover" />}
      </div>

      <section className="mt-14 rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6 sm:p-8">
        <h2 className="font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Hear about meetings and new Chronicles</h2>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">
          Leave your email and the Society will let you know about meetings, plant sales and the next Chronicle.
        </p>
        {state === 'done' ? (
          <p className="mt-6 inline-flex items-center gap-2 text-[hsl(var(--botanical))]" role="status">
            <CheckCircle2 className="h-5 w-5" aria-hidden="true" /> Thank you. No grower is ever alone.
          </p>
        ) : (
          <form onSubmit={submit} className="mt-6 grid gap-4 sm:grid-cols-2" noValidate>
            <label className="text-sm">
              <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Name (optional)</span>
              <input value={name} onChange={(e) => setName(e.target.value)} className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2.5" />
            </label>
            <label className="text-sm">
              <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Email</span>
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2.5" />
            </label>
            <label className="text-sm">
              <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Phone number (optional)</span>
              <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className="mt-1 w-full rounded-sm border border-border bg-background px-3 py-2.5" />
            </label>
            <label className="flex items-start gap-2 self-end text-xs leading-relaxed text-[hsl(var(--ink))]">
              <input type="checkbox" checked={sms} onChange={(e) => setSms(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[hsl(var(--botanical))]" />
              Text me updates. Msg &amp; data rates may apply. Reply STOP to unsubscribe.
            </label>
            {error && <p className="text-sm text-[hsl(var(--burgundy))] sm:col-span-2" role="alert">{error}</p>}
            <button
              type="submit"
              disabled={state === 'sending'}
              className="inline-flex items-center justify-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-6 py-3 font-label text-[0.6rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))] disabled:opacity-60 sm:col-span-2 sm:justify-self-start"
            >
              {state === 'sending' && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Keep me posted
            </button>
          </form>
        )}
      </section>
    </div>
  );
};

export default FcosPage;
