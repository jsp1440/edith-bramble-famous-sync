import React, { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, Filter } from 'lucide-react';
import { listProfiles, getProfile, LIBRARY_PATH } from '@/lib/orchid-continuum';
import { CROSS_CUTTING, EVIDENCE_CLASS_LABEL, PROFILE_SPECIALTIES, REVIEW_STATE_LABEL, SECTION_LABEL, SPECIALTIES, claimsFor } from '@/lib/evidence';
import type { Claim } from '@/lib/evidence-types';
import SubmissionForm from '@/components/evidence/SubmissionForm';
import { ClassBadge, ReviewBadge } from '@/components/evidence/EvidenceUI';

const allClaims = () => listProfiles().flatMap((p) => claimsFor(p));
const findClaim = (id: string | null) => (id ? allClaims().find((c) => c.id === id) : undefined);

const Banner: React.FC<{ kicker: string; title: string; children?: React.ReactNode }> = ({ kicker, title, children }) => (
  <header className="bg-[hsl(var(--botanical))]">
    <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 sm:py-16">
      <p className="font-ui text-[1.0625rem] font-bold uppercase tracking-wide text-[hsl(44_60%_85%)]">{kicker}</p>
      <h1 className="mt-3 font-display text-4xl font-semibold leading-tight text-[hsl(44_50%_97%)] sm:text-5xl">{title}</h1>
      {children && <div className="mt-4 max-w-3xl text-[1.3125rem] leading-relaxed text-[hsl(44_45%_93%)]">{children}</div>}
    </div>
  </header>
);

/* ---------------- How we handle evidence ---------------- */

export const HowWeHandleEvidencePage: React.FC = () => (
  <div>
    <Banner kicker="Orchid Culture Library" title="How we handle evidence" />
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-12 text-[1.3125rem] leading-[1.7] text-[hsl(var(--ink))] sm:px-6">
      <p>The FCOS Orchid Culture Library and Orchid Continuum are living scientific and horticultural resources.</p>
      <p>Our goal is not to pretend that every question about orchid biology or culture has a single settled answer.</p>
      <p>Where possible, factual claims are linked to their original sources.</p>
      <p>
        Published research, botanical databases, horticultural guidance, field observations, experienced-grower observations and Orchid
        Continuum interpretations are identified separately.
      </p>
      <p>When evidence is incomplete or experts disagree, we aim to show that uncertainty rather than hide it.</p>
      <p>If you find an error, stronger evidence, or an important qualification, we invite you to submit it for review.</p>

      <section className="rounded-md border-2 border-border bg-white/60 p-6">
        <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">The kinds of evidence we keep apart</h2>
        <ul className="mt-4 space-y-3">
          {(Object.keys(EVIDENCE_CLASS_LABEL) as (keyof typeof EVIDENCE_CLASS_LABEL)[]).map((k) => (
            <li key={k}>
              <ClassBadge cls={k} />
              <p className="mt-1 text-[1.125rem]">{EVIDENCE_CLASS_LABEL[k].note}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="rounded-md border-2 border-border bg-white/60 p-6">
        <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">Review states</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {(Object.keys(REVIEW_STATE_LABEL) as (keyof typeof REVIEW_STATE_LABEL)[]).map((s) => <ReviewBadge key={s} state={s} />)}
        </div>
        <p className="mt-3 text-[1.125rem]">
          A statement is <strong>source-checked</strong> only when a person has attached and read its source. It is <strong>expert-reviewed</strong> only
          when accepted specialist reviews exist. The software never promotes a statement on its own.
        </p>
      </section>

      <section className="rounded-md border-2 border-border bg-white/60 p-6">
        <h2 className="font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">AI, images and maps</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-[1.125rem]">
          <li>The current profile drafts were written with AI assistance. That is recorded, and AI output is never treated as evidence.</li>
          <li>Anything produced by Orchid Continuum reasoning is labelled <em>Orchid Continuum inference</em> until evidence supports it.</li>
          <li>No provenance, no scientific photograph. Story artwork is labelled <em>Story illustration — AI generated</em>.</li>
          <li>Occurrence points are not ranges, and sensitive localities are generalised or withheld for conservation.</li>
          <li>We never invent citations, DOIs, links, occurrences, reviewers or review counts. A blank marked <strong>Evidence pending</strong> is the honest answer.</li>
        </ul>
      </section>

      <aside className="rounded-md bg-[hsl(var(--botanical))] p-6 text-[hsl(44_50%_95%)]">
        <p className="font-display text-2xl font-semibold">See something we should check?</p>
        <Link to="/report-evidence" className="mt-4 inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(44_60%_94%)] px-6 font-ui text-[1.125rem] font-semibold text-[hsl(var(--botanical))]">
          Report an error or add evidence <ArrowRight className="h-5 w-5" aria-hidden="true" />
        </Link>
      </aside>
    </div>
  </div>
);

/* ---------------- Report an error / add evidence ---------------- */

export const ReportEvidencePage: React.FC = () => {
  const [params] = useSearchParams();
  const claim = findClaim(params.get('claim'));
  return (
    <div>
      <Banner kicker="Help us improve" title="Report an error or add evidence">
        Orchid knowledge continues to develop. If you find something that appears inaccurate, overly broad, outdated, or unsupported, please
        help us improve this resource.
      </Banner>
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <SubmissionForm mode="report" claim={claim} profileId={params.get('profile') ?? undefined} />
      </div>
    </div>
  );
};

/* ---------------- Expert review ---------------- */

const matchesSpecialty = (c: Claim, s: string) =>
  (PROFILE_SPECIALTIES[c.profileId] ?? []).includes(s) || (CROSS_CUTTING[s] ?? []).includes(c.section);

export const ExpertReviewPage: React.FC = () => {
  const [params, setParams] = useSearchParams();
  const selected = findClaim(params.get('claim'));
  const [specialty, setSpecialty] = useState<string>(params.get('specialty') ?? '');
  const [profileId, setProfileId] = useState<string>(params.get('profile') ?? '');

  const claims = useMemo(
    () => allClaims().filter((c) => (!specialty || matchesSpecialty(c, specialty)) && (!profileId || c.profileId === profileId)),
    [specialty, profileId],
  );

  const pick = (id: string | null) => {
    const n = new URLSearchParams(params);
    if (id) n.set('claim', id);
    else n.delete('claim');
    setParams(n);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (selected) {
    const p = getProfile(selected.profileId);
    return (
      <div>
        <Banner kicker="Expert review" title="Review a specific claim" />
        <div className="mx-auto max-w-3xl space-y-6 px-4 py-12 sm:px-6">
          <button type="button" onClick={() => pick(null)} className="min-h-[48px] font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline">
            ← Back to claim list
          </button>
          <section className="rounded-md border-2 border-[hsl(var(--botanical))] bg-white/60 p-6">
            <p className="font-ui text-[1.0625rem] font-bold text-[hsl(var(--botanical))]">{p?.name} · {SECTION_LABEL[selected.section]}</p>
            <p className="mt-2 font-display text-[1.5rem] italic leading-relaxed text-[hsl(var(--charcoal))]">“{selected.text}”</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <ClassBadge cls={selected.evidenceClass} />
              <ReviewBadge state={selected.reviewState} />
            </div>
            <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
              Your review is added alongside this claim. It never overwrites it — disagreement is preserved as information.
            </p>
          </section>
          <SubmissionForm mode="review" claim={selected} />
        </div>
      </div>
    );
  }

  return (
    <div>
      <Banner kicker="Orchid Culture Library" title="Expert review">
        Review individual statements, not whole articles. Choose your specialty to see only the claims that fall within it.
      </Banner>
      <div className="mx-auto max-w-5xl space-y-8 px-4 py-12 sm:px-6">
        <div className="rounded-md border-2 border-border bg-white/60 p-5">
          <p className="flex items-center gap-2 font-ui text-[1.125rem] font-bold text-[hsl(var(--charcoal))]">
            <Filter className="h-5 w-5" aria-hidden="true" /> Review claims in my specialty
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" onClick={() => setSpecialty('')} aria-pressed={!specialty} className={`min-h-[44px] rounded-md border-2 px-3 text-[1rem] font-semibold ${!specialty ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border text-[hsl(var(--ink))]'}`}>
              All
            </button>
            {SPECIALTIES.map((s) => (
              <button key={s} type="button" onClick={() => setSpecialty(s)} aria-pressed={specialty === s} className={`min-h-[44px] rounded-md border-2 px-3 text-[1rem] font-semibold ${specialty === s ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border text-[hsl(var(--ink))]'}`}>
                {s}
              </button>
            ))}
          </div>
          <label className="mt-4 block max-w-md">
            <span className="font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]">Profile</span>
            <select value={profileId} onChange={(e) => setProfileId(e.target.value)} className="mt-1 block min-h-[52px] w-full rounded-md border-2 border-border bg-white px-3 text-[1.125rem]">
              <option value="">All profiles</option>
              {listProfiles().map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </label>
        </div>

        <p className="text-[1.1875rem] text-[hsl(var(--ink))]"><strong>{claims.length}</strong> claims match. Every one is currently a draft awaiting evidence.</p>
        {claims.length === 0 && (
          <p className="rounded-md border-2 border-dashed border-border p-5 text-[1.125rem]">No profile in the library covers this specialty yet.</p>
        )}
        <ul className="space-y-3">
          {claims.map((c) => (
            <li key={c.id} className="flex flex-col gap-3 rounded-md border-2 border-border bg-white/60 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="font-ui text-[1rem] font-bold text-[hsl(var(--botanical))]">{getProfile(c.profileId)?.name} · {SECTION_LABEL[c.section]}</p>
                <p className="mt-1 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">{c.text}</p>
              </div>
              <button type="button" onClick={() => pick(c.id)} className="inline-flex min-h-[48px] shrink-0 items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">
                Review <ArrowRight className="h-5 w-5" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>
        <Link to={LIBRARY_PATH} className="inline-block text-[1.125rem] font-semibold text-[hsl(var(--botanical))] underline">Back to the Orchid Culture Library</Link>
      </div>
    </div>
  );
};
