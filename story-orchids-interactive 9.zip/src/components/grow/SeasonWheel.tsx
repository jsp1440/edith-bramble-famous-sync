import React, { useState } from 'react';

const seasons = ['Spring', 'Summer', 'Autumn', 'Winter'] as const;
type Season = (typeof seasons)[number];

const groups: { name: string; notes: Record<Season, string> }[] = [
  {
    name: 'Catasetum (Catasetinae)',
    notes: {
      Spring: 'New growth starts; water once its own roots are a few inches long.',
      Summer: 'Heavy drinker and feeder while the pseudobulb swells.',
      Autumn: 'Leaves yellow and fall as growth matures — reduce water.',
      Winter: 'Leafless, dry rest. It is not dead.',
    },
  },
  {
    name: 'Phragmipedium',
    notes: {
      Spring: 'Consistent moisture, bright shade.',
      Summer: 'Consistent moisture; watch heat and water quality.',
      Autumn: 'Still consistent moisture — no Catasetum-style rest.',
      Winter: 'Moist, never stagnant; roots still need oxygen.',
    },
  },
  {
    name: 'Nobile-type Dendrobium',
    notes: {
      Spring: 'New canes begin; regular water and light feeding.',
      Summer: 'Active growth; bright light.',
      Autumn: 'Canes mature — less nitrogen, less water, cooler nights.',
      Winter: 'Cool and drier; buds form along the nodes in many plants.',
    },
  },
  {
    name: 'Cymbidium',
    notes: {
      Spring: 'Flowering ends; repot if needed.',
      Summer: 'Growth outdoors in coastal conditions.',
      Autumn: 'Cooling nights can help spike initiation — watch the base.',
      Winter: 'Spikes develop; protect from frost.',
    },
  },
];

const SeasonWheel: React.FC = () => {
  const [season, setSeason] = useState<Season>('Autumn');
  return (
    <div className="rounded-sm border border-border/80 bg-[hsl(var(--cream))] p-6">
      <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))]">Season Wheel · general tendencies</p>
      <h3 className="mt-1 font-display text-2xl font-semibold text-[hsl(var(--charcoal))]">Same greenhouse, different years</h3>
      <div className="mt-4 grid grid-cols-4 gap-1.5" role="tablist" aria-label="Season">
        {seasons.map((s) => (
          <button
            key={s}
            type="button"
            role="tab"
            aria-selected={season === s}
            onClick={() => setSeason(s)}
            className={`rounded-sm px-2 py-2.5 font-label text-[0.55rem] uppercase ${
              season === s ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border border-border text-[hsl(var(--ink))]'
            }`}
          >
            {s}
          </button>
        ))}
      </div>
      <ul className="mt-4 space-y-3" aria-live="polite">
        {groups.map((g) => (
          <li key={g.name} className="rounded-sm border border-border/70 bg-background p-3">
            <p className="font-display text-lg font-semibold text-[hsl(var(--charcoal))]">{g.name}</p>
            <p className="mt-0.5 text-sm leading-relaxed text-[hsl(var(--ink))]">{g.notes[season]}</p>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-muted-foreground">Coastal Central California framing. Clone, parentage and microclimate change the details.</p>
    </div>
  );
};

export default SeasonWheel;
