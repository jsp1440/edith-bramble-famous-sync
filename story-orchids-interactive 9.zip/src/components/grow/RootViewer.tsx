import React, { useState } from 'react';
import { Droplets, Sun } from 'lucide-react';

const ROOT_XS = [40, 90, 150, 210, 260];
const rootPath = (x: number, i: number) =>
  `M${x} 24 C ${x + (i % 2 ? 20 : -20)} 60, ${x + (i % 2 ? -10 : 15)} 90, ${x + (i % 2 ? 12 : -8)} 132`;

/** Velamen silver → green when wet. Tap to water / dry. Colour is one clue, never a rule. */
const RootViewer: React.FC = () => {
  const [wet, setWet] = useState(false);
  const fill = wet ? 'hsl(110 35% 42%)' : 'hsl(90 8% 82%)';
  const stroke = wet ? 'hsl(110 35% 30%)' : 'hsl(90 6% 62%)';

  return (
    <div className="rounded-xl border-2 border-[hsl(var(--charcoal))]/30 bg-white p-6 shadow-sm">
      <p className="font-label uppercase text-[hsl(var(--moss))]">Root Viewer · observed biology</p>
      <h3 className="mt-1 font-display text-3xl font-semibold text-[hsl(var(--charcoal))]">Silver roots, green roots</h3>
      <p className="mt-2 text-[1.125rem] text-[hsl(var(--ink))]">Press the button to see how velamen changes when it is wet.</p>

      <svg viewBox="0 0 300 140" className="mt-4 w-full" role="img" aria-label={wet ? 'Wet orchid roots, green' : 'Dry orchid roots, silver'}>
        <rect x="0" y="0" width="300" height="24" fill="hsl(30 30% 40%)" rx="3" />
        {ROOT_XS.map((x, i) => (
          <path key={`o${x}`} d={rootPath(x, i)} fill="none" stroke={stroke} strokeWidth="11" strokeLinecap="round" className="velamen" />
        ))}
        {ROOT_XS.map((x, i) => (
          <path key={`i${x}`} d={rootPath(x, i)} fill="none" stroke={fill} strokeWidth="7" strokeLinecap="round" className="velamen" />
        ))}
      </svg>

      <button
        type="button"
        onClick={() => setWet((w) => !w)}
        aria-pressed={wet}
        className="mt-4 inline-flex min-h-[52px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]"
      >
        {wet ? <Sun className="h-5 w-5" aria-hidden="true" /> : <Droplets className="h-5 w-5" aria-hidden="true" />}
        {wet ? 'Let them dry' : 'Water the roots'}
      </button>
      <p className="mt-2 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]" aria-live="polite">
        Now showing: {wet ? 'wet velamen, translucent, green tissue showing through' : 'dry velamen, silvery-white'}
      </p>

      <p className="mt-3 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
        Many epiphytic orchid roots are wrapped in velamen, a spongy layer of dead cells. Dry, it scatters light and looks silvery-white. Wet, it
        fills with water, turns translucent and the green tissue beneath shows through.
      </p>
      <p className="mt-3 rounded-md border-2 border-[hsl(var(--burgundy))]/50 bg-[hsl(348_40%_97%)] p-4 text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
        <strong>Colour is one clue, not a rule.</strong> A silver root does not mean every orchid needs water now, and a green root does not
        always mean it is wet enough. Genus, potting mix, root health, temperature and growth stage all change the answer. Phragmipediums and
        resting Catasetums, for example, are watered completely differently. Growers combine root colour with pot weight and the plant's season.
      </p>
    </div>
  );
};

export default RootViewer;
