import React, { useEffect, useRef, useState } from 'react';
import { Bookmark, BookmarkCheck, X } from 'lucide-react';

/**
 * Remembers where the reader is in a long, single-page story.
 * - Saves automatically (debounced) and on "Save my place".
 * - On return, offers CONTINUE READING; it never auto-jumps, and never
 *   restarts sound (sound is always opt-in elsewhere).
 */
const ReadingPlace: React.FC<{ storageKey: string; minY?: number }> = ({ storageKey, minY = 900 }) => {
  const [offer, setOffer] = useState<number | null>(null);
  const [saved, setSaved] = useState(false);
  const [show, setShow] = useState(false);
  const t = useRef<number>();

  const write = (y: number) => {
    try {
      localStorage.setItem(storageKey, JSON.stringify({ y, at: Date.now() }));
    } catch {
      /* ignore */
    }
  };

  useEffect(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      const v = raw ? (JSON.parse(raw) as { y: number }) : null;
      if (v && v.y > minY && window.scrollY < 200) setOffer(v.y);
    } catch {
      /* ignore */
    }
    const onScroll = () => {
      setShow(window.scrollY > minY);
      window.clearTimeout(t.current);
      t.current = window.setTimeout(() => {
        if (window.scrollY > minY) write(window.scrollY);
      }, 800);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.clearTimeout(t.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storageKey, minY]);

  const saveNow = () => {
    write(window.scrollY);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  return (
    <>
      {offer !== null && (
        <div role="dialog" aria-label="Continue reading" className="no-print fixed inset-x-0 bottom-5 z-[65] flex justify-center px-4">
          <div className="flex flex-wrap items-center justify-center gap-2 rounded-2xl border-2 border-white/25 bg-[hsl(30_14%_8%)]/95 p-2 pl-4 text-[hsl(42_40%_95%)] shadow-2xl backdrop-blur" style={{ fontSize: 17 }}>
            <span className="font-ui font-semibold">Welcome back</span>
            <button
              type="button"
              onClick={() => {
                window.scrollTo({ top: offer, behavior: 'auto' });
                setOffer(null);
              }}
              className="min-h-[48px] rounded-full bg-[hsl(36_60%_68%)] px-5 font-ui font-bold text-[hsl(30_20%_8%)] hover:bg-[hsl(36_65%_75%)]"
            >
              Continue reading
            </button>
            <button type="button" onClick={() => setOffer(null)} className="inline-flex min-h-[48px] items-center gap-1.5 rounded-full px-4 font-ui font-semibold hover:bg-white/10">
              <X className="h-5 w-5" aria-hidden="true" /> Start at the beginning
            </button>
          </div>
        </div>
      )}
      {show && (
        <button
          type="button"
          onClick={saveNow}
          className="no-print fixed bottom-4 left-4 z-[55] inline-flex min-h-[48px] items-center gap-2 rounded-full border-2 border-white/30 bg-[hsl(30_14%_8%)]/85 px-4 font-ui font-semibold text-[hsl(42_40%_95%)] shadow-lg backdrop-blur hover:bg-[hsl(30_14%_12%)]"
          style={{ fontSize: 17 }}
        >
          {saved ? <BookmarkCheck className="h-5 w-5" aria-hidden="true" /> : <Bookmark className="h-5 w-5" aria-hidden="true" />}
          {saved ? 'Place saved' : 'Save my place'}
        </button>
      )}
    </>
  );
};

export default ReadingPlace;
