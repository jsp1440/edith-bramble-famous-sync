import React from 'react';
import { Printer, Download } from 'lucide-react';

interface PrintButtonProps {
  label?: string;
  onClick?: () => void;
  variant?: 'solid' | 'quiet';
  downloadHref?: string;
  downloadName?: string;
}

const PrintButton: React.FC<PrintButtonProps> = ({
  label = 'Print',
  onClick,
  variant = 'quiet',
  downloadHref,
  downloadName,
}) => {
  const base =
    'no-print inline-flex items-center gap-2 rounded-sm px-3.5 py-2 font-label text-[0.62rem] uppercase transition-colors';
  const styles =
    variant === 'solid'
      ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]'
      : 'border border-border bg-transparent text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10';

  if (downloadHref) {
    return (
      <a
        href={downloadHref}
        download={downloadName}
        target="_blank"
        rel="noopener noreferrer"
        className={`${base} ${styles}`}
      >
        <Download className="h-3.5 w-3.5" aria-hidden="true" />
        {label}
      </a>
    );
  }

  return (
    <button type="button" onClick={onClick ?? (() => window.print())} className={`${base} ${styles}`}>
      <Printer className="h-3.5 w-3.5" aria-hidden="true" />
      {label}
    </button>
  );
};

export default PrintButton;
