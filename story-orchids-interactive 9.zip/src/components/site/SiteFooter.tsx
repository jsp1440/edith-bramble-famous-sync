import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { site } from '@/lib/content';
import { Flourish } from './Ornaments';

const CRM_ENDPOINT = 'https://famous.ai/api/crm/6a86b1e2a25ecaf758848148/subscribe';

const SiteFooter: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [smsOptIn, setSmsOptIn] = useState(true);
  const [status, setStatus] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus('error');
      setMessage('Please enter a valid email address.');
      return;
    }
    setStatus('sending');
    try {
      await fetch(CRM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          name: name || undefined,
          phone: phone || undefined,
          sms_opt_in: smsOptIn === true,
          source: 'footer-signup',
          tags: ['newsletter', 'edith-bramble-chronicles', 'fcos'],
        }),
      });
      setStatus('done');
      setMessage('You are on the list. New Chronicles arrive with the seasons.');
      setName('');
      setEmail('');
      setPhone('');
    } catch {
      setStatus('error');
      setMessage('Something went wrong. Please try again.');
    }
  };

  const groups = [
    { id: 'story', label: 'Story' },
    { id: 'learn', label: 'Learn' },
    { id: 'make', label: 'Make' },
    { id: 'play', label: 'Play' },
  ];

  const linkCls = 'text-[1.125rem] leading-snug text-[hsl(42_45%_95%)] underline-offset-4 hover:underline';

  return (
    <footer className="site-footer eb-panel-green mt-24">
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:px-10">
        <Flourish className="mb-12" />

        <div className="grid gap-14 lg:grid-cols-[1.2fr_2fr]">
          <div>
            <h2 className="font-display text-3xl font-semibold">{site.title}</h2>
            <p className="mt-2 font-body text-lg italic text-[hsl(44_70%_80%)]">{site.subtitle}</p>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-[hsl(42_45%_95%)]">{site.fcos.about[0]}</p>
            <p className="mt-5 font-display text-2xl italic text-[hsl(44_70%_84%)]">“{site.fcos.talisman}”</p>

            <form onSubmit={onSubmit} className="mt-10 max-w-md space-y-4 rounded-lg border border-[hsl(42_30%_90%/0.25)] bg-[hsl(145_36%_12%)] p-5 sm:p-6" aria-label="Join the mailing list">
              <p className="font-display text-2xl font-semibold">Be told when the next Chronicle opens</p>
              <div className="grid gap-4">
                <label className="block">
                  <span className="mb-1 block text-base font-semibold">Your name (optional)</span>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                    className="min-h-[52px] w-full rounded-md border-2 px-4 py-2 text-lg outline-none focus:border-[hsl(44_70%_70%)]"
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-base font-semibold">Email address</span>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                    className="min-h-[52px] w-full rounded-md border-2 px-4 py-2 text-lg outline-none focus:border-[hsl(44_70%_70%)]"
                  />
                </label>
                <label className="block">
                  <span className="mb-1 block text-base font-semibold">Phone number (optional)</span>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    autoComplete="tel"
                    className="min-h-[52px] w-full rounded-md border-2 px-4 py-2 text-lg outline-none focus:border-[hsl(44_70%_70%)]"
                  />
                </label>
              </div>
              <label className="flex items-start gap-3 text-base leading-relaxed text-[hsl(42_45%_95%)]">
                <input
                  type="checkbox"
                  checked={smsOptIn}
                  onChange={(e) => setSmsOptIn(e.target.checked)}
                  className="mt-1 h-6 w-6 shrink-0 rounded-sm accent-[hsl(44_70%_70%)]"
                />
                <span>Text me updates. Msg &amp; data rates may apply. Reply STOP to unsubscribe.</span>
              </label>
              <button
                type="submit"
                disabled={status === 'sending'}
                className="eb-btn-cream min-h-[52px] w-full rounded-md px-6 font-ui text-lg font-semibold transition-colors disabled:opacity-60 sm:w-auto"
              >
                {status === 'sending' ? 'Sending…' : 'Join the Society list'}
              </button>
              {message && (
                <p
                  role="status"
                  className={`rounded-md px-3 py-2 text-lg font-semibold ${status === 'error' ? 'bg-[hsl(348_60%_92%)] text-[hsl(348_60%_22%)]' : 'bg-[hsl(42_55%_95%)] text-[hsl(145_34%_15%)]'}`}
                >
                  {message}
                </p>
              )}
            </form>
          </div>

          <div className="grid gap-10 sm:grid-cols-2 xl:grid-cols-3">
            <nav aria-label="The series">
              <p className="mb-4 font-display text-2xl font-semibold text-[hsl(44_70%_80%)]">The Series</p>
              <ul className="space-y-3">
                {(site.primaryNav || []).map((item) => (
                  <li key={item.to}>
                    <Link to={item.to} className={linkCls}>
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>

            {groups.map((group) => (
              <nav key={group.id} aria-label={group.label}>
                <p className="mb-4 font-display text-2xl font-semibold text-[hsl(44_70%_80%)]">{group.label}</p>
                <ul className="space-y-3">
                  {site.modules
                    .filter((m) => m.group === group.id)
                    .map((m) => (
                      <li key={m.id}>
                        <Link to={m.path} className={linkCls}>
                          {m.title}
                        </Link>
                      </li>
                    ))}
                  {group.id === 'story' && (
                    <li>
                      <Link to="/chronicle/chronicle-i" className={linkCls}>
                        Chronicle I — The Night of the Black Rot
                      </Link>
                    </li>
                  )}
                  {group.id === 'make' && (
                    <li>
                      <Link to="/about" className={linkCls}>
                        About &amp; contributing
                      </Link>
                    </li>
                  )}
                </ul>
              </nav>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-4 border-t border-[hsl(42_30%_90%/0.25)] pt-8 text-base leading-relaxed text-[hsl(42_45%_95%)] sm:flex-row sm:items-start sm:justify-between">
          <p className="max-w-2xl">
            © {new Date().getFullYear()} {site.fcos.name}. Story, illustration and educational material published for
            members and the curious public.
          </p>
          <p className="font-semibold text-[hsl(44_70%_82%)]">Observe, photograph, and sketch wild orchids. Do not collect them.</p>
        </div>
      </div>
    </footer>
  );
};

export default SiteFooter;
