import React, { useEffect, useRef, useState } from 'react';
import { BookOpen, Check, Settings2, X } from 'lucide-react';
import { useReading } from '@/contexts/ReadingContext';
import { TEXT_SIZES, type ReadingPrefs } from '@/lib/reading-prefs';

/* ------------------------------------------------------------------
   Visible reading controls for the site header:
   A−  A  A+   and a "Reading settings" panel.
   Sizes are in px so the header chrome stays predictable at every
   text size; the page content itself reflows with the chosen size.
------------------------------------------------------------------- */

const sizeBtn =
  'eb-ctl inline-flex h-12 min-w-[3rem] items-center justify-center rounded-md border-2 px-2.5 font-ui font-bold leading-none transition-colors disabled:cursor-not-allowed disabled:opacity-40';

export const TextSizeControl: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { prefs, smaller, larger, resetSize } = useReading();
  const idx = TEXT_SIZES.findIndex((s) => s.id === prefs.size);
  const current = TEXT_SIZES[idx] || TEXT_SIZES[1];
  const on = 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]';
  const off = 'border-[hsl(var(--border))] bg-[hsl(var(--cream))] text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10';
  return (
    <div role="group" aria-label="Text size" className={`flex items-center gap-1.5 ${className}`}>
      <span className="hidden font-ui font-semibold text-[hsl(var(--ink))] md:inline" style={{ fontSize: 16 }} aria-hidden="true">
        Text
      </span>
      <button type="button" onClick={smaller} disabled={idx <= 0} aria-label="Make text smaller" title="Smaller text" className={`${sizeBtn} ${off}`} style={{ fontSize: 17 }}>
        A−
      </button>
      <button type="button" onClick={resetSize} aria-pressed={prefs.size === 'standard'} aria-label="Standard text size" title="Standard text size" className={`${sizeBtn} ${prefs.size === 'standard' ? on : off}`} style={{ fontSize: 20 }}>
        A
      </button>
      <button type="button" onClick={larger} disabled={idx >= TEXT_SIZES.length - 1} aria-pressed={idx > 1} aria-label="Make text larger" title="Larger text" className={`${sizeBtn} ${idx > 1 ? on : off}`} style={{ fontSize: 23 }}>
        A+
        {idx > 2 && <span className="ml-0.5" style={{ fontSize: 15 }}>+</span>}
      </button>
      <span className="sr-only" aria-live="polite">
        Text size: {current.label}
      </span>
    </div>
  );
};

/** Large segmented choice (radio group) used inside Reading Settings. */
function Choice<T extends string>({
  legend,
  value,
  options,
  onChange,
  hint,
}: {
  legend: string;
  value: T;
  options: { id: T; label: string }[];
  onChange: (v: T) => void;
  hint?: string;
}) {
  return (
    <fieldset className="mt-5 first:mt-0">
      <legend className="font-ui font-bold text-[hsl(var(--charcoal))]" style={{ fontSize: 18 }}>
        {legend}
      </legend>
      {hint && (
        <p className="mt-0.5 font-ui text-[hsl(var(--ink))]" style={{ fontSize: 16, lineHeight: 1.45 }}>
          {hint}
        </p>
      )}
      <div className="mt-2 flex flex-wrap gap-2">
        {options.map((o) => {
          const sel = o.id === value;
          return (
            <button
              key={o.id}
              type="button"
              role="radio"
              aria-checked={sel}
              onClick={() => onChange(o.id)}
              className={`eb-ctl inline-flex min-h-[48px] items-center gap-2 rounded-md border-2 px-4 font-ui font-semibold ${
                sel
                  ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                  : 'border-[hsl(var(--border))] bg-[hsl(var(--cream))] text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10'
              }`}
              style={{ fontSize: 17 }}
            >
              {sel && <Check className="h-5 w-5" aria-hidden="true" />}
              {o.label}
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

export const ReadingSettings: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { prefs, set } = useReading();
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent | TouchEvent) => {
      if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('touchstart', onDoc);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('touchstart', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const patch = (p: Partial<ReadingPrefs>) => set(p);

  return (
    <div ref={wrap} className={`relative ${className}`}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label="Reading settings"
        title="Reading settings"
        className="eb-ctl inline-flex h-12 items-center gap-2 rounded-md border-2 border-[hsl(var(--border))] bg-[hsl(var(--cream))] px-3 font-ui font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10"
        style={{ fontSize: 17 }}
      >
        <Settings2 className="h-5 w-5" aria-hidden="true" />
        <span className="hidden lg:inline">Reading</span>
      </button>
      {open && (
        <div
          role="dialog"
          aria-label="Reading settings"
          className="eb-settings-panel fixed inset-x-3 top-auto z-[70] mt-2 max-h-[80vh] overflow-y-auto rounded-lg border-2 border-[hsl(var(--botanical))]/40 bg-[hsl(var(--cream))] p-5 shadow-2xl sm:absolute sm:inset-x-auto sm:right-0 sm:top-full sm:w-[26rem] sm:max-w-[calc(100vw-2rem)]"
        >
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <p className="font-display font-semibold text-[hsl(var(--charcoal))]" style={{ fontSize: 26, lineHeight: 1.15 }}>
                Reading settings
              </p>
              <p className="mt-1 font-ui text-[hsl(var(--ink))]" style={{ fontSize: 16, lineHeight: 1.45 }}>
                Saved on this device. No account needed.
              </p>
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close reading settings" className="eb-ctl inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-md border-2 border-[hsl(var(--border))] text-[hsl(var(--ink))]">
              <X className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>

          <Choice legend="Text size" value={prefs.size} onChange={(v) => patch({ size: v })} options={TEXT_SIZES.map((s) => ({ id: s.id, label: s.label }))} />
          <Choice
            legend="Contrast"
            value={prefs.contrast}
            onChange={(v) => patch({ contrast: v })}
            hint="High contrast darkens text and strengthens outlines."
            options={[
              { id: 'standard', label: 'Standard' },
              { id: 'high', label: 'High contrast' },
            ]}
          />
          <Choice
            legend="Motion"
            value={prefs.motion}
            onChange={(v) => patch({ motion: v })}
            hint="Reduced keeps the pictures but stops drifting fog and moving effects."
            options={[
              { id: 'auto', label: 'Automatic' },
              { id: 'full', label: 'Full' },
              { id: 'reduced', label: 'Reduced' },
            ]}
          />
          <Choice
            legend="Sound"
            value={prefs.sound}
            onChange={(v) => patch({ sound: v })}
            hint="Quiet atmosphere in Chronicle I. Always off unless you turn it on."
            options={[
              { id: 'off', label: 'Off' },
              { id: 'on', label: 'On' },
            ]}
          />
          <Choice
            legend="Story reading view"
            value={prefs.readingView ? 'on' : 'off'}
            onChange={(v) => patch({ readingView: v === 'on' })}
            hint="Larger story text, calmer pages, fewer extras. Illustrations stay."
            options={[
              { id: 'off', label: 'Off' },
              { id: 'on', label: 'On' },
            ]}
          />

          <button
            type="button"
            onClick={() => patch({ size: 'standard', contrast: 'standard', motion: 'auto', sound: 'off', readingView: false })}
            className="mt-6 min-h-[48px] font-ui font-semibold text-[hsl(var(--burgundy))] underline underline-offset-4"
            style={{ fontSize: 17 }}
          >
            Reset to the usual settings
          </button>
        </div>
      )}
    </div>
  );
};

/** "Reading view" switch shown on Chronicle I and II. */
export const ReadingViewToggle: React.FC<{ className?: string; floating?: boolean }> = ({ className = '', floating }) => {
  const { prefs, set } = useReading();
  const on = prefs.readingView;
  return (
    <button
      type="button"
      onClick={() => set({ readingView: !on })}
      aria-pressed={on}
      className={`no-print eb-ctl inline-flex min-h-[48px] items-center gap-2 rounded-full border-2 px-4 font-ui font-semibold shadow-lg ${
        on
          ? 'border-[hsl(var(--cream))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
          : floating
            ? 'border-white/30 bg-[hsl(30_14%_8%)]/85 text-[hsl(42_40%_95%)] backdrop-blur hover:bg-[hsl(30_14%_14%)]'
            : 'border-[hsl(var(--border))] bg-[hsl(var(--cream))] text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10'
      } ${floating ? 'fixed bottom-4 right-4 z-[56]' : ''} ${className}`}
      style={{ fontSize: 17 }}
    >
      <BookOpen className="h-5 w-5" aria-hidden="true" />
      {on ? 'Reading view: on' : 'Reading view'}
    </button>
  );
};
