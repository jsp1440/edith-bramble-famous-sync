import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Mail } from 'lucide-react';
import type { ChronicleMeta } from '@/lib/content-types';
import { chroniclePath, getMedia } from '@/lib/content';

/* One card per Chronicle in chronicles.json. Adding Chronicle IV later is
   a data change only. Sealed cards stay fully legible: mystery comes from
   the wax-seal treatment, not from low contrast. */

const ChronicleCard: React.FC<{ c: ChronicleMeta }> = ({ c }) => {
  const live = c.status === 'live';
  const cover = getMedia(c.cover);

  const body = (
    <article
      className={`flex h-full flex-col overflow-hidden rounded-xl border-2 shadow-md transition-transform ${
        live ? 'border-[hsl(var(--botanical))]/70 bg-white group-hover:-translate-y-1' : 'border-[hsl(var(--charcoal))]/70 bg-[hsl(30_14%_14%)]'
      }`}
    >
      <div className="relative aspect-[3/2] overflow-hidden">
        {live && cover ? (
          <img src={cover.src} alt={cover.alt} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_50%_40%,hsl(36_30%_30%),hsl(30_16%_10%))]">
            <div className="flex h-28 w-28 items-center justify-center rounded-full border-4 border-[hsl(348_40%_22%)] bg-[radial-gradient(circle_at_35%_30%,hsl(348_55%_42%),hsl(348_55%_24%))] shadow-[0_6px_18px_rgb(0_0_0/0.5)]">
              <span className="font-display text-4xl font-semibold text-[hsl(42_60%_90%)]">{c.number}</span>
            </div>
          </div>
        )}
        <span
          className={`absolute right-3 top-3 rounded-md px-3 py-1.5 font-ui text-[1rem] font-bold uppercase tracking-wide ${
            live ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'bg-[hsl(42_60%_92%)] text-[hsl(30_18%_10%)]'
          }`}
        >
          {live ? 'Available now' : 'Sealed'}
        </span>
      </div>
      <div className="flex flex-1 flex-col p-6">
        <p className={`font-label uppercase ${live ? 'text-[hsl(var(--moss))]' : 'text-[hsl(44_70%_80%)]'}`}>Chronicle {c.number}</p>
        <h3 className={`mt-1 font-display text-3xl font-semibold leading-tight ${live ? 'text-[hsl(var(--charcoal))]' : 'text-[hsl(42_55%_96%)]'}`}>
          {live ? c.title : 'Sealed'}
        </h3>
        <p className={`mt-3 flex-1 text-[1.1875rem] leading-relaxed ${live ? 'text-[hsl(var(--ink))]' : 'italic text-[hsl(42_45%_93%)]'}`}>
          {c.summary}
        </p>
        {live ? (
          <span className="mt-5 inline-flex min-h-[52px] w-fit items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))]">
            <BookOpen className="h-5 w-5" aria-hidden="true" /> Read Chronicle {c.number}
          </span>
        ) : (
          <span className="mt-5 inline-flex items-center gap-2 font-ui text-[1.0625rem] font-semibold text-[hsl(44_70%_82%)]">
            <Mail className="h-5 w-5" aria-hidden="true" /> Not yet opened
          </span>
        )}
      </div>
    </article>
  );

  return live ? (
    <Link to={chroniclePath(c.slug)} className="group block h-full rounded-xl">
      {body}
    </Link>
  ) : (
    <div className="h-full" aria-label={`Chronicle ${c.number}, sealed`}>
      {body}
    </div>
  );
};

export default ChronicleCard;
