import React from 'react';
import { getMedia } from '@/lib/content';

export const Flourish: React.FC<{ className?: string }> = ({ className = '' }) => (
  <div className={`flex items-center justify-center gap-3 ${className}`} aria-hidden="true">
    <span className="h-px w-16 bg-gradient-to-r from-transparent to-border sm:w-28" />
    <svg width="74" height="20" viewBox="0 0 74 20" fill="none" className="text-[hsl(var(--moss))]">
      <path d="M37 2c-4 4-9 5-14 5 5 1 10 3 14 6 4-3 9-5 14-6-5 0-10-1-14-5Z" stroke="currentColor" strokeWidth="1" />
      <path d="M2 13c8 0 14-2 20-6M72 13c-8 0-14-2-20-6" stroke="currentColor" strokeWidth="1" strokeLinecap="round" />
      <circle cx="37" cy="15" r="2" fill="currentColor" opacity="0.7" />
    </svg>
    <span className="h-px w-16 bg-gradient-to-l from-transparent to-border sm:w-28" />
  </div>
);

/* Section eyebrow. Readable standard: 17px+, deep forest green, semibold. */
export const Kicker: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <p className={`font-label text-[1.0625rem] uppercase text-[hsl(var(--moss))] ${className}`}>{children}</p>
);

export const SectionHeading: React.FC<{
  kicker?: string;
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
}> = ({ kicker, title, subtitle, align = 'left' }) => (
  <div className={align === 'center' ? 'text-center' : ''}>
    {kicker && <Kicker className="mb-3">{kicker}</Kicker>}
    <h2 className="font-display text-4xl font-semibold leading-tight text-[hsl(var(--charcoal))] sm:text-5xl">
      {title}
    </h2>
    {subtitle && (
      <p className={`mt-4 max-w-2xl text-xl leading-relaxed text-[hsl(var(--ink))] ${align === 'center' ? 'mx-auto' : ''}`}>
        {subtitle}
      </p>
    )}
  </div>
);

export const PendingTag: React.FC<{ label?: string }> = ({ label = 'Pending content' }) => (
  <span className="inline-flex items-center gap-2 rounded-full border-2 border-dashed border-[hsl(var(--moss))]/70 bg-[hsl(var(--cream))] px-3 py-1 font-label text-[1.0625rem] uppercase text-[hsl(var(--moss))]">
    <span className="h-2 w-2 rounded-full bg-[hsl(var(--amber))]" aria-hidden="true" />
    {label}
  </span>
);

/* Notices: solid, clearly separated boxes with near-black body text. */
const toneStyles: Record<string, string> = {
  caution: 'border-[hsl(var(--burgundy))] bg-[hsl(348_45%_95%)] text-[hsl(var(--burgundy))]',
  ethics: 'eb-panel-green border-[hsl(44_70%_70%)]',
  fiction: 'border-[hsl(30_60%_40%)] bg-[hsl(40_70%_93%)] text-[hsl(30_50%_20%)]',
  info: 'border-[hsl(var(--botanical))] bg-[hsl(var(--cream))] text-[hsl(var(--botanical))]',
};

export const Notice: React.FC<{ tone?: string; title: string; body: string }> = ({ tone = 'info', title, body }) => (
  <aside className={`rounded-md border-l-[6px] px-6 py-5 ${toneStyles[tone] || toneStyles.info}`} role="note">
    <p className="font-label text-[1.0625rem] uppercase">{title}</p>
    <p className="mt-2 text-lg leading-relaxed text-[hsl(var(--ink))]">{body}</p>
  </aside>
);

export const Figure: React.FC<{
  mediaId?: string | null;
  caption?: string;
  className?: string;
  imgClassName?: string;
  ratio?: string;
}> = ({ mediaId, caption, className = '', imgClassName = '', ratio }) => {
  const asset = getMedia(mediaId);
  if (!asset) {
    return (
      <div className={`flex items-center justify-center rounded-md border-2 border-dashed border-border bg-muted/40 p-8 ${className}`}>
        <PendingTag label="Illustration pending" />
      </div>
    );
  }
  return (
    <figure className={className}>
      <div className={`overflow-hidden rounded-md border border-border/70 bg-muted ${ratio || ''}`}>
        <img
          src={asset.src}
          alt={asset.alt}
          loading="lazy"
          decoding="async"
          className={`h-full w-full object-cover ${imgClassName}`}
        />
      </div>
      {(caption || asset.credit) && (
        <figcaption className="mt-3 border-l-4 border-[hsl(var(--botanical))]/50 pl-3 font-body text-lg italic leading-relaxed text-[hsl(var(--ink))]">
          {caption || asset.credit}
        </figcaption>
      )}
    </figure>
  );
};
