import React, { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, LogIn, ShieldCheck } from 'lucide-react';
import { site } from '@/lib/content';
import { useAuth } from '@/contexts/AuthContext';
import { ReadingSettings, TextSizeControl } from '@/components/site/ReadingControls';

/** Primary destinations. `secondary` items collapse into the menu first
 *  (on narrower screens and at larger text sizes) — they never shrink. */
const PRIMARY: { to: string; label: string; end?: boolean; secondary?: boolean }[] = [
  { to: '/chronicle-1', label: 'Chronicle I' },
  { to: '/chronicle-2', label: 'Chronicle II' },
  { to: '/greenhouse', label: 'Greenhouse' },
  { to: '/grow', label: 'Grow', secondary: true },
  { to: '/diagnostic-bench', label: 'Bench', secondary: true },
  { to: '/culture-library', label: 'Culture Library' },
  { to: '/science', label: 'Science', end: true, secondary: true },
  { to: '/characters', label: 'Characters' },
];

const groups: { id: string; label: string }[] = [
  { id: 'story', label: 'Story' },
  { id: 'learn', label: 'Learn' },
  { id: 'make', label: 'Make' },
  { id: 'play', label: 'Play' },
];

const menuLink =
  'flex min-h-[48px] items-center rounded-md px-3 font-ui text-[1.125rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10';
const menuHeading = 'mb-2 font-ui text-[1rem] font-bold uppercase tracking-wide text-[hsl(var(--moss))]';

const SiteHeader: React.FC = () => {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { user, profile, isEditor, openAuth, signOut } = useAuth();
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  // Publish the sticky header's height so sticky sub-navs sit just below it.
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const publish = () => {
      const sticky = getComputedStyle(el).position === 'sticky';
      document.documentElement.style.setProperty('--eb-header-h', `${sticky ? el.offsetHeight : 0}px`);
    };
    publish();
    const ro = new ResizeObserver(publish);
    ro.observe(el);
    window.addEventListener('resize', publish);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', publish);
    };
  }, []);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `eb-nav-link inline-flex min-h-[48px] items-center rounded-md px-3 font-ui text-[1.0625rem] font-semibold transition-colors ${
      isActive
        ? 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
        : 'text-[hsl(var(--ink))] underline-offset-4 hover:bg-[hsl(var(--botanical))]/10 hover:underline'
    }`;

  return (
    <header ref={ref} className="site-header z-40 border-b-2 border-[hsl(var(--botanical))]/25 bg-[hsl(var(--cream))] md:sticky md:top-0">
      {/* Row 1: identity · reading controls · menu */}
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-x-3 gap-y-2 px-4 py-2.5 sm:px-6 lg:px-8">
        <Link to="/" className="flex min-w-0 items-center gap-3" aria-label={`${site.title} — home`}>
          <svg width="36" height="36" viewBox="0 0 40 40" aria-hidden="true" className="shrink-0 text-[hsl(var(--botanical))]">
            <circle cx="20" cy="20" r="18.5" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M20 9c-3 5-7 7-11 7 4 2 8 5 11 9 3-4 7-7 11-9-4 0-8-2-11-7Z" fill="currentColor" />
            <circle cx="20" cy="29" r="2" fill="hsl(var(--amber))" />
          </svg>
          <span className="min-w-0 leading-none">
            <span className="block font-display font-bold leading-tight tracking-tight text-[hsl(var(--charcoal))]" style={{ fontSize: 'clamp(20px, 1.2vw + 14px, 25px)' }}>
              The Edith Bramble Chronicles
            </span>
            <span className="mt-0.5 hidden font-body italic text-[hsl(var(--moss))] lg:block" style={{ fontSize: 16 }}>
              {site.subtitle} · {site.org}
            </span>
          </span>
        </Link>

        <div className="flex items-center gap-2">
          <TextSizeControl className="hidden sm:flex" />
          <ReadingSettings className="hidden sm:block" />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="site-menu"
            className="eb-ctl inline-flex h-12 items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-4 font-ui font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
            style={{ fontSize: 17 }}
          >
            {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
            <span className="lg:hidden">Menu</span>
            <span className="hidden lg:inline">More</span>
          </button>
        </div>
      </div>

      {/* Phone: reading controls get their own always-visible row */}
      <div className="flex items-center justify-between gap-2 border-t border-border/60 px-4 py-2 sm:hidden">
        <TextSizeControl />
        <ReadingSettings />
      </div>

      {/* Row 2 (large screens): primary navigation. Wraps rather than shrinks. */}
      <nav className="eb-primary-nav hidden border-t border-border/60 lg:block" aria-label="Primary">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-1 px-4 py-1.5 sm:px-6 lg:px-8">
          {PRIMARY.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.end} className={(s) => `${linkClass(s)} ${item.secondary ? 'eb-nav-secondary' : ''}`}>
              {item.label}
            </NavLink>
          ))}
          <NavLink
            to="/fcos"
            className="eb-ctl ml-auto inline-flex min-h-[48px] items-center rounded-md bg-[hsl(var(--botanical))] px-4 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
          >
            Join FCOS
          </NavLink>
          {user ? (
            <NavLink
              to="/admin"
              className="eb-ctl inline-flex min-h-[48px] items-center gap-1.5 rounded-md border-2 border-border px-3 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10"
              title={profile?.email || undefined}
            >
              <ShieldCheck className="h-5 w-5 text-[hsl(var(--botanical))]" aria-hidden="true" />
              {isEditor ? 'Workspace' : 'Account'}
            </NavLink>
          ) : (
            <button
              type="button"
              onClick={openAuth}
              className="eb-ctl inline-flex min-h-[48px] items-center gap-1.5 rounded-md border-2 border-border px-3 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--ink))] hover:bg-[hsl(var(--botanical))]/10"
            >
              <LogIn className="h-5 w-5" aria-hidden="true" />
              Editor sign in
            </button>
          )}
        </div>
      </nav>

      {open && (
        <div id="site-menu" className="max-h-[calc(100vh-var(--eb-header-h,0px))] overflow-y-auto border-t-2 border-border/70 bg-[hsl(var(--cream))]">
          <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
            <p className={menuHeading}>Main sections</p>
            <ul className="grid gap-1 sm:grid-cols-2 lg:grid-cols-4">
              {PRIMARY.map((item) => (
                <li key={item.to}>
                  <NavLink to={item.to} end={item.end} className={({ isActive }) => `${menuLink} ${isActive ? 'bg-[hsl(var(--botanical))] !text-[hsl(var(--cream))]' : ''}`}>
                    {item.label}
                  </NavLink>
                </li>
              ))}
              <li>
                <Link to="/fcos" className={`${menuLink} bg-[hsl(var(--botanical))] !text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]`}>
                  Join FCOS
                </Link>
              </li>
            </ul>

            <div className="mt-7 grid gap-7 sm:grid-cols-2 lg:grid-cols-4">
              {groups.map((group) => {
                const mods = site.modules.filter((m) => m.group === group.id);
                if (!mods.length) return null;
                return (
                  <div key={group.id}>
                    <p className={menuHeading}>{group.label}</p>
                    <ul className="space-y-1">
                      {mods.map((m) => (
                        <li key={m.id}>
                          <Link to={m.path} className={menuLink}>
                            {m.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>

            <div className="mt-7 grid gap-7 border-t border-border/60 pt-6 sm:grid-cols-2">
              <div>
                <p className={menuHeading}>Evidence &amp; sources</p>
                <ul className="space-y-1">
                  <li><Link to="/how-we-handle-evidence" className={menuLink}>How we handle evidence</Link></li>
                  <li><Link to="/expert-review" className={menuLink}>Expert review</Link></li>
                  <li><Link to="/report-evidence" className={menuLink}>Suggest a correction</Link></li>
                </ul>
              </div>
              <div>
                <p className={menuHeading}>Society editors</p>
                {user ? (
                  <div className="flex flex-wrap items-center gap-3">
                    <Link to="/admin" className={`${menuLink} border-2 border-border`}>
                      <ShieldCheck className="mr-2 h-5 w-5 text-[hsl(var(--botanical))]" aria-hidden="true" />
                      {isEditor ? 'Editor workspace' : 'Account'}
                    </Link>
                    <button type="button" onClick={signOut} className={`${menuLink} text-[hsl(var(--burgundy))]`}>
                      Sign out
                    </button>
                    {profile?.email && <span className="font-ui text-[1rem] text-[hsl(var(--ink))]">{profile.email}</span>}
                  </div>
                ) : (
                  <button type="button" onClick={openAuth} className={`${menuLink} border-2 border-border`}>
                    <LogIn className="mr-2 h-5 w-5" aria-hidden="true" />
                    Editor sign in
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default SiteHeader;
