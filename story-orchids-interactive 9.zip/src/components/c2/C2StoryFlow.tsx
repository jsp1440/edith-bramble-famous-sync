import React from 'react';
import type { StoryBlock } from '@/lib/content-types';
import { parseInline } from '@/lib/story-parser';
import { getMedia } from '@/lib/content';
import StoryEffect, { EffectImage } from '@/components/story/StoryEffects';
import { Fog, FrogLeap, Vignette } from '@/components/c1/Atmosphere';
import { useInView, useReducedMotion, useScrollProgress } from '@/components/c1/c1-hooks';

interface Props {
  blocks: StoryBlock[];
  onDiscover: (id: string) => void;
  onGrower?: (id: string) => void;
  onScience?: (id: string) => void;
}

const Inline: React.FC<{ text: string; onDiscover: (id: string) => void; onGrower?: (id: string) => void }> = ({ text, onDiscover, onGrower }) => (
  <>
    {parseInline(text).map((t, i) => {
      if (t.type === 'strong') return <strong key={i}>{t.value}</strong>;
      if (t.type === 'em') return <em key={i}>{t.value}</em>;
      if (t.type === 'grower') {
        const label = t.italic ? <em>{t.value}</em> : t.value;
        if (!onGrower) return <React.Fragment key={i}>{label}</React.Fragment>;
        return (
          <button
            key={i}
            type="button"
            onClick={() => onGrower(t.id)}
            aria-label={`Open Grower Card: ${t.value}`}
            className="inline cursor-pointer text-[hsl(var(--botanical))] underline decoration-[hsl(var(--botanical))]/45 underline-offset-[5px] hover:decoration-[hsl(var(--botanical))]"
          >
            {label}
          </button>
        );
      }
      if (t.type === 'discovery')
        return (
          <button key={i} type="button" onClick={() => onDiscover(t.id)} className="discovery-mark text-[hsl(var(--botanical))] underline decoration-dotted underline-offset-4">
            {t.value}
          </button>
        );
      return <React.Fragment key={i}>{t.value}</React.Fragment>;
    })}
  </>
);

/** Paragraphs fade up gently as they arrive — once, never blocking scroll. */
const Para: React.FC<{ children: React.ReactNode; first?: boolean }> = ({ children, first }) => {
  const [ref, inView] = useInView<HTMLParagraphElement>(0.15);
  const reduced = useReducedMotion();
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (inView) setShown(true);
  }, [inView]);
  return (
    <p
      ref={ref}
      className={`eb-story mb-7 text-[hsl(30_16%_11%)] transition-[opacity,transform] duration-700 ${first ? 'drop-cap' : ''} ${
        shown || reduced ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0'
      }`}
    >
      {children}
    </p>
  );
};

/** A full-bleed cinematic plate: the image drifts slowly while the reader scrolls past, fog breathing over it. */
const Plate: React.FC<{ id: string; caption?: string; effect?: string }> = ({ id, caption, effect }) => {
  const asset = getMedia(id);
  const [ref, p] = useScrollProgress<HTMLDivElement>();
  const reduced = useReducedMotion();
  if (!asset) return null;
  return (
    <figure ref={ref} className="relative left-1/2 my-14 w-screen -translate-x-1/2 overflow-hidden bg-[hsl(30_14%_8%)]">
      <div className="relative h-[62svh] min-h-[320px] sm:h-[78svh]">
        <div className="absolute inset-[-6%]" style={reduced ? undefined : { transform: `translateY(${(p - 0.5) * -6}%) scale(1.04)` }}>
          <EffectImage src={asset.src} alt={asset.alt} effect={effect} className="h-full w-full object-cover" />
        </div>
        <Fog density={0.22} tint="36 20% 88%" />
        <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(180deg,hsl(40_33%_94%)_0%,transparent_12%,transparent_70%,hsl(30_14%_6%/0.75)_100%)]" />
        {caption && (
          <figcaption className="absolute inset-x-4 bottom-4 mx-auto max-w-3xl rounded-md bg-[hsl(30_14%_6%)]/85 px-6 py-4 text-center font-display text-xl italic text-[hsl(42_45%_96%)] sm:text-2xl">
            {caption}
            <span className="mt-1 block font-ui text-[1.0625rem] font-semibold not-italic text-[hsl(44_60%_82%)]">Illustration</span>
          </figcaption>
        )}
      </div>
    </figure>
  );
};

/** Frameless botanical vignette that floats in the margin of the reading column. */
const MarginVignette: React.FC<{ id: string; side: 'left' | 'right'; caption?: string; effect?: string }> = ({ id, side, caption, effect }) => {
  const asset = getMedia(id);
  if (!asset) return null;
  const float = side === 'right' ? 'md:float-right md:-mr-24 md:ml-8' : 'md:float-left md:-ml-24 md:mr-8';
  const mask = 'radial-gradient(ellipse 50% 50% at 50% 50%, #000 58%, transparent 78%)';
  return (
    <figure className={`mx-auto my-6 w-[80%] md:w-[48%] ${float} ${effect === 'stanhopea' ? 'mb-24' : ''}`}>
      <div style={{ WebkitMaskImage: mask, maskImage: mask }}>
        <EffectImage src={asset.src} alt={asset.alt} effect={effect} className="aspect-[4/5] w-full object-cover" />
      </div>
      {caption && <figcaption className="mt-1 text-center font-display text-sm italic text-[hsl(var(--moss))]">{caption}</figcaption>}
    </figure>
  );
};

/** Ernie, discovered in the margin — never pointed out. */
const ErnieSpot: React.FC<{ id?: string; side: 'left' | 'right' }> = ({ id = 'ernie-pot', side }) => {
  const asset = getMedia(id);
  if (!asset) return null;
  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none mx-auto my-2 h-28 w-28 sm:h-32 sm:w-32 md:my-0 md:h-40 md:w-40 ${side === 'right' ? 'md:float-right md:-mr-44 md:ml-4' : 'md:float-left md:-ml-44 md:mr-4'}`}
    >
      <Vignette img={{ src: asset.src, alt: '' }} shape="round" className="h-full w-full" />
    </div>
  );
};

const Note: React.FC<{ title?: string; lines: string[]; i: number }> = ({ title, lines, i }) => (
  <figure
    className="paper-aged relative clear-both mx-auto my-10 max-w-md rounded-sm border border-[hsl(30_25%_60%)]/50 px-7 pb-6 pt-8 shadow-[0_10px_24px_-12px_hsl(30_30%_20%/0.6)]"
    style={{ transform: `rotate(${i % 2 ? 0.8 : -0.9}deg)` }}
  >
    <span aria-hidden="true" className="absolute left-1/2 top-2 h-3 w-3 -translate-x-1/2 rounded-full bg-[hsl(8_50%_40%)] shadow-[0_1px_2px_rgb(0_0_0/0.5)]" />
    {title && <figcaption className="mb-2 font-label text-[1.0625rem] uppercase text-[hsl(var(--moss))]">{title}</figcaption>}
    <p className="font-hand text-xl leading-[1.75] text-[hsl(30_18%_9%)] sm:text-2xl">
      {lines.map((l, li) => (
        <span key={li} className="block">
          {l}
        </span>
      ))}
    </p>
  </figure>
);

const ErnieFinale: React.FC = () => {
  const moss = getMedia('ernie-portrait');
  return (
    <div className="relative clear-both mx-auto my-12 h-44 max-w-md">
      {moss && (
        <div className="absolute inset-0 opacity-70" aria-hidden="true">
          <Vignette img={{ src: moss.src, alt: '' }} shape="soft" className="h-full w-full" imgClassName="blur-[2px] brightness-75" />
        </div>
      )}
      <FrogLeap className="bottom-10 left-1/2 -translate-x-1/2" storageKey="eb-c2-ernie-leap" size={64} />
    </div>
  );
};

const C2StoryFlow: React.FC<Props> = ({ blocks, onDiscover, onGrower, onScience }) => {
  let para = 0;
  let wrap = 0;
  let ernie = 0;
  let notes = 0;
  return (
    <div className="story-prose">
      {blocks.map((b, i) => {
        switch (b.type) {
          case 'paragraph':
            para += 1;
            return (
              <Para key={i} first={para === 1}>
                <Inline text={b.text} onDiscover={onDiscover} onGrower={onGrower} />
              </Para>
            );
          case 'note':
            notes += 1;
            return <Note key={i} title={b.title} lines={b.lines} i={notes} />;
          case 'image':
            if (b.layout === 'wrap-left' || b.layout === 'wrap-right') {
              wrap += 1;
              return <MarginVignette key={i} id={b.id} side={b.layout === 'wrap-right' ? 'right' : 'left'} caption={b.caption} effect={b.effect} />;
            }
            return <Plate key={i} id={b.id} caption={b.caption} effect={b.effect} />;
          case 'effect':
            if (b.name === 'ernie' || b.name === 'frog' || b.name === 'frog-hop') {
              ernie += 1;
              return <ErnieSpot key={i} id={b.name === 'ernie' ? b.id : undefined} side={ernie % 2 ? 'right' : 'left'} />;
            }
            if (b.name === 'ernie-leap') return <ErnieFinale key={i} />;
            return (
              <div key={i} className="clear-both">
                <StoryEffect name={b.name} id={b.id} stage={b.stage} />
              </div>
            );
          case 'science':
            if (!onScience) return null;
            return (
              <p key={i} className="no-print -mt-2 mb-8 text-right">
                <button
                  type="button"
                  onClick={() => onScience(b.id)}
                  className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-[hsl(var(--botanical))]/30 bg-[hsl(var(--botanical))]/[0.05] px-4 py-2 font-label text-[0.56rem] uppercase tracking-wide text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))]/10"
                >
                  {b.label || 'Why does this orchid do that?'} <span aria-hidden="true">→</span>
                </button>
              </p>
            );
          case 'closing':
            return (
              <p key={i} className="clear-both my-16 text-center font-display text-3xl italic text-[hsl(var(--botanical))] sm:text-4xl">
                {b.text}
              </p>
            );
          case 'quote':
            return (
              <blockquote key={i} className="clear-both my-10 border-l-2 border-[hsl(var(--amber))] pl-6 font-display text-xl italic text-[hsl(var(--botanical))]">
                <Inline text={b.text} onDiscover={onDiscover} onGrower={onGrower} />
              </blockquote>
            );
          default:
            return null;
        }
      })}
      <div className="clear-both" />
    </div>
  );
};

export default C2StoryFlow;
