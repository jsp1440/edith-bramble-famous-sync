import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, ChevronDown } from 'lucide-react';
import type { ScienceConcept } from '@/lib/content-types';

/* Provenance labels — the single source of truth for how this project
   distinguishes established knowledge from invented story material. */
export const ProvenanceLabel: React.FC<{ label: 'observed' | 'fiction'; className?: string }> = ({
  label,
  className = '',
}) => {
  const observed = label === 'observed';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 font-label text-[0.52rem] uppercase tracking-wide ${
        observed
          ? 'border-[hsl(var(--botanical))]/50 bg-[hsl(var(--botanical))]/8 text-[hsl(var(--botanical))]'
          : 'border-[hsl(var(--burgundy))]/50 bg-[hsl(var(--burgundy))]/6 text-[hsl(var(--burgundy))]'
      } ${className}`}
    >
      <span
        className={`h-1.5 w-1.5 rounded-full ${observed ? 'bg-[hsl(var(--botanical))]' : 'bg-[hsl(var(--burgundy))]'}`}
        aria-hidden="true"
      />
      {observed ? 'Observed biology' : 'Fictional extension'}
    </span>
  );
};

const LAYERS: { id: 'basic' | 'deeper' | 'scientific'; label: string; hint: string }[] = [
  { id: 'basic', label: 'Basic', hint: 'Plain language' },
  { id: 'deeper', label: 'Deeper', hint: 'Botanical mechanism' },
  { id: 'scientific', label: 'Scientific', hint: 'Technical detail' },
];

interface Props {
  concept: ScienceConcept;
  defaultOpen?: boolean;
}

/* Reusable three-layer science component. Any topic, any Chronicle. */
const ScienceCard: React.FC<Props> = ({ concept, defaultOpen = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  const [layer, setLayer] = useState<'basic' | 'deeper' | 'scientific'>('basic');
  const panelId = `science-${concept.id}`;

  return (
    <article
      id={concept.id}
      className="scroll-mt-24 rounded-sm border border-border/80 bg-[hsl(var(--cream))]"
    >
      <h3>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls={panelId}
          className="flex w-full items-start justify-between gap-4 px-5 py-5 text-left sm:px-6"
        >
          <span className="min-w-0">
            <span className="flex flex-wrap items-center gap-2">
              <ProvenanceLabel label={concept.label} />
              <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">{concept.kind}</span>
            </span>
            <span className="mt-2 block font-display text-xl font-semibold leading-snug text-[hsl(var(--charcoal))] sm:text-2xl">
              {concept.title}
            </span>
            <span className="mt-1.5 block text-sm leading-relaxed text-muted-foreground">{concept.summary}</span>
          </span>
          <ChevronDown
            className={`mt-1 h-5 w-5 shrink-0 text-[hsl(var(--moss))] transition-transform ${open ? 'rotate-180' : ''}`}
            aria-hidden="true"
          />
        </button>
      </h3>

      {open && (
        <div id={panelId} className="border-t border-border/70 px-5 pb-6 pt-5 sm:px-6">
          <div className="flex flex-wrap gap-2" role="tablist" aria-label={`Depth of explanation for ${concept.title}`}>
            {LAYERS.map((l) => (
              <button
                key={l.id}
                type="button"
                role="tab"
                aria-selected={layer === l.id}
                onClick={() => setLayer(l.id)}
                className={`rounded-sm border px-3 py-2 text-left font-label text-[0.55rem] uppercase transition-colors ${
                  layer === l.id
                    ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                    : 'border-border bg-background text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]/60'
                }`}
              >
                <span className="block">{l.label}</span>
                <span className={`mt-0.5 block text-[0.48rem] ${layer === l.id ? 'opacity-80' : 'text-muted-foreground'}`}>
                  {l.hint}
                </span>
              </button>
            ))}
          </div>

          <div className="mt-5 space-y-4">
            {concept.layers[layer].map((para, i) => (
              <p key={i} className="max-w-prose text-[0.98rem] leading-relaxed text-[hsl(var(--ink))]">
                {para}
              </p>
            ))}
          </div>

          {concept.layers.caution && (
            <aside
              role="note"
              className="mt-5 flex gap-3 rounded-sm border-l-4 border-[hsl(var(--burgundy))]/50 bg-[hsl(var(--burgundy))]/5 px-4 py-3"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(var(--burgundy))]" aria-hidden="true" />
              <span>
                <span className="block font-label text-[0.55rem] uppercase text-[hsl(var(--burgundy))]">Caution</span>
                <span className="mt-1 block text-sm leading-relaxed text-[hsl(var(--ink))]">
                  {concept.layers.caution}
                </span>
              </span>
            </aside>
          )}

          {concept.chronicleNote && (
            <p className="mt-5 border-l-2 border-[hsl(var(--amber))]/60 pl-4 font-display text-[1rem] italic leading-relaxed text-[hsl(var(--moss))]">
              {concept.chronicleNote}
            </p>
          )}

          <div className="mt-6 flex flex-wrap items-center gap-x-4 gap-y-2">
            {concept.chronicle && (
              <Link
                to={`/chronicle/${concept.chronicle}`}
                className="font-label text-[0.55rem] uppercase text-[hsl(var(--botanical))] underline underline-offset-4"
              >
                Where this appears in the story
              </Link>
            )}
            {concept.related?.map((r) => (
              <a
                key={r}
                href={`#${r}`}
                className="font-label text-[0.55rem] uppercase text-[hsl(var(--moss))] underline underline-offset-4 hover:text-[hsl(var(--botanical))]"
              >
                {r.replace(/-/g, ' ')}
              </a>
            ))}
          </div>
        </div>
      )}
    </article>
  );
};

export default ScienceCard;
