import React from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { Sheet, SheetContent, SheetDescription, SheetTitle } from '@/components/ui/sheet';
import { getProfile, profilePath } from '@/lib/orchid-continuum';
import { getScienceConcept } from '@/lib/content';
import OrchidProfileView from '@/components/science/OrchidProfileView';
import ScienceCard from '@/components/science/ScienceCard';

/* Opens an orchid science profile (or a science concept) over the story.
   The story underneath never scrolls or unmounts, so closing returns the
   reader to exactly where they were. */
const ScienceDrawer: React.FC<{ id: string | null; onClose: () => void }> = ({ id, onClose }) => {
  const profile = getProfile(id);
  const concept = profile ? undefined : getScienceConcept(id);
  const open = !!(profile || concept);

  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="right" className="w-full overflow-y-auto bg-[hsl(var(--cream))] p-0 sm:max-w-xl lg:max-w-2xl">
        <div className="sticky top-0 z-10 border-b border-border/70 bg-[hsl(var(--cream))]/95 px-5 py-4 backdrop-blur sm:px-6">
          <p className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Why does this orchid do that?</p>
          <SheetTitle className="mt-1 pr-8 font-display text-2xl font-semibold leading-tight text-[hsl(var(--charcoal))]">
            {profile?.name || concept?.title}
          </SheetTitle>
          <SheetDescription className="sr-only">
            Optional science layer. Close to return to your place in the story.
          </SheetDescription>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] rounded-sm bg-[hsl(var(--botanical))] px-4 py-2 font-label text-[0.56rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
            >
              Back to the story
            </button>
            <Link
              to={profile ? profilePath(profile.id) : `/science#${concept?.id}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[44px] items-center gap-1.5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))] underline underline-offset-4"
            >
              {profile ? 'Explore this orchid in the Culture Library' : 'Full page'} (new tab) <ExternalLink className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </div>
        <div className="px-5 py-6 sm:px-6">
          {profile && <OrchidProfileView profile={profile} compact />}
          {concept && <ScienceCard concept={concept} defaultOpen />}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default ScienceDrawer;
