import React from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, ImageOff, ShieldCheck, ArrowRight } from 'lucide-react';
import type { OrchidProfile } from '@/lib/orchid-types';
import { AOS_HOME, REGIONS, getProfile, profilePath } from '@/lib/orchid-continuum';
import { AosGuidance } from '@/components/evidence/EvidenceUI';
import { chroniclePath } from '@/lib/content';
import { ProvenanceLabel } from '@/components/science/ScienceCard';
import ReadThePlant from '@/components/science/ReadThePlant';

const Section: React.FC<{ n: number; title: string; children: React.ReactNode }> = ({ n, title, children }) => (
  <section className="border-t border-border/70 pt-6">
    <h3 className="flex items-baseline gap-3 font-display text-xl font-semibold text-[hsl(var(--charcoal))] sm:text-2xl">
      <span className="font-label text-[0.55rem] text-[hsl(var(--amber))]">{String(n).padStart(2, '0')}</span>
      {title}
    </h3>
    <div className="mt-3">{children}</div>
  </section>
);

export const DistributionMap: React.FC<{ profile: OrchidProfile }> = ({ profile }) => (
  <figure>
    <svg viewBox="0 0 200 100" className="w-full rounded-sm border border-border/70 bg-[hsl(200_20%_94%)]" role="img" aria-label={`Schematic map: ${profile.origin.regions.map((r) => REGIONS[r].label).join(', ')}`}>
      {[20, 40, 60, 80].map((y) => (
        <line key={y} x1="0" x2="200" y1={y} y2={y} stroke="hsl(200 15% 82%)" strokeWidth="0.3" />
      ))}
      {[40, 80, 120, 160].map((x) => (
        <line key={x} y1="0" y2="100" x1={x} x2={x} stroke="hsl(200 15% 82%)" strokeWidth="0.3" />
      ))}
      <line x1="0" x2="200" y1="50" y2="50" stroke="hsl(30 30% 60%)" strokeWidth="0.4" strokeDasharray="2 2" />
      {/* faint landmass hints */}
      <path d="M30 20 Q45 18 55 30 L60 40 Q62 45 58 48 L62 55 Q70 50 80 58 L75 75 Q68 85 62 80 L58 62 Q50 55 48 45 L40 38 Q30 30 30 20Z" fill="hsl(96 15% 84%)" />
      <path d="M120 18 Q150 15 170 25 L165 45 Q158 48 150 44 L140 40 Q128 32 120 18Z" fill="hsl(96 15% 84%)" />
      <path d="M172 58 Q185 55 192 62 L190 75 Q180 80 172 72Z" fill="hsl(96 15% 84%)" />
      {profile.origin.regions.map((r) => {
        const p = REGIONS[r];
        return (
          <g key={r}>
            <circle cx={p.x} cy={p.y} r="3.2" fill="hsl(300 30% 40% / 0.25)" />
            <circle cx={p.x} cy={p.y} r="1.4" fill="hsl(300 35% 32%)" />
          </g>
        );
      })}
    </svg>
    <figcaption className="mt-1.5 flex flex-wrap gap-1.5">
      {profile.origin.regions.map((r) => (
        <span key={r} className="rounded-sm bg-muted px-2 py-0.5 font-label text-[0.5rem] uppercase text-[hsl(var(--ink))]">
          {REGIONS[r].label}
        </span>
      ))}
      <span className="font-label text-[0.48rem] uppercase text-muted-foreground">Schematic — not a range map</span>
    </figcaption>
  </figure>
);

export const AosButton: React.FC<{ profile: OrchidProfile }> = ({ profile }) => (
  <div className="rounded-sm border-2 border-[hsl(var(--botanical))]/40 bg-background p-4">
    <p className="font-label text-[0.55rem] uppercase text-[hsl(var(--botanical))]">Primary culture reference — American Orchid Society</p>
    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
      This page adds habitat, adaptation and physiology context in its own words. It does not reproduce the AOS sheet.
    </p>
    {profile.aos.url ? (
      <a
        href={profile.aos.url}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-3 inline-flex min-h-[44px] items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
      >
        AOS Care &amp; Culture: {profile.aos.sheetTitle} <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
      </a>
    ) : (
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <a
          href={AOS_HOME}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex min-h-[44px] items-center gap-2 rounded-sm bg-[hsl(var(--botanical))] px-5 py-2.5 font-label text-[0.58rem] uppercase text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))]"
        >
          American Orchid Society <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
        </a>
        <span className="font-label text-[0.5rem] uppercase text-[hsl(var(--amber))]">
          {profile.aos.sheetTitle} sheet link awaiting verification
        </span>
      </div>
    )}
  </div>
);

const fitTone: Record<string, string> = {
  good: 'bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]',
  possible: 'bg-[hsl(var(--botanical))]/15 text-[hsl(var(--botanical))]',
  difficult: 'bg-[hsl(var(--burgundy))]/10 text-[hsl(var(--burgundy))]',
  unknown: 'bg-muted text-muted-foreground',
};

const OrchidProfileView: React.FC<{ profile: OrchidProfile; compact?: boolean }> = ({ profile, compact }) => {
  return (
    <div className="space-y-6">
      <header>
        <div className="flex flex-wrap items-center gap-2">
          <ProvenanceLabel label="observed" />
          <span className="font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">Science profile · {profile.rank}</span>
        </div>
        <p className="mt-3 font-display text-xl italic leading-relaxed text-[hsl(var(--botanical))]">{profile.hook}</p>
        <p className="mt-3 inline-flex flex-wrap items-center gap-2 rounded-md border-2 border-dashed border-[hsl(30_20%_35%)] bg-[hsl(44_30%_94%)] px-3 py-1.5 font-ui text-[1rem] font-semibold text-[hsl(30_25%_14%)]">
          <ShieldCheck className="h-4 w-4" aria-hidden="true" />
          FCOS curated draft · evidence pending · expert review pending
        </p>
      </header>

      <Section n={1} title="Orchid / group">
        <p className="font-display text-lg italic text-[hsl(var(--charcoal))]">{profile.acceptedName}</p>
        <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{profile.taxonomy}</p>
        {profile.variationNote && (
          <p className="mt-2 rounded-sm border-l-4 border-[hsl(var(--amber))]/60 bg-[hsl(var(--amber))]/8 px-3 py-2 text-sm text-[hsl(var(--ink))]">
            {profile.variationNote}
          </p>
        )}
      </Section>

      <Section n={2} title="Where it comes from">
        <div className={`grid gap-4 ${compact ? '' : 'md:grid-cols-2'}`}>
          <DistributionMap profile={profile} />
          <p className="text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">{profile.origin.summary}</p>
        </div>
      </Section>

      <Section n={3} title="Habitat">
        <dl className="grid gap-2 sm:grid-cols-2">
          {profile.habitat.map((h) => (
            <div key={h.label} className="rounded-sm border border-border/70 bg-background px-3 py-2">
              <dt className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">{h.label}</dt>
              <dd className="mt-0.5 text-sm leading-relaxed text-[hsl(var(--ink))]">{h.value}</dd>
            </div>
          ))}
        </dl>
      </Section>

      <Section n={4} title="See it in nature">
        <div className="grid gap-3 sm:grid-cols-2">
          {profile.natureImages.map((slot) =>
            slot.photo ? (
              <figure key={slot.caption}>
                <img src={slot.photo.src} alt={slot.caption} loading="lazy" className="aspect-[4/3] w-full rounded-sm object-cover" />
                <figcaption className="mt-1 text-xs text-muted-foreground">
                  Photograph · {slot.photo.creator ? `${slot.photo.creator} · ` : ''}{slot.photo.license} · {slot.photo.source}
                </figcaption>
              </figure>
            ) : (
              <div key={slot.caption} className="flex aspect-[4/3] flex-col items-center justify-center gap-2 rounded-sm border border-dashed border-border bg-muted/40 p-4 text-center">
                <ImageOff className="h-5 w-5 text-muted-foreground" aria-hidden="true" />
                <p className="text-sm text-[hsl(var(--ink))]">{slot.caption}</p>
                <p className="font-label text-[0.46rem] uppercase text-muted-foreground">Photograph slot · awaiting rights-cleared image</p>
              </div>
            ),
          )}
        </div>
      </Section>

      <Section n={5} title="Read the plant">
        <ReadThePlant profile={profile} compact={compact} />
      </Section>

      <Section n={6} title="Adaptations">
        <ul className="space-y-2">
          {profile.adaptations.map((a) => (
            <li key={a.structure} className="flex flex-col gap-0.5 rounded-sm border border-border/70 bg-background px-3 py-2 sm:flex-row sm:gap-3">
              <span className="font-semibold text-[hsl(var(--charcoal))] sm:w-48 sm:shrink-0">{a.structure}</span>
              <span className="text-sm leading-relaxed text-[hsl(var(--ink))]">{a.fn}</span>
            </li>
          ))}
        </ul>
      </Section>

      <Section n={7} title="Seasonal life">
        <ol className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {profile.seasonal.map((s, i) => (
            <li key={s.phase} className="rounded-sm border border-border/70 bg-background p-3">
              <span className="font-label text-[0.48rem] uppercase text-[hsl(var(--amber))]">{i + 1} · {s.when}</span>
              <p className="mt-1 font-display text-lg text-[hsl(var(--charcoal))]">{s.phase}</p>
              <p className="mt-0.5 text-sm text-muted-foreground">{s.note}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section n={8} title="What the grower sees">
        <ul className="grid gap-1.5 sm:grid-cols-2">
          {profile.growerSees.map((g) => (
            <li key={g} className="flex gap-2 text-sm leading-relaxed text-[hsl(var(--ink))]">
              <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(var(--botanical))]" aria-hidden="true" />
              {g}
            </li>
          ))}
        </ul>
      </Section>

      <Section n={9} title="What that means in culture">
        <dl className="grid gap-2 sm:grid-cols-2">
          {profile.culture.map((c) => (
            <div key={c.label} className="rounded-sm border border-border/70 bg-background px-3 py-2">
              <dt className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">{c.label}</dt>
              <dd className="mt-0.5 text-sm leading-relaxed text-[hsl(var(--ink))]">{c.value}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-2 text-xs text-muted-foreground">No watering schedule is given on purpose: the plant's stage, your media and your climate decide the interval.</p>
      </Section>

      <Section n={10} title="Where could I grow it?">
        <ul className="grid gap-2 sm:grid-cols-2">
          {profile.whereToGrow.map((w) => (
            <li key={w.place} className="rounded-sm border border-border/70 bg-background px-3 py-2">
              <span className="flex items-center justify-between gap-2">
                <span className="font-semibold text-[hsl(var(--charcoal))]">{w.place}</span>
                <span className={`rounded-sm px-2 py-0.5 font-label text-[0.46rem] uppercase ${fitTone[w.fit]}`}>{w.fit}</span>
              </span>
              <span className="mt-0.5 block text-sm text-muted-foreground">{w.note}</span>
            </li>
          ))}
        </ul>
      </Section>

      <Section n={11} title="Why are these orchids neighbors?">
        <ul className="space-y-2">
          {profile.neighbors.map((nb) => {
            const other = getProfile(nb.id);
            return (
              <li key={nb.name} className="rounded-sm border border-border/70 bg-background px-3 py-2 text-sm">
                {other ? (
                  <Link to={`/science/orchids/${other.id}`} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">
                    {nb.name}
                  </Link>
                ) : (
                  <span className="font-semibold text-[hsl(var(--charcoal))]">{nb.name}</span>
                )}
                <span className="text-[hsl(var(--ink))]"> — {nb.why}</span>
              </li>
            );
          })}
        </ul>
        <Link to="/greenhouse#neighbors" className="mt-3 inline-flex items-center gap-1.5 font-label text-[0.55rem] uppercase text-[hsl(var(--botanical))] underline underline-offset-4">
          Compare any two in Edith's greenhouse <ArrowRight className="h-3 w-3" aria-hidden="true" />
        </Link>
      </Section>

      {profile.sameNameDifferentLife && (
        <Section n={12} title="Same name, different life">
          <ul className="space-y-2">
            {profile.sameNameDifferentLife.map((s) => (
              <li key={s.name} className="rounded-sm border-l-4 border-[hsl(var(--amber))]/60 bg-[hsl(var(--amber))]/8 px-3 py-2 text-sm">
                {s.id ? (
                  <Link to={`/science/orchids/${s.id}`} className="font-semibold text-[hsl(var(--botanical))] underline underline-offset-4">{s.name}</Link>
                ) : (
                  <span className="font-semibold text-[hsl(var(--charcoal))]">{s.name}</span>
                )}
                <span className="text-[hsl(var(--ink))]"> — {s.contrast}</span>
              </li>
            ))}
          </ul>
        </Section>
      )}

      <Section n={13} title="American Orchid Society reference">
        <AosGuidance profile={profile} />
        <p className="mt-3 text-[1.0625rem] text-[hsl(var(--ink))]">
          Everything else on this page is FCOS / Orchid Continuum interpretation, drafted with AI assistance and awaiting sources.{' '}
          <Link to={profilePath(profile.id, 'evidence')} className="font-semibold text-[hsl(var(--botanical))] underline">See the evidence status of each statement</Link>.
        </p>
      </Section>

      <Section n={14} title="Scientific sources">
        {profile.sources.length ? (
          <ol className="list-decimal space-y-1 pl-5 text-sm">
            {profile.sources.map((s) => (
              <li key={s.id}>
                {s.url ? <a href={s.url} target="_blank" rel="noopener noreferrer" className="underline">{s.citation}</a> : s.citation}
              </li>
            ))}
          </ol>
        ) : (
          <p className="rounded-sm border border-dashed border-border bg-muted/40 px-4 py-3 text-sm text-muted-foreground">
            Supporting references will be attached from the approved dataset. None are shown until they have been supplied and
            checked — this site does not generate citations.
          </p>
        )}
        {profile.chronicles.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {profile.chronicles.map((c) => (
              <Link key={c.id} to={chroniclePath(c.id)} className="rounded-sm border border-border px-3 py-2 text-sm text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]/60">
                <span className="font-label text-[0.48rem] uppercase text-[hsl(var(--moss))]">In the story · </span>
                {c.note}
              </Link>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
};

export default OrchidProfileView;
