import React, { useState } from 'react';
import { Eye, FlaskConical, Mountain, Sprout, EyeOff } from 'lucide-react';
import { getMedia } from '@/lib/content';
import type { OrchidProfile } from '@/lib/orchid-types';

/* READ THE PLANT — before reading culture instructions, look at the plant.
   Observation and inference are always shown as separate layers. */
const LAYERS = [
  { key: 'see', label: 'What you can see', icon: Eye, tone: 'observation' },
  { key: 'does', label: 'What science says this structure does', icon: FlaskConical, tone: 'inference' },
  { key: 'habitat', label: 'What habitat evidence suggests', icon: Mountain, tone: 'inference' },
  { key: 'culture', label: 'What it may mean for culture', icon: Sprout, tone: 'inference' },
] as const;

const ReadThePlant: React.FC<{ profile: OrchidProfile; compact?: boolean }> = ({ profile, compact }) => {
  const [activeId, setActiveId] = useState(profile.readThePlant[0]?.id);
  const feature = profile.readThePlant.find((f) => f.id === activeId) || profile.readThePlant[0];
  const img = getMedia(profile.image);
  if (!feature) return null;

  return (
    <div className="rounded-sm border border-[hsl(var(--botanical))]/30 bg-[hsl(var(--botanical))]/[0.04] p-4 sm:p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-display text-2xl font-semibold tracking-tight text-[hsl(var(--charcoal))]">Read the plant</h3>
        <p className="font-label text-[0.5rem] uppercase text-[hsl(var(--moss))]">Look first · then read the culture</p>
      </div>

      <div className={`mt-4 grid gap-5 ${compact ? '' : 'md:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]'}`}>
        <div>
          {img && (
            <figure>
              <img src={img.src} alt={img.alt} loading="lazy" className="aspect-square w-full rounded-sm border border-border/70 object-cover" />
              <figcaption className="mt-1.5 inline-flex items-center gap-1.5 rounded-sm bg-[hsl(var(--amber))]/15 px-2 py-0.5 font-label text-[0.48rem] uppercase text-[hsl(30_40%_28%)]">
                Illustration · not a documentary photograph
              </figcaption>
            </figure>
          )}
          <div className="mt-3 flex flex-wrap gap-2" role="tablist" aria-label="Plant features">
            {profile.readThePlant.map((f) => (
              <button
                key={f.id}
                type="button"
                role="tab"
                aria-selected={f.id === feature.id}
                onClick={() => setActiveId(f.id)}
                className={`min-h-[40px] rounded-sm border px-3 py-2 text-left text-sm transition-colors ${
                  f.id === feature.id
                    ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]'
                    : 'border-border bg-background text-[hsl(var(--ink))] hover:border-[hsl(var(--botanical))]/60'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3" role="tabpanel">
          {LAYERS.map(({ key, label, icon: Icon, tone }) => (
            <div key={key} className="rounded-sm border border-border/70 bg-background px-4 py-3">
              <p className="flex items-center gap-2 font-label text-[0.52rem] uppercase text-[hsl(var(--moss))]">
                <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                {label}
                <span
                  className={`ml-auto rounded-sm px-1.5 py-0.5 text-[0.44rem] ${
                    tone === 'observation' ? 'bg-[hsl(var(--botanical))]/10 text-[hsl(var(--botanical))]' : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {tone === 'observation' ? 'Observation' : 'Inference'}
                </span>
              </p>
              <p className="mt-1.5 text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">{feature[key]}</p>
            </div>
          ))}
          <div className="rounded-sm border-l-4 border-[hsl(var(--burgundy))]/60 bg-[hsl(var(--burgundy))]/5 px-4 py-3">
            <p className="flex items-center gap-2 font-label text-[0.52rem] uppercase text-[hsl(var(--burgundy))]">
              <EyeOff className="h-3.5 w-3.5" aria-hidden="true" />
              What this image cannot tell you
            </p>
            <p className="mt-1.5 text-[0.95rem] leading-relaxed text-[hsl(var(--ink))]">{feature.cannotTell}</p>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
              No image — and no image analysis — can prove a plant's physiology (for example CAM metabolism) or set an exact
              watering interval. Handle the plant, check the roots, and look again tomorrow.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReadThePlant;
