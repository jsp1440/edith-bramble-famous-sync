import React, { useCallback, useEffect, useState } from 'react';
import { Loader2, RefreshCw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { getProfile } from '@/lib/orchid-continuum';
import { RESPONSE_LABEL } from '@/components/evidence/EvidenceUI';

type Status = 'pending' | 'accepted' | 'rejected' | 'needs-follow-up';
interface Row {
  id: string;
  kind: string;
  profile_id: string | null;
  claim_id: string | null;
  claim_text: string | null;
  response: string;
  comment: string | null;
  suggested_wording: string | null;
  source_url: string | null;
  doi: string | null;
  citation: string | null;
  reference_note: string | null;
  taxon_group: string | null;
  growing_environment: string | null;
  geographic_context: string | null;
  reviewer_name: string | null;
  reviewer_expertise: string[] | null;
  contact_email: string | null;
  contact_phone: string | null;
  status: Status;
  moderator_note: string | null;
  created_at: string;
}

const STATUSES: { id: Status; label: string }[] = [
  { id: 'pending', label: 'Pending' },
  { id: 'needs-follow-up', label: 'Needs follow-up' },
  { id: 'accepted', label: 'Accepted (shown publicly)' },
  { id: 'rejected', label: 'Rejected' },
];

/* Moderation queue. Accepting a review publishes the REVIEW alongside the
   claim; it never edits the claim. Claim text changes are made by an
   editor in the repository, source first. */
const ReviewQueue: React.FC = () => {
  const [status, setStatus] = useState<Status>('pending');
  const [rows, setRows] = useState<Row[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setRows(null);
    const { data, error } = await supabase.from('evidence_submissions').select('*').eq('status', status).order('created_at', { ascending: false });
    if (error) setErr(error.message);
    setRows((data as Row[]) ?? []);
  }, [status]);

  useEffect(() => {
    load();
  }, [load]);

  const move = async (id: string, next: Status) => {
    const { error } = await supabase.from('evidence_submissions').update({ status: next, moderator_note: notes[id] || null, reviewed_at: new Date().toISOString() }).eq('id', id);
    if (error) setErr(error.message);
    else load();
  };

  return (
    <div className="space-y-5">
      <p className="text-[1.125rem] leading-relaxed text-[hsl(var(--ink))]">
        Error reports, added evidence and expert reviews. Accepting a review shows it publicly next to the claim with the reviewer's stated
        expertise; it does <strong>not</strong> change the claim. Disagreements stay visible.
      </p>
      <div className="flex flex-wrap items-center gap-2">
        {STATUSES.map((s) => (
          <button key={s.id} type="button" onClick={() => setStatus(s.id)} aria-pressed={status === s.id} className={`min-h-[44px] rounded-md border-2 px-4 text-[1rem] font-semibold ${status === s.id ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border text-[hsl(var(--ink))]'}`}>
            {s.label}
          </button>
        ))}
        <button type="button" onClick={load} className="inline-flex min-h-[44px] items-center gap-1.5 rounded-md border-2 border-border px-3 text-[1rem] font-semibold">
          <RefreshCw className="h-4 w-4" aria-hidden="true" /> Refresh
        </button>
      </div>
      {err && <p role="alert" className="rounded-md border-2 border-[hsl(0_50%_35%)] p-3 text-[1.0625rem] text-[hsl(0_60%_25%)]">{err}</p>}
      {rows === null ? (
        <p className="flex items-center gap-2 text-[1.125rem]"><Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" /> Loading…</p>
      ) : rows.length === 0 ? (
        <p className="rounded-md border-2 border-dashed border-border p-5 text-[1.125rem]">Nothing in this queue.</p>
      ) : (
        <ul className="space-y-4">
          {rows.map((r) => (
            <li key={r.id} className="rounded-md border-2 border-border bg-white/70 p-5 text-[1.0625rem] text-[hsl(var(--ink))]">
              <p className="font-ui font-bold text-[hsl(var(--botanical))]">
                {r.kind} · {RESPONSE_LABEL[r.response] ?? r.response} · {r.profile_id ? getProfile(r.profile_id)?.name ?? r.profile_id : 'General'} · {new Date(r.created_at).toLocaleString()}
              </p>
              {r.claim_text && <p className="mt-2 italic">“{r.claim_text}”</p>}
              {r.claim_id && <p className="text-[1rem]">Claim id: <code>{r.claim_id}</code></p>}
              <dl className="mt-3 grid gap-2 sm:grid-cols-2">
                {([
                  ['Comment', r.comment],
                  ['Suggested wording', r.suggested_wording],
                  ['Source URL', r.source_url],
                  ['DOI', r.doi],
                  ['Citation', r.citation],
                  ['Reference', r.reference_note],
                  ['Taxon / group', r.taxon_group],
                  ['Growing environment', r.growing_environment],
                  ['Geographic context', r.geographic_context],
                  ['Reviewer', [r.reviewer_name, r.reviewer_expertise?.join(', ')].filter(Boolean).join(' — ')],
                  ['Contact', [r.contact_email, r.contact_phone].filter(Boolean).join(' · ')],
                ] as [string, string | null][]).filter(([, v]) => v).map(([k, v]) => (
                  <div key={k}>
                    <dt className="font-semibold">{k}</dt>
                    <dd className="whitespace-pre-wrap break-words">{k === 'Source URL' ? <a href={v!} target="_blank" rel="noopener noreferrer" className="underline">{v}</a> : v}</dd>
                  </div>
                ))}
              </dl>
              <label className="mt-3 block">
                <span className="font-semibold">Moderator note</span>
                <textarea rows={2} defaultValue={r.moderator_note ?? ''} onChange={(e) => setNotes((n) => ({ ...n, [r.id]: e.target.value }))} className="mt-1 block w-full rounded-md border-2 border-border bg-white px-3 py-2" />
              </label>
              <div className="mt-3 flex flex-wrap gap-2">
                {STATUSES.filter((s) => s.id !== r.status).map((s) => (
                  <button key={s.id} type="button" onClick={() => move(r.id, s.id)} className="min-h-[44px] rounded-md border-2 border-[hsl(var(--botanical))] px-4 font-semibold text-[hsl(var(--botanical))] hover:bg-[hsl(var(--botanical))] hover:text-[hsl(var(--cream))]">
                    Mark {s.label.toLowerCase()}
                  </button>
                ))}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ReviewQueue;
