import React, { useState } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Claim } from '@/lib/evidence-types';
import { SPECIALTIES } from '@/lib/evidence';
import { listProfiles } from '@/lib/orchid-continuum';

const CRM_URL = 'https://famous.ai/api/crm/6a86b1e2a25ecaf758848148/subscribe';

const REVIEW_RESPONSES = [
  { id: 'agree', label: 'Agree' },
  { id: 'agree-qualified', label: 'Agree with qualification' },
  { id: 'disagree', label: 'Disagree' },
  { id: 'needs-evidence', label: 'Needs evidence' },
  { id: 'add-source', label: 'Add source' },
  { id: 'add-grower-observation', label: 'Add grower observation' },
] as const;

const input = 'mt-1 block w-full rounded-md border-2 border-[hsl(30_15%_45%)] bg-white px-3 py-3 text-[1.125rem] text-[hsl(var(--ink))] focus:border-[hsl(var(--botanical))] focus:outline-none focus:ring-2 focus:ring-[hsl(var(--botanical))]/30';
const lbl = 'block font-ui text-[1.0625rem] font-semibold text-[hsl(var(--charcoal))]';

const Field: React.FC<{ label: string; hint?: string; children: React.ReactNode }> = ({ label, hint, children }) => (
  <label className="block">
    <span className={lbl}>{label}</span>
    {hint && <span className="block text-[1rem] text-[hsl(var(--ink))]">{hint}</span>}
    {children}
  </label>
);

const isUrl = (s: string) => !s || /^https?:\/\/\S+\.\S+/.test(s);
const isDoi = (s: string) => !s || /^10\.\d{4,9}\/\S+$/.test(s.replace(/^https?:\/\/(dx\.)?doi\.org\//, ''));

const SubmissionForm: React.FC<{ mode: 'report' | 'review'; claim?: Claim; profileId?: string; onDone?: () => void }> = ({ mode, claim, profileId, onDone }) => {
  const [f, setF] = useState({
    profile: claim?.profileId ?? profileId ?? '',
    statement: claim?.text ?? '',
    response: mode === 'review' ? '' : 'report-error',
    comment: '',
    suggested: '',
    sourceUrl: '',
    doi: '',
    citation: '',
    reference: '',
    observation: '',
    taxon: '',
    environment: '',
    geo: '',
    name: '',
    email: '',
    phone: '',
  });
  const [expertise, setExpertise] = useState<string[]>([]);
  const [sms, setSms] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const up = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF((s) => ({ ...s, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    if (mode === 'review' && !f.response) return setErr('Please choose a response.');
    if (!f.statement.trim()) return setErr('Please identify the specific statement.');
    if (mode === 'report' && !f.comment.trim()) return setErr('Please describe the reason for concern.');
    if (!isUrl(f.sourceUrl)) return setErr('The source URL should start with http:// or https://');
    if (!isDoi(f.doi)) return setErr('A DOI looks like 10.1234/abcd — please check it.');
    if (f.email && !/^\S+@\S+\.\S+$/.test(f.email)) return setErr('Please check the email address.');
    setBusy(true);
    const kind = mode === 'review' ? 'expert-review' : f.sourceUrl || f.doi || f.citation || f.observation ? 'evidence-addition' : 'error-report';
    // Server-side RPC: inserts without reading back, so no visitor can read the
    // moderation queue (contact details stay private to editors).
    const { error } = await supabase.rpc('submit_evidence', { payload: {
      kind,
      profile_id: f.profile || null,
      claim_id: claim?.id ?? null,
      claim_text: f.statement.trim(),
      response: f.response,
      comment: [f.comment, f.observation && `Grower observation: ${f.observation}`].filter(Boolean).join('\n\n') || null,
      suggested_wording: f.suggested || null,
      source_url: f.sourceUrl || null,
      doi: f.doi ? f.doi.replace(/^https?:\/\/(dx\.)?doi\.org\//, '') : null,
      citation: f.citation || null,
      reference_note: f.reference || null,
      taxon_group: f.taxon || null,
      growing_environment: f.environment || null,
      geographic_context: f.geo || null,
      reviewer_name: f.name || null,
      reviewer_expertise: expertise,
      contact_email: f.email || null,
      contact_phone: f.phone || null,
    } });
    if (error) {
      setBusy(false);
      return setErr('Sorry — the submission could not be saved. Please try again.');
    }
    if (f.email) {
      fetch(CRM_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: f.email,
          name: f.name || undefined,
          phone: f.phone || undefined,
          sms_opt_in: sms === true,
          source: mode === 'review' ? 'expert-review' : 'contact-form',
          tags: mode === 'review' ? ['expert-reviewer', 'culture-library', ...expertise] : ['evidence-report', 'culture-library'],
        }),
      }).catch(() => undefined);
    }
    setBusy(false);
    setDone(true);
    onDone?.();
  };

  if (done) {
    return (
      <div className="rounded-md bg-[hsl(var(--botanical))] p-6 text-[hsl(44_50%_95%)]" role="status">
        <CheckCircle2 className="h-8 w-8" aria-hidden="true" />
        <p className="mt-2 font-display text-2xl font-semibold">Thank you — received for review.</p>
        <p className="mt-2 text-[1.1875rem] leading-relaxed">
          Your submission is in the moderation queue. It does not change the published text automatically; an editor will weigh it alongside
          the evidence, and the original statement stays visible until then.
        </p>
        <button type="button" onClick={() => setDone(false)} className="mt-4 min-h-[48px] rounded-md bg-[hsl(44_60%_94%)] px-5 font-ui text-[1.0625rem] font-semibold text-[hsl(var(--botanical))]">
          Submit another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-6" noValidate>
      {mode === 'review' && (
        <fieldset>
          <legend className={lbl}>Your response to this claim</legend>
          <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {REVIEW_RESPONSES.map((r) => (
              <label key={r.id} className={`flex min-h-[52px] cursor-pointer items-center gap-3 rounded-md border-2 px-4 text-[1.0625rem] font-semibold ${f.response === r.id ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border text-[hsl(var(--ink))]'}`}>
                <input type="radio" name="response" value={r.id} checked={f.response === r.id} onChange={up('response')} className="h-5 w-5" />
                {r.label}
              </label>
            ))}
          </div>
        </fieldset>
      )}

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Page / profile">
          <select value={f.profile} onChange={up('profile')} className={input}>
            <option value="">General / not profile-specific</option>
            {listProfiles().map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            <option value="edith-greenhouse">Edith's greenhouse explorer</option>
          </select>
        </Field>
        <Field label="Taxon / group (optional)"><input value={f.taxon} onChange={up('taxon')} className={input} /></Field>
      </div>

      <Field label="The specific statement">
        <textarea value={f.statement} onChange={up('statement')} rows={3} className={input} readOnly={!!claim} />
      </Field>

      <Field label={mode === 'review' ? 'Comment' : 'Reason for concern'}>
        <textarea value={f.comment} onChange={up('comment')} rows={4} className={input} />
      </Field>
      <Field label={mode === 'review' ? 'Suggested wording (optional)' : 'Proposed correction (optional)'}>
        <textarea value={f.suggested} onChange={up('suggested')} rows={3} className={input} />
      </Field>

      <fieldset className="rounded-md border-2 border-border p-5">
        <legend className="px-2 font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">Supporting evidence (optional)</legend>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Source URL"><input type="url" value={f.sourceUrl} onChange={up('sourceUrl')} className={input} placeholder="https://" /></Field>
          <Field label="DOI"><input value={f.doi} onChange={up('doi')} className={input} placeholder="10.xxxx/…" /></Field>
        </div>
        <div className="mt-5 space-y-5">
          <Field label="Book or article citation"><textarea value={f.citation} onChange={up('citation')} rows={2} className={input} /></Field>
          <Field label="Other reference" hint="e.g. a link to a photo, herbarium record, or shared file"><input value={f.reference} onChange={up('reference')} className={input} /></Field>
          <Field label="Grower observation" hint="What you have seen in your own growing — kept labelled as grower experience, never as published evidence.">
            <textarea value={f.observation} onChange={up('observation')} rows={3} className={input} />
          </Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Growing environment" hint="Greenhouse, windowsill, outdoors…"><input value={f.environment} onChange={up('environment')} className={input} /></Field>
            <Field label="Geographic / climate context" hint="e.g. coastal California, USDA zone"><input value={f.geo} onChange={up('geo')} className={input} /></Field>
          </div>
        </div>
      </fieldset>

      <fieldset className="rounded-md border-2 border-border p-5">
        <legend className="px-2 font-ui text-[1.0625rem] font-bold text-[hsl(var(--charcoal))]">About you</legend>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={mode === 'review' ? 'Reviewer name' : 'Name (optional)'}><input value={f.name} onChange={up('name')} className={input} autoComplete="name" /></Field>
          <Field label="Email (optional)"><input type="email" value={f.email} onChange={up('email')} className={input} autoComplete="email" /></Field>
          <Field label="Phone number (optional)"><input type="tel" value={f.phone} onChange={up('phone')} className={input} autoComplete="tel" /></Field>
        </div>
        {(f.email || f.phone) && (
          <label className="mt-4 flex items-start gap-3 text-[1.0625rem] text-[hsl(var(--ink))]">
            <input type="checkbox" checked={sms} onChange={(e) => setSms(e.target.checked)} className="mt-1 h-5 w-5" />
            Text me updates. Msg &amp; data rates may apply. Reply STOP to unsubscribe.
          </label>
        )}
        <div className="mt-5">
          <p className={lbl}>{mode === 'review' ? 'Your areas of expertise' : 'Relevant experience (optional)'}</p>
          <p className="text-[1rem] text-[hsl(var(--ink))]">Stated expertise is recorded with your response. It is context, not automatic authority.</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {SPECIALTIES.map((s) => {
              const on = expertise.includes(s);
              return (
                <button key={s} type="button" aria-pressed={on} onClick={() => setExpertise((x) => (on ? x.filter((y) => y !== s) : [...x, s]))} className={`min-h-[44px] rounded-md border-2 px-3 text-[1rem] font-semibold ${on ? 'border-[hsl(var(--botanical))] bg-[hsl(var(--botanical))] text-[hsl(var(--cream))]' : 'border-border text-[hsl(var(--ink))]'}`}>
                  {s}
                </button>
              );
            })}
          </div>
        </div>
      </fieldset>

      {err && <p role="alert" className="rounded-md border-2 border-[hsl(0_50%_35%)] bg-[hsl(0_60%_95%)] px-4 py-3 text-[1.0625rem] font-semibold text-[hsl(0_60%_25%)]">{err}</p>}
      <button type="submit" disabled={busy} className="inline-flex min-h-[56px] items-center gap-2 rounded-md bg-[hsl(var(--botanical))] px-8 font-ui text-[1.1875rem] font-semibold text-[hsl(var(--cream))] hover:bg-[hsl(var(--moss))] disabled:opacity-60">
        {busy && <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />}
        Submit for review
      </button>
      <p className="text-[1rem] text-[hsl(var(--ink))]">Submissions go to a moderation queue. Nothing you send changes the published page automatically.</p>
    </form>
  );
};

export default SubmissionForm;
