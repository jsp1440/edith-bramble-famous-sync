import microclimates from './microclimates.json';

/* ------------------------------------------------------------------
   CANONICAL MODEL of Edith Bramble's greenhouse.
   Every story illustration, map and explorer should treat this as the
   one building. Camera angles may change; architecture may not.

   Edith and her greenhouse are fictional. The building, its dimensions
   and its interior zone layout are a FICTIONAL working orchid greenhouse
   in the story's Pismo Beach setting.
------------------------------------------------------------------- */

export const GREENHOUSE_CREDIT = {
  text:
    "Edith Bramble is fictional. Edith Bramble's greenhouse is a fictional working orchid greenhouse located in the story's Pismo Beach setting.",
};

export const ARCHITECTURE = {
  source: 'Approximate dimensions of the fictional greenhouse.',
  overall: { lengthFt: 48, widthFt: 16 },
  central: { lengthFt: 32, widthFt: 16, heightFt: 15, note: 'Taller central greenhouse' },
  ends: { count: 2, lengthFt: 8, widthFt: 8, heightFt: 12, note: 'Two lower end areas' },
};

export const ENVIRONMENT = {
  architecturalInspiration:
    "A tall central house with lower end rooms, a central aisle, zoned benches, hanging baskets, a Ficus canopy, ventilation and a light gradient from the bright south side to the shadier north side create the different microclimates Edith grows in.",
  fictionalLocal:
    "Edith's greenhouse stands in fictional Pismo Beach, on the coast. Marine layer, sea air and milder swings are the story's setting. No measured temperatures or humidities are claimed.",
};


export type Orientation = 'north' | 'south' | 'west' | 'east' | 'center';

export interface GreenhouseZone {
  id: string;
  name: string;
  /** Plan rectangle in feet: x 0 (west) → 48 (east), y 0 (north) → 16 (south). */
  plan: { x: number; y: number; w: number; h: number };
  kind: 'growing' | 'structure';
  microclimate: string;
  whyDifferent: string;
  orchids: string[];
  autumn: string;
  edithWatches: string;
  relatedProfiles: string[];
}

type MC = { id: string; name: string; summary: string; detail: string; orchids: string[] };
const mc = (id: string) => (microclimates as MC[]).find((m) => m.id === id);
const fromMc = (id: string) => ({ name: mc(id)?.name ?? id, microclimate: mc(id)?.summary ?? '', whyDifferent: mc(id)?.detail ?? '', orchids: mc(id)?.orchids ?? [] });

export const ZONES: GreenhouseZone[] = [
  {
    id: 'cool-west', kind: 'growing', plan: { x: 0, y: 4, w: 8, h: 8 }, ...fromMc('cool-west'),
    autumn: 'The first zone to feel the season turn as nights lengthen and cool.',
    edithWatches: 'Whether cool-cued plants are getting the autumn contrast they need — and that warm growers have not drifted in.',
    relatedProfiles: ['dendrobium-nobile'],
  },
  {
    id: 'wet-bench', kind: 'growing', plan: { x: 8, y: 0, w: 10, h: 6 }, ...fromMc('wet-bench'),
    autumn: 'Moisture stays consistent; this bench does not get a dry rest.',
    edithWatches: 'Fresh water, never stale; roots firm, not mushy.',
    relatedProfiles: ['phragmipedium'],
  },
  {
    id: 'dry-rest', kind: 'growing', plan: { x: 18, y: 0, w: 8, h: 6 }, ...fromMc('dry-rest'),
    autumn: 'Fills up as deciduous plants finish their growths and drop leaves.',
    edithWatches: 'That only plants actually entering rest are moved here — never a plant that is still in active growth.',
    relatedProfiles: ['catasetinae', 'lycaste'],
  },
  {
    id: 'ficus', kind: 'growing', plan: { x: 26, y: 0, w: 14, h: 6 }, ...fromMc('ficus'),
    autumn: 'Lower sun angle changes where the dappled shade falls.',
    edithWatches: 'Mounts drying between waterings and the moving air that keeps them healthy.',
    relatedProfiles: [],
  },
  {
    id: 'cattleya', kind: 'growing', plan: { x: 8, y: 10, w: 14, h: 6 }, ...fromMc('cattleya'),
    autumn: 'Sheaths and spikes develop; stability matters more than change.',
    edithWatches: 'Developing sheaths and spikes — and that nobody moves these plants.',
    relatedProfiles: ['laelia-anceps'],
  },
  {
    id: 'staging', kind: 'structure', plan: { x: 22, y: 10, w: 10, h: 6 },
    name: 'Transition / staging area', microclimate: 'Just inside the main door; conditions shift whenever the door opens.',
    whyDifferent: 'Plants coming in from outside, or going out, pause here so changes are gradual rather than sudden.',
    orchids: ['Plants in transit between zones'],
    autumn: 'Busy: outdoor plants come in as conditions dictate.',
    edithWatches: 'Pests hitching a ride indoors, and sudden changes in light.',
    relatedProfiles: ['cymbidium', 'sarcochilus'],
  },
  {
    id: 'warm-zone', kind: 'growing', plan: { x: 40, y: 4, w: 8, h: 8 }, ...fromMc('warm-zone'),
    autumn: 'Kept warm while the rest of the house cools.',
    edithWatches: 'That warm growers are never "rested" cold because a cool-growing cousin needs it.',
    relatedProfiles: ['dendrobium-phalaenanthe'],
  },
  {
    id: 'hanging', kind: 'growing', plan: { x: 14, y: 6, w: 16, h: 4 }, ...fromMc('hanging'),
    autumn: 'Baskets can swing in the draughts as vents are adjusted.',
    edithWatches: 'Spikes heading downward through the basket, unobstructed.',
    relatedProfiles: ['stanhopea'],
  },
  {
    id: 'outdoor-lath', kind: 'growing', plan: { x: 22, y: 18, w: 14, h: 6 }, ...fromMc('outdoor-lath'),
    autumn: 'Coastal nights provide seasonal cues; plants come in when conditions require.',
    edithWatches: 'Forecasts, wind and the first cold snaps.',
    relatedProfiles: ['cymbidium', 'laelia-anceps', 'sarcochilus'],
  },
];

/** Fixed architectural features (fictional placement, constant across all illustrations). */
export const FEATURES = [
  { id: 'entrance', label: 'Main entrance (south wall)', x: 27, y: 16 },
  { id: 'aisle', label: 'Central aisle', x: 24, y: 8 },
  { id: 'fan-west', label: 'Ventilation fan (west wall)', x: 0, y: 8 },
  { id: 'fan-ridge', label: 'Circulation fan (central ridge)', x: 24, y: 7 },
];

export const ORIENTATION_NOTES = [
  { side: 'North benches', note: 'Wet slippers, dry-rest shelf and the Ficus canopy with mounted plants.' },
  { side: 'South benches', note: 'The brightest side: Cattleya / Laelia bench and the staging area by the door.' },
  { side: 'West end (cooler air)', note: 'Lower 8 × 8 ft end room, first to cool, beside the ventilation fan.' },
  { side: 'East end (protected)', note: 'Lower 8 × 8 ft end room, the warm protected zone.' },
  { side: 'Outside', note: 'Lath-house transition beyond the south door.' },
];

/* ------------------------------------------------------------------
   ZONE GUIDE — the consistent "Walk the greenhouse" structure.
   These are QUALITATIVE, RELATIVE descriptions of a FICTIONAL building
   (e.g. "brightest bench in the house"). No measured temperature,
   humidity or light values are given, because none exist.
   Factual orchid-biology statements live in the Culture Library profiles,
   where each carries its own evidence indicator.
------------------------------------------------------------------- */
export interface ZoneGuide {
  short: string;
  light: string;
  temperature: string;
  moisture: string;
  airflow: string;
  seasonalRole: string;
  whyEdith: string;
}

export const ZONE_GUIDE: Record<string, ZoneGuide> = {
  'cool-west': {
    short: 'Cool West',
    light: 'Softer light in the lower west end room.',
    temperature: 'The first part of the house to cool in the evening; coolest at night.',
    moisture: 'Dries more slowly on foggy evenings, so watering is timed early in the day.',
    airflow: 'Beside the west ventilation fan — the strongest air exchange in the house.',
    seasonalRole: 'Supplies autumn cooling contrast without chilling the rest of the collection.',
    whyEdith: 'Plants that respond to cooler autumn nights get them here, and warm growers stay well away.',
  },
  'wet-bench': {
    short: 'Wet Slippers',
    light: 'Even, indirect light along the north benches.',
    temperature: 'Intermediate — neither the coolest nor the warmest position.',
    moisture: 'Kept consistently moist: shallow trays and moss beneath the bench.',
    airflow: 'Gentle but continuous, so moisture never becomes stagnant water.',
    seasonalRole: 'No dry rest — this bench is managed the same way through autumn.',
    whyEdith: 'Grouping moisture-loving plants lets one watering routine serve them without drowning their neighbours.',
  },
  'dry-rest': {
    short: 'Dry Rest',
    light: 'Moderate light on the north side.',
    temperature: 'Intermediate.',
    moisture: 'Deliberately dry once a plant has genuinely entered rest.',
    airflow: 'Good, steady movement.',
    seasonalRole: 'Fills up in autumn as deciduous plants finish growths and drop leaves.',
    whyEdith: 'Separating resting plants stops them being watered along with everything else.',
  },
  ficus: {
    short: 'Ficus / Mounts',
    light: 'Dappled, shifting shade beneath the Ficus canopy.',
    temperature: 'Buffered — the canopy softens the hottest and coolest hours.',
    moisture: 'Mounts dry quickly and are watered more often than potted plants.',
    airflow: 'Good horizontal movement beneath the branches.',
    seasonalRole: 'The lower autumn sun changes where the shade falls.',
    whyEdith: 'Mounted plants need fast drying and moving air; the canopy supplies shade that shade cloth cannot imitate.',
  },
  cattleya: {
    short: 'Bright Cattleya',
    light: 'The brightest bench, along the south glazing.',
    temperature: 'Warms and dries fastest during the day.',
    moisture: 'Allowed to dry between waterings.',
    airflow: 'Good; pots are spaced rather than crowded.',
    seasonalRole: 'Sheaths and spikes develop — stability matters more than change.',
    whyEdith: 'Plants that need high light to flower get the one place in a foggy coastal house that reliably supplies it.',
  },
  staging: {
    short: 'Staging',
    light: 'Changes whenever the door is opened.',
    temperature: 'Shifts with the outside air near the door.',
    moisture: 'Plants are checked individually here, not watered as a group.',
    airflow: 'Draughty when the door is open.',
    seasonalRole: 'Busy in autumn as outdoor plants come in.',
    whyEdith: 'A pause between outside and inside makes changes gradual and lets her check for hitch-hiking pests.',
  },
  'warm-zone': {
    short: 'Warm East',
    light: 'Moderate, protected light in the east end room.',
    temperature: 'The warmest, most stable position; kept warm while the rest of the house cools.',
    moisture: 'Even moisture; no enforced dry rest.',
    airflow: 'Moving air but protected from cold draughts.',
    seasonalRole: 'Holds warm growers steady through autumn.',
    whyEdith: 'Warm-growing plants are never "rested" cold just because a cool-growing cousin needs it.',
  },
  hanging: {
    short: 'Hanging Baskets',
    light: 'Higher up, brighter than the benches below.',
    temperature: 'Warmer air collects high in the tall central house.',
    moisture: 'Open baskets drain and dry quickly.',
    airflow: 'Exposed; baskets move with the vent air.',
    seasonalRole: 'Spikes heading downward need the space below kept clear.',
    whyEdith: 'Some inflorescences grow downward through the basket — hanging them high leaves room beneath.',
  },
  'outdoor-lath': {
    short: 'Lath House',
    light: 'Filtered through lath slats.',
    temperature: 'Follows the outdoor coastal nights.',
    moisture: 'Fog, dew and rain add to watering.',
    airflow: 'Open air.',
    seasonalRole: 'Coastal autumn nights act as a seasonal cue; plants come in when conditions require.',
    whyEdith: 'Plants that benefit from cool nights and outdoor light get them here, protected from extremes.',
  },
};

export const zoneShort = (id: string) => ZONE_GUIDE[id]?.short ?? ZONES.find((z) => z.id === id)?.name ?? id;
