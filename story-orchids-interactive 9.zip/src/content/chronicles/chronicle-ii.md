---
id: chronicle-ii
title: The Greenhouse That Forgot Autumn
subtitle: Chronicle II · in five chapters
number: II
accent: autumn
epigraph: "Autumn does not happen to the greenhouse. It happens differently to every plant in it."
epigraphSource: Edith Bramble
notice: Chronicle II is fiction. Hazel's magic is invented; the growing mistakes she makes are real. Every supporting character is fictional. Underlined orchid names open an optional Grower Card that closes back to exactly where you were reading.
---

## Chapter One — The Wrong Kind of Perfect

By the first week of September, Edith Bramble had been missing for eleven months.

Her greenhouse had never looked better.

That was the first sign something was terribly wrong.

::: image id="c2-perfect" layout="full" caption="Labels faced forward. No wandering roots crossed the aisle." :::

The benches were immaculate. Labels faced forward. No wandering roots crossed the aisle. The hanging baskets had been lowered to a tidy eye level, and the floor had been swept clean of bark, moss and old pseudobulb sheaths. The two ficus trees had been pruned until sunlight reached places that had spent years in shifting shade.

Edith's sister Rosalind stood at the door with Marian. "Hazel did all this. The gardener. I couldn't keep up with five hundred orchids. She said Edith had made everything unnecessarily complicated."

Marian looked down the central aisle. "Easier for whom?"

::: effect name="ernie" id="ernie-pot" :::

That was when she saw the [[phragmipedium|Phragmipedium]]. Its leaves had begun folding lengthwise. She lifted the pot. Far too light. Rosalind said it had been watered on Friday. It was Wednesday.

::: image id="c2-phrag-cata" layout="full" caption="Three feet apart: one far too light, one far too heavy." :::

Three feet away sat a [[catasetinae|Catasetum]] with a fat mature pseudobulb and yellowing leaves. Its pot was heavy, the medium wet. Hazel, Rosalind explained, had thought the yellow leaves meant it needed more water.

Marian touched a leaf. It came away in her hand.

Rosalind winced. "Is it dying?"

"No. It's getting ready to sleep."

::: image id="c2-karen-leaf" layout="wrap-right" caption="The yellow leaf was not a symptom." :::

Many Catasetums come from tropical American forests where the year divides into two unequal halves: months of reliable rain, then months when almost none falls. A plant there cannot keep soft, thin leaves through the dry season; they would cost more water than it could find. So it lives quickly. Through the wet months it builds a new growth as fast as it can and packs the season's profit into the swelling pseudobulb. When the growth is complete, the leaves yellow — the plant withdrawing what it can from them — and they fall cleanly at the joint. What remains is a green storage organ holding a summer's work, waiting for rain. The yellow leaf was not a symptom. It was the plant turning a page.

::: science id="catasetinae" label="Why does a Catasetum drop its leaves?" :::

The Phragmipedium told a different story. Many Phragmipediums grow where their roots rarely meet a true dry season — on seeping rock faces, wet slopes and the banks of mountain streams. They carry no pseudobulb to fall back on; their fan of leaves and fuzzy roots depend on a supply that simply keeps coming. When it stops, the leaves fold along their length. Not every species lives that wet. But this one had been given the Catasetum's winter in the middle of its own endless spring.

::: science id="phragmipedium" label="Why does this Phragmipedium need steady moisture?" :::

Walter arrived with coffee. Marian handed him the yellow leaf instead of taking a cup.

"One's too dry and one's too wet," he said, looking from pot to pot.

"Both watered by the same calendar."

Rosalind stared. "But they're both orchids."

Walter closed his eyes. Marian smiled. "That sentence may explain the entire greenhouse. The plants aren't being difficult. They're remembering different places."

::: effect name="leaf-senescence" :::

By noon other members of the Five Cities Orchid Society had arrived, and each found another contradiction. Silas held up two [[dendrobium-strategies|Dendrobiums]] Hazel had given the same bench, the same water and the same fertilizer. "Same genus," he said. "Different planets."

At the far bench Theo lifted a [[stanhopea|Stanhopea]] basket out of a decorative solid cachepot as though disarming something. "Hazel made the basket prettier," he said, "and the plant less able to flower."

A deciduous [[lycaste|Lycaste]] was being watered because its leaves were yellowing; an evergreen one had been left to dry because Hazel had decided "Lycastes rest in autumn." [[cymbidium|Cymbidiums]] and [[sarcochilus|Sarcochilus]] had been carried indoors as the nights cooled. Warm novelty Phalaenopsis shivered beside the cool west glass.

By late afternoon Marian had stopped looking for one disease. The problem was not neglect. The problem was uniformity.

"Edith didn't give every plant the same treatment," she said. "So why would they all be failing in the same way? Because someone else did."

That evening Rosalind found Hazel's final invoice. At the bottom, in elegant handwriting, were three words.

::: note title="Hazel's invoice" :::
SEASONAL INCONSISTENCIES CORRECTED.
:::

Hazel had not failed to understand Edith's greenhouse. She had understood exactly what made it work.

And removed it.

As the others gathered their coats, the west glass began to fog, though the evening was dry. Marian watched a clear line draw itself through the condensation, slowly, as if a fingertip were tracing it from the other side.

::: effect name="fog-help" id="c1-glass-night" :::

Then the fog closed over it, and the glass was only glass.

## Chapter Two — The Map of Many Climates

Saturday morning began with colored tags.

::: image id="c2-tags" layout="full" caption="Red, blue, yellow — and white, which was the hardest." :::

::: note title="The tags" :::
RED — MOVE.
BLUE — WATER DIFFERENTLY.
YELLOW — WATCH.
WHITE — LEAVE IT ALONE.
:::

Walter objected to white. "We drove here to do nothing?"

"Sometimes doing nothing is the treatment."

"I've been training for this my entire life."

Marian set one rule: nobody moved a plant until they could explain why.

Hazel's organization had erased much of Edith's system, but not all of it. Old hooks remained in the rafters where baskets had once hung high in the warm air. Pale mineral rings showed where wet pots had stood for years. Moss thickened beneath one bench and nowhere else. The western end cooled first in the evening; the fan had worn a clean arc in the dust. Old photographs showed baskets hanging beneath the ficus before it was pruned.

::: image id="c2-zone-map" layout="full" caption="Soon the map looked less like a floor plan than weather." :::

Imogen pinned photographs to a large drawing of the greenhouse. Silas traced airflow with a thread on a stick. Theo marked the mounted-plant zone under the ficus. Hollis knelt by the Phragmipedium bench and pressed the moss: "This bench was always wet. On purpose." Graham marked the bright Cattleya wall. Desmond marked the outdoor Cymbidium benches. Ansel stood in the lath house doorway, feeling the sea air, and marked where the Sarcochilus had hung.

"Edith wasn't managing one greenhouse," Marian said. "She was managing many little ones."

::: effect name="ernie" id="ernie-moss" :::

At the Lycaste bench Rosalind found two labels: *Lycaste aromatica*, and an evergreen hybrid with *L. skinneri* ancestry.

::: image id="c2-lycastes" layout="full" effect="turn-subtle" caption="Lycaste aromatica, yellowing toward rest — and an evergreen hybrid that is not." :::

"Before you read the label, read the plant," Marian said. "What do you see?"

"Leaves going bad." Then Rosalind looked longer. "No. The pseudobulb is plump. The leaves are yellowing evenly, all at once. There are little spines on the old bulbs. And that one is still green."

*Lycaste aromatica* belongs to a group of yellow-flowered Lycastes from seasonally dry forests of Mexico and Central America. Its broad, pleated leaves are built for one fast season; when the dry months come, the plant withdraws what it can from them and lets them go, and the sharp points on the old bulbs are what remain of the leaf bases. The evergreen hybrid carries the inheritance of *L. skinneri*, a plant of cooler, moister mountain forest, where keeping working leaves through the year makes sense. The same yellowing on the evergreen would have been a warning. On the deciduous one it was a calendar. Observe, identify, understand the plant's seasonal strategy — and only then respond.

::: science id="lycaste" label="Deciduous or evergreen? Read this Lycaste" :::

"The label tells you what it is," Marian said. "The plant tells you how it lives."

Across the aisle Silas set the two Dendrobiums side by side.

::: image id="c2-ed-dendrobiums" layout="full" caption="Same genus. Different planets." :::

Nobile-type [[dendrobium-strategies|Dendrobiums]] descend from plants of the Himalayan foothills and the mountains of northern Indochina, where the monsoon brings warm, soaking summers and then withdraws, leaving winters that are cool, bright and dry. Their jointed canes are storage organs, filled during the rains. When a cane finishes, it makes a final leaf at its tip and the plant's business changes: cooler nights, less water, less nitrogen, and buds begin to form along the canes. Push warmth and fertilizer into it through autumn and it often answers with baby plants instead of flowers.

The Phalaenanthe-type came from somewhere else entirely — the warm tropical lowlands of northeastern Australia and New Guinea, where winter never turns cold. Its canes keep their leaves for years. Chill it and dry it like its cousin, and it drops those leaves in distress.

::: science id="dendrobium-nobile" label="Same genus, different lives — explore" :::

Silas carried the nobile-type west, where the marine layer reached first, and the Phalaenanthe-type to the warm side beside the Phalaenopsis. "To understand how to grow an orchid," he said, "first ask where it came from."

Walter looked at Marian. "I am not going to say they're both Dendrobiums."

"Growth."

::: image id="c2-cymbidium" layout="wrap-left" caption="For these, cooling autumn nights are part of the message." :::

Outside, Desmond was staring at the [[cymbidium|Cymbidiums]] Hazel had brought in during August. "She thought the cold was dangerous," Rosalind said.

"For these, cooling autumn nights are part of the message." Desmond parted the leaves at the base of a mature growth. "See that? Possibly a spike. We watch before we declare victory."

That became Marian's favorite sentence of the day. The calendar told them what to watch for. The plant told them whether it was ready.

Hazel had not removed autumn. She had replaced many autumns with one.

## Chapter Three — Putting Autumn Back

Restoration began slowly. That was deliberate.

"We don't correct uniform care with uniform correction," Marian said.

::: image id="c2-lathhouse" layout="full" caption="Coastal nights could cool them naturally again." :::

The first Cymbidiums went back outside under the lath, where the coastal nights could cool them. The large-flowered Cymbidiums in Edith's collection descend mostly from mountain species of the Himalaya and southern China, plants that grow through warm, wet summers and feel the nights drop sharply as autumn arrives. In many standard types that seasonal fall in night temperature is associated with the start of flower spikes. A coastal lath house delivers it — cool marine-layer nights, bright days, moving air — in a way a uniformly warm greenhouse cannot. Frost is still an enemy, and not every Cymbidium wants the same chill.

::: science id="cymbidium" label="Why do cool nights matter to a Cymbidium?" :::

::: image id="gc-sarcochilus" layout="wrap-right" caption="Sarcochilus · botanical illustration" :::

Ansel hung the [[sarcochilus|Sarcochilus]] beside them and grinned: an Australian orchid next to plants whose ancestors grew in the Himalaya. Sarcochilus come from eastern Australia — some on rock faces in open forest, some on trees in cool, shaded rainforest gullies. They have no pseudobulbs; what they store is held in thick leaves and in roots that wander into the air. That makes them vulnerable to two opposite failures: drying out too long, and sitting cold and wet in still air. What they want is moderate temperature, regular moisture and constant air movement — and the Central Coast, with mild summers, cool nights and a steady sea breeze, overlaps those needs remarkably well. Geography did not decide who shared the lath house. The conditions did.

::: science id="sarcochilus" label="Why do an Australian and a Himalayan orchid share a bench?" :::

::: image id="c2-lance-phrags" layout="full" caption="Moist roots still need oxygen." :::

Hollis took the [[phragmipedium|Phragmipediums]]. He lifted one pot, then another. "This one needs water now." He watered it thoroughly, then turned to Walter. "Don't turn this into a slogan that all Phrags want to sit in stagnant water. Moist roots still need oxygen. The point is that this plant doesn't want the Catasetum's dry winter."

::: effect name="root-tip" :::

At the Cattleya bench Graham stopped everyone. A mature pseudobulb carried a developing sheath. "No moving this one. No repotting, no dramatic change, no bumping it around because we're enthusiastic. Not every autumn job is something we do to a plant. Sometimes the job is stability."

Walter raised a white tag. Graham took it and wrote underneath:

::: note title="The white tag" :::
BUT PAY ATTENTION.
:::

::: image id="c2-stanhopea" layout="wrap-left" effect="stanhopea" caption="Container shape is culture too." :::

Theo rehung the [[stanhopea|Stanhopea]] basket so nothing blocked its bottom. A Stanhopea's flower spike does something most orchid spikes never do: it grows down. In the wet forests of Mexico and Central and South America these plants sit in tangled root masses on branches, and their inflorescences push downward through roots and debris to hang in open air beneath the plant, where their heavy fragrance reaches the bees that pollinate them. The whole architecture assumes nothing solid underneath. In a closed pot the spike simply meets a wall. A perfectly healthy plant can still never flower.

::: science id="stanhopea" label="Why does a Stanhopea need an open basket?" :::

"Container shape is culture too," Theo said. Rosalind had thought orchid culture meant water, light and fertilizer. By midafternoon she understood it also meant airflow, drainage, root exposure, temperature, timing, mounting, basket design — and sometimes not interfering.

Then Ansel found the [[laelia-anceps|*Laelia anceps*]], moved indoors with the plants Hazel considered vulnerable to autumn. Graham joined him. From the top of the mature pseudobulb rose a long green structure.

::: image id="c2-laelia-spike" layout="wrap-right" caption="Laelia anceps · the spike, early October." :::

"Root?" Walter asked. "New growth?"

Graham smiled. "Spike."

*Laelia anceps* grows on trees in the oak and pine-oak forests of the Mexican mountains, in bright, airy positions where summer rains are followed by a long dry winter and cool nights. Through the wet months the plant builds a compact, four-angled pseudobulb. As the season turns, a spike rises from the top of that finished bulb and keeps lengthening for weeks. Nothing about it is sudden. The spike is a record of work already done. When and how it opens varies from clone to clone and garden to garden.

::: science id="laelia-anceps" label="How does Laelia anceps keep time?" :::

"That goes back outside," Graham said, "and then nobody moves it while it's spiking."

::: effect name="laelia-clock" stage="1" :::

The *Laelia* became their clock. The greenhouse changed around it.

::: image id="c2-dry-shelf" layout="full" caption="The dry-rest shelf became drier." :::

The dry-rest shelf became drier. The Phragmipedium bench stayed moist. Warm growers stayed warm; cooler groups felt the coastal nights. [[fertilizer|Fertilizer]] continued for plants still actively growing and was reduced or stopped where genuine seasonal rest demanded it. Feeding followed active growth and the condition of each plant — not the date printed on a calendar.

::: effect name="laelia-clock" stage="2" :::

By early October the greenhouse looked less organized than it had under Hazel. Baskets hung at different heights. One shelf was deliberately dry while another was watered often. Temporary shade cloth stood in for the ficus canopy Hazel had cut away. The greenhouse was imperfect again. And healthier.

::: effect name="ernie" id="ernie-can" :::

Then Imogen found the business card.

::: note title="A business card" :::
HAZEL NIGHTSHADE
GARDEN RESTORATION & PRESERVATION
—
NOTHING PROPERLY PRESERVED SHOULD EVER BE ALLOWED TO DIE BACK.
:::

Marian read it twice. Dormancy looked like death to Hazel. Leaf fall looked like failure. Cool nights were threats, dry rest was neglect, and change itself was the enemy.

"She thinks anything that stops growing is dying," Marian said.

Outside, the *Laelia* spike moved in the evening air. "Autumn isn't killing this greenhouse," she said. "It's telling it what comes next."

## Chapter Four — Hazel's Perfect Greenhouse

Hazel returned on October twenty-fourth.

Rosalind saw her first, standing outside the south wall at dusk in gardening gloves and the same dark olive overshirt she had worn all summer. No pointed hat. No broom. She looked like a gardener. That made Walter more nervous.

::: image id="c2-hazel-glass" layout="full" effect="breakout" caption="She looked like a gardener." :::

Marian stepped outside. Hazel looked past her through the glass. "You've made a mess."

"We're working on it."

"You had order."

"We had symptoms."

"I kept them growing."

"No. You kept them from changing."

Hazel pointed at the dry-rest shelf. "Those plants are leafless. You stopped feeding them. You're withholding water."

"Because their growth cycle changed."

Hazel's eyes moved to the Phragmipedium bench. "Yet those are wet. Inconsistent."

"Correct."

She turned to the cool west end, where the nobile Dendrobiums stood in the marine air, and then to the warm side. "You chill some and coddle others. You let leaves die. You call this care?"

"We call it paying attention."

The door opened behind Marian. Silas, Graham, Hollis, Theo, Desmond, Ansel, Imogen and Walter had gathered inside.

"Committees do not improve nature," Hazel said.

Walter whispered, "She has clearly attended board meetings."

A gust pushed fog across the yard. Hazel placed one gloved hand against the glass. The fans inside slowed — not stopped, slowed — and condensation began to spread across the panes.

::: image id="c2-fallen-leaf" layout="wrap-right" caption="The leaf landed. Nothing terrible happened." :::

The growers answered first as growers. Silas went to the fan controls; Imogen checked the power. Doors opened where the night allowed. Plants that had been watered were given air. No one sprayed anything mysterious. They managed the greenhouse — and that seemed to irritate Hazel more than fear would have.

::: effect name="laelia-clock" stage="3" :::

Then she saw the *Laelia anceps*. The spike had lengthened; buds were defining themselves near its tip.

"That should have stopped," she said. "I corrected the cold."

"You interrupted the season."

Marian understood. Hazel's hold was strongest where the greenhouse had been made uniform. Every restored difference weakened it: the cool zone, the warm zone, the wet bench, the dry shelf, the plants outside, the baskets hung high. Not magic symbols. Biology.

Hazel pressed both hands against the glass.

::: effect name="falling-leaf" :::

Inside, one yellow [[catasetinae|Catasetum]] leaf detached and drifted to the floor.

Walter whispered, "Should we pick that up?"

"No."

The leaf landed. Nothing terrible happened. The plant remained alive, and stored inside its pseudobulb was the summer it had just completed.

"You'll lose them," Hazel said.

"Some, eventually," Marian said. "A living collection changes. Plants grow, rest, flower, fail, recover, age. We learn and we adapt. Preservation isn't the same thing as refusing change."

The fog thickened around Hazel until she was only a darker place in it. Her voice stayed behind. "Then let us see what your autumn gives you."

When the fog cleared, she was gone.

"Was that a threat?" Walter asked.

"Probably."

"Good. I was worried October was becoming relaxing."

Marian looked at the *Laelia* buds. Halloween was one week away.

## Chapter Five — The Greenhouse Remembers

On Halloween afternoon, nobody mentioned Edith. Almost a year had passed since the black rot, the grimoire and her disappearance, and hope had become something they handled carefully.

Instead they prepared the greenhouse — not for a séance, but for visitors. If Hazel believed autumn meant decline, the Five Cities Orchid Society would answer with an open greenhouse.

::: image id="c2-halloween" layout="full" caption="The greenhouse no longer looked perfect. It looked alive." :::

On the wet bench, Phragmipedium roots stayed moist and active. On the dry shelf, Catasetinae rested on bare pseudobulbs. Nobile-type Dendrobiums stood where cool nights could reach them; the warm-growing kind stayed protected. Cymbidiums stayed outdoors under the lath, and the Sarcochilus hung in the moving sea air. Stanhopea baskets swung with their bottoms open. Evergreen Lycastes kept their leaves while their deciduous cousins let theirs go.

::: effect name="laelia-clock" stage="4" :::

Near sunset Imogen called everyone outside. The [[laelia-anceps|*Laelia anceps*]] had opened — not every bud, but two flowers, magenta-lavender against the gray coastal evening, carried high on the long arching spike.

::: image id="c2-laelia-bloom" layout="full" effect="turn" caption="This plant's timing — not a universal date." :::

Walter stared. "That's it? I was expecting thunder."

"It's an orchid," Graham said.

"Given our history, that's not reassuring."

The flower was not a miracle, Marian said. That was why it mattered. This plant had received enough summer growth, enough light and its seasonal transition, and it had followed its own biology. Another clone, in another garden, might have opened in November. It did not prove magic had been defeated. It proved the greenhouse was keeping time again.

::: effect name="hazel-fog" :::

Then the fog came, faster than it should have. Visitors stopped talking. The society's charm from last Halloween hung above the door. Hazel appeared beyond the glass and looked at the greenhouse: wet, dry, warm, cool, growing, resting, green, leafless. Nothing matched.

She raised her hand. The lights flickered. Condensation raced across one pane. Walter whispered, "Here we go."

But instead of blackening, the glass cleared.

A figure stood on the other side of the door. Small. Disheveled. One shoe missing.

::: image id="c2-edith-returns" layout="full" caption="“Oh, for heaven's sake.”" :::

Edith Bramble looked through the glass at the crowd, then at the orchids, then at Hazel.

"Oh, for heaven's sake," she said.

Rosalind made a sound somewhere between a laugh and a sob. Marian opened the door, and Edith stepped inside.

"You chose decay," Hazel said.

Edith looked genuinely offended. "I chose seasons."

"You let things die."

"I let leaves fall."

"You let growth stop."

"I let plants rest. And then they begin again. Not all at once, and not all alike."

"You let the greenhouse become disorder."

Edith looked around at a wet Phrag, a dry Catasetum, a warm Dendrobium at one end and a cool one at the other, and a Stanhopea hanging inconveniently in the aisle. She smiled. "Yes."

Hazel's outline began thinning into fog. Edith pointed at the *Laelia*. "That flower isn't here because we defeated autumn. It's here because autumn arrived."

Hazel vanished. No explosion, no scream. The fog simply folded around the place where she had stood.

Then Edith looked at the ficus. Her expression changed. "Who pruned my trees?"

Walter pointed toward the fog. "Hazel."

Edith studied the damage for a long moment. "Coward."

::: image id="c2-tart" layout="full" caption="Coffee crowded onto the potting bench." :::

Later, with coffee crowded onto the potting bench and apple-blackberry tart disappearing faster than anyone admitted, Marian found Edith walking the benches slowly, touching a label here, lifting a pot there. "How did you keep all of this straight?"

"I didn't keep it straight. I kept looking." Edith set the pot down. "First you ask what the orchid is. Then what kind, within that group. Then where its ancestors came from. Then what season it's in — what stage of growth. And then you look at the actual plant."

"That's it?"

"No." Edith took Marian's coffee. "Tomorrow you look again."

Outside, Halloween fog pressed against the glass. Inside, five hundred orchids continued doing different things.

Exactly as they should.

::: effect name="ernie-leap" :::

::: closing :::
Watch the plant before the calendar.
:::
