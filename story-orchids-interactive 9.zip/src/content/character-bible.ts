/**
 * CHARACTER + WORLD BIBLE — The Edith Bramble Chronicles.
 * Every illustration prompt for the Chronicles must start from these
 * descriptions so characters and the greenhouse stay continuous from scene
 * to scene. Editors: when an image is regenerated, paste STYLE + the
 * character line(s) + GREENHOUSE into the prompt verbatim.
 */

export const STYLE =
  'Painterly botanical-gothic storybook illustration, gouache and oil texture, muted greens, umbers and slate-blue fog, warm lamplight, botanically accurate orchids, cinematic composition, no text.';

export const GREENHOUSE =
  "Edith's greenhouse: an old white-painted wooden Victorian glasshouse on the Pismo Beach bluffs; scarred redwood benches, brick floor, slat baskets hanging from the rafters with silvery aerial roots, two ficus trees at the north end, a lath house outside the west door, coastal fog on the glass.";

export interface CharacterLook {
  id: string;
  name: string;
  role: string;
  look: string;
}

/* Supporting Society characters are story characters, not portraits of real
   people. Keep their descriptions to costume/props needed for scene
   continuity — no ages, no invented personal details — and prefer showing
   hands, backs, objects and plants over faces. */
export const CHARACTER_LOOKS: CharacterLook[] = [
  { id: 'edith', name: 'Edith Bramble', role: 'Experienced grower; dry wit; observant, not omniscient.', look: 'petite elderly woman, silver-gray hair in a loose bun with escaping wisps, round wire-rimmed glasses, moss-green cardigan over a cream blouse, long canvas apron, brown lace-up shoes' },
  { id: 'hazel', name: 'Hazel Nightshade', role: 'Intelligent antagonist who equates permanence with perfection.', look: 'tall, gaunt woman, long straight black hair streaked with gray, pale angular face, dark olive overshirt, long charcoal coat, gardening gloves; never a pointed hat' },
  { id: 'marian', name: 'Marian', role: 'Diagnostic, evidence-first thinker. Fictional.', look: 'woman with a short auburn bob, reading glasses on a beaded cord, navy quilted vest over a denim shirt' },
  { id: 'walter', name: 'Walter', role: 'Experienced, practical, funny — never incompetent. Fictional.', look: 'tall man, flat tweed cap, brown waxed jacket, usually carrying coffee' },
  { id: 'rosalind', name: 'Rosalind', role: "Edith's intelligent non-specialist sister. Fictional.", look: 'woman in a lavender cardigan and silk scarf' },
  { id: 'silas', name: 'Silas', role: 'Dendrobiums and greenhouse systems. Fictional.', look: 'man in a plaid flannel shirt; prefer showing his hands holding two Dendrobiums or a thread on a stick' },
  { id: 'theo', name: 'Theo', role: 'Mounted orchids and Stanhopea baskets. Fictional.', look: 'man in a green fleece; prefer showing hands lifting a Stanhopea basket' },
  { id: 'hollis', name: 'Hollis', role: 'Phragmipediums. Fictional.', look: 'man in a canvas hat; prefer showing hands pressing moss on the slipper bench' },
  { id: 'graham', name: 'Graham', role: 'Cattleya alliance. Fictional.', look: 'man in a rolled-sleeve shirt; prefer showing the Cattleya sheath or Laelia spike' },
  { id: 'desmond', name: 'Desmond', role: 'Cymbidiums. Fictional.', look: 'man in a knitted sweater; prefer showing hands parting Cymbidium leaves' },
  { id: 'ansel', name: 'Ansel', role: 'Sarcochilus; coastal growing. Fictional.', look: 'man in a windbreaker, seen from behind in the lath house doorway' },
  { id: 'imogen', name: 'Imogen', role: 'Documentation and mapping. Fictional.', look: 'woman in a rust-colored jacket; prefer showing the pinned photographs and camera' },
  { id: 'ernie', name: 'Ernie', role: "Unexplained greenhouse frog; recurring easter egg.", look: 'a single tiny Pacific tree frog (Pseudacris regilla), moss-green with a dark eye stripe, realistic anatomy, never cartoon' },
];

export const characterLook = (id: string) => CHARACTER_LOOKS.find((c) => c.id === id);

/** Build a continuity-safe prompt for a new illustration. */
export function scenePrompt(action: string, characterIds: string[] = []): string {
  const people = characterIds
    .map((id) => characterLook(id))
    .filter(Boolean)
    .map((c) => `${c!.name.toUpperCase()}: ${c!.look}`)
    .join('. ');
  return [STYLE, GREENHOUSE, people, action].filter(Boolean).join(' ');
}
