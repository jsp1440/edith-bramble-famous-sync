import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  PREFS_EVENT,
  TEXT_SIZES,
  applyPrefs,
  isMotionReduced,
  loadPrefs,
  updatePrefs,
  type ReadingPrefs,
  type TextSize,
} from '@/lib/reading-prefs';

interface ReadingApi {
  prefs: ReadingPrefs;
  set: (patch: Partial<ReadingPrefs>) => void;
  smaller: () => void;
  larger: () => void;
  resetSize: () => void;
  reducedMotion: boolean;
}

const Ctx = createContext<ReadingApi | null>(null);

const order: TextSize[] = TEXT_SIZES.map((s) => s.id);

export const ReadingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [prefs, setPrefs] = useState<ReadingPrefs>(() => loadPrefs());

  useEffect(() => {
    applyPrefs(prefs);
    const onChange = (e: Event) => setPrefs((e as CustomEvent<ReadingPrefs>).detail);
    window.addEventListener(PREFS_EVENT, onChange);
    // Follow the operating system when motion is left on "automatic".
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onMq = () => applyPrefs(loadPrefs());
    mq.addEventListener?.('change', onMq);
    return () => {
      window.removeEventListener(PREFS_EVENT, onChange);
      mq.removeEventListener?.('change', onMq);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const set = useCallback((patch: Partial<ReadingPrefs>) => {
    setPrefs(updatePrefs(patch));
  }, []);

  const step = (d: number) => {
    const i = order.indexOf(loadPrefs().size);
    set({ size: order[Math.max(0, Math.min(order.length - 1, i + d))] });
  };

  return (
    <Ctx.Provider
      value={{
        prefs,
        set,
        smaller: () => step(-1),
        larger: () => step(1),
        resetSize: () => set({ size: 'standard' }),
        reducedMotion: isMotionReduced(prefs),
      }}
    >
      {children}
    </Ctx.Provider>
  );
};

export function useReading(): ReadingApi {
  const v = useContext(Ctx);
  if (v) return v;
  const prefs = loadPrefs();
  return {
    prefs,
    set: (p) => updatePrefs(p),
    smaller: () => undefined,
    larger: () => undefined,
    resetSize: () => updatePrefs({ size: 'standard' }),
    reducedMotion: isMotionReduced(prefs),
  };
}
