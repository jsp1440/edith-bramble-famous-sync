import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

export interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  role: 'member' | 'editor' | 'admin';
}

interface AuthState {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isEditor: boolean;
  authOpen: boolean;
  openAuth: () => void;
  closeAuth: () => void;
  signIn: (email: string, password: string) => Promise<{ error?: string }>;
  signUp: (
    email: string,
    password: string,
    displayName: string,
    asEditor: boolean,
  ) => Promise<{ error?: string; message?: string }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  setRole: (role: Profile['role']) => Promise<{ error?: string }>;
}

const AuthContext = createContext<AuthState>({} as AuthState);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [authOpen, setAuthOpen] = useState(false);

  const loadProfile = useCallback(async (userId: string, email: string, displayName?: string) => {
    const { data } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
    if (data) {
      setProfile(data as Profile);
      return;
    }
    // Fallback if the auth trigger has not yet provisioned the row.
    const { data: created } = await supabase
      .from('profiles')
      .insert({ id: userId, email, display_name: displayName || email.split('@')[0], role: 'member' })
      .select()
      .maybeSingle();
    setProfile((created as Profile) || null);
  }, []);

  useEffect(() => {
    let active = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session ?? null);
      if (data.session?.user) {
        loadProfile(data.session.user.id, data.session.user.email || '').finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (nextSession?.user) {
        loadProfile(nextSession.user.id, nextSession.user.email || '');
      } else {
        setProfile(null);
      }
    });

    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return error ? { error: error.message } : {};
  }, []);

  const signUp = useCallback(
    // `_asEditor` is ignored on purpose: every public signup is a member.
    // Editor/admin roles are granted only by an administrator through the
    // server-side `set_user_role` function (see supabase/migrations).
    async (email: string, password: string, displayName: string, _asEditor?: boolean) => {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { display_name: displayName } },
      });
      if (error) return { error: error.message };
      if (data.user && !data.session) {
        return { message: 'Check your inbox to confirm the address, then sign in.' };
      }
      return {};
    },
    [],
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (session?.user) await loadProfile(session.user.id, session.user.email || '');
  }, [session, loadProfile]);

  /** Admin-only. The database rejects this for anyone who is not an admin. */
  const setRole = useCallback(
    async (role: Profile['role'], targetUserId?: string) => {
      if (!session?.user) return { error: 'Not signed in.' };
      const { error } = await supabase.rpc('set_user_role', { target: targetUserId ?? session.user.id, new_role: role });
      if (error) return { error: error.message };
      await refreshProfile();
      return {};
    },
    [session, refreshProfile],
  );

  const value = useMemo<AuthState>(
    () => ({
      user: session?.user ?? null,
      session,
      profile,
      loading,
      isEditor: profile?.role === 'editor' || profile?.role === 'admin',
      authOpen,
      openAuth: () => setAuthOpen(true),
      closeAuth: () => setAuthOpen(false),
      signIn,
      signUp,
      signOut,
      refreshProfile,
      setRole,
    }),
    [session, profile, loading, authOpen, signIn, signUp, signOut, refreshProfile, setRole],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
