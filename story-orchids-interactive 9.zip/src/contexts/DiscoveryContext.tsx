import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

interface DiscoveryState {
  discovered: string[];
  discover: (id: string) => void;
  isDiscovered: (id: string) => boolean;
  reset: () => void;
}

const STORAGE_KEY = 'ebc:discovered';

const DiscoveryContext = createContext<DiscoveryState>({
  discovered: [],
  discover: () => undefined,
  isDiscovered: () => false,
  reset: () => undefined,
});

export const DiscoveryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [discovered, setDiscovered] = useState<string[]>(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(discovered));
    } catch {
      /* storage unavailable — discoveries simply do not persist */
    }
  }, [discovered]);

  const discover = useCallback((id: string) => {
    setDiscovered((prev) => (prev.includes(id) ? prev : [...prev, id]));
  }, []);

  const isDiscovered = useCallback((id: string) => discovered.includes(id), [discovered]);

  const reset = useCallback(() => setDiscovered([]), []);

  const value = useMemo(
    () => ({ discovered, discover, isDiscovered, reset }),
    [discovered, discover, isDiscovered, reset],
  );

  return <DiscoveryContext.Provider value={value}>{children}</DiscoveryContext.Provider>;
};

export const useDiscovery = () => useContext(DiscoveryContext);
