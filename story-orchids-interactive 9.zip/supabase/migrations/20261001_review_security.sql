-- Edith Bramble Chronicles — community review + role security (mirrors live schema, 2026-10-01)
-- NOTE: on this host the API connects as the table OWNER role, so every table
-- uses FORCE ROW LEVEL SECURITY and policies are written TO public with JWT-claim checks.

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY,
  email text NOT NULL,
  display_name text,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('member','editor','admin')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS claim_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  contributor_id text NOT NULL,
  taxon_key bigint,
  taxon_name text NOT NULL,
  claim_id text NOT NULL,
  claim_text text NOT NULL,
  claim_source text,
  evidence_class text,
  choice text NOT NULL CHECK (choice IN ('agree','qualify','disagree','unsure')),
  reasoning text,
  confidence text CHECK (confidence IN ('low','medium','high')),
  experience_level text CHECK (experience_level IN ('beginner','hobbyist','experienced','professional')),
  review_state text NOT NULL DEFAULT 'submitted' CHECK (review_state IN ('submitted','moderated','flagged')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS claim_review_counts (
  claim_id text NOT NULL, choice text NOT NULL, n integer NOT NULL DEFAULT 0,
  PRIMARY KEY (claim_id, choice)
);
-- evidence_submissions: see live schema (unchanged columns); RLS below.

CREATE OR REPLACE FUNCTION is_admin() RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER AS $$
  SELECT EXISTS (SELECT 1 FROM profiles WHERE id = NULLIF(current_setting('request.jwt.claim.sub', true), '')::uuid AND role = 'admin');
$$;
-- is_editor() pre-exists: true when the caller's own profile role is editor or admin.

CREATE OR REPLACE FUNCTION profiles_role_guard() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  jwt_role text := NULLIF(current_setting('request.jwt.claim.role', true), '');
  privileged boolean := (jwt_role IS NULL OR jwt_role = 'service_role');
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NOT privileged AND NOT is_admin() THEN NEW.role := 'member'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.role IS DISTINCT FROM OLD.role AND NOT privileged AND NOT is_admin() THEN
    RAISE EXCEPTION 'Only an administrator can change roles' USING ERRCODE = '42501';
  END IF;
  IF NEW.id IS DISTINCT FROM OLD.id AND NOT privileged THEN
    RAISE EXCEPTION 'Profile id is immutable' USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER profiles_role_guard_trg BEFORE INSERT OR UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION profiles_role_guard();

CREATE OR REPLACE FUNCTION set_user_role(target uuid, new_role text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF NOT is_admin() THEN RAISE EXCEPTION 'Only an administrator can change roles' USING ERRCODE = '42501'; END IF;
  IF new_role NOT IN ('member','editor','admin') THEN RAISE EXCEPTION 'Invalid role'; END IF;
  UPDATE profiles SET role = new_role, updated_at = now() WHERE id = target;
END; $$;

CREATE OR REPLACE FUNCTION claim_review_count_trg() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO claim_review_counts (claim_id, choice, n) VALUES (NEW.claim_id, NEW.choice, 1)
  ON CONFLICT (claim_id, choice) DO UPDATE SET n = claim_review_counts.n + 1;
  RETURN NEW;
END; $$;
CREATE TRIGGER claim_review_count_after_insert AFTER INSERT ON claim_reviews FOR EACH ROW EXECUTE FUNCTION claim_review_count_trg();

CREATE OR REPLACE VIEW claim_review_tallies AS SELECT claim_id, choice, n FROM claim_review_counts;

-- Submission RPCs insert without RETURNING, so private rows are never readable by submitters.
-- (submit_claim_review and submit_evidence: see live definitions; signed-in reviewers are
--  always recorded under auth.uid(), never a client-supplied id.)

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;            ALTER TABLE profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE claim_reviews ENABLE ROW LEVEL SECURITY;       ALTER TABLE claim_reviews FORCE ROW LEVEL SECURITY;
ALTER TABLE claim_review_counts ENABLE ROW LEVEL SECURITY; ALTER TABLE claim_review_counts FORCE ROW LEVEL SECURITY;
ALTER TABLE evidence_submissions ENABLE ROW LEVEL SECURITY; ALTER TABLE evidence_submissions FORCE ROW LEVEL SECURITY;

CREATE POLICY "Profiles insertable by owner" ON profiles FOR INSERT TO public WITH CHECK (auth.uid() IS NOT NULL AND id = auth.uid() AND role = 'member');
CREATE POLICY "Profiles provisioned server-side" ON profiles FOR INSERT TO public WITH CHECK (NULLIF(current_setting('request.jwt.claim.role', true), '') IS NULL OR current_setting('request.jwt.claim.role', true) = 'service_role');
CREATE POLICY "Profiles readable by owner" ON profiles FOR SELECT TO public USING (auth.uid() IS NOT NULL AND id = auth.uid());
CREATE POLICY "Profiles updatable by owner" ON profiles FOR UPDATE TO public USING (auth.uid() IS NOT NULL AND id = auth.uid()) WITH CHECK (auth.uid() IS NOT NULL AND id = auth.uid());

CREATE POLICY "Anyone can submit a claim review" ON claim_reviews FOR INSERT TO public
  WITH CHECK (review_state = 'submitted' AND char_length(claim_text) < 2000 AND (reasoning IS NULL OR char_length(reasoning) < 4000)
    AND (auth.uid() IS NULL OR contributor_id = auth.uid()::text));
CREATE POLICY "Editors read claim reviews" ON claim_reviews FOR SELECT TO public USING (is_editor());
CREATE POLICY "Editors moderate claim reviews" ON claim_reviews FOR UPDATE TO public USING (is_editor()) WITH CHECK (is_editor());

CREATE POLICY "Public reads review counts" ON claim_review_counts FOR SELECT TO public USING (true);
CREATE POLICY "Counts written only by trigger" ON claim_review_counts FOR ALL TO public USING (pg_trigger_depth() > 0) WITH CHECK (pg_trigger_depth() > 0);

CREATE POLICY "Anyone can submit evidence for review" ON evidence_submissions FOR INSERT TO public WITH CHECK (status = 'pending' AND moderator_note IS NULL AND reviewed_at IS NULL);
CREATE POLICY "Editors read queue" ON evidence_submissions FOR SELECT TO public USING (is_editor());
CREATE POLICY "Editors moderate queue" ON evidence_submissions FOR UPDATE TO public USING (is_editor()) WITH CHECK (is_editor());

-- To promote the first administrator (owner action, run in the database console):
--   UPDATE profiles SET role = 'admin' WHERE email = '<owner email>';
