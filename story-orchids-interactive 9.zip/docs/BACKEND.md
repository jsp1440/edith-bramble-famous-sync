# Edith Bramble Chronicles — backend reference

## One data path
```
Edith frontend ─► src/lib/oc-direct.ts (read-only OC client)
                    ├─ direct browser fetch  (only if the OC service allows this origin via CORS)
                    └─ orchid-explorer action "oc-get" (read-only, path-allowlisted relay)
                         ─► OC Public API  /api/species/search · /images/genus/{genus}
                         ─► OC Calyx       /api/platform/federation/resolve-species
                                           /api/platform/species/{taxon_id}/dossier
               ─► orchid-explorer (genus-species paging, GBIF fallback media/occurrences/literature)
```
CORS status (probed 2026-10-01): both OC services return `Access-Control-Allow-Origin`
only for `https://orchidcontinuum.org`. Browser calls from any other origin are blocked,
recorded in `ocDiagnostics.errors` (kind `cors`), and routed through the relay. Adding the
Edith site origin to the OC CORS allowlist enables the direct path with no code change.

### Media resolver order (exact taxon only, never a substitute species)
1. Orchid Continuum exact-taxon living photo (genus media library + Calyx `living_media`)
2. Existing exact-taxon living photo (orchid-explorer: OC search image, then GBIF)
3. Orchid Continuum exact-taxon herbarium/specimen image
4. Existing exact-taxon specimen image (GBIF)
5. "No image available" — only after the OC query has settled

### OC media integrity screen (src/lib/oc-direct.ts `screen()`)
Rejected before display: images attached to more than one taxon in the same genus payload,
orchidspecies.com culture icons (temphot/partialsun/scent…), PDFs/non-image files,
placeholders, file names naming another species/genus, explicit "all rights reserved"/copyright
licences, non-species rows, insecure http URLs (except hosts known to serve https).
Calyx dossiers are accepted only when their accepted name equals the requested name.
## Edge functions
| Name | Purpose | Source |
|---|---|---|
| `orchid-explorer` | GBIF paging/fallback resolver + read-only OC relay (actions: `profile`, `genus-species`, `media`, `dossier`, `oc-dossier`, `oc-get`, `coverage`) | deployed; source of record in Famous function store — export with `get_function_body` |
| `oc-probe` | diagnostic reachability + CORS check for OC services | deployed |
| `eb-permission-test` | release test of role elevation + review RLS using only the public anon key | deployed |
| `basemap-static`, `c1-edit-plate` | earlier map / artwork helpers | deployed |

## Environment variables
| Variable | Where | Required | Default |
|---|---|---|---|
| `VITE_ORCHID_CONTINUUM_API_BASE_URL` (or `VITE_OC_API_BASE_URL`) | browser build (public URL, not a secret) | no | `https://orchid-continuum-public-api.onrender.com` |
| `VITE_CALYX_API_URL` | browser build (public URL, not a secret) | no | `https://orchid-calyx-backend.onrender.com` |
| `OC_PUBLIC_API_BASE` | orchid-explorer (relay target — keep equal to the VITE value) | no | `https://orchid-continuum-public-api.onrender.com` |
| `OC_CALYX_API_BASE` | orchid-explorer (relay target — keep equal to the VITE value) | no | `https://orchid-calyx-backend.onrender.com` |
| `GATEWAY_API_KEY` | AI / maps gateway functions | yes for those functions | — |

The browser bundle contains only the public **anon** key (`src/lib/supabase.ts`). No service-role key,
OC credential or provider key is in client code.

## Roles
* Every signup is `member` (enforced by trigger `profiles_role_guard`; client metadata is ignored).
* Only an `admin` can change roles, through RPC `set_user_role(target, new_role)`.
* First admin: owner runs `UPDATE profiles SET role='admin' WHERE email='…'` in the database console.

## Release tests
* `invoke eb-permission-test` — expect every line `PASS`.
* `invoke orchid-explorer {"action":"coverage","genus":"Dracula","offset":0,"limit":18}` — media coverage sample.
